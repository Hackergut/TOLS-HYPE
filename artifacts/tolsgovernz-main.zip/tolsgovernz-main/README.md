# TOLS Governance — Casino Control Tower

The operator console for the TOLS Casino platform. It is a **separate
deployment** from the player-facing casino (`tols-casino-next`) and connects to
it **only** through a signed API bridge (RS256 JWT for reads/approvals, HMAC
for Casino → Governance events) — no shared database, no shared session.

## Sections

| Section | Purpose |
| --- | --- |
| **Overview** | Cross-platform summary: KPI strip + one card per section, click to jump |
| Dashboard | Platform KPIs, revenue, jackpot, alerts |
| Financial | Escrow, waterfall protocol, internal ledger, variance alerts |
| Live Map | Real Leaflet map (CARTO tiles) plotting sessions/nodes/events at real lat/lng |
| Live Players | Active sessions, engagement, device/browser |
| Players | Player intelligence (profiles, risk, RTP, sessions) |
| Segments / Promotions / Affiliates | Marketing & CRM |
| Wallets / Payments / Blockchain | Money movement & on-chain views |
| **RTP & Game Controls** | House edge, RTP monitor and outcome rules |
| Vendors / ML Pipeline / AI Tutor / Notifications | Game ops |
| **KYC / Verification** | Identity verification queue |
| **Responsible Gaming** | Self-exclusion, deposit/wager/loss/session limits |
| **Risk & Fraud** | AML flags and suspicious-activity review |
| Legal / Auth / API Hub | Compliance & system |
| **Casino Link** | The bridge: withdrawals approve/reject, deposits, treasury, HMAC-signed events |
| **Marketing CMS** | Promotions + game content published to the casino lobby |

## Security

- **Whole-app operator gate** — the entire console is behind a signed
  httpOnly-cookie session (`/api/gov/auth`). The browser never holds a secret.
- **Machine-to-machine bridge** — RS256 JWTs (`src/lib/platform`) for
  Governance → Casino reads/approvals; HMAC-SHA256 (`GOVERNANCE_BRIDGE_SECRET`,
  `X-Bridge-Signature`) for Casino → Governance events. Operator cookies are
  never accepted on the webhook. Scopes (`deposits:read`,
  `withdrawals:approve`, `content:read`, `payments:read`) are enforced on JWT
  requests; 60s TTL + `jti` replay protection; `alg:none` downgrades rejected.
- **Fail-closed** — missing/misconfigured secrets return 503, never fall open.

## Auth

```
node scripts/hash-password.mjs <password>   # → GOVERNANCE_OPERATOR_PASSWORD_HASH
openssl rand -hex 32                          # → GOVERNANCE_SESSION_SECRET
```

Credentials live in the environment (`GOVERNANCE_OPERATOR_USER`,
`GOVERNANCE_OPERATOR_PASSWORD_HASH`). The hash format is `scrypt:salt:hash`
(colons, not `$` — `$` is expanded by Next.js's `.env` loader).

## Key exchange with the Casino

```bash
node scripts/generate-keys.mjs     # per platform; exchange PUBLIC keys
```

Then set `PLATFORM_*` and `PARTNER_*` on both sides (see
`docs/PLATFORM_INTEGRATION.md`).

## Run

```bash
npm install
npx prisma generate && npx prisma db push
npm run seed:cms                  # demo promotions + games
npm run dev                       # http://localhost:3000
```

## Tests

```bash
node --test tests/platform-jwt.test.mjs tests/platform-hmac.test.mjs tests/governance-auth.test.mjs
```

## Docs

- `docs/PLATFORM_INTEGRATION.md` — the JWT bridge contract & scopes
- `docs/CMS.md` — marketing content flow to the casino
- `docs/WALLET.md` — watch-only wallet / Trust Wallet integration
- `telegram-bot/README.md` — private operator Telegram bot (approve/reject
  withdrawals, deposits, stats, payments from a phone chat)
