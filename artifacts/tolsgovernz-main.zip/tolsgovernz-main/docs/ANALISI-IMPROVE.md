# Analisi completa — miglioramenti realizzati e verificati

> Branch: `arena/01a0149c-tolsgovernz` · Commit base `90e6c7a` → HEAD `0740afa`
> 47 file toccati · +12.591 / −5.846 righe · 3 commit pushati su GitHub.

---

## 1. Panoramica dei commit

| Commit | Contenuto |
|---|---|
| `9061bb4` | Tutte le viste/route su dati reali + bot Telegram operatore + fix bridge |
| `0740afa` | Completa il cerchio: wallets bridge-aware, status probe, script setup chiavi, patch casino |

---

## 2. Aree di miglioramento (dettaglio)

### A. Eliminazione dei mockup — 13 route API riscritte da dati hardcoded → DB reale

Prima di questo lavoro, le seguenti route servivano **dati finti scritti a mano**
(es. `{"id":"w1","playerName":"Alex Mercer"...}`). Ora leggono le tabelle del DB:

| Route | Fonte dati reale |
|---|---|
| `/api/wallets` | Wallet + WalletTransaction + CurrencyRate + PaymentMethod |
| `/api/notifications` | Notification + Preference + Template + Channel |
| `/api/payments` | DepositRequest + WithdrawalRequest + PaymentProvider |
| `/api/blockchain` | CryptoWallet + BlockchainTransaction + Network + SmartContract |
| `/api/ml-pipeline` | MLModel + MLPrediction + MLTrainingJob + MLFeatureStore |
| `/api/api-hub` | ApiToken + Webhook + Delivery + Integration + McpEndpoint + UsageLog |
| `/api/vendors` | GameProvider + ProviderGame + Callback + Credential + HealthLog |
| `/api/live-map` | PlayerSession + ServerNode + LiveEvent |
| `/api/live-players` | PlayerSession + LiveEvent |
| `/api/player-tracking` | DepositRequest + Session + GameControl + Wallet + Timeline |
| `/api/responsible-gaming` | ResponsibleLimit + PlayerProfile |
| `/api/rtp` | GameControl |
| `/api/auth` | User + Casino + UserSession + RolePermission |

**+3 viste** che fetchavano l'API ma rendevano ancora MOCK interno, ora consumano
davvero i dati: `auth-view.tsx`, `blockchain-view.tsx`, `ml-pipeline-view.tsx`.

**Verifica**: tutti gli endpoint rispondono `200` con dati reali (testato in runtime).

### B. Seed dei dati mancanti — `scripts/seed-real.ts` (461 righe, nuovo)

Le tabelle che nessun seed popolava sono ora riempite con dati coerenti:

| Tabella | Record |
|---|---|
| KycCase | 6 |
| AmlFlag | 6 |
| ResponsibleLimit | 8 |
| GameProvider / ProviderGame | 6 / 12 |
| ProviderCallback / Credential / HealthLog | 6 / 6 / 6 |
| UserSession | 6 |
| BlockchainTransaction / SmartContract | 12 / 5 |
| MLPrediction / MLTrainingJob | 12 / 6 |
| GameControl | 12 |
| PlayerNote / Timeline / BonusHistory / Heatmap | 5 / 10 / 8 / 20 |
| Payment (subscription) | 6 |

I 3 seed esistenti (`seed-new`, `seed-new-features`, `seed-api-notif`) sono stati
allineati al client DB condiviso (`@/lib/db`).

### C. Viste "denaro" bridge-aware — dati reali dal casino con fallback demo

Nuovo helper `src/lib/platform/bridge-data.ts` (130 righe):
- `isBridgeConfigured()`, `fetchBridgeDeposits()`, `fetchBridgeWithdrawals()`,
  `fetchBridgePayments()`, `fetchBridgeWallets()`.
- Best-effort: timeout 3s, cooldown 15s se il casino è giù, ritorno `null` su ogni
  errore (mai eccezioni), fail-closed.

Route rese bridge-aware (rispondono con `source: "casino" | "demo"`):
- `/api/payments` — depositi/prelievi reali dal casino, stats ricalcolate.
- `/api/financial` — depositi/prelievi dal bridge; house earnings + ledger restano
  governance-side (corretto per architettura).
- `/api/wallets` — saldi reali dal casino (nuovo endpoint `wallets:read`).

**Comportamento**: appena il bridge è configurato + raggiungibile, la console passa
**automaticamente** da "demo" a "reale", senza toccare altro codice.
**Verifica**: testato con un mock casino locale in entrambi i rami (demo ✓, casino ✓).

### D. Fix del bridge (bug reali trovati e corretti)

1. **Bug guard** — `if (gate) return gate` era *sempre* truthy: con token valido
   rispondeva `500` su `deposits`, `withdrawals`, `approve`, `reject`, `webhooks`.
   → Corretto in `if ("response" in gate) return gate.response` (5 file). Ora
   `401` senza token / `502` fail-closed con token.
2. **`/api/platform/connection`** — `getPlatformClient()` fuori dal try causava
   `500` quando il bridge non era configurato. Ora riporta
   `{ ok:false, configured:false, error:"…missing env…" }` con `200`.
3. **`/api/platform/stats`** (nuovo) — completa la parità con la superficie esposta
   dal casino (mancava nella governance).
4. **`/api/platform/status`** (nuovo, 73 righe) — diagnostico operator-gated che
   mostra in un colpo solo: cosa è configurato, cosa manca, raggiungibilità del
   casino e i passi successivi.

### E. Bot Telegram operatore privato — `telegram-bot/` (8 file, zero dipendenze)

| File | Ruolo |
|---|---|
| `bot.mjs` (330) | logica pura comandi/callback (testabile offline) |
| `gov-client.mjs` (118) | client HTTP verso i controller `/api/platform/*` |
| `index.mjs` (201) | runner: long-polling + webhook (secret header) + mock mode |
| `test.mjs` (119) | suite di test offline (mock governance) |
| `README.md` / `.env.example` / `package.json` / `mock-updates.json` | supporto |

Funzionalità: `/status`, `/stats`, `/deposits`, `/withdrawals` (con bottoni
inline ✅ Approve / ❌ Reject), `/payments`, `/approve <id> <txHash>`,
`/reject <id>`, `/cancel`.

Sicurezza: whitelist per chat ID (`TELEGRAM_ADMIN_IDS`), approve in 2 step
(chiede txHash), nessun segreto in chat (parla solo con la Governance che firma
il JWT verso il casino), confronto costante del secret webhook.

**Verifica**: `node telegram-bot/test.mjs` → ✅ 11/11 test passano (auth,
deny intruso, flusso approve/reject completo). Mock-mode verificato contro la
governance reale in esecuzione.

### F. Patch lato casino — `docs/casino-platform-wallets-telegram.patch` (130 righe)

Il casino (`tols-casino-next`) è un repo separato: le modifiche sono consegnate
come patch da applicare con `git am --3way`:

1. **`/api/platform/wallets`** (nuovo) — saldi wallet watch-only con JWT `wallets:read`.
2. **Scope `wallets:read`** in `src/lib/platform-auth.ts`.
3. **Notifiche Telegram** su `approve`/`reject` prelievi (`fireTelegramAlert`)
   → il casino già notificava il prelievo richiesto; ora notifica anche l'esito.
   Loop operatore completo.

### G. Runtime di sviluppo — WASM Postgres (PGlite)

Il sandbox non può installare Postgres né scaricare i binari nativi di Prisma
(`binaries.prisma.sh` bloccato). Soluzione: PGlite (Postgres in WASM) + driver
adapter, senza modificare il percorso di produzione.

- `src/lib/db.ts` (22 righe cambiate) — usa l'adapter PGlite **solo** se
  `PGLITE_DATABASE_DIR` è impostato; altrimenti il client nativo invariato.
- `next.config.ts` (+3) — `serverExternalPackages` per i pacchetti WASM.
- `package.json` — deps `@electric-sql/pglite`, `prisma-pglite`,
  `@prisma/driver-adapter-utils`.
- Config/schema locale in `db/` (gitignored, 82 tabelle create + seedate).

### H. Script di setup — `scripts/bridge-setup.mjs` (88 righe, nuovo)

Genera le 2 coppie RSA-3072 + secret e stampa i blocchi `.env` pronti da
incollare per **Governance**, **Casino** e **bot Telegram** (opzione `--out <dir>`).
Riduce a un comando l'allestimento del ponte.

### I. Documentazione

- `README.md` — link alla doc del bot.
- `docs/PLATFORM_INTEGRATION.md` — endpoint `payments/stats/wallets` aggiunti.

---

## 3. Stato verifica (onesto)

| Cosa | Stato |
|---|---|
| 13 route mock→DB + 3 viste | ✅ runtime `200` con dati reali |
| Seed tabelle mancanti | ✅ 82 tabelle, record verificati |
| Bridge-aware (payments/financial/wallets) | ✅ testato in entrambi i rami (demo + mock casino) |
| Fix guard bridge | ✅ `401`/`502` fail-closed corretto |
| `/api/platform/status` | ✅ `200`, riporta `partnerPublicKey` mancante |
| Bot Telegram | ✅ test offline 11/11; **non** testato contro Telegram reale |
| Patch casino | ✅ generata; **non applicata** (repo esterno, serve il tuo intervento) |
| TypeScript | ✅ 0 errori nei file toccati (14 errori pre-esistenti in file non toccati: payments-view, players-view, ai-tutor, page) |

### Rotte ancora `mock/static` (per natura, non per dimenticanza)

| Route | Perché è così |
|---|---|
| `gov/auth`, `platform/health`, `health` | auth reale / liveness probe (non dati) |
| `platform/whoami` | echeggia i claim JWT verificati (reale) |
| `ai-tutor` | usa l'SDK LLM reale `z-ai-web-dev-sdk`, non dati finti |
| `realtime/stream` | feed SSE sintetico (da collegare ai webhook in produzione) |

---

## 4. Cosa resta da fare (fuori dal mio controllo)

1. **Scambio chiavi** — `PLATFORM_PUBLIC_KEY` → casino (`PLATFORM_JWT_PUBLIC_KEY`);
   pubblica del casino → `PARTNER_PUBLIC_KEY` qui.
2. **Applicare la patch** sul casino e ridistribuire.
3. **Creare il bot con @BotFather** e compilare `telegram-bot/.env` (serve il tuo
   token; nessun bot è stato creato a tua insaputa).
4. **Host persistente** per il bot (long-polling non gira su serverless).
5. `realtime/stream` → collegare agli eventi webhook reali.

---

## 5. Note e rischi

- **Nessun bot Telegram è stato creato**: il codice è inerte finché non configuri
  il token. `api.telegram.org` non è raggiungibile dal sandbox.
- **I dati sono demo** finché il bridge non è attivo: le viste denaro passano da
  sole a "casino" appena scambiate le chiavi, ma i numeri attuali sono seed.
- **I commit sono su GitHub** (pushati), quindi sopravvivono ai reset dell'ambiente.
- Il clone locale di `tols-casino-next` è di sola lettura (le modifiche viaggiano
  via patch, secondo la convenzione `docs/*.patch` già presente nel repo).
