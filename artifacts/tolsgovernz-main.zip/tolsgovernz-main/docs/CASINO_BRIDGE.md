# Casino Bridge — Governance (gov.tols.fun) ⇄ Casino (www.tols.fun)

The two twin Vercel projects (**hackguts-projects**):

| Project | Vercel | Origin |
|---|---|---|
| Casino | `tols-casino-next` | https://www.tols.fun |
| Governance (THIS repo) | `tolsgovernz` | https://gov.tols.fun |

Governance **controls** the Casino. Every operator screen (Overview, Users,
Wallets, Cash Flow, Bets, RTP, Promotions) reads **live Casino data** through
the platform API and writes back to the Casino. There are no mock tables and
no local fake ledgers for those domains. The Casino operator UI is retired —
this repo is the only operator console. Never `tolscrypto.base44.app`,
never a Casino `/control/admin` panel.

## Auth — two channels

### 1. READ/WRITE REST (Governance → Casino)

An RS256 JWT signed with `PLATFORM_JWT_PRIVATE_KEY` (this project only) and
sent as `Authorization: Bearer <jwt>`:

```
alg  RS256
iss  tols-governance        (PLATFORM_JWT_ISSUER)
aud  tols-casino            (PLATFORM_JWT_AUDIENCE)
iat, exp                    (≤ 10 minutes)
role platform
scope optional              (empty = the Casino allows all)
```

The Casino verifies with `PLATFORM_JWT_PUBLIC_KEY` (set on `tols-casino-next`
**only** — never on this project).

Implementation: `src/lib/casino/jwt.ts` (minting), `src/lib/casino/client.ts`
(request + envelope relay).

### 2. COMMANDS (Governance → Casino webhook)

`POST https://www.tols.fun/api/bridge/webhook` with

```
Content-Type:       application/json
X-Bridge-Signature: sha256=<hex(HMAC_SHA256(rawBody, GOVERNANCE_BRIDGE_SECRET))>
X-Bridge-Timestamp: <unix seconds>          (max skew 5 minutes)
Body: { "type": "<event>", "payload": { … }, "ts": "<iso>", "source": "governance" }
```

Same secret on both Vercel projects (alias `GOVERNANCE_WEBHOOK_SECRET`).
`{ "type": "ping" }` needs no auth and answers `{ type: "pong" }`.

Commands: `governance.rtp_update`, `governance.wallet_adjust`,
`governance.player_block`, `governance.bonus_credit`,
`governance.session_invalidate`, `governance.support_reply`,
`governance.support_close`, `governance.limits_update`,
`governance.feature_flag`.

Implementation: `src/lib/casino/webhook.ts` + `POST /api/casino/command`.

### 3. EVENTS IN (Casino → Governance)

The Casino POSTs signed events to, in order until non-404:

1. `https://gov.tols.fun/api/platform/webhooks`
2. `https://gov.tols.fun/api/platform/webhook`
3. `https://gov.tols.fun/api/bridge/events`

All three are mounted here and share one handler
(`src/lib/casino/inbound.ts`) with the same HMAC headers. Accepted types:
`casino.bet`, `casino.win`, `casino.deposit_pending`,
`casino.deposit_confirmed`, `casino.withdrawal_pending`,
`casino.withdrawal_settled`, `casino.session_start`, `casino.session_end`,
`casino.health`, `casino.support_message`, `casino.support_ticket`,
`casino.bonus_released`, `bridge.sync_request`. Events persist idempotently
into `PlatformEvent` (unique `eventId`, falling back to a body hash) and are
shown in the Casino Link section.

## Environment (Vercel → tolsgovernz → Production, then Redeploy)

```
APP_URL=https://www.tols.fun
GOVERNANCE_TOWER_URL=https://gov.tols.fun
GOVERNANCE_BRIDGE_SECRET=<same 64-hex as the Casino>
PLATFORM_JWT_PRIVATE_KEY=<RS256 private PEM; base64 of the PEM is OK>
PLATFORM_JWT_ISSUER=tols-governance
PLATFORM_JWT_AUDIENCE=tols-casino
```

Never set `PLATFORM_JWT_PUBLIC_KEY` here — the public key belongs on the
Casino project.

## Wiring check (what the Casino Link section runs)

1. `GET  CASINO/api/platform/health` (public) → `jwtConfigured: true`, `db.ok: true`
2. `GET  CASINO/api/platform` (public catalog)
3. `GET  CASINO/api/bridge/webhook` (public) → `reachable: true`
4. `POST CASINO/api/bridge/webhook {type:"ping"}` → `pong`
5. `GET  CASINO/api/platform/whoami` with a Governance-signed JWT → 200

If whoami fails, fix keys/iss/aud. Do not mock.

## Operator screens → Casino endpoints

The browser only ever calls same-origin controller routes (`/api/casino/*`,
operator cookie); the server mints the JWT and forwards to
`CASINO/api/platform/*`:

| Screen | Casino endpoints |
|---|---|
| Dashboard (Overview) | `GET /api/platform/overview`, `GET /api/platform/stats` |
| Players / signups | `GET /api/platform/users`, `GET/PATCH /api/platform/users/:id` (block/unblock) |
| Wallets | `GET /api/platform/wallets`, `POST /api/platform/wallets/adjust` |
| Cash Flow | `GET /api/platform/cashflow`, `/deposits`, `/withdrawals`, `/payments`, `POST /withdrawals/:id/approve\|reject` |
| Bets | `GET /api/platform/bets?gameId=&userId=&result=` |
| RTP | `GET/PUT /api/platform/rtp` (bias 0..2, 1 = fair; `{action:"reset"}` disables) |
| Promotions | `GET/PUT /api/platform/promotions` (`entity: "promo"\|"game"`, `key`, …) |
| Casino Link | health + whoami + webhook ping + stored event feed |

All Casino envelopes are `{ success: true, data, pagination? }` or
`{ success: false, error }` and are relayed verbatim.
