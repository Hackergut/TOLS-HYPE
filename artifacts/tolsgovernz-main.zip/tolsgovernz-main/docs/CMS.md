# Governance → Casino: Marketing CMS

The Governance owns the marketing layer. Operators edit **promotions** and
**game entries** in the Governance UI; the Casino lobby renders them live over
the JWT platform bridge. There is no direct database link — content flows one
way (Governance publishes, Casino pulls) and the Casino never depends on the
CMS being up.

```
┌──────────────────────────────┐        GET /api/platform/content
│ GOVERNANCE (CMS owner)        │  ◄────  (RS256 JWT, scope content:read)
│                              │  ─────►  { promotions[], games[] }
│  /api/cms/promotions  (CRUD) │
│  /api/cms/games       (CRUD) │
│  /api/platform/content        │
└──────────────────────────────┘
                  ▲
                  │ pulls every ≤30s, caches, merges over local defaults
┌──────────────────────────────┐
│ CASINO (lobby consumer)       │
│  /api/cms/content  (server)   │  → mergeContent() → lobby
│  useCmsContent()  (client)    │  → hero + promo strip + Originals cards
└──────────────────────────────┘
```

## 1. What operators manage

**Promotions** (hero carousel + promo strip): title, subtitle, CTA label, target
(a game id like `dice`, or a section like `rewards`), image URL, lime accent
flag, order, active.

**Games** (marketable entries keyed by the engine slug): name, tagline,
description, provider, category, image override, order, `featured` and `isNew`
flags, active. Entries only *enrich* the eleven Originals the engine can
launch; a slug with no engine game is stored but not surfaced (no dead links).

## 2. How it flows

1. Operator edits in **Governance → Marketing CMS** (persisted to SQLite via
   Prisma models `CmsPromotion` / `CmsGame`).
2. The Casino calls **`/api/platform/content`** with a signed RS256 JWT
   (`scope: content:read`). Governance returns only `active` rows.
3. Casino's **`/api/cms/content`** route pulls it server-side (30s in-memory
   cache), then `mergeContent()` merges it over the built-in defaults.
4. The lobby (`useCmsContent()`) renders the merged result. If the CMS is
   offline or the bridge is unconfigured, the lobby shows the defaults — never
   an empty page.

## 3. Merge rules (pure & tested — `tests/cms.test.mjs`)

- `null` remote → local defaults.
- Remote **promotions** replace the defaults when non-empty.
- Remote **games** enrich known Originals by `gameId` (name/tagline/image/
  order/flags); unknown slugs are ignored.
- Ordering: `featured` first, then `sortOrder`.
- **House edge / max win are NOT part of this layer** — they always come from
  the engine (`getGameMeta()`), so marketing can never misstate the odds.

## 4. Trust boundary

- The browser never signs a JWT and never sees the partner's public key: the
  Casino's own `/api/cms/content` route does the signed fetch server-side.
- `content:read` is a read-only scope; it cannot approve withdrawals or touch
  wallet data.
- Editing the CMS requires the Governance operator session (signed cookie) or
  the machine bearer token — same gate as the Casino-link controller routes.

## 5. Local dev setup

Already wired in the dev `.env.local` files (keys cross-exchanged). The Casino
reaches the Governance CMS at `PARTNER_BASE_URL` (Governance `:3000`). After
changing the Prisma schema, run on the Governance:

```bash
npx prisma generate && npx prisma db push
```

Then open **Governance → Marketing CMS**, add a promotion/game, and the Casino
lobby picks it up within the cache TTL.
