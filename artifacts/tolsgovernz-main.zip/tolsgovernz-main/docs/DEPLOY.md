# Deploy in produzione — TOLS Governance

> **Percorso solo-iPad (nessun terminale):** crea il database Postgres su
> Supabase, poi incolla `docs/schema.postgres.sql` nell'SQL editor (crea le 82
> tabelle senza `prisma db push`). Genera chiavi e segreti dalla pagina
> `/tools/setup` del deploy (Web Crypto, tutto nel browser). Per la password
> operatore puoi usare `GOVERNANCE_OPERATOR_PASSWORD` (testo semplice) invece
> dell'hash scrypt. I passaggi completi sono nel Percorso A qui sotto.


Checklist operativa per portare **TOLS Governance** online. Ci sono **due
percorsi** validi; entrambi usano **PostgreSQL** (il vecchio SQLite non è
compatibile con Vercel):

- **Percorso A — Vercel (consigliato)**: stesso provider del casino, zero server
  da gestire.
- **Percorso B — Hetzner Cloud + Dokploy**: self-hosted, con Postgres su volume
  o servizio esterno (Supabase/Neon).

Il casino resta su **Vercel** in entrambi i casi. Le due app si parlano **solo**
tramite il bridge RS256-JWT — nessun database condiviso.

---

## 0. Architettura target

```
[Browser operatore] ──HTTPS──▶ TOLS Governance (Vercel o Hetzner/Dokploy)
                                    │  RS256-JWT (PARTNER_BASE_URL)
                                    ▼
                              TOLS Casino (Vercel)
```

---

# PERCORSO A — Vercel

## A1. Creare il database Postgres

Scegli un Postgres gestito (gratis per iniziare):

- **Supabase** → progetto nuovo → *Settings → Database → Connection string*.
- **Neon** → progetto nuovo → connection string (pooled) + **direct** URL.
- **Vercel Postgres** → integrazione nel dashboard Vercel.

## A2. Creare le tabelle (una volta sola)

**Da computer (metodo preferito):**

```bash
npm install
export DATABASE_URL="postgresql://USER:PASSWORD@HOST:5432/governance?sslmode=require"
# Neon: esporta anche DIRECT_URL (URL "direct", non pooled) per prisma
npx prisma db push
```

**Solo-iPad (nessun terminale):** apri il repo su GitHub → `docs/schema.postgres.sql`
→ copia tutto il contenuto → incollalo nell'**SQL Editor** di Supabase (o
Neon/Vercel Postgres) → *Run*. Il file è generato da
`scripts/export-schema-sql.mjs` e crea tutte le 82 tabelle, chiavi esterne e
indici in un'unica transazione.

## A3. Importare il progetto su Vercel

- **New Project → Import** → `Hackergut/tolsgovernz`.
- Framework: **Next.js** (rilevato automaticamente; `vercel.json` è già nel repo).
- Node: **22.x** (o il `engines` già presente nel `package.json`).

## A4. Variabili d'ambiente su Vercel

Impostale in **Settings → Environment Variables**:

| Variabile | Valore |
| --- | --- |
| `DATABASE_URL` | URL Postgres (Neon: usa quello **pooled**) |
| `DIRECT_URL` | solo per **Neon**: URL **direct** per `prisma` |
| `PLATFORM_ID` | `tols-governance` |
| `PLATFORM_PRIVATE_KEY` | privata Governance (base64) — segreta |
| `PLATFORM_PUBLIC_KEY` | pubblica Governance (base64) |
| `PARTNER_PLATFORM_ID` | `tols-casino` |
| `PARTNER_PUBLIC_KEY` | pubblica Casino (base64) |
| `PARTNER_BASE_URL` | `https://tols-casino-next.vercel.app` |
| `GOVERNANCE_SESSION_SECRET` | `openssl rand -hex 32` |
| `GOVERNANCE_OPERATOR_USER` | `admin` (cambiarlo) |
| `GOVERNANCE_OPERATOR_PASSWORD_HASH` | `node scripts/hash-password.mjs <password>` (oppure `GOVERNANCE_OPERATOR_PASSWORD` in chiaro per il quickstart iPad) |
| `GOVERNANCE_ADMIN_TOKEN` | `openssl rand -hex 32` |
| `GOVERNANCE_BRIDGE_SECRET` | `openssl rand -hex 32` — **stesso valore** sul progetto Vercel `tols-casino-next` |
| `APP_URL` | `https://www.tols.fun` |
| `GOVERNANCE_TOWER_URL` | `https://gov.tols.fun` |

> Il build esegue già `prisma generate` (script `postinstall` + `vercel.json`).
> `NEXT_PUBLIC_MAP_TILE_URL` (opzionale) va in **Settings → Environment
> Variables** ma come var build-time.

## A5. Deploy e verifica

```bash
curl -i https://<governance>.vercel.app/api/health   # → 200 {"ok":true,...}
```

- Login con `GOVERNANCE_OPERATOR_USER` + password.
- In **Casino Link** verifica che il bridge risponda.

---

# PERCORSO B — Hetzner Cloud + Dokploy

## B1. Requisiti

- VPS Hetzner **CX22** (2 vCPU / 4 GB), Ubuntu 24.04, ~30 GB disco.
- Dominio per Governance (es. `gov.tols.gg`) → record **A** verso l'IP.

## B2. Installare Dokploy

```bash
ssh root@<IP_VPS>
curl -fsSL https://dokploy.com/install.sh | sh
```

## B3. App in Dokploy

- **New Project → New Service → Application**
- Git: `Hackergut/tolsgovernz`, branch `arena/01a008d7-tolsgovernz` (o `main`).
- **Build Type**: `Dockerfile` — Port: `3000` — Domains: `gov.tols.gg`.

Il build gira **sul VPS** (dove `prisma generate` scarica gli engine).

## B4. Database Postgres (self-hosted o esterno)

Scegli **una** delle due:

- **Servizio esterno** (Supabase/Neon) → imposta `DATABASE_URL` e via.
- **Postgres dentro Dokploy** → aggiungi un service Postgres e usa la sua URL.

Il vecchio volume SQLite `/app/db` non serve più: la entrypoint esegue
`prisma db push` verso Postgres al primo avvio.

## B5. Variabili d'ambiente

Stessa tabella del **Percorso A** (A4), con `PARTNER_BASE_URL` identico.

## B6. Verifica

```bash
curl -i https://gov.tols.gg/api/health   # → 200
```

---

## Chiavi (entrambi i percorsi)

```bash
node scripts/generate-keys.mjs            # su Governance → tieni privata, dai la pubblica al Casino
node scripts/generate-keys.mjs            # sul Casino    → dai la pubblica a Governance
node scripts/hash-password.mjs '<password>'   # → GOVERNANCE_OPERATOR_PASSWORD_HASH
openssl rand -hex 32                      # → GOVERNANCE_SESSION_SECRET / GOVERNANCE_ADMIN_TOKEN
```

## Lato casino (Vercel)

1. Applica il rebuild del casino (`docs/casino-engine-cms-wallet.patch`) dal repo
   casino o da una nuova sessione Arena su `tols-casino-next`:
   ```bash
   git am --3way docs/casino-engine-cms-wallet.patch
   ```
2. Su Vercel (progetto casino) imposta: `DATABASE_URL`/`DIRECT_URL`,
   `ADMIN_SESSION_SECRET`, `CRON_SECRET`, `RESTRICTED_COUNTRIES`,
   `PLATFORM_*`/`PARTNER_*` con `PARTNER_BASE_URL` → URL di Governance.
3. Popola il catalogo: `POST /api/games {"action":"seed"}`.

## Checklist finale

- [ ] Database Postgres creato e raggiungibile
- [ ] Tabelle create (`npx prisma db push`)
- [ ] Progetto importato su Vercel (o Dokploy), env impostate
- [ ] Chiavi rigenerate per la produzione e scambiate col casino
- [ ] Deploy verde, `/api/health` → 200
- [ ] Login operatore funzionante
- [ ] Bridge verificato in entrambe le direzioni

## Sicurezza

- **Non riusare** le chiavi dev di `.env.local`: rigenerale per produzione.
- Mai committare `.env*` (già in `.gitignore`); il vecchio `db/custom.db` è stato
  rimosso dal tracking.
- **Backup**: abilita i backup automatici del provider Postgres.
- Per dati reali, valuta `prisma migrate` invece di `db push`.
