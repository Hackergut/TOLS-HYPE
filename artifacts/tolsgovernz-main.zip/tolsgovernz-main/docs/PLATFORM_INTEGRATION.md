# TOLS Platform Integration — Secure API Bridge (RS256 JWT)

Two independent platforms, two independent deployments, **zero shared state** —
connected only through a small, signed API surface:

| Platform | Repo | Role |
|---|---|---|
| **Governance** | `TOLS-GOVERNANCE` | Control tower: reads casino data, decides on withdrawals, receives events. |
| **Casino** | `tols-casino-next` | Player platform: owns the data (deposits/withdrawals), executes decisions, emits events. |

```
┌────────────────────────────┐                 ┌────────────────────────────┐
│  GOVERNANCE (control tower) │                 │   CASINO (player platform) │
│                            │   RS256 JWT     │                            │
│  GET deposits  ─────────────┼──bearer token──►│  /api/platform/deposits    │
│  GET withdrawals ───────────┼────────────────►│  /api/platform/withdrawals │
│  POST approve/reject ───────┼────────────────►│  /api/platform/withdrawals │
│                            │                 │       /:id/approve|reject  │
│  /api/platform/webhooks ◄───┼─────────────────│  HMAC events (bridge)      │
│  (POST — HMAC, not cookie)  │                 │                            │
└────────────────────────────┘                 └────────────────────────────┘
```

The connection is machine-to-machine (M2M): no shared database, no shared
cookie, no browser session, no SSH dependency at the application layer.

* **Governance → Casino** (reads, approvals): short-lived **RS256 JWT**.
* **Casino → Governance** (events): **HMAC-SHA256** over the raw JSON body
  with `GOVERNANCE_BRIDGE_SECRET` (`X-Bridge-Signature` /
  `X-Bridge-Timestamp`). Operator cookies are never accepted on this path.

---

## 1. Trust model

* Each platform owns **its own RSA keypair**.
* The **caller signs** outbound requests with its **private** key.
* The **receiver verifies** inbound requests with the **caller's public** key.
* JWT reads use **no shared symmetric secret** — a leaked public key proves
  nothing, and a compromised platform only exposes its own private key.
* Event webhooks additionally share `GOVERNANCE_BRIDGE_SECRET` (HMAC). That
  secret never authenticates an operator browser session.

```
Governance (private key A ──signs──► Casino (verifies with public key A)
Casino     (private key B ──signs──► Governance (verifies with public key B)
```

### JWT claims

| Claim | Meaning |
|---|---|
| `iss` | Caller platform id (`tols-governance` / `tols-casino`) |
| `sub` | Principal (`system`, or an operator id) |
| `aud` | Receiver platform id — **must match** the receiver |
| `scope` | Space-separated scopes (see §4) |
| `iat` / `nbf` / `exp` | Timestamps; TTL is **60s** by default |
| `jti` | Unique id — used for **replay protection** |

Verification enforces: signature (`RS256` only), `iss`, `aud`, time window,
and the required `scope`. Failures return 401 (bad token) / 403 (missing
scope) / 503 (platform auth not configured) — never data.

---

## 2. Setup (key exchange)

Generate a keypair on **each** platform:

```bash
node scripts/generate-keys.mjs
```

Then configure the environment:

**Governance (`TOLS-GOVERNANCE/.env`):**

```bash
PLATFORM_ID=tols-governance
PLATFORM_PRIVATE_KEY=<governance private key, base64 or PEM>
PLATFORM_PUBLIC_KEY=<governance public key>          # optional, for key exchange
PARTNER_PLATFORM_ID=tols-casino
PARTNER_PUBLIC_KEY=<CASINO public key>               # verifies inbound events
PARTNER_BASE_URL=https://casino.example.com

GOVERNANCE_ADMIN_TOKEN=<random long token>           # gates Governance controller routes
GOVERNANCE_BRIDGE_SECRET=<openssl rand -hex 32>      # SAME value as the Casino
APP_URL=https://www.tols.fun
GOVERNANCE_TOWER_URL=https://gov.tols.fun
```

**Casino (`tols-casino-next/.env`):**

```bash
PLATFORM_ID=tols-casino
PLATFORM_PRIVATE_KEY=<casino private key, base64 or PEM>
PLATFORM_PUBLIC_KEY=<casino public key>              # optional
PARTNER_PLATFORM_ID=tols-governance
PARTNER_PUBLIC_KEY=<GOVERNANCE public key>           # verifies inbound requests
PARTNER_BASE_URL=https://gov.tols.fun
GOVERNANCE_BRIDGE_SECRET=<same hex as Governance>
GOVERNANCE_TOWER_URL=https://gov.tols.fun
APP_URL=https://www.tols.fun
```

Keys can be PEM (with `\n` or literal `\\n`) or base64-encoded. `getPlatformConfig()`
validates them at startup and **fails closed** if anything is missing or invalid.

---

## 3. Endpoint reference

### Casino — exposed to Governance

| Method | Path | Scope | Description |
|---|---|---|---|
| GET | `/api/platform/health` | — (public) | Liveness probe |
| GET | `/api/platform/whoami` | any valid token | Echoes verified claims (connectivity test) |
| GET | `/api/platform/deposits` | `deposits:read` | List deposits (`?status=`, `?limit=`) |
| GET | `/api/platform/withdrawals` | `withdrawals:read` | List withdrawals (`?status=`, `?limit=`) |
| POST | `/api/platform/withdrawals/:id/approve` | `withdrawals:approve` | Approve (requires `{ txHash }`); emits `withdrawal.approved` |
| POST | `/api/platform/withdrawals/:id/reject` | `withdrawals:approve` | Reject + refund wallet; emits `withdrawal.rejected` |
| GET | `/api/platform/payments` | `payments:read` | Treasury / payments summary |
| GET | `/api/platform/stats` | any valid token | Aggregate stats (users, bets, deposits, withdrawals) |
| GET | `/api/platform/wallets` | `wallets:read` | Wallet balances (watch-only) — added via `docs/casino-platform-wallets-telegram.patch` |

### Governance — exposed to Casino

| Method | Path | Scope | Description |
|---|---|---|---|
| GET | `/api/platform/health` | — (public) | Liveness probe |
| GET | `/api/platform/whoami` | any valid token | Echoes verified claims |
| POST | `/api/platform/webhooks` | HMAC `GOVERNANCE_BRIDGE_SECRET` | Receive Casino events. `{"type":"ping"}` → pong (no cookie). Other events: `X-Bridge-Signature` + `X-Bridge-Timestamp` only — never the operator cookie. Idempotent on event id. |
| GET | `/api/platform/webhooks` | — (public) | Reachability probe `{ success: true, reachable: true }`. Operators (cookie / admin token) still get the event list. |
| GET | `/api/platform/content` | `content:read` | Publish marketing content (promotions + games) to the Casino |

### Governance — controller endpoints (its own UI → Casino)

| Method | Path | Notes |
|---|---|---|
| GET | `/api/platform/deposits` | Proxies Casino deposit list |
| GET | `/api/platform/withdrawals` | Proxies Casino withdrawal list |
| POST | `/api/platform/withdrawals/:id/approve` | Forwards `{ txHash }` to Casino |
| POST | `/api/platform/withdrawals/:id/reject` | Forwards rejection to Casino |

These require `Authorization: Bearer <GOVERNANCE_ADMIN_TOKEN>`.

---

## 4. Scopes

| Scope | Grants |
|---|---|
| `deposits:read` | Read the deposit list |
| `deposits:approve` | (reserved) Approve/credit deposits |
| `withdrawals:read` | Read the withdrawal list |
| `withdrawals:approve` | Approve **or** reject a withdrawal |
| `events:write` | Push events to the partner webhook |
| `content:read` | Pull marketing content (promotions + games) from the CMS |
| `*` | Wildcard (testing only — never in production) |

Grant the least privilege each integration needs.

---

## 5. Events (Casino → Governance)

Live Casino (`pushBridgeEvent`) POSTs HMAC-signed JSON:

```json
{ "type": "casino.bet", "payload": { "…": "…" }, "ts": "2026-08-21T00:00:00.000Z", "source": "casino" }
```

Headers (required for every type except `ping`):

```
X-Bridge-Signature: sha256=<hmac-sha256 of the raw body with GOVERNANCE_BRIDGE_SECRET>
X-Bridge-Timestamp: <unix seconds, ±5 minutes>
```

`{"type":"ping"}` always replies `{ "type": "pong", "reachable": true }` — no
cookie, HMAC optional. A browser GET of this URL is only a liveness probe; the
real test is a signed POST.

Canonical money events (still accepted):

| Type | Meaning |
|---|---|
| `deposit.confirmed` | On-chain deposit verified & credited |
| `deposit.failed` | Deposit did not confirm |
| `withdrawal.requested` | Player submitted a withdrawal |
| `withdrawal.approved` | Governance approved it |
| `withdrawal.rejected` | Governance rejected it (funds refunded) |

The receiver upserts on `event.id` (or a SHA-256 of the raw body), so retries
are safe.

---

## 6. Security hardening

* **Short TTL** (60s) + `jti` replay cache (in-process; use Redis in multi-instance).
* **RS256 only** — `alg: none` / `HS256` downgrades are rejected.
* **HMAC events** — Casino → Governance webhooks verify `GOVERNANCE_BRIDGE_SECRET` in constant time; missing secret → 503; operator cookies are ignored.
* **Fail closed** — missing/misconfigured secrets → 503, never an open route.
* **Constant-time** comparisons on the Governance admin token.
* **Least-privilege scopes**, validated on every request.
* Deploy over **HTTPS/TLS** only; add **mTLS** or an **SSH tunnel / private
  network** at the transport layer if the two hosts are co-located.
* Store keys in a **KMS/secret manager**, never in the repo. `*.pem` and `.env*`
  are gitignored. Rotate keys by generating a new pair and swapping
  `PARTNER_PUBLIC_KEY` on the peer first, then `PLATFORM_PRIVATE_KEY` locally.

---

## 7. Running & testing

```bash
# Unit tests (no dependencies, Node ≥ 22.18):
node --test tests/platform-jwt.test.mjs tests/platform-hmac.test.mjs tests/governance-auth.test.mjs

# Governance (SQLite) — create the events table:
cd TOLS-GOVERNANCE && npm run db:push

# Dev servers (run on separate ports/hosts):
cd TOLS-GOVERNANCE && npm run dev        # http://localhost:3000
cd tols-casino-next && npm run dev       # http://localhost:3001
```

Smoke-test the bridge (once both are running and keys are exchanged):

```bash
# Public reachability (no cookie):
curl https://gov.tols.fun/api/platform/webhooks
# → { "success": true, "reachable": true, … }

# Signed ping (the real wiring test — HMAC, not a browser GET):
BODY='{"type":"ping"}'
SIG=$(node -e "const {createHmac}=require('crypto');process.stdout.write(createHmac('sha256',process.env.GOVERNANCE_BRIDGE_SECRET).update(process.argv[1]).digest('hex'))" "$BODY")
curl -X POST https://gov.tols.fun/api/platform/webhooks \
  -H "Content-Type: application/json" \
  -H "X-Bridge-Signature: sha256=$SIG" \
  -H "X-Bridge-Timestamp: $(date +%s)" \
  -d "$BODY"
# → { "success": true, "type": "pong", … }
```

---

## 8. What is intentionally NOT wired yet

* The Governance **UI pages** (players/wallets/financial) still serve mock data —
  the platform endpoints above are the real integration layer to point them at.
* The Governance **operator session** is still mocked; the controller routes are
  gated by `GOVERNANCE_ADMIN_TOKEN` until the real operator auth is wired (see
  the Casino's `src/lib/admin-auth.ts` for the reference pattern).
* Deposit **approval** is read-only for now (deposits are confirmed on-chain;
  the `deposits:approve` scope is reserved for manual crediting).
* Replay cache is per-process; switch to a shared store for horizontal scale.
