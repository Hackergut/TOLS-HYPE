# Master wallet & deposits (watch-only) — Trust Wallet integration

## The one rule that protects everything

> **The server never holds a seed phrase or a private key.** The mnemonic lives
> in Trust Wallet on the operator's device. The platform stores only **public
> receive addresses** and is therefore *watch-only*: it can detect and credit
> incoming deposits, but it can never move funds. If the server is ever
> compromised, the attacker can see addresses and balances but cannot sign a
> transaction out.

## How the deposit system is structured (Shuffle-style unified flow)

One deposit flow for every chain — the player picks a network + USD amount and
gets an address + a scannable QR. The QR encodes the chain's native **payment
URI** (`bitcoin:…`, `ethereum:…`, `solana:…`), which is the "unified QR": a
single UX, with the correct per-chain encoding underneath.

```
player ── choose network + $amount ──► /api/deposits (create intent)
            │                            • unique crypto amount (fingerprint)
            │                            • QR + address + "send exactly" copy
            ▼
        on-chain tx ──► chain-verifier (fail-closed) ──► deposit-watcher
                             │   mined? to our address? amount matches?
                             ▼
                    credit wallet (idempotent, USD via amountUsd)
```

Key invariants (already implemented, kept by this work):
- **Fail-closed verifier** — a broken RPC can never cause a false credit.
- **Idempotent crediting** — `credited:false→true` in a transaction + unique
  `(chain, txHash)` index, so a deposit can only be claimed once.
- **Unique amount** per intent — lets players deposit without pasting a hash
  (matched by the exact amount that landed).
- **USD↔crypto conversion** in the QR — the player is told to send the right
  coin amount, never "50 BTC" for a $50 deposit.

## Setting up the master wallet (Trust Wallet)

1. **Generate (or open) the master wallet — offline, on your own machine:**
   ```bash
   node scripts/generate-wallet.mjs
   ```
   This prints a 12-word mnemonic, the watch-only xpub, and the derived public
   addresses (BTC SegWit + Legacy, and one EVM address for ETH/Polygon/BNB +
   USDT/USDC tokens). **Nothing is written to disk.**

2. **Import the mnemonic into Trust Wallet** (Settings → Wallets → "+" →
   Import → enter the 12 words). Trust Wallet now holds the funds.

3. **Paste the PUBLIC addresses into the platform** (Governance → Casino Link →
   Treasury, or the Casino admin → Deposit Addresses page):
   - `btc` → BTC SegWit (`bc1…`) or Legacy (`1…`) — whichever Trust Wallet shows
   - `eth`, `usdt_erc20`, `usdc_erc20`, `polygon`, `bnb`, `usdt_bep20` → the **EVM** address
   - `solana` → copy from Trust Wallet → Solana → Receive (different curve, not
     derivable by this script)

4. **Never** put the mnemonic in `.env`, a repo, chat, or an issue. The admin
   route and the wallet guard (`src/lib/wallet/guard.ts`) actively reject
   seed phrases and private keys wherever an address is expected.

## Security hardening

- `scripts/generate-wallet.mjs` derives only from a mnemonic supplied on your
  machine and prints it once; it never persists key material.
- `src/lib/wallet/guard.ts` (`looksLikeSecret`) centralises detection of
  mnemonics, 32-byte hex private keys, and WIF — wired into the deposit-address
  admin route.
- Derivation is unit-tested against published BIP39/BIP44/BIP84 vectors
  (`tests/wallet.test.mjs`), so a wrong address can't silently enter the
  platform.
- For production volume, set `BTC_API_URL` / `ETH_RPC_URL` / … to Alchemy,
  QuickNode or Helius (see `.env.example`) — the public defaults are fine only
  for testing.
- If the mnemonic ever leaks: **move the funds to a new wallet immediately**,
  generate a fresh wallet, and re-point the deposit addresses.

## Governance reflection

The Governance **Casino Link → Treasury** tab reflects the casino's payments in
real time over the JWT bridge (`payments:read`): per-chain addresses, deposit
and withdrawal totals, and the pending-withdrawal queue — all watch-only.
