-- Generated from prisma/schema.prisma by scripts/export-schema-sql.mjs
-- Paste this whole file into the Supabase/Neon/Vercel SQL editor to create
-- the Governance schema without running `prisma db push`.

BEGIN;

CREATE TABLE "CasinoDeposit" (
    "id" TEXT NOT NULL,
    "playerId" TEXT NOT NULL,
    "amount" DOUBLE PRECISION NOT NULL,
    "currency" TEXT NOT NULL DEFAULT 'USD',
    "method" TEXT NOT NULL,
    "txHash" TEXT,
    "status" TEXT NOT NULL DEFAULT 'pending',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL
,
    PRIMARY KEY ("id")

);

CREATE TABLE "TotalWithdrawal" (
    "id" TEXT NOT NULL,
    "playerId" TEXT NOT NULL,
    "amount" DOUBLE PRECISION NOT NULL,
    "currency" TEXT NOT NULL DEFAULT 'USD',
    "method" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'pending',
    "approvedBy" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL
,
    PRIMARY KEY ("id")

);

CREATE TABLE "HouseEarning" (
    "id" TEXT NOT NULL,
    "gameId" TEXT NOT NULL,
    "grossRevenue" DOUBLE PRECISION NOT NULL,
    "playerPayout" DOUBLE PRECISION NOT NULL,
    "houseEdge" DOUBLE PRECISION NOT NULL,
    "netEarning" DOUBLE PRECISION NOT NULL,
    "periodStart" TIMESTAMP(3) NOT NULL,
    "periodEnd" TIMESTAMP(3) NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
,
    PRIMARY KEY ("id")

);

CREATE TABLE "CommissionLog" (
    "id" TEXT NOT NULL,
    "affiliateId" TEXT NOT NULL,
    "playerId" TEXT NOT NULL,
    "amount" DOUBLE PRECISION NOT NULL,
    "tier" TEXT NOT NULL,
    "rate" DOUBLE PRECISION NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
,
    PRIMARY KEY ("id")

);

CREATE TABLE "GlobalJackpot" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "currentAmount" DOUBLE PRECISION NOT NULL,
    "seedAmount" DOUBLE PRECISION NOT NULL,
    "contributionRate" DOUBLE PRECISION NOT NULL,
    "lastWonAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL
,
    PRIMARY KEY ("id")

);

CREATE TABLE "InternalLedger" (
    "id" TEXT NOT NULL,
    "category" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "amount" DOUBLE PRECISION NOT NULL,
    "type" TEXT NOT NULL,
    "periodWeek" TEXT NOT NULL,
    "reference" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
,
    PRIMARY KEY ("id")

);

CREATE TABLE "EscrowAccount" (
    "id" TEXT NOT NULL,
    "totalBalance" DOUBLE PRECISION NOT NULL,
    "pendingSettlement" DOUBLE PRECISION NOT NULL,
    "lastSettlement" TIMESTAMP(3),
    "settlementFrequency" TEXT NOT NULL DEFAULT 'weekly',
    "status" TEXT NOT NULL DEFAULT 'active',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL
,
    PRIMARY KEY ("id")

);

CREATE TABLE "SettlementLog" (
    "id" TEXT NOT NULL,
    "escrowId" TEXT NOT NULL,
    "amount" DOUBLE PRECISION NOT NULL,
    "recipients" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'processing',
    "settledAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
,
    PRIMARY KEY ("id")

);

CREATE TABLE "BudgetTarget" (
    "id" TEXT NOT NULL,
    "category" TEXT NOT NULL,
    "targetAmount" DOUBLE PRECISION NOT NULL,
    "actualAmount" DOUBLE PRECISION NOT NULL,
    "variance" DOUBLE PRECISION NOT NULL,
    "periodWeek" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL
,
    PRIMARY KEY ("id")

);

CREATE TABLE "VarianceAlert" (
    "id" TEXT NOT NULL,
    "category" TEXT NOT NULL,
    "expectedValue" DOUBLE PRECISION NOT NULL,
    "actualValue" DOUBLE PRECISION NOT NULL,
    "variancePercent" DOUBLE PRECISION NOT NULL,
    "threshold" DOUBLE PRECISION NOT NULL DEFAULT 15.0,
    "severity" TEXT NOT NULL,
    "isRead" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
,
    PRIMARY KEY ("id")

);

CREATE TABLE "PlayerProfile" (
    "id" TEXT NOT NULL,
    "username" TEXT NOT NULL,
    "email" TEXT,
    "vipLevel" TEXT NOT NULL DEFAULT 'bronze',
    "totalDeposits" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "totalWagers" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "totalWins" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "lifetimeValue" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "churnRisk" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "status" TEXT NOT NULL DEFAULT 'active',
    "country" TEXT,
    "registeredAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "lastActivityAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL
,
    PRIMARY KEY ("id")
,
    CONSTRAINT "PlayerProfile_username_key" UNIQUE ("username")

);

CREATE TABLE "GameControl" (
    "id" TEXT NOT NULL,
    "playerId" TEXT NOT NULL,
    "gameId" TEXT NOT NULL,
    "gameName" TEXT NOT NULL,
    "sessions" INTEGER NOT NULL DEFAULT 0,
    "totalWagered" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "totalWon" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "avgSessionDuration" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "lastPlayedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL
,
    PRIMARY KEY ("id")

);

CREATE TABLE "ResponsibleLimit" (
    "id" TEXT NOT NULL,
    "playerId" TEXT NOT NULL,
    "dailyDepositLimit" DOUBLE PRECISION,
    "weeklyDepositLimit" DOUBLE PRECISION,
    "monthlyDepositLimit" DOUBLE PRECISION,
    "sessionTimeLimit" DOUBLE PRECISION,
    "lossLimit" DOUBLE PRECISION,
    "selfExclusionEnd" TIMESTAMP(3),
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL
,
    PRIMARY KEY ("id")

);

CREATE TABLE "PlayerNote" (
    "id" TEXT NOT NULL,
    "playerId" TEXT NOT NULL,
    "authorRole" TEXT NOT NULL,
    "content" TEXT NOT NULL,
    "isInternal" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
,
    PRIMARY KEY ("id")

);

CREATE TABLE "PlayerSegmentAssignment" (
    "id" TEXT NOT NULL,
    "playerId" TEXT NOT NULL,
    "segmentId" TEXT NOT NULL,
    "assignedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
,
    PRIMARY KEY ("id")

);

CREATE TABLE "PlayerTimeline" (
    "id" TEXT NOT NULL,
    "playerId" TEXT NOT NULL,
    "eventType" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "metadata" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
,
    PRIMARY KEY ("id")

);

CREATE TABLE "PlayerHeatmap" (
    "id" TEXT NOT NULL,
    "playerId" TEXT NOT NULL,
    "gameId" TEXT NOT NULL,
    "dayOfWeek" INTEGER NOT NULL,
    "hourOfDay" INTEGER NOT NULL,
    "intensity" DOUBLE PRECISION NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL
,
    PRIMARY KEY ("id")

);

CREATE TABLE "PlayerBonusHistory" (
    "id" TEXT NOT NULL,
    "playerId" TEXT NOT NULL,
    "promotionId" TEXT,
    "bonusCode" TEXT,
    "amount" DOUBLE PRECISION NOT NULL,
    "wageringRequired" DOUBLE PRECISION NOT NULL,
    "wageringCompleted" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "status" TEXT NOT NULL DEFAULT 'active',
    "claimedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "expiresAt" TIMESTAMP(3)
,
    PRIMARY KEY ("id")

);

CREATE TABLE "Segment" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT,
    "rules" TEXT NOT NULL,
    "playerCount" INTEGER NOT NULL DEFAULT 0,
    "isDynamic" BOOLEAN NOT NULL DEFAULT true,
    "color" TEXT NOT NULL DEFAULT '#10b981',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL
,
    PRIMARY KEY ("id")

);

CREATE TABLE "Promotion" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "type" TEXT NOT NULL,
    "segmentId" TEXT,
    "bonusPercent" DOUBLE PRECISION,
    "maxAmount" DOUBLE PRECISION,
    "freeSpins" INTEGER,
    "wageringMultiplier" DOUBLE PRECISION NOT NULL DEFAULT 30,
    "minDeposit" DOUBLE PRECISION,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "startsAt" TIMESTAMP(3) NOT NULL,
    "endsAt" TIMESTAMP(3) NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL
,
    PRIMARY KEY ("id")

);

CREATE TABLE "PromotionStat" (
    "id" TEXT NOT NULL,
    "promotionId" TEXT NOT NULL,
    "claims" INTEGER NOT NULL DEFAULT 0,
    "conversions" INTEGER NOT NULL DEFAULT 0,
    "totalBonusGiven" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "totalWagered" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "revenue" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "periodDate" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
,
    PRIMARY KEY ("id")

);

CREATE TABLE "BonusCode" (
    "id" TEXT NOT NULL,
    "promotionId" TEXT NOT NULL,
    "code" TEXT NOT NULL,
    "maxUses" INTEGER,
    "currentUses" INTEGER NOT NULL DEFAULT 0,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "expiresAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
,
    PRIMARY KEY ("id")
,
    CONSTRAINT "BonusCode_code_key" UNIQUE ("code")

);

CREATE TABLE "WageringRequirement" (
    "id" TEXT NOT NULL,
    "playerBonusId" TEXT NOT NULL,
    "totalRequired" DOUBLE PRECISION NOT NULL,
    "totalCompleted" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "remaining" DOUBLE PRECISION NOT NULL,
    "gamesContrib" TEXT,
    "expiresAt" TIMESTAMP(3) NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL
,
    PRIMARY KEY ("id")

);

CREATE TABLE "ConversionTracking" (
    "id" TEXT NOT NULL,
    "promotionId" TEXT,
    "playerId" TEXT NOT NULL,
    "eventType" TEXT NOT NULL,
    "value" DOUBLE PRECISION,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
,
    PRIMARY KEY ("id")

);

CREATE TABLE "CronSchedule" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "taskType" TEXT NOT NULL,
    "cronExpression" TEXT NOT NULL,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "lastRunAt" TIMESTAMP(3),
    "nextRunAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL
,
    PRIMARY KEY ("id")

);

CREATE TABLE "AffiliateProfile" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "website" TEXT,
    "tier" TEXT NOT NULL DEFAULT 'bronze',
    "commissionRate" DOUBLE PRECISION NOT NULL DEFAULT 25,
    "totalEarnings" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "activePlayers" INTEGER NOT NULL DEFAULT 0,
    "status" TEXT NOT NULL DEFAULT 'active',
    "joinedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL
,
    PRIMARY KEY ("id")
,
    CONSTRAINT "AffiliateProfile_email_key" UNIQUE ("email")

);

CREATE TABLE "AffiliatePerformance" (
    "id" TEXT NOT NULL,
    "affiliateId" TEXT NOT NULL,
    "period" TEXT NOT NULL,
    "clicks" INTEGER NOT NULL DEFAULT 0,
    "signups" INTEGER NOT NULL DEFAULT 0,
    "ftd" INTEGER NOT NULL DEFAULT 0,
    "revenue" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
,
    PRIMARY KEY ("id")

);

CREATE TABLE "AffiliateCommission" (
    "id" TEXT NOT NULL,
    "affiliateId" TEXT NOT NULL,
    "amount" DOUBLE PRECISION NOT NULL,
    "source" TEXT NOT NULL,
    "periodMonth" TEXT NOT NULL,
    "isPaid" BOOLEAN NOT NULL DEFAULT false,
    "paidAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
,
    PRIMARY KEY ("id")

);

CREATE TABLE "AffiliateTier" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "minFtd" INTEGER NOT NULL,
    "minRevenue" DOUBLE PRECISION NOT NULL,
    "commissionRate" DOUBLE PRECISION NOT NULL,
    "bonusRate" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
,
    PRIMARY KEY ("id")

);

CREATE TABLE "ContractSignature" (
    "id" TEXT NOT NULL,
    "contractType" TEXT NOT NULL,
    "documentName" TEXT NOT NULL,
    "documentUrl" TEXT,
    "docusignId" TEXT,
    "signers" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'pending',
    "expiresAt" TIMESTAMP(3),
    "signedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL
,
    PRIMARY KEY ("id")

);

CREATE TABLE "AuditLog" (
    "id" TEXT NOT NULL,
    "userId" TEXT,
    "userRole" TEXT,
    "action" TEXT NOT NULL,
    "resource" TEXT NOT NULL,
    "resourceId" TEXT,
    "details" TEXT,
    "ipAddress" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
,
    PRIMARY KEY ("id")

);

CREATE TABLE "UserRole" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "role" TEXT NOT NULL,
    "permissions" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL
,
    PRIMARY KEY ("id")
,
    CONSTRAINT "UserRole_userId_key" UNIQUE ("userId")

);

CREATE TABLE "AITutorInstance" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "contextType" TEXT NOT NULL,
    "contextId" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL
,
    PRIMARY KEY ("id")

);

CREATE TABLE "AILog" (
    "id" TEXT NOT NULL,
    "model" TEXT NOT NULL,
    "prompt" TEXT NOT NULL,
    "response" TEXT NOT NULL,
    "tokensUsed" INTEGER,
    "latencyMs" INTEGER,
    "tutorInstanceId" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
,
    PRIMARY KEY ("id")

);

CREATE TABLE "AIModelMetric" (
    "id" TEXT NOT NULL,
    "modelName" TEXT NOT NULL,
    "version" TEXT NOT NULL,
    "accuracy" DOUBLE PRECISION,
    "avgLatencyMs" DOUBLE PRECISION,
    "totalRequests" INTEGER NOT NULL DEFAULT 0,
    "successRate" DOUBLE PRECISION,
    "periodDate" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
,
    PRIMARY KEY ("id")

);

CREATE TABLE "Wallet" (
    "id" TEXT NOT NULL,
    "playerId" TEXT NOT NULL,
    "currency" TEXT NOT NULL,
    "balance" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "availableBalance" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "lockedBalance" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "bonusBalance" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "isPrimary" BOOLEAN NOT NULL DEFAULT false,
    "status" TEXT NOT NULL DEFAULT 'active',
    "lastDepositAt" TIMESTAMP(3),
    "lastWithdrawAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL
,
    PRIMARY KEY ("id")

);

CREATE TABLE "WalletTransaction" (
    "id" TEXT NOT NULL,
    "walletId" TEXT NOT NULL,
    "type" TEXT NOT NULL,
    "amount" DOUBLE PRECISION NOT NULL,
    "balanceBefore" DOUBLE PRECISION NOT NULL,
    "balanceAfter" DOUBLE PRECISION NOT NULL,
    "currency" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'completed',
    "reference" TEXT,
    "gameId" TEXT,
    "gameName" TEXT,
    "promotionId" TEXT,
    "metadata" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
,
    PRIMARY KEY ("id")

);

CREATE TABLE "PaymentMethod" (
    "id" TEXT NOT NULL,
    "playerId" TEXT NOT NULL,
    "type" TEXT NOT NULL,
    "provider" TEXT NOT NULL,
    "label" TEXT NOT NULL,
    "identifier" TEXT,
    "isDefault" BOOLEAN NOT NULL DEFAULT false,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "currency" TEXT NOT NULL DEFAULT 'USD',
    "metadata" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL
,
    PRIMARY KEY ("id")

);

CREATE TABLE "PaymentProvider" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "type" TEXT NOT NULL,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "minDeposit" DOUBLE PRECISION NOT NULL DEFAULT 10,
    "maxDeposit" DOUBLE PRECISION NOT NULL DEFAULT 50000,
    "minWithdrawal" DOUBLE PRECISION NOT NULL DEFAULT 20,
    "maxWithdrawal" DOUBLE PRECISION NOT NULL DEFAULT 100000,
    "feePercent" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "feeFixed" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "processingTime" TEXT NOT NULL DEFAULT 'instant',
    "supportedCurrencies" TEXT NOT NULL,
    "logo" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL
,
    PRIMARY KEY ("id")

);

CREATE TABLE "DepositRequest" (
    "id" TEXT NOT NULL,
    "playerId" TEXT NOT NULL,
    "walletId" TEXT NOT NULL,
    "amount" DOUBLE PRECISION NOT NULL,
    "currency" TEXT NOT NULL,
    "method" TEXT NOT NULL,
    "provider" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'pending',
    "txHash" TEXT,
    "feeAmount" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "netAmount" DOUBLE PRECISION NOT NULL,
    "paymentMethodId" TEXT,
    "metadata" TEXT,
    "confirmedAt" TIMESTAMP(3),
    "expiresAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL
,
    PRIMARY KEY ("id")

);

CREATE TABLE "WithdrawalRequest" (
    "id" TEXT NOT NULL,
    "playerId" TEXT NOT NULL,
    "walletId" TEXT NOT NULL,
    "amount" DOUBLE PRECISION NOT NULL,
    "currency" TEXT NOT NULL,
    "method" TEXT NOT NULL,
    "provider" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'pending',
    "approvedBy" TEXT,
    "approvedAt" TIMESTAMP(3),
    "txHash" TEXT,
    "feeAmount" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "netAmount" DOUBLE PRECISION NOT NULL,
    "paymentMethodId" TEXT,
    "rejectionReason" TEXT,
    "metadata" TEXT,
    "processedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL
,
    PRIMARY KEY ("id")

);

CREATE TABLE "CurrencyRate" (
    "id" TEXT NOT NULL,
    "fromCurrency" TEXT NOT NULL,
    "toCurrency" TEXT NOT NULL,
    "rate" DOUBLE PRECISION NOT NULL,
    "source" TEXT NOT NULL DEFAULT 'api',
    "updatedAt" TIMESTAMP(3) NOT NULL
,
    PRIMARY KEY ("id")

);

CREATE TABLE "PlayerSession" (
    "id" TEXT NOT NULL,
    "playerId" TEXT NOT NULL,
    "gameId" TEXT NOT NULL,
    "gameName" TEXT NOT NULL,
    "ipAddress" TEXT,
    "country" TEXT,
    "city" TEXT,
    "latitude" DOUBLE PRECISION,
    "longitude" DOUBLE PRECISION,
    "deviceType" TEXT,
    "browser" TEXT,
    "os" TEXT,
    "entryPoint" TEXT,
    "wagerAmount" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "winAmount" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "spinsPlayed" INTEGER NOT NULL DEFAULT 0,
    "startedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "lastActivityAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "endedAt" TIMESTAMP(3),
    "status" TEXT NOT NULL DEFAULT 'active'
,
    PRIMARY KEY ("id")

);

CREATE TABLE "GeoLocation" (
    "id" TEXT NOT NULL,
    "playerId" TEXT NOT NULL,
    "country" TEXT NOT NULL,
    "countryCode" TEXT NOT NULL,
    "city" TEXT,
    "region" TEXT,
    "latitude" DOUBLE PRECISION NOT NULL,
    "longitude" DOUBLE PRECISION NOT NULL,
    "timezone" TEXT,
    "isp" TEXT,
    "isVpn" BOOLEAN NOT NULL DEFAULT false,
    "isProxy" BOOLEAN NOT NULL DEFAULT false,
    "isTor" BOOLEAN NOT NULL DEFAULT false,
    "detectedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL
,
    PRIMARY KEY ("id")

);

CREATE TABLE "LiveEvent" (
    "id" TEXT NOT NULL,
    "eventType" TEXT NOT NULL,
    "playerId" TEXT,
    "playerName" TEXT,
    "gameId" TEXT,
    "gameName" TEXT,
    "amount" DOUBLE PRECISION,
    "currency" TEXT,
    "country" TEXT,
    "countryCode" TEXT,
    "city" TEXT,
    "latitude" DOUBLE PRECISION,
    "longitude" DOUBLE PRECISION,
    "metadata" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
,
    PRIMARY KEY ("id")

);

CREATE TABLE "ServerNode" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "region" TEXT NOT NULL,
    "countryCode" TEXT NOT NULL,
    "latitude" DOUBLE PRECISION NOT NULL,
    "longitude" DOUBLE PRECISION NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'online',
    "activePlayers" INTEGER NOT NULL DEFAULT 0,
    "maxPlayers" INTEGER NOT NULL DEFAULT 10000,
    "cpuLoad" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "memoryLoad" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "latencyMs" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "uptime" DOUBLE PRECISION NOT NULL DEFAULT 99.9,
    "lastHeartbeat" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL
,
    PRIMARY KEY ("id")

);

CREATE TABLE "ApiToken" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "token" TEXT NOT NULL,
    "tokenPrefix" TEXT NOT NULL,
    "ownerId" TEXT NOT NULL,
    "scopes" TEXT NOT NULL,
    "rateLimit" INTEGER NOT NULL DEFAULT 1000,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "lastUsedAt" TIMESTAMP(3),
    "expiresAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL
,
    PRIMARY KEY ("id")
,
    CONSTRAINT "ApiToken_token_key" UNIQUE ("token")

);

CREATE TABLE "WebhookEndpoint" (
    "id" TEXT NOT NULL,
    "apiTokenId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "url" TEXT NOT NULL,
    "events" TEXT NOT NULL,
    "secret" TEXT NOT NULL,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "retryCount" INTEGER NOT NULL DEFAULT 3,
    "timeoutMs" INTEGER NOT NULL DEFAULT 5000,
    "lastTriggerAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL
,
    PRIMARY KEY ("id")

);

CREATE TABLE "WebhookDelivery" (
    "id" TEXT NOT NULL,
    "webhookId" TEXT NOT NULL,
    "eventId" TEXT NOT NULL,
    "payload" TEXT NOT NULL,
    "statusCode" INTEGER,
    "response" TEXT,
    "duration" INTEGER,
    "success" BOOLEAN NOT NULL,
    "attempt" INTEGER NOT NULL DEFAULT 1,
    "nextRetryAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
,
    PRIMARY KEY ("id")

);

CREATE TABLE "Integration" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "type" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'pending',
    "apiTokenId" TEXT,
    "config" TEXT NOT NULL,
    "syncStats" TEXT,
    "logo" TEXT,
    "lastSyncAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL
,
    PRIMARY KEY ("id")

);

CREATE TABLE "McpEndpoint" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "version" TEXT NOT NULL DEFAULT '1.0.0',
    "baseUrl" TEXT NOT NULL,
    "tools" TEXT NOT NULL,
    "resources" TEXT NOT NULL,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "requiresAuth" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL
,
    PRIMARY KEY ("id")

);

CREATE TABLE "ApiUsageLog" (
    "id" TEXT NOT NULL,
    "apiTokenId" TEXT NOT NULL,
    "endpoint" TEXT NOT NULL,
    "method" TEXT NOT NULL,
    "statusCode" INTEGER NOT NULL,
    "durationMs" INTEGER NOT NULL,
    "ipAddress" TEXT,
    "userAgent" TEXT,
    "error" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
,
    PRIMARY KEY ("id")

);

CREATE TABLE "Notification" (
    "id" TEXT NOT NULL,
    "userId" TEXT,
    "type" TEXT NOT NULL,
    "category" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "message" TEXT NOT NULL,
    "metadata" TEXT,
    "isRead" BOOLEAN NOT NULL DEFAULT false,
    "readAt" TIMESTAMP(3),
    "channel" TEXT NOT NULL DEFAULT 'in_app',
    "priority" TEXT NOT NULL DEFAULT 'normal',
    "expiresAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
,
    PRIMARY KEY ("id")

);

CREATE TABLE "NotificationPreference" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "category" TEXT NOT NULL,
    "channel" TEXT NOT NULL,
    "isEnabled" BOOLEAN NOT NULL DEFAULT true,
    "minPriority" TEXT NOT NULL DEFAULT 'normal',
    "quietHoursStart" TEXT,
    "quietHoursEnd" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL
,
    PRIMARY KEY ("id")

);

CREATE TABLE "NotificationTemplate" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "category" TEXT NOT NULL,
    "titleTemplate" TEXT NOT NULL,
    "bodyTemplate" TEXT NOT NULL,
    "channel" TEXT NOT NULL DEFAULT 'in_app',
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL
,
    PRIMARY KEY ("id")

);

CREATE TABLE "NotificationChannel" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "type" TEXT NOT NULL,
    "config" TEXT NOT NULL,
    "isVerified" BOOLEAN NOT NULL DEFAULT false,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL
,
    PRIMARY KEY ("id")

);

CREATE TABLE "GameProvider" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "slug" TEXT NOT NULL,
    "type" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'pending',
    "logoUrl" TEXT,
    "website" TEXT,
    "description" TEXT,
    "integrationType" TEXT NOT NULL DEFAULT 'api',
    "apiVersion" TEXT,
    "baseUrl" TEXT,
    "callbackUrl" TEXT,
    "secretKey" TEXT,
    "apiKey" TEXT,
    "allowedIps" TEXT,
    "supportedCurrencies" TEXT,
    "supportedLocales" TEXT,
    "maxConcurrentSessions" INTEGER NOT NULL DEFAULT 5000,
    "defaultRtp" DOUBLE PRECISION,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "isCertified" BOOLEAN NOT NULL DEFAULT false,
    "certifiedAt" TIMESTAMP(3),
    "lastHealthCheck" TIMESTAMP(3),
    "totalGames" INTEGER NOT NULL DEFAULT 0,
    "activeGames" INTEGER NOT NULL DEFAULT 0,
    "activePlayers" INTEGER NOT NULL DEFAULT 0,
    "monthlyRevenue" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "errorRate" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "avgLatencyMs" INTEGER NOT NULL DEFAULT 0,
    "uptime" DOUBLE PRECISION NOT NULL DEFAULT 99.9,
    "joinedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL
,
    PRIMARY KEY ("id")
,
    CONSTRAINT "GameProvider_slug_key" UNIQUE ("slug")

);

CREATE TABLE "ProviderGame" (
    "id" TEXT NOT NULL,
    "providerId" TEXT NOT NULL,
    "externalId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "slug" TEXT NOT NULL,
    "type" TEXT NOT NULL,
    "category" TEXT,
    "subCategory" TEXT,
    "coverUrl" TEXT,
    "demoUrl" TEXT,
    "rtp" DOUBLE PRECISION,
    "volatility" TEXT,
    "hitFrequency" DOUBLE PRECISION,
    "maxWin" DOUBLE PRECISION,
    "maxBet" DOUBLE PRECISION,
    "minBet" DOUBLE PRECISION,
    "defaultBet" DOUBLE PRECISION,
    "lines" INTEGER,
    "features" TEXT,
    "supportedCurrencies" TEXT,
    "supportedLocales" TEXT,
    "isMobile" BOOLEAN NOT NULL DEFAULT true,
    "isDesktop" BOOLEAN NOT NULL DEFAULT true,
    "isLandscape" BOOLEAN NOT NULL DEFAULT true,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "isFeatured" BOOLEAN NOT NULL DEFAULT false,
    "isNew" BOOLEAN NOT NULL DEFAULT false,
    "launchDate" TIMESTAMP(3),
    "totalBets" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "totalWins" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "totalSessions" INTEGER NOT NULL DEFAULT 0,
    "avgSessionMin" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "popularityScore" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL
,
    PRIMARY KEY ("id")

);

CREATE TABLE "ProviderCallback" (
    "id" TEXT NOT NULL,
    "providerId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "eventType" TEXT NOT NULL,
    "url" TEXT NOT NULL,
    "method" TEXT NOT NULL DEFAULT 'POST',
    "authType" TEXT NOT NULL DEFAULT 'hmac',
    "secretKey" TEXT,
    "ipWhitelist" TEXT,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "retryPolicy" TEXT,
    "timeoutMs" INTEGER NOT NULL DEFAULT 5000,
    "lastReceivedAt" TIMESTAMP(3),
    "lastSuccessAt" TIMESTAMP(3),
    "totalReceived" INTEGER NOT NULL DEFAULT 0,
    "totalSuccess" INTEGER NOT NULL DEFAULT 0,
    "totalFailed" INTEGER NOT NULL DEFAULT 0,
    "avgProcessingMs" INTEGER NOT NULL DEFAULT 0,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL
,
    PRIMARY KEY ("id")

);

CREATE TABLE "ProviderCredential" (
    "id" TEXT NOT NULL,
    "providerId" TEXT NOT NULL,
    "environment" TEXT NOT NULL,
    "apiKey" TEXT,
    "apiSecret" TEXT,
    "bearerToken" TEXT,
    "certPath" TEXT,
    "additional" TEXT,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "lastUsedAt" TIMESTAMP(3),
    "expiresAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL
,
    PRIMARY KEY ("id")

);

CREATE TABLE "ProviderHealthLog" (
    "id" TEXT NOT NULL,
    "providerId" TEXT NOT NULL,
    "metric" TEXT NOT NULL,
    "value" DOUBLE PRECISION NOT NULL,
    "unit" TEXT NOT NULL,
    "threshold" DOUBLE PRECISION,
    "isAlert" BOOLEAN NOT NULL DEFAULT false,
    "details" TEXT,
    "checkedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
,
    PRIMARY KEY ("id")

);

CREATE TABLE "Casino" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "slug" TEXT NOT NULL,
    "domain" TEXT,
    "logo" TEXT,
    "status" TEXT NOT NULL DEFAULT 'pending',
    "plan" TEXT NOT NULL DEFAULT 'starter',
    "config" TEXT,
    "settings" TEXT,
    "maxPlayers" INTEGER NOT NULL DEFAULT 1000,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL
,
    PRIMARY KEY ("id")
,
    CONSTRAINT "Casino_slug_key" UNIQUE ("slug")
,
    CONSTRAINT "Casino_domain_key" UNIQUE ("domain")

);

CREATE TABLE "User" (
    "id" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "passwordHash" TEXT,
    "name" TEXT,
    "role" TEXT NOT NULL DEFAULT 'viewer',
    "casinoId" TEXT,
    "image" TEXT,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "lastLoginAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL
,
    PRIMARY KEY ("id")
,
    CONSTRAINT "User_email_key" UNIQUE ("email")

);

CREATE TABLE "UserSession" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "token" TEXT NOT NULL,
    "ipAddress" TEXT,
    "userAgent" TEXT,
    "expiresAt" TIMESTAMP(3) NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
,
    PRIMARY KEY ("id")
,
    CONSTRAINT "UserSession_token_key" UNIQUE ("token")

);

CREATE TABLE "RolePermission" (
    "id" TEXT NOT NULL,
    "role" TEXT NOT NULL,
    "resource" TEXT NOT NULL,
    "actions" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL
,
    PRIMARY KEY ("id")

);

CREATE TABLE "Subscription" (
    "id" TEXT NOT NULL,
    "casinoId" TEXT NOT NULL,
    "stripeCustomerId" TEXT,
    "stripeSubscriptionId" TEXT,
    "plan" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'incomplete',
    "currentPeriodStart" TIMESTAMP(3),
    "currentPeriodEnd" TIMESTAMP(3),
    "cancelAtPeriodEnd" BOOLEAN NOT NULL DEFAULT false,
    "trialEndsAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL
,
    PRIMARY KEY ("id")
,
    CONSTRAINT "Subscription_stripeCustomerId_key" UNIQUE ("stripeCustomerId")
,
    CONSTRAINT "Subscription_stripeSubscriptionId_key" UNIQUE ("stripeSubscriptionId")

);

CREATE TABLE "Invoice" (
    "id" TEXT NOT NULL,
    "subscriptionId" TEXT NOT NULL,
    "stripeInvoiceId" TEXT,
    "amount" DOUBLE PRECISION NOT NULL,
    "currency" TEXT NOT NULL DEFAULT 'USD',
    "status" TEXT NOT NULL DEFAULT 'draft',
    "description" TEXT,
    "pdfUrl" TEXT,
    "paidAt" TIMESTAMP(3),
    "dueDate" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL
,
    PRIMARY KEY ("id")
,
    CONSTRAINT "Invoice_stripeInvoiceId_key" UNIQUE ("stripeInvoiceId")

);

CREATE TABLE "Payment" (
    "id" TEXT NOT NULL,
    "subscriptionId" TEXT NOT NULL,
    "stripePaymentId" TEXT,
    "amount" DOUBLE PRECISION NOT NULL,
    "currency" TEXT NOT NULL DEFAULT 'USD',
    "status" TEXT NOT NULL DEFAULT 'pending',
    "method" TEXT,
    "receiptUrl" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
,
    PRIMARY KEY ("id")
,
    CONSTRAINT "Payment_stripePaymentId_key" UNIQUE ("stripePaymentId")

);

CREATE TABLE "PlanFeature" (
    "id" TEXT NOT NULL,
    "plan" TEXT NOT NULL,
    "feature" TEXT NOT NULL,
    "isEnabled" BOOLEAN NOT NULL DEFAULT true,
    "limit" INTEGER,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
,
    PRIMARY KEY ("id")

);

CREATE TABLE "CryptoWallet" (
    "id" TEXT NOT NULL,
    "address" TEXT NOT NULL,
    "network" TEXT NOT NULL,
    "type" TEXT NOT NULL,
    "label" TEXT NOT NULL,
    "balance" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "balanceUsd" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "currency" TEXT NOT NULL DEFAULT 'ETH',
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "isVerified" BOOLEAN NOT NULL DEFAULT false,
    "lastSyncAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL
,
    PRIMARY KEY ("id")
,
    CONSTRAINT "CryptoWallet_address_key" UNIQUE ("address")

);

CREATE TABLE "BlockchainTransaction" (
    "id" TEXT NOT NULL,
    "walletId" TEXT NOT NULL,
    "txHash" TEXT,
    "type" TEXT NOT NULL,
    "fromAddress" TEXT,
    "toAddress" TEXT,
    "amount" DOUBLE PRECISION NOT NULL,
    "currency" TEXT NOT NULL,
    "amountUsd" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "gasFee" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "gasFeeUsd" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "blockNumber" INTEGER,
    "confirmations" INTEGER NOT NULL DEFAULT 0,
    "status" TEXT NOT NULL DEFAULT 'pending',
    "metadata" TEXT,
    "confirmedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL
,
    PRIMARY KEY ("id")
,
    CONSTRAINT "BlockchainTransaction_txHash_key" UNIQUE ("txHash")

);

CREATE TABLE "BlockchainNetwork" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "chainId" INTEGER,
    "symbol" TEXT NOT NULL,
    "type" TEXT NOT NULL,
    "rpcUrl" TEXT NOT NULL,
    "explorerUrl" TEXT NOT NULL,
    "isSupported" BOOLEAN NOT NULL DEFAULT true,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL
,
    PRIMARY KEY ("id")

);

CREATE TABLE "SmartContract" (
    "id" TEXT NOT NULL,
    "networkId" TEXT NOT NULL,
    "address" TEXT NOT NULL,
    "type" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "abi" TEXT,
    "isVerified" BOOLEAN NOT NULL DEFAULT false,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "deployedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL
,
    PRIMARY KEY ("id")

);

CREATE TABLE "MLModel" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "type" TEXT NOT NULL,
    "algorithm" TEXT NOT NULL,
    "version" TEXT NOT NULL DEFAULT '1.0.0',
    "status" TEXT NOT NULL DEFAULT 'draft',
    "accuracy" DOUBLE PRECISION,
    "precision" DOUBLE PRECISION,
    "recall" DOUBLE PRECISION,
    "f1Score" DOUBLE PRECISION,
    "features" TEXT NOT NULL,
    "hyperparams" TEXT,
    "trainingDataSize" INTEGER,
    "lastTrainedAt" TIMESTAMP(3),
    "deployedAt" TIMESTAMP(3),
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL
,
    PRIMARY KEY ("id")

);

CREATE TABLE "MLPrediction" (
    "id" TEXT NOT NULL,
    "modelId" TEXT NOT NULL,
    "input" TEXT NOT NULL,
    "output" TEXT NOT NULL,
    "confidence" DOUBLE PRECISION NOT NULL,
    "entityId" TEXT,
    "entityType" TEXT,
    "executedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "durationMs" INTEGER NOT NULL DEFAULT 0,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
,
    PRIMARY KEY ("id")

);

CREATE TABLE "MLTrainingJob" (
    "id" TEXT NOT NULL,
    "modelId" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'queued',
    "progress" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "startDate" TIMESTAMP(3),
    "endDate" TIMESTAMP(3),
    "duration" INTEGER,
    "metrics" TEXT,
    "error" TEXT,
    "config" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL
,
    PRIMARY KEY ("id")

);

CREATE TABLE "MLFeatureStore" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT,
    "schema" TEXT NOT NULL,
    "source" TEXT NOT NULL,
    "refreshInterval" INTEGER,
    "lastRefreshAt" TIMESTAMP(3),
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL
,
    PRIMARY KEY ("id")

);

CREATE TABLE "PlatformEvent" (
    "id" TEXT NOT NULL,
    "eventId" TEXT NOT NULL,
    "type" TEXT NOT NULL,
    "source" TEXT NOT NULL,
    "payload" TEXT NOT NULL,
    "receivedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
,
    PRIMARY KEY ("id")
,
    CONSTRAINT "PlatformEvent_eventId_key" UNIQUE ("eventId")

);

CREATE TABLE "CmsPromotion" (
    "id" TEXT NOT NULL,
    "title" TEXT NOT NULL DEFAULT '',
    "subtitle" TEXT NOT NULL DEFAULT '',
    "cta" TEXT NOT NULL DEFAULT 'Play',
    "imageUrl" TEXT NOT NULL DEFAULT '',
    "target" TEXT NOT NULL DEFAULT '',
    "accent" BOOLEAN NOT NULL DEFAULT false,
    "sortOrder" INTEGER NOT NULL DEFAULT 0,
    "active" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL
,
    PRIMARY KEY ("id")

);

CREATE TABLE "CmsGame" (
    "id" TEXT NOT NULL,
    "gameId" TEXT NOT NULL,
    "name" TEXT NOT NULL DEFAULT '',
    "tagline" TEXT NOT NULL DEFAULT '',
    "description" TEXT NOT NULL DEFAULT '',
    "provider" TEXT NOT NULL DEFAULT 'TOLS',
    "category" TEXT NOT NULL DEFAULT 'originals',
    "imageUrl" TEXT NOT NULL DEFAULT '',
    "sortOrder" INTEGER NOT NULL DEFAULT 0,
    "featured" BOOLEAN NOT NULL DEFAULT false,
    "isNew" BOOLEAN NOT NULL DEFAULT false,
    "active" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL
,
    PRIMARY KEY ("id")
,
    CONSTRAINT "CmsGame_gameId_key" UNIQUE ("gameId")

);

CREATE TABLE "KycCase" (
    "id" TEXT NOT NULL,
    "playerName" TEXT NOT NULL,
    "email" TEXT NOT NULL DEFAULT '',
    "country" TEXT NOT NULL DEFAULT '',
    "status" TEXT NOT NULL DEFAULT 'pending',
    "risk" TEXT NOT NULL DEFAULT 'low',
    "documents" TEXT NOT NULL DEFAULT '[]',
    "submittedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "reviewedAt" TIMESTAMP(3),
    "notes" TEXT NOT NULL DEFAULT '',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL
,
    PRIMARY KEY ("id")

);

CREATE TABLE "AmlFlag" (
    "id" TEXT NOT NULL,
    "playerName" TEXT NOT NULL,
    "type" TEXT NOT NULL DEFAULT 'aml',
    "severity" TEXT NOT NULL DEFAULT 'medium',
    "detail" TEXT NOT NULL DEFAULT '',
    "status" TEXT NOT NULL DEFAULT 'open',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL
,
    PRIMARY KEY ("id")

);

-- Foreign keys
ALTER TABLE "CasinoDeposit" ADD CONSTRAINT "CasinoDeposit_playerId_fkey" FOREIGN KEY ("playerId") REFERENCES "PlayerProfile"("id");
ALTER TABLE "TotalWithdrawal" ADD CONSTRAINT "TotalWithdrawal_playerId_fkey" FOREIGN KEY ("playerId") REFERENCES "PlayerProfile"("id");
ALTER TABLE "CommissionLog" ADD CONSTRAINT "CommissionLog_affiliateId_fkey" FOREIGN KEY ("affiliateId") REFERENCES "AffiliateProfile"("id");
ALTER TABLE "SettlementLog" ADD CONSTRAINT "SettlementLog_escrowId_fkey" FOREIGN KEY ("escrowId") REFERENCES "EscrowAccount"("id");
ALTER TABLE "PlayerNote" ADD CONSTRAINT "PlayerNote_playerId_fkey" FOREIGN KEY ("playerId") REFERENCES "PlayerProfile"("id");
ALTER TABLE "PlayerSegmentAssignment" ADD CONSTRAINT "PlayerSegmentAssignment_playerId_fkey" FOREIGN KEY ("playerId") REFERENCES "PlayerProfile"("id");
ALTER TABLE "PlayerSegmentAssignment" ADD CONSTRAINT "PlayerSegmentAssignment_segmentId_fkey" FOREIGN KEY ("segmentId") REFERENCES "Segment"("id");
ALTER TABLE "PlayerTimeline" ADD CONSTRAINT "PlayerTimeline_playerId_fkey" FOREIGN KEY ("playerId") REFERENCES "PlayerProfile"("id");
ALTER TABLE "PlayerBonusHistory" ADD CONSTRAINT "PlayerBonusHistory_playerId_fkey" FOREIGN KEY ("playerId") REFERENCES "PlayerProfile"("id");
ALTER TABLE "Promotion" ADD CONSTRAINT "Promotion_segmentId_fkey" FOREIGN KEY ("segmentId") REFERENCES "Segment"("id");
ALTER TABLE "PromotionStat" ADD CONSTRAINT "PromotionStat_promotionId_fkey" FOREIGN KEY ("promotionId") REFERENCES "Promotion"("id");
ALTER TABLE "BonusCode" ADD CONSTRAINT "BonusCode_promotionId_fkey" FOREIGN KEY ("promotionId") REFERENCES "Promotion"("id");
ALTER TABLE "AffiliatePerformance" ADD CONSTRAINT "AffiliatePerformance_affiliateId_fkey" FOREIGN KEY ("affiliateId") REFERENCES "AffiliateProfile"("id");
ALTER TABLE "Wallet" ADD CONSTRAINT "Wallet_playerId_fkey" FOREIGN KEY ("playerId") REFERENCES "PlayerProfile"("id");
ALTER TABLE "WalletTransaction" ADD CONSTRAINT "WalletTransaction_walletId_fkey" FOREIGN KEY ("walletId") REFERENCES "Wallet"("id");
ALTER TABLE "PaymentMethod" ADD CONSTRAINT "PaymentMethod_playerId_fkey" FOREIGN KEY ("playerId") REFERENCES "PlayerProfile"("id");
ALTER TABLE "DepositRequest" ADD CONSTRAINT "DepositRequest_playerId_fkey" FOREIGN KEY ("playerId") REFERENCES "PlayerProfile"("id");
ALTER TABLE "WithdrawalRequest" ADD CONSTRAINT "WithdrawalRequest_playerId_fkey" FOREIGN KEY ("playerId") REFERENCES "PlayerProfile"("id");
ALTER TABLE "PlayerSession" ADD CONSTRAINT "PlayerSession_playerId_fkey" FOREIGN KEY ("playerId") REFERENCES "PlayerProfile"("id");
ALTER TABLE "WebhookEndpoint" ADD CONSTRAINT "WebhookEndpoint_apiTokenId_fkey" FOREIGN KEY ("apiTokenId") REFERENCES "ApiToken"("id");
ALTER TABLE "WebhookDelivery" ADD CONSTRAINT "WebhookDelivery_webhookId_fkey" FOREIGN KEY ("webhookId") REFERENCES "WebhookEndpoint"("id");
ALTER TABLE "ApiUsageLog" ADD CONSTRAINT "ApiUsageLog_apiTokenId_fkey" FOREIGN KEY ("apiTokenId") REFERENCES "ApiToken"("id");
ALTER TABLE "ProviderGame" ADD CONSTRAINT "ProviderGame_providerId_fkey" FOREIGN KEY ("providerId") REFERENCES "GameProvider"("id");
ALTER TABLE "ProviderCallback" ADD CONSTRAINT "ProviderCallback_providerId_fkey" FOREIGN KEY ("providerId") REFERENCES "GameProvider"("id");
ALTER TABLE "ProviderCredential" ADD CONSTRAINT "ProviderCredential_providerId_fkey" FOREIGN KEY ("providerId") REFERENCES "GameProvider"("id");
ALTER TABLE "ProviderHealthLog" ADD CONSTRAINT "ProviderHealthLog_providerId_fkey" FOREIGN KEY ("providerId") REFERENCES "GameProvider"("id");
ALTER TABLE "User" ADD CONSTRAINT "User_casinoId_fkey" FOREIGN KEY ("casinoId") REFERENCES "Casino"("id");
ALTER TABLE "UserSession" ADD CONSTRAINT "UserSession_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id");
ALTER TABLE "Subscription" ADD CONSTRAINT "Subscription_casinoId_fkey" FOREIGN KEY ("casinoId") REFERENCES "Casino"("id");
ALTER TABLE "Invoice" ADD CONSTRAINT "Invoice_subscriptionId_fkey" FOREIGN KEY ("subscriptionId") REFERENCES "Subscription"("id");
ALTER TABLE "Payment" ADD CONSTRAINT "Payment_subscriptionId_fkey" FOREIGN KEY ("subscriptionId") REFERENCES "Subscription"("id");
ALTER TABLE "BlockchainTransaction" ADD CONSTRAINT "BlockchainTransaction_walletId_fkey" FOREIGN KEY ("walletId") REFERENCES "CryptoWallet"("id");
ALTER TABLE "MLPrediction" ADD CONSTRAINT "MLPrediction_modelId_fkey" FOREIGN KEY ("modelId") REFERENCES "MLModel"("id");
ALTER TABLE "MLTrainingJob" ADD CONSTRAINT "MLTrainingJob_modelId_fkey" FOREIGN KEY ("modelId") REFERENCES "MLModel"("id");

CREATE INDEX "PlatformEvent_type_idx" ON "PlatformEvent"("type");
CREATE INDEX "PlatformEvent_source_idx" ON "PlatformEvent"("source");
CREATE INDEX "CmsPromotion_active_sortOrder_idx" ON "CmsPromotion"("active", "sortOrder");
CREATE INDEX "CmsGame_active_featured_sortOrder_idx" ON "CmsGame"("active", "featured", "sortOrder");
CREATE INDEX "KycCase_status_idx" ON "KycCase"("status");
CREATE INDEX "AmlFlag_status_severity_idx" ON "AmlFlag"("status", "severity");

COMMIT;

