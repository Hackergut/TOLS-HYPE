import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: process.env.STANDALONE === "1" ? "standalone" : undefined,
  /* config options here */
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  // Allow the Arena live-preview proxy origin during development (dev only).
  allowedDevOrigins: ["*.e2b.app"],
  // Load the WASM Postgres (PGlite) + driver adapter from node_modules at
  // runtime (they read a bundled .wasm from disk via fs), instead of bundling.
  serverExternalPackages: ["@electric-sql/pglite", "prisma-pglite"],
};

export default nextConfig;
