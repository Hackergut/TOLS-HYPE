#!/usr/bin/env node
// ─────────────────────────────────────────────────────────────────────────────
// One-shot bridge setup: generates the two RSA-3072 keypairs (Governance + a
// fresh casino pair if needed) and prints the exact .env blocks to paste on
// each side, plus the Telegram operator-bot block. Zero dependencies.
//
//   node scripts/bridge-setup.mjs
//
// This only GENERATES and PRINTS — it writes nothing to disk except (with
// --out <dir>) optional .env snippets for review. You paste the values into
// Vercel / Dokploy / telegram-bot/.env yourself.
// ─────────────────────────────────────────────────────────────────────────────

import { generateKeyPairSync, randomBytes } from "node:crypto";
import { writeFileSync, mkdirSync } from "node:fs";

const b64 = (pem) => Buffer.from(pem, "utf8").toString("base64");
const hex = (bytes) => randomBytes(bytes).toString("hex");

function keypair() {
  const { privateKey, publicKey } = generateKeyPairSync("rsa", {
    modulusLength: 3072,
    publicKeyEncoding: { type: "spki", format: "pem" },
    privateKeyEncoding: { type: "pkcs8", format: "pem" },
  });
  return { privateKey: b64(privateKey), publicKey: b64(publicKey) };
}

const governance = keypair();
const casino = keypair();
const bridgeSecret = hex(32);
const govAdminToken = hex(32);

const govBlock = `# ── TOLS GOVERNANCE (.env) ──
PLATFORM_ID=tols-governance
PLATFORM_PRIVATE_KEY=${governance.privateKey}
PLATFORM_PUBLIC_KEY=${governance.publicKey}
PARTNER_PLATFORM_ID=tols-casino
PARTNER_PUBLIC_KEY=${casino.publicKey}
PARTNER_BASE_URL=https://www.tols.fun

GOVERNANCE_BRIDGE_SECRET=${bridgeSecret}
GOVERNANCE_ADMIN_TOKEN=${govAdminToken}
`;

const casinoBlock = `# ── TOLS CASINO (.env) ──
PLATFORM_ID=tols-casino
PLATFORM_PRIVATE_KEY=${casino.privateKey}
PLATFORM_PUBLIC_KEY=${casino.publicKey}
PARTNER_PLATFORM_ID=tols-governance
PARTNER_PUBLIC_KEY=${governance.publicKey}
PARTNER_BASE_URL=https://gov.tols.fun

GOVERNANCE_BRIDGE_SECRET=${bridgeSecret}
# The casino also verifies the Tower's JWT with the governance public key:
PLATFORM_JWT_PUBLIC_KEY=${governance.publicKey}
PLATFORM_JWT_ISSUER=tols-governance
PLATFORM_JWT_AUDIENCE=tols-casino

# Operator Telegram alerts (casino → private chat):
TELEGRAM_BOT_TOKEN=<from @BotFather>
TELEGRAM_CHAT_ID=<private chat id>
`;

const botBlock = `# ── TOLS OPERATOR TELEGRAM BOT (telegram-bot/.env) ──
TELEGRAM_BOT_TOKEN=<from @BotFather>
TELEGRAM_ADMIN_IDS=<your numeric Telegram id>
GOVERNANCE_URL=https://gov.tols.fun
GOVERNANCE_ADMIN_TOKEN=${govAdminToken}
`;

console.log("\n═══════════════ 1. TOLS GOVERNANCE (.env) ═══════════════\n" + govBlock);
console.log("═══════════════ 2. TOLS CASINO (.env) ═══════════════\n" + casinoBlock);
console.log("═══════════════ 3. OPERATOR TELEGRAM BOT (telegram-bot/.env) ═══════════════\n" + botBlock);
console.log("Steps:");
console.log("  1. Paste block 1 into Governance env, block 2 into Casino env (Vercel → Settings → Environment Variables → Redeploy).");
console.log("  2. Create the bot with @BotFather, put its token + your Telegram id into block 3.");
console.log("  3. Verify: curl https://www.tols.fun/api/platform/health  and  Governance /api/platform/status.");

const out = process.argv.indexOf("--out");
if (out !== -1 && process.argv[out + 1]) {
  const dir = process.argv[out + 1];
  mkdirSync(dir, { recursive: true });
  writeFileSync(`${dir}/governance.env`, govBlock);
  writeFileSync(`${dir}/casino.env`, casinoBlock);
  writeFileSync(`${dir}/operator-bot.env`, botBlock);
  console.log(`\nWrote env snippets to ${dir}/ (governance.env, casino.env, operator-bot.env)`);
}
