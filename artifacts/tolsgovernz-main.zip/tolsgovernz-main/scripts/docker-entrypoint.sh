#!/bin/sh
# TOLS Governance container entrypoint.
# 1. Syncs the PostgreSQL schema (idempotent; creates tables on an empty DB).
# 2. Starts the Next.js standalone server.
set -e

echo "[entrypoint] syncing Prisma schema…"
# --skip-generate: client already generated at build time.
# --accept-data-loss: keeps the push non-interactive. For a production DB with
# real data, prefer `prisma migrate` instead (see docs/DEPLOY.md).
npx prisma db push --skip-generate --accept-data-loss

echo "[entrypoint] starting server…"
exec node server.js
