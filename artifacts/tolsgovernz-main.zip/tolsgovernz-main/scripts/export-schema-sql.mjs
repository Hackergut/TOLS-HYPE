#!/usr/bin/env node
// export-schema-sql.mjs — generate PostgreSQL DDL from prisma/schema.prisma.
//
// Pure Node (no deps, no Prisma engine). This lets an operator create the
// schema from a browser SQL editor (Supabase/Neon/Vercel) without running
// `prisma db push` on a machine. Identifiers are quoted exactly like Prisma
// does, so the generated tables match what Prisma Client expects.
//
// Foreign keys are emitted AFTER all tables (like pg_dump), because Postgres
// requires a referenced table to exist before the referencing FK.
//
// Usage: node scripts/export-schema-sql.mjs > docs/schema.postgres.sql
import { readFileSync } from "node:fs";

const SCHEMA_PATH = new URL("../prisma/schema.prisma", import.meta.url).pathname;

const SCALARS = new Set([
  "String", "Int", "Float", "Boolean", "DateTime", "BigInt", "Decimal", "Json", "Bytes",
]);

const TYPE_MAP = {
  String: "TEXT",
  Int: "INTEGER",
  Float: "DOUBLE PRECISION",
  Boolean: "BOOLEAN",
  DateTime: "TIMESTAMP(3)",
  BigInt: "BIGINT",
  Decimal: "DECIMAL(65,30)",
  Json: "JSONB",
  Bytes: "BYTEA",
};

const src = readFileSync(SCHEMA_PATH, "utf8");
const lines = src.split("\n");

const models = [];
let current = null;

const modelRe = /^model\s+(\w+)\s*\{/;
const enumRe = /^enum\s+(\w+)\s*\{/;

for (const raw of lines) {
  const line = raw.trim();
  if (!line || line.startsWith("//")) continue;

  const m = line.match(modelRe);
  if (m) {
    current = { name: m[1], fields: [], blocks: [] };
    models.push(current);
    continue;
  }
  if (enumRe.test(line)) {
    current = null; // no enums in this schema
    continue;
  }
  if (line === "}") {
    current = null;
    continue;
  }
  if (!current) continue;

  if (line.startsWith("@@")) {
    current.blocks.push(line);
    continue;
  }

  // Field line: name Type[?][] attributes…
  const fm = line.match(/^(\w+)\s+(\w+)(\?|\[\])?\s*(.*)$/);
  if (!fm) continue;
  const [, name, type, modifier, attrs] = fm;
  current.fields.push({ name, type, modifier: modifier || "", attrs: attrs || "" });
}

// ── Emission helpers ─────────────────────────────────────────────────────────
function defaultValue(attrs) {
  const d = attrs.match(/@default\((\w+\(\)|"[^"]*"|[^)]+)\)/);
  if (!d) return null;
  const inner = d[1].trim();
  if (inner === "now()") return "CURRENT_TIMESTAMP";
  if (inner === "cuid()" || inner === "uuid()" || inner === "autoincrement()") return "__CLIENT__";
  if (/^".*"$/.test(inner)) {
    const s = inner.slice(1, -1).replace(/'/g, "''");
    return `'${s}'`;
  }
  if (/^(true|false|\d+(\.\d+)?)$/.test(inner)) return inner;
  return null; // unknown default — skip rather than emit invalid SQL
}

const sql = [];
sql.push("-- Generated from prisma/schema.prisma by scripts/export-schema-sql.mjs");
sql.push("-- Paste this whole file into the Supabase/Neon/Vercel SQL editor to create");
sql.push("-- the Governance schema without running `prisma db push`.");
sql.push("");
sql.push("BEGIN;");
sql.push("");

const fkStatements = [];

for (const model of models) {
  const cols = [];
  const pk = [];
  const uniques = [];

  for (const f of model.fields) {
    if (!SCALARS.has(f.type)) {
      // Relation object/list — no column, but maybe a FK (from the object side).
      const rel = f.attrs.match(/@relation\(fields:\s*\[(\w+)\],\s*references:\s*\[(\w+)\]\)/);
      if (rel) {
        fkStatements.push({
          table: model.name,
          col: rel[1],
          refTable: f.type,
          refCol: rel[2],
        });
      }
      continue;
    }
    const sqlType = TYPE_MAP[f.type] || "TEXT";
    const nullable = f.modifier === "?";
    let def = "";
    const dv = defaultValue(f.attrs);
    if (dv === "__CLIENT__") def = ""; // cuid()/uuid()/autoincrement() — client/identity side
    else if (dv) def = ` DEFAULT ${dv}`;
    const notNull = nullable ? "" : " NOT NULL";
    cols.push(`    "${f.name}" ${sqlType}${notNull}${def}`);

    if (/\s@id\b/.test(" " + f.attrs)) pk.push(f.name);
    if (/\s@unique\b/.test(" " + f.attrs)) uniques.push([f.name]);
  }

  for (const b of model.blocks) {
    const idm = b.match(/@@id\(\[([^\]]+)\]\)/);
    if (idm) pk.push(...idm[1].split(",").map((s) => s.trim()));
    const um = b.match(/@@unique\(\[([^\]]+)\]\)/);
    if (um) uniques.push(um[1].split(",").map((s) => s.trim()));
  }

  sql.push(`CREATE TABLE "${model.name}" (`);
  sql.push(cols.join(",\n"));
  if (pk.length) sql.push(`,\n    PRIMARY KEY (${pk.map((c) => `"${c}"`).join(", ")})`);
  for (const u of uniques) {
    sql.push(`,\n    CONSTRAINT "${model.name}_${u.join("_")}_key" UNIQUE (${u.map((c) => `"${c}"`).join(", ")})`);
  }
  sql.push("\n);");
  sql.push("");
}

// ── Foreign keys (after all tables exist) ───────────────────────────────────
if (fkStatements.length) {
  sql.push("-- Foreign keys");
  for (const fk of fkStatements) {
    sql.push(
      `ALTER TABLE "${fk.table}" ADD CONSTRAINT "${fk.table}_${fk.col}_fkey" FOREIGN KEY ("${fk.col}") REFERENCES "${fk.refTable}"("${fk.refCol}");`
    );
  }
  sql.push("");
}

// ── Indexes ──────────────────────────────────────────────────────────────────
for (const model of models) {
  for (const b of model.blocks) {
    const im = b.match(/@@index\(\[([^\]]+)\]\)/);
    if (im) {
      const cols = im[1].split(",").map((s) => s.trim());
      sql.push(`CREATE INDEX "${model.name}_${cols.join("_")}_idx" ON "${model.name}"(${cols.map((c) => `"${c}"`).join(", ")});`);
    }
  }
}
if (models.some((m) => m.blocks.some((b) => /@@index/.test(b)))) sql.push("");

sql.push("COMMIT;");
sql.push("");

console.log(sql.join("\n"));
