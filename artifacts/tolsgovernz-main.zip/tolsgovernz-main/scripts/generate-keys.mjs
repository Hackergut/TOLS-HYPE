#!/usr/bin/env node
// Generate an RSA keypair for platform-to-platform auth and print ready-to-use
// .env values. Run once PER PLATFORM — Governance and Casino each need their
// own keypair, then exchange PUBLIC keys:
//
//   node scripts/generate-keys.mjs          # on Governance → keep private, give public to Casino
//   node scripts/generate-keys.mjs          # on Casino    → keep private, give public to Governance
import { generateKeyPairSync } from "node:crypto";

const { privateKey, publicKey } = generateKeyPairSync("rsa", {
  modulusLength: 3072,
  publicKeyEncoding: { type: "spki", format: "pem" },
  privateKeyEncoding: { type: "pkcs8", format: "pem" },
});

const b64 = (pem) => Buffer.from(pem, "utf8").toString("base64");

console.log("════════════ RSA 3072 KEYPAIR (SPKI public / PKCS#8 private) ════════════\n");
console.log("── PUBLIC key (share with the PARTNER platform) ──\n");
console.log(publicKey);
console.log("── base64 — set on the PARTNER as PARTNER_PUBLIC_KEY ──\n");
console.log(b64(publicKey) + "\n");
console.log("── PRIVATE key (KEEP SECRET — this platform only) ──\n");
console.log(privateKey);
console.log("── base64 — set on THIS platform as PLATFORM_PRIVATE_KEY ──\n");
console.log(b64(privateKey) + "\n");
console.log("════════════════════════════ .env snippets ════════════════════════════════");
console.log("# THIS platform");
console.log("PLATFORM_PRIVATE_KEY=" + b64(privateKey));
console.log("PLATFORM_PUBLIC_KEY=" + b64(publicKey));
console.log("# PARTNER platform");
console.log("PARTNER_PUBLIC_KEY=" + b64(publicKey));
console.log("══════════════════════════════════════════════════════════════════════════");
