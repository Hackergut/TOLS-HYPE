#!/usr/bin/env node
// Hash an operator password for GOVERNANCE_OPERATOR_PASSWORD_HASH (scrypt).
// Usage: node scripts/hash-password.mjs <password>
import { randomBytes, scryptSync } from "node:crypto";

const plain = process.argv[2];
if (!plain) {
  console.error("Usage: node scripts/hash-password.mjs <password>");
  process.exit(1);
}

const salt = randomBytes(16).toString("hex");
const hash = scryptSync(plain, salt, 64).toString("hex");
// ":" separators, not "$" — "$" is expanded by Next.js's .env loader.
console.log(`scrypt:${salt}:${hash}`);
