// Seed the Marketing CMS with demo content (promotions + game entries).
// Idempotent: uses upsert on the stable gameId slug.
import { db } from '@/lib/db'

const PROMOTIONS = [
  { title: '$100,000 Weekly Race', subtitle: 'Climb the leaderboard — resets Monday', cta: 'Enter', imageUrl: '/brand/hero-table.jpg', target: 'rewards', accent: true, sortOrder: 0 },
  { title: 'Dice Duel', subtitle: 'New TOLS Original · 1% edge', cta: 'Play', imageUrl: '/games/originals/dice.jpg', target: 'dice', accent: false, sortOrder: 1 },
  { title: 'TOLS Roulette', subtitle: 'European single zero · 97.3% RTP', cta: 'Play', imageUrl: '/games/originals/roulette.jpg', target: 'roulette', accent: false, sortOrder: 2 },
  { title: 'Neon Sevens', subtitle: 'Three reels, one payline · 97% RTP', cta: 'Spin', imageUrl: '/games/originals/slots.jpg', target: 'slots', accent: false, sortOrder: 3 },
  { title: 'Affiliate Program', subtitle: 'Earn commission on every referral', cta: 'Join', imageUrl: '', target: 'affiliate', accent: true, sortOrder: 4 },
]

const GAMES = [
  { gameId: 'dice', name: 'Dice', tagline: 'Roll over or under your target number for big multipliers.', sortOrder: 0, featured: true },
  { gameId: 'crash', name: 'Crash', tagline: 'Watch the multiplier rise — cash out before it crashes!', sortOrder: 1, featured: false },
  { gameId: 'mines', name: 'Mines', tagline: 'Reveal safe tiles and avoid the mines.', sortOrder: 2, featured: false },
  { gameId: 'limbo', name: 'Limbo', tagline: 'Set your target multiplier — instant result.', sortOrder: 3, featured: false },
  { gameId: 'plinko', name: 'Plinko', tagline: 'Drop the ball and watch it bounce to a win!', sortOrder: 4, featured: false },
  { gameId: 'coinflip', name: 'Coinflip', tagline: 'Pick heads or tails — 1.98x payout.', sortOrder: 5, featured: false },
  { gameId: 'wheel', name: 'Wheel', tagline: 'Spin the wheel for big multipliers.', sortOrder: 6, featured: false },
  { gameId: 'keno', name: 'Keno', tagline: 'Pick 1-10 numbers. Match to win!', sortOrder: 7, featured: false },
  { gameId: 'shoot', name: 'Shoot', tagline: 'Shoot a target and reveal its multiplier!', sortOrder: 8, featured: false },
  { gameId: 'slots', name: 'Slots', tagline: 'Spin the reels — match symbols on the payline!', sortOrder: 9, isNew: true },
  { gameId: 'roulette', name: 'Roulette', tagline: 'European single-zero — numbers, colours and more!', sortOrder: 10, featured: false },
]

async function seed() {
  console.log('🌱 Seeding Marketing CMS…')

  const existingPromos = await db.cmsPromotion.count()
  if (existingPromos === 0) {
    for (const p of PROMOTIONS) {
      await db.cmsPromotion.create({ data: p })
    }
    console.log(`   → ${PROMOTIONS.length} promotions created`)
  } else {
    console.log(`   → skipped promotions (${existingPromos} already present)`)
  }

  for (const g of GAMES) {
    await db.cmsGame.upsert({
      where: { gameId: g.gameId },
      create: { ...g, provider: 'TOLS', category: 'originals', description: '', imageUrl: '' },
      update: { name: g.name, tagline: g.tagline, sortOrder: g.sortOrder, featured: g.featured, isNew: (g as { isNew?: boolean }).isNew ?? false },
    })
  }
  console.log(`   → ${GAMES.length} game entries upserted`)

  console.log('✅ CMS seed complete')
}

seed()
  .catch((e) => {
    console.error('❌ CMS seed failed:', e)
    process.exit(1)
  })
  .finally(() => process.exit(0))
