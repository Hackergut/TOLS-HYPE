// Seed the remaining "real data" tables that the other seed scripts do not
// populate. Runs on the local DB (set PGLITE_DATABASE_DIR) or on Postgres.
// Idempotent: clears + recreates only the tables listed below.
import { db as prisma } from '@/lib/db'

const pick = <T,>(arr: T[]): T => arr[Math.floor(Math.random() * arr.length)]
const rand = (min: number, max: number) => min + Math.random() * (max - min)
const randInt = (min: number, max: number) => Math.floor(rand(min, max + 1))
const round2 = (n: number) => Math.round(n * 100) / 100
const daysAgo = (d: number) => new Date(Date.now() - d * 24 * 60 * 60 * 1000)
const minsAgo = (m: number) => new Date(Date.now() - m * 60 * 1000)

async function main() {
  console.log('🌱 Seeding remaining real-data tables…\n')

  const players = await prisma.playerProfile.findMany({ select: { id: true, username: true, country: true } })
  const users = await prisma.user.findMany({ select: { id: true, name: true, email: true } })
  const cryptoWallets = await prisma.cryptoWallet.findMany()
  const networks = await prisma.blockchainNetwork.findMany()
  const models = await prisma.mLModel.findMany({ select: { id: true, name: true } })
  const subscription = await prisma.subscription.findFirst()
  if (players.length < 5) {
    console.error('❌ Base seed required first (no players found).')
    process.exit(1)
  }

  // ── Clear tables managed by this seed ──────────────────────────────────
  console.log('🧹 Clearing…')
  await prisma.payment.deleteMany()
  await prisma.playerHeatmap.deleteMany()
  await prisma.playerTimeline.deleteMany()
  await prisma.playerBonusHistory.deleteMany()
  await prisma.playerNote.deleteMany()
  await prisma.gameControl.deleteMany()
  await prisma.mLTrainingJob.deleteMany()
  await prisma.mLPrediction.deleteMany()
  await prisma.smartContract.deleteMany()
  await prisma.blockchainTransaction.deleteMany()
  await prisma.userSession.deleteMany()
  await prisma.providerHealthLog.deleteMany()
  await prisma.providerCredential.deleteMany()
  await prisma.providerCallback.deleteMany()
  await prisma.providerGame.deleteMany()
  await prisma.gameProvider.deleteMany()
  await prisma.responsibleLimit.deleteMany()
  await prisma.amlFlag.deleteMany()
  await prisma.kycCase.deleteMany()

  // ── KYC ────────────────────────────────────────────────────────────────
  console.log('🪪 Seeding KYC…')
  const kycStatuses = ['pending', 'pending', 'pending', 'approved', 'approved', 'rejected']
  const kycRisks = ['low', 'medium', 'high', 'low', 'low', 'medium']
  for (let i = 0; i < 6; i++) {
    const p = players[i % players.length]
    await prisma.kycCase.create({
      data: {
        playerName: p.username,
        email: `${p.username.toLowerCase()}@email.com`,
        country: p.country ?? 'US',
        status: kycStatuses[i],
        risk: kycRisks[i],
        documents: JSON.stringify(['id_front', 'id_back', 'selfie']),
        submittedAt: daysAgo(i + 1),
        reviewedAt: i >= 3 ? daysAgo(0.5) : null,
        notes: i === 5 ? 'Document mismatch — rejected' : '',
      },
    })
  }

  // ── AML flags ──────────────────────────────────────────────────────────
  console.log('🚨 Seeding AML flags…')
  const flagTypes = ['aml', 'multi_account', 'chargeback', 'bonus_abuse', 'aml', 'multi_account']
  const flagSeverities = ['high', 'medium', 'high', 'low', 'medium', 'low']
  const flagDetails = [
    'Deposit pattern matches structured smurfing (7 tx < $1k in 30m)',
    'Shared device + IP with 2 other accounts',
    'Deposit charged back by issuing bank',
    'Multiple accounts claiming welcome bonus',
    'Withdrawal to a wallet linked to a sanctioned list',
    'Suspicious session velocity from a single device',
  ]
  for (let i = 0; i < 6; i++) {
    const p = players[i % players.length]
    await prisma.amlFlag.create({
      data: {
        playerName: p.username,
        type: flagTypes[i],
        severity: flagSeverities[i],
        detail: flagDetails[i],
        status: i >= 4 ? 'reviewed' : 'open',
        createdAt: daysAgo(i + 1),
      },
    })
  }

  // ── Responsible limits ─────────────────────────────────────────────────
  console.log('🛡️  Seeding responsible-gaming limits…')
  const limitKinds = ['deposit', 'loss', 'session', 'wager', 'deposit', 'loss', 'session', 'self_exclusion']
  for (let i = 0; i < 8; i++) {
    const p = players[i % players.length]
    await prisma.responsibleLimit.create({
      data: {
        playerId: p.id,
        dailyDepositLimit: ['deposit', 'wager'].includes(limitKinds[i]) ? randInt(200, 2000) : null,
        weeklyDepositLimit: i % 3 === 0 ? randInt(1000, 8000) : null,
        monthlyDepositLimit: i % 4 === 0 ? randInt(5000, 20000) : null,
        sessionTimeLimit: limitKinds[i] === 'session' ? randInt(30, 120) : null,
        lossLimit: limitKinds[i] === 'loss' ? randInt(500, 5000) : null,
        selfExclusionEnd: limitKinds[i] === 'self_exclusion' ? daysAgo(-180) : null,
        isActive: true,
      },
    })
  }

  // ── Game providers + games + callbacks + credentials + health ──────────
  console.log('🎰 Seeding vendors (game providers)…')
  const providersDef = [
    { name: 'Evolution Gaming', slug: 'evolution-gaming', type: 'live_casino', status: 'active', isCertified: true, totalGames: 340, activeGames: 328, activePlayers: 12450, monthlyRevenue: 4200000, errorRate: 0.3, avgLatencyMs: 45, uptime: 99.97, defaultRtp: 97.3 },
    { name: 'Pragmatic Play', slug: 'pragmatic-play', type: 'slots', status: 'active', isCertified: true, totalGames: 620, activeGames: 590, activePlayers: 18320, monthlyRevenue: 6100000, errorRate: 0.4, avgLatencyMs: 52, uptime: 99.95, defaultRtp: 96.5 },
    { name: 'NetEnt', slug: 'netent', type: 'slots', status: 'active', isCertified: true, totalGames: 280, activeGames: 261, activePlayers: 8940, monthlyRevenue: 2700000, errorRate: 0.2, avgLatencyMs: 38, uptime: 99.98, defaultRtp: 96.8 },
    { name: "Play'n GO", slug: 'playn-go', type: 'slots', status: 'active', isCertified: true, totalGames: 300, activeGames: 288, activePlayers: 7210, monthlyRevenue: 2100000, errorRate: 0.5, avgLatencyMs: 41, uptime: 99.94, defaultRtp: 96.2 },
    { name: 'Ezugi', slug: 'ezugi', type: 'live_casino', status: 'suspended', isCertified: false, totalGames: 60, activeGames: 0, activePlayers: 0, monthlyRevenue: 0, errorRate: 3.1, avgLatencyMs: 220, uptime: 97.4, defaultRtp: 97.0 },
    { name: 'Betsoft', slug: 'betsoft', type: 'table_games', status: 'active', isCertified: true, totalGames: 210, activeGames: 198, activePlayers: 4310, monthlyRevenue: 980000, errorRate: 0.6, avgLatencyMs: 49, uptime: 99.9, defaultRtp: 96.0 },
  ]
  const providerIds: Record<string, string> = {}
  for (const d of providersDef) {
    const created = await prisma.gameProvider.create({
      data: {
        name: d.name, slug: d.slug, type: d.type, status: d.status,
        website: `https://www.${d.slug}.com`, description: `${d.name} — certified game content provider.`,
        integrationType: 'api', apiVersion: 'v' + randInt(1, 3) + '.' + randInt(0, 9),
        baseUrl: `https://api.${d.slug}.com`, callbackUrl: `https://tols-casino.com/callbacks/${d.slug}`,
        secretKey: 'sk_' + d.slug + '_***', apiKey: 'ak_' + d.slug + '_***',
        allowedIps: JSON.stringify(['185.26.156.0/24']),
        supportedCurrencies: JSON.stringify(['USD', 'EUR', 'GBP']),
        supportedLocales: JSON.stringify(['en', 'de', 'es']),
        maxConcurrentSessions: 5000, defaultRtp: d.defaultRtp,
        isActive: d.status !== 'suspended', isCertified: d.isCertified,
        certifiedAt: d.isCertified ? daysAgo(randInt(60, 700)) : null,
        lastHealthCheck: minsAgo(randInt(1, 20)),
        totalGames: d.totalGames, activeGames: d.activeGames, activePlayers: d.activePlayers,
        monthlyRevenue: d.monthlyRevenue, errorRate: d.errorRate, avgLatencyMs: d.avgLatencyMs,
        uptime: d.uptime, joinedAt: daysAgo(randInt(100, 900)),
      },
    })
    providerIds[d.slug] = created.id
  }

  console.log('🎲 Seeding provider games…')
  const gamesDef = [
    { p: 'evolution-gaming', name: 'Auto Baccarat', type: 'live_table', category: 'Baccarat', rtp: 98.94, volatility: 'low', featured: true },
    { p: 'evolution-gaming', name: 'Lightning Roulette', type: 'live_table', category: 'Roulette', rtp: 97.3, volatility: 'medium', featured: true },
    { p: 'pragmatic-play', name: 'Sweet Bonanza', type: 'slot', category: 'Slots', rtp: 96.51, volatility: 'high', featured: true },
    { p: 'pragmatic-play', name: 'Gates of Olympus', type: 'slot', category: 'Slots', rtp: 96.5, volatility: 'very_high', featured: true },
    { p: 'netent', name: 'Starburst', type: 'slot', category: 'Slots', rtp: 96.09, volatility: 'low', featured: false },
    { p: 'netent', name: 'Divine Fortune', type: 'jackpot', category: 'Jackpot', rtp: 96.59, volatility: 'medium', featured: true },
    { p: 'playn-go', name: 'Book of Dead', type: 'slot', category: 'Slots', rtp: 96.21, volatility: 'high', featured: true },
    { p: 'playn-go', name: 'Reactoonz', type: 'slot', category: 'Slots', rtp: 96.51, volatility: 'high', featured: false },
    { p: 'ezugi', name: 'Live Baccarat', type: 'live_table', category: 'Baccarat', rtp: 98.76, volatility: 'low', featured: false },
    { p: 'betsoft', name: 'The Slotfather', type: 'slot', category: 'Slots', rtp: 95.72, volatility: 'medium', featured: false },
    { p: 'betsoft', name: 'Mega Glam Life', type: 'jackpot', category: 'Jackpot', rtp: 95.3, volatility: 'high', featured: false },
    { p: 'evolution-gaming', name: 'Crazy Time', type: 'live_table', category: 'Game Show', rtp: 95.41, volatility: 'medium', featured: true },
  ]
  for (const g of gamesDef) {
    const pid = providerIds[g.p]
    await prisma.providerGame.create({
      data: {
        providerId: pid,
        externalId: g.p + '_' + g.name.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
        name: g.name,
        slug: g.name.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
        type: g.type, category: g.category, subCategory: g.category,
        coverUrl: null, demoUrl: null,
        rtp: g.rtp, volatility: g.volatility, hitFrequency: rand(15, 30),
        maxWin: randInt(1000, 50000), maxBet: 1000, minBet: 0.1, defaultBet: 1,
        lines: g.type === 'slot' ? randInt(10, 40) : null,
        features: JSON.stringify(['free_spins', 'bonus_round', 'wild']),
        supportedCurrencies: JSON.stringify(['USD', 'EUR']),
        supportedLocales: JSON.stringify(['en', 'de']),
        isMobile: true, isDesktop: true, isLandscape: true,
        isActive: true, isFeatured: g.featured, isNew: g.p === 'betsoft',
        launchDate: daysAgo(randInt(30, 1000)),
        totalBets: rand(100000, 8000000), totalWins: rand(90000, 7000000),
        totalSessions: randInt(2000, 300000), avgSessionMin: rand(4, 12),
        popularityScore: rand(40, 98),
      },
    })
  }

  console.log('🔁 Seeding provider callbacks…')
  const cbTypes = [
    { name: 'Game Session Events', eventType: 'game.session_start' },
    { name: 'Wallet Callbacks', eventType: 'wallet.credit' },
    { name: 'Player Tracking', eventType: 'player.login' },
  ]
  for (const slug of Object.keys(providerIds)) {
    const cb = cbTypes[randInt(0, cbTypes.length - 1)]
    await prisma.providerCallback.create({
      data: {
        providerId: providerIds[slug],
        name: cb.name, eventType: cb.eventType,
        url: `/callbacks/${slug}/${cb.name.toLowerCase().replace(/ /g, '-')}`,
        method: 'POST', authType: 'hmac',
        secretKey: 'hmac_' + slug + '_***',
        ipWhitelist: JSON.stringify(['185.26.156.0/24']),
        isActive: true, retryPolicy: JSON.stringify({ maxRetries: 3, backoffMs: 1000 }),
        timeoutMs: 5000, lastReceivedAt: minsAgo(randInt(1, 30)), lastSuccessAt: minsAgo(randInt(1, 30)),
        totalReceived: randInt(1000, 500000), totalSuccess: randInt(990, 500000), totalFailed: randInt(0, 400),
        avgProcessingMs: randInt(20, 200),
      },
    })
  }

  console.log('🔑 Seeding provider credentials…')
  for (const slug of Object.keys(providerIds)) {
    await prisma.providerCredential.create({
      data: {
        providerId: providerIds[slug],
        environment: 'production',
        apiKey: 'ak_' + slug + '_prod_***',
        apiSecret: 'sk_' + slug + '_prod_***',
        bearerToken: null, certPath: null,
        additional: JSON.stringify({ timeout: 5000 }),
        isActive: true, lastUsedAt: minsAgo(randInt(1, 60)),
        expiresAt: daysAgo(-randInt(30, 300)),
      },
    })
  }

  console.log('❤️  Seeding provider health logs…')
  const healthMetrics = [
    { metric: 'uptime', unit: '%', threshold: 99.5 },
    { metric: 'latency', unit: 'ms', threshold: 120 },
    { metric: 'error_rate', unit: '%', threshold: 1 },
    { metric: 'callback_success', unit: '%', threshold: 99 },
  ]
  for (const slug of Object.keys(providerIds)) {
    const h = healthMetrics[randInt(0, healthMetrics.length - 1)]
    const val = h.metric === 'uptime' || h.metric === 'callback_success' ? rand(97, 100) : h.metric === 'latency' ? randInt(20, 220) : rand(0, 4)
    await prisma.providerHealthLog.create({
      data: {
        providerId: providerIds[slug],
        metric: h.metric, value: round2(val), unit: h.unit, threshold: h.threshold,
        isAlert: h.metric === 'latency' ? val > h.threshold : h.metric === 'error_rate' ? val > h.threshold : false,
        details: JSON.stringify({ status: 'ok' }),
        checkedAt: minsAgo(randInt(1, 15)),
      },
    })
  }

  // ── User sessions ──────────────────────────────────────────────────────
  console.log('👤 Seeding user sessions…')
  const browsers = ['Chrome 121', 'Firefox 122', 'Safari 17', 'Edge 120']
  for (const u of users) {
    for (let j = 0; j < 2; j++) {
      await prisma.userSession.create({
        data: {
          userId: u.id,
          token: 'sess_' + Math.random().toString(36).slice(2),
          ipAddress: `${randInt(1, 255)}.${randInt(0, 255)}.${randInt(0, 255)}.${randInt(1, 254)}`,
          userAgent: pick(browsers) + ' / ' + pick(['Windows 11', 'macOS 14', 'iOS 17', 'Android 14']),
          expiresAt: daysAgo(-1),
          createdAt: minsAgo(randInt(5, 300)),
        },
      })
    }
  }

  // ── Blockchain transactions + smart contracts ──────────────────────────
  console.log('⛓️  Seeding blockchain transactions & contracts…')
  const txTypes = ['deposit', 'withdrawal', 'transfer', 'contract_call']
  const statuses = ['confirmed', 'confirming', 'pending', 'failed']
  for (const w of cryptoWallets) {
    for (let j = 0; j < 3; j++) {
      const type = txTypes[j % txTypes.length]
      const status = statuses[j % statuses.length]
      const amount = round2(rand(0.01, 10))
      await prisma.blockchainTransaction.create({
        data: {
          walletId: w.id,
          txHash: '0x' + Math.random().toString(16).slice(2, 14) + Math.random().toString(16).slice(2, 14),
          type,
          fromAddress: '0x' + Math.random().toString(16).slice(2, 12),
          toAddress: w.address,
          amount, currency: w.currency, amountUsd: round2(amount * (w.balanceUsd / Math.max(w.balance, 0.0001))),
          gasFee: round2(rand(0.0001, 0.01)), gasFeeUsd: round2(rand(0.5, 20)),
          blockNumber: status === 'confirmed' || status === 'confirming' ? randInt(1000000, 20000000) : null,
          confirmations: status === 'confirmed' ? randInt(6, 100) : status === 'confirming' ? randInt(1, 5) : 0,
          status, metadata: null,
          confirmedAt: status === 'confirmed' ? minsAgo(randInt(5, 300)) : null,
          createdAt: minsAgo(randInt(5, 300)),
        },
      })
    }
  }
  const contractDefs = [
    { name: 'Escrow Vault', type: 'escrow', isVerified: true },
    { name: 'TOLS Token', type: 'token', isVerified: true },
    { name: 'Player NFT Collection', type: 'nft', isVerified: true },
    { name: 'Staking Pool', type: 'staking', isVerified: false },
    { name: 'Governance DAO', type: 'governance', isVerified: true },
  ]
  for (let i = 0; i < contractDefs.length; i++) {
    const net = networks[i % networks.length]
    await prisma.smartContract.create({
      data: {
        networkId: net.id,
        address: '0x' + Math.random().toString(16).slice(2, 18) + Math.random().toString(16).slice(2, 18),
        name: contractDefs[i].name, type: contractDefs[i].type,
        abi: JSON.stringify([{ type: 'function' }]),
        isVerified: contractDefs[i].isVerified, isActive: true,
        deployedAt: daysAgo(randInt(100, 900)),
      },
    })
  }

  // ── ML predictions + training jobs ─────────────────────────────────────
  console.log('🤖 Seeding ML predictions & training jobs…')
  const modelNames = models.map((m) => m.name)
  for (const m of models) {
    for (let j = 0; j < 3; j++) {
      const confidence = round2(rand(0.55, 0.99))
      await prisma.mLPrediction.create({
        data: {
          modelId: m.id,
          input: JSON.stringify({ feature: randInt(0, 100), extra: randInt(0, 50) }),
          output: JSON.stringify({ score: confidence, risk_level: confidence > 0.8 ? 'high' : confidence > 0.65 ? 'medium' : 'low' }),
          confidence, entityId: 'P-' + randInt(1000, 9999), entityType: 'player',
          executedAt: minsAgo(randInt(1, 120)), durationMs: randInt(5, 60),
        },
      })
    }
  }
  const jobStatuses = ['completed', 'completed', 'running', 'failed', 'queued', 'completed']
  for (let i = 0; i < 6; i++) {
    const m = models[i % models.length]
    const status = jobStatuses[i]
    await prisma.mLTrainingJob.create({
      data: {
        modelId: m.id, status,
        progress: status === 'completed' ? 100 : status === 'running' ? randInt(10, 90) : status === 'queued' ? 0 : randInt(10, 90),
        startDate: minsAgo(randInt(30, 5000)),
        endDate: status === 'completed' || status === 'failed' ? minsAgo(randInt(5, 4000)) : null,
        duration: status === 'completed' || status === 'failed' ? randInt(30, 400) : null,
        metrics: JSON.stringify({ loss: round2(rand(0.02, 0.4)), accuracy: round2(rand(0.85, 0.98)) }),
        error: status === 'failed' ? 'CUDA out of memory. Tried to allocate 2.00 GiB' : null,
        config: null,
      },
    })
  }

  // ── Game controls (RTP per game) ───────────────────────────────────────
  console.log('🎮 Seeding game controls…')
  const gameNames = ['Dice', 'Crash', 'Mines', 'Limbo', 'Plinko', 'Coinflip', 'Wheel', 'Keno', 'Slots', 'Roulette', 'Blackjack', 'Baccarat']
  for (let i = 0; i < 12; i++) {
    const p = players[i % players.length]
    const g = gameNames[i]
    const wagered = round2(rand(5000, 300000))
    const rtp = rand(94, 101)
    await prisma.gameControl.create({
      data: {
        playerId: p.id, gameId: g.toLowerCase(), gameName: g,
        sessions: randInt(10, 5000),
        totalWagered: wagered, totalWon: round2(wagered * rtp / 100),
        avgSessionDuration: round2(rand(3, 25)),
        lastPlayedAt: minsAgo(randInt(5, 5000)),
      },
    })
  }

  // ── Player notes / timeline / bonus history / heatmap ─────────────────
  console.log('📝 Seeding player notes, timeline, bonus history…')
  const noteTexts = [
    'High-value player — treat with priority support.',
    'Requested withdrawal limit increase.',
    'Flagged by AML for review; contact before crediting.',
    'Preferred contact via email; VIP concierge assigned.',
    'Recent churn risk — offer retention bonus.',
  ]
  for (let i = 0; i < 5; i++) {
    const p = players[i]
    await prisma.playerNote.create({
      data: { playerId: p.id, authorRole: pick(['finance', 'controller', 'support']), content: noteTexts[i], isInternal: true },
    })
  }
  for (let i = 0; i < 10; i++) {
    const p = players[i % players.length]
    await prisma.playerTimeline.create({
      data: {
        playerId: p.id,
        eventType: pick(['deposit', 'withdrawal', 'game_session', 'bonus_claim', 'limit_change']),
        description: pick([
          'Deposit confirmed on-chain',
          'Withdrawal requested',
          'Claimed welcome bonus',
          'Session started',
          'Updated responsible-gaming limits',
        ]),
        metadata: null,
        createdAt: minsAgo(randInt(5, 10000)),
      },
    })
  }
  for (let i = 0; i < 8; i++) {
    const p = players[i % players.length]
    const amount = randInt(10, 500)
    await prisma.playerBonusHistory.create({
      data: {
        playerId: p.id,
        promotionId: null,
        bonusCode: 'BONUS' + randInt(100, 999),
        amount,
        wageringRequired: amount * randInt(10, 40),
        wageringCompleted: round2(amount * rand(0, 35)),
        status: pick(['active', 'completed', 'completed', 'expired']),
        claimedAt: minsAgo(randInt(60, 10000)),
        expiresAt: daysAgo(-randInt(1, 14)),
      },
    })
  }
  for (let i = 0; i < 20; i++) {
    const p = players[i % players.length]
    await prisma.playerHeatmap.create({
      data: {
        playerId: p.id, gameId: pick(gameNames).toLowerCase(),
        dayOfWeek: randInt(0, 6), hourOfDay: randInt(0, 23),
        intensity: round2(rand(0.05, 1)),
      },
    })
  }

  // ── Payments (billing) ─────────────────────────────────────────────────
  if (subscription) {
    console.log('💳 Seeding subscription payments…')
    const payStatuses = ['succeeded', 'succeeded', 'succeeded', 'refunded', 'pending', 'succeeded']
    for (let i = 0; i < 6; i++) {
      await prisma.payment.create({
        data: {
          subscriptionId: subscription.id,
          stripePaymentId: 'pi_' + Math.random().toString(36).slice(2, 16),
          amount: [299, 799, 1999][randInt(0, 2)],
          currency: 'USD',
          status: payStatuses[i],
          method: pick(['card', 'crypto', 'bank_transfer']),
          receiptUrl: 'https://pay.stripe.com/receipts/pi_' + Math.random().toString(36).slice(2, 10),
          createdAt: daysAgo(i * 30 + 1),
        },
      })
    }
  }

  console.log('✅ Remaining real-data tables seeded.')
  await prisma.$disconnect()
}

main()
  .catch((e) => {
    console.error('❌ Seed failed:', e)
    process.exit(1)
  })
  .finally(() => process.exit(0))
