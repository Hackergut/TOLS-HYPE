// /api/api-hub — API tokens, webhooks, integrations, MCP endpoints. Real data
// from the local DB (ApiToken / WebhookEndpoint / WebhookDelivery / Integration
// / McpEndpoint / ApiUsageLog).
import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

const iso = (d: Date | null, fallback = '') => (d ? d.toISOString() : fallback)
const parseJson = (s: string | null, fallback: unknown = null): unknown => {
  if (!s) return fallback
  try {
    return JSON.parse(s)
  } catch {
    return fallback
  }
}
const parseArr = (s: string | null): string[] => {
  const v = parseJson(s)
  return Array.isArray(v) ? v : []
}

export async function GET() {
  try {
    const [tokens, webhooks, deliveries, integrations, mcpEndpoints, usageLogs] = await Promise.all([
      db.apiToken.findMany({ include: { usageLogs: true, webhooks: true } }),
      db.webhookEndpoint.findMany({ include: { apiToken: { select: { name: true } }, deliveries: true } }),
      db.webhookDelivery.findMany({ include: { webhook: { select: { name: true } } }, orderBy: { createdAt: 'desc' } }),
      db.integration.findMany(),
      db.mcpEndpoint.findMany(),
      db.apiUsageLog.findMany({ orderBy: { createdAt: 'desc' } }),
    ])

    const now = Date.now()
    const dayAgo = now - 24 * 60 * 60 * 1000
    const usageByToken = new Map<string, { total: number; last24h: number }>()
    for (const u of usageLogs) {
      const cur = usageByToken.get(u.apiTokenId) ?? { total: 0, last24h: 0 }
      cur.total += 1
      if (u.createdAt.getTime() >= dayAgo) cur.last24h += 1
      usageByToken.set(u.apiTokenId, cur)
    }

    const tokenRows = tokens.map((t) => {
      const u = usageByToken.get(t.id) ?? { total: 0, last24h: 0 }
      return {
        id: t.id,
        name: t.name,
        tokenPrefix: t.tokenPrefix,
        ownerId: t.ownerId,
        scopes: parseArr(t.scopes),
        rateLimit: t.rateLimit,
        isActive: t.isActive,
        lastUsedAt: iso(t.lastUsedAt),
        expiresAt: iso(t.expiresAt),
        createdAt: t.createdAt.toISOString(),
        usageCount: u.total,
        last24hCalls: u.last24h,
      }
    })

    const webhookRows = webhooks.map((w) => {
      const dels = w.deliveries
      const success = dels.filter((d) => d.success).length
      return {
        id: w.id,
        name: w.name,
        url: w.url,
        events: parseArr(w.events),
        isActive: w.isActive,
        retryCount: w.retryCount,
        timeoutMs: w.timeoutMs,
        lastTriggerAt: iso(w.lastTriggerAt),
        successRate: dels.length ? Math.round((success / dels.length) * 1000) / 10 : 100,
        totalDeliveries: dels.length,
        apiTokenName: w.apiToken?.name ?? '',
        createdAt: w.createdAt.toISOString(),
      }
    })

    const deliveryRows = deliveries.map((d) => ({
      id: d.id,
      webhookName: d.webhook?.name ?? '',
      eventId: d.eventId,
      statusCode: d.statusCode ?? 0,
      duration: d.duration ?? 0,
      success: d.success,
      attempt: d.attempt,
      createdAt: d.createdAt.toISOString(),
    }))

    const integrationRows = integrations.map((i) => {
      const sync = (parseJson(i.syncStats, {}) as { recordsSynced?: number; errors?: number }) ?? {}
      return {
        id: i.id,
        name: i.name,
        type: i.type,
        status: i.status,
        lastSyncAt: iso(i.lastSyncAt),
        recordsSynced: sync.recordsSynced ?? 0,
        errors: sync.errors ?? 0,
        logo: i.logo ?? '🔌',
        createdAt: i.createdAt.toISOString(),
      }
    })

    const mcpRows = mcpEndpoints.map((m) => ({
      id: m.id,
      name: m.name,
      description: m.description,
      version: m.version,
      baseUrl: m.baseUrl,
      tools: parseJson(m.tools, []),
      resources: parseJson(m.resources, []),
      isActive: m.isActive,
      requiresAuth: m.requiresAuth,
      createdAt: m.createdAt.toISOString(),
    }))

    const totalDeliveries = deliveries.length
    const deliverySuccess = deliveries.filter((d) => d.success).length
    const totalCalls24h = tokenRows.reduce((s, t) => s + t.last24hCalls, 0)
    const stats = {
      totalTokens: tokenRows.length,
      activeTokens: tokenRows.filter((t) => t.isActive).length,
      totalWebhooks: webhookRows.length,
      totalDeliveries,
      deliverySuccessRate: totalDeliveries ? Math.round((deliverySuccess / totalDeliveries) * 1000) / 10 : 0,
      totalIntegrations: integrationRows.length,
      activeIntegrations: integrationRows.filter((i) => i.status === 'connected').length,
      totalApiCalls24h: totalCalls24h,
      avgLatencyMs: usageLogs.length ? Math.round(usageLogs.reduce((s, u) => s + u.durationMs, 0) / usageLogs.length) : 0,
    }

    // 24h usage histogram
    const usageData = Array.from({ length: 24 }, (_, i) => {
      const hourStart = now - (23 - i) * 60 * 60 * 1000
      const hourEnd = hourStart + 60 * 60 * 1000
      const calls = usageLogs.filter((u) => u.createdAt.getTime() >= hourStart && u.createdAt.getTime() < hourEnd).length
      return { hour: `${String(new Date(hourStart).getHours()).padStart(2, '0')}:00`, calls }
    })

    return NextResponse.json({
      tokens: tokenRows,
      webhooks: webhookRows,
      webhookDeliveries: deliveryRows,
      integrations: integrationRows,
      mcpEndpoints: mcpRows,
      stats,
      usageData,
    })
  } catch (error) {
    console.error('api-hub route error:', error)
    return NextResponse.json({ error: 'Failed to fetch API hub data' }, { status: 500 })
  }
}
