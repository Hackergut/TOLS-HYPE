// /api/auth — operators, sessions and the role→permission matrix. Real data
// from the local DB (User / Casino / UserSession / RolePermission).
import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

const ROLE: Record<string, string> = {
  admin: 'Admin', controller: 'Controller', finance: 'Finance',
  marketing: 'Marketing', support: 'Support', viewer: 'Viewer',
}
const RESOURCE: Record<string, string> = {
  players: 'Players', financial: 'Financial', wallets: 'Wallets',
  promotions: 'Promotions', settings: 'Settings', vendors: 'Vendors', api: 'API',
}

const fmt = (d: Date | null) => {
  if (!d) return ''
  const p = (n: number) => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`
}

const deviceOf = (ua: string) => (/Mobile|Android|iPhone|iOS/i.test(ua) ? 'Mobile' : /Mac|Laptop/i.test(ua) ? 'Laptop' : 'Desktop')

export async function GET() {
  try {
    const [users, sessions, permissions] = await Promise.all([
      db.user.findMany({ include: { casino: { select: { name: true } } }, orderBy: { createdAt: 'asc' } }),
      db.userSession.findMany({ include: { user: { select: { name: true } } }, orderBy: { createdAt: 'desc' } }),
      db.rolePermission.findMany(),
    ])

    const userRows = users.map((u) => ({
      id: u.id,
      name: u.name,
      email: u.email,
      role: ROLE[u.role] ?? u.role,
      casino: u.casino?.name ?? 'All Casinos',
      status: u.isActive ? 'active' : 'inactive',
      lastLogin: fmt(u.lastLoginAt),
    }))

    const sessionRows = sessions.map((s) => ({
      id: s.id,
      user: s.user?.name ?? '',
      ipAddress: s.ipAddress,
      device: deviceOf(s.userAgent ?? ''),
      browser: s.userAgent,
      started: fmt(s.createdAt),
      expires: fmt(s.expiresAt),
      isActive: s.expiresAt.getTime() > Date.now(),
    }))

    const matrix: Record<string, Record<string, string[]>> = {}
    for (const p of permissions) {
      const role = ROLE[p.role] ?? p.role
      const resource = RESOURCE[p.resource] ?? p.resource
      let actions: string[] = []
      try {
        const v = JSON.parse(p.actions)
        if (Array.isArray(v)) actions = v
      } catch {
        actions = []
      }
      if (!matrix[role]) matrix[role] = {}
      matrix[role][resource] = actions
    }

    return NextResponse.json({ users: userRows, sessions: sessionRows, permissions: matrix })
  } catch (error) {
    console.error('auth route error:', error)
    return NextResponse.json({ error: 'Failed to fetch auth data' }, { status: 500 })
  }
}
