// /api/blockchain — on-chain view. Real data from the local DB
// (CryptoWallet / BlockchainTransaction / BlockchainNetwork / SmartContract).
import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

const iso = (d: Date | null, fallback = '') => (d ? d.toISOString() : fallback)

export async function GET() {
  try {
    const [wallets, transactions, networks, contracts] = await Promise.all([
      db.cryptoWallet.findMany(),
      db.blockchainTransaction.findMany({ orderBy: { createdAt: 'desc' } }),
      db.blockchainNetwork.findMany(),
      db.smartContract.findMany(),
    ])

    const networkName = new Map(networks.map((n) => [n.id, n.name]))

    const walletRows = wallets.map((w) => ({
      id: w.id,
      address: w.address,
      network: w.network,
      type: w.type,
      label: w.label,
      balance: w.balance,
      balanceUsd: w.balanceUsd,
      currency: w.currency,
      isActive: w.isActive,
      isVerified: w.isVerified,
      lastSyncAt: iso(w.lastSyncAt),
      createdAt: w.createdAt.toISOString(),
    }))

    const txRows = transactions.map((t) => ({
      id: t.id,
      walletId: t.walletId,
      txHash: t.txHash ?? '',
      type: t.type,
      fromAddress: t.fromAddress,
      toAddress: t.toAddress,
      amount: t.amount,
      currency: t.currency,
      amountUsd: t.amountUsd,
      gasFee: t.gasFee,
      gasFeeUsd: t.gasFeeUsd,
      blockNumber: t.blockNumber,
      confirmations: t.confirmations,
      status: t.status,
      confirmedAt: iso(t.confirmedAt),
      createdAt: t.createdAt.toISOString(),
    }))

    const networkRows = networks.map((n) => ({
      id: n.id,
      name: n.name,
      chainId: n.chainId,
      symbol: n.symbol,
      type: n.type,
      rpcUrl: n.rpcUrl,
      explorerUrl: n.explorerUrl,
      isSupported: n.isSupported,
      isActive: n.isActive,
    }))

    const contractRows = contracts.map((c) => ({
      id: c.id,
      name: c.name,
      address: c.address,
      network: networkName.get(c.networkId) ?? '',
      type: c.type,
      isVerified: c.isVerified,
      deployedAt: iso(c.deployedAt),
      isActive: c.isActive,
    }))

    return NextResponse.json({ wallets: walletRows, transactions: txRows, networks: networkRows, contracts: contractRows })
  } catch (error) {
    console.error('blockchain route error:', error)
    return NextResponse.json({ error: 'Failed to fetch blockchain data' }, { status: 500 })
  }
}
