// Alias the Casino also probes: POST /api/bridge/events
export { GET, POST, HEAD, OPTIONS } from "@/app/api/platform/webhooks/route";
