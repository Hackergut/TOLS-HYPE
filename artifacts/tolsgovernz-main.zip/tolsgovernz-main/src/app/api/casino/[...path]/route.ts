// /api/casino/* — Governance controller proxy to the LIVE Casino platform API.
//
// The browser calls these same-origin routes with the operator cookie; the
// server mints a fresh RS256 JWT (PLATFORM_JWT_PRIVATE_KEY, iss=tols-governance,
// aud=tols-casino) and forwards to https://www.tols.fun/api/platform/<path>.
// No mock data ever: every response is the Casino's own JSON envelope
// ({ success, data, pagination? }), relayed verbatim.
//
// Allowlist (method + path pattern) — everything else is 404:
//   GET    overview | stats | cashflow | payments
//   GET    users | users/:id          PATCH users/:id
//   GET    wallets                    POST  wallets/adjust
//   GET    deposits | withdrawals     POST  withdrawals/:id/approve|reject
//   GET    bets
//   GET    rtp                        PUT   rtp
//   GET    promotions                 PUT   promotions
import { NextRequest } from "next/server";
import { requireGovOperatorOrToken } from "@/lib/governance-auth";
import { casinoRequest, relayCasinoResponse, bridgeErrorResponse } from "@/lib/casino/client";

interface Rule {
  method: string;
  pattern: RegExp;
}

const ALLOWED: Rule[] = [
  { method: "GET", pattern: /^(overview|stats|cashflow|payments)$/ },
  { method: "GET", pattern: /^users$/ },
  { method: "GET", pattern: /^users\/[^/]+$/ },
  { method: "PATCH", pattern: /^users\/[^/]+$/ },
  { method: "GET", pattern: /^wallets$/ },
  { method: "POST", pattern: /^wallets\/adjust$/ },
  { method: "GET", pattern: /^(deposits|withdrawals|bets)$/ },
  { method: "POST", pattern: /^withdrawals\/[^/]+\/(approve|reject)$/ },
  { method: "GET", pattern: /^rtp$/ },
  { method: "PUT", pattern: /^rtp$/ },
  { method: "GET", pattern: /^promotions$/ },
  { method: "PUT", pattern: /^promotions$/ },
];

function isAllowed(method: string, path: string): boolean {
  return ALLOWED.some((r) => r.method === method && r.pattern.test(path));
}

async function relay(req: NextRequest, params: Promise<{ path: string[] }>) {
  const gate = requireGovOperatorOrToken(req);
  if ("response" in gate) return gate.response;

  const { path } = await params;
  const joined = (path ?? []).map(encodeURIComponent).join("/").replace(/%2F/gi, "/");
  // Path segments arrive decoded; re-encode each one, keeping separators.
  const clean = (path ?? []).map((s) => encodeURIComponent(s)).join("/");

  if (!isAllowed(req.method, (path ?? []).join("/"))) {
    return Response.json(
      { success: false, error: `Unknown casino API route: ${req.method} ${joined}` },
      { status: 404 },
    );
  }

  const search = req.nextUrl.search ?? "";
  const target = `/api/platform/${clean}${search}`;

  let body: unknown;
  if (req.method !== "GET" && req.method !== "HEAD") {
    body = await req.json().catch(() => undefined);
  }

  try {
    const res = await casinoRequest(req.method, target, { body });
    return relayCasinoResponse(res);
  } catch (e) {
    return bridgeErrorResponse(e);
  }
}

export async function GET(req: NextRequest, ctx: { params: Promise<{ path: string[] }> }) {
  return relay(req, ctx.params);
}
export async function POST(req: NextRequest, ctx: { params: Promise<{ path: string[] }> }) {
  return relay(req, ctx.params);
}
export async function PUT(req: NextRequest, ctx: { params: Promise<{ path: string[] }> }) {
  return relay(req, ctx.params);
}
export async function PATCH(req: NextRequest, ctx: { params: Promise<{ path: string[] }> }) {
  return relay(req, ctx.params);
}
