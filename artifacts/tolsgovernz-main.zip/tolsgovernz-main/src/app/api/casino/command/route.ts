// POST /api/casino/command — fire a signed HMAC command at the Casino webhook.
//
// Body: { "type": "governance.<command>", "payload": { ... } }
// The server signs the raw JSON with GOVERNANCE_BRIDGE_SECRET and POSTs to
// https://www.tols.fun/api/bridge/webhook with X-Bridge-Signature +
// X-Bridge-Timestamp. Used for push commands that are not REST forms:
//   governance.rtp_update, governance.wallet_adjust, governance.player_block,
//   governance.bonus_credit, governance.session_invalidate,
//   governance.support_reply, governance.support_close,
//   governance.limits_update, governance.feature_flag — plus "ping".
import { NextRequest } from "next/server";
import { requireGovOperatorOrToken } from "@/lib/governance-auth";
import { sendCasinoCommand, OUTBOUND_COMMANDS } from "@/lib/casino/webhook";

export async function POST(req: NextRequest) {
  const gate = requireGovOperatorOrToken(req);
  if ("response" in gate) return gate.response;

  const body = (await req.json().catch(() => null)) as {
    type?: string;
    payload?: Record<string, unknown>;
  } | null;

  const type = String(body?.type ?? "").trim();
  if (!type || !(OUTBOUND_COMMANDS as readonly string[]).includes(type)) {
    return Response.json(
      { success: false, error: `type must be one of: ${OUTBOUND_COMMANDS.join(", ")}` },
      { status: 400 },
    );
  }

  const result = await sendCasinoCommand(type, body?.payload ?? {});
  const envelope =
    result.body && typeof result.body === "object"
      ? result.body
      : { success: result.ok, error: result.ok ? undefined : `Casino webhook HTTP ${result.status}` };

  return Response.json(envelope, { status: result.status >= 500 ? 502 : result.status });
}
