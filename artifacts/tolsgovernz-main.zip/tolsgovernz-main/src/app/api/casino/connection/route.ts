// GET /api/casino/connection — single Casino connection panel (env-backed).
// Probes, in order:
//   1. GET  CASINO/api/platform/health   (public)   → live/offline + latency
//   2. GET  CASINO/api/platform/whoami   (JWT)      → authenticated true/false
//   3. POST CASINO/api/bridge/webhook    {type:ping} → pong (HMAC channel)
import { NextRequest } from "next/server";
import { requireGovOperatorOrToken } from "@/lib/governance-auth";
import { casinoConfigReport, getCasinoConfig } from "@/lib/casino/config";
import { casinoGet, CasinoBridgeError } from "@/lib/casino/client";
import { sendCasinoCommand } from "@/lib/casino/webhook";

export async function GET(req: NextRequest) {
  const gate = requireGovOperatorOrToken(req);
  if ("response" in gate) return gate.response;

  const cfg = getCasinoConfig();
  const report = casinoConfigReport();

  // 1 — public health (no auth): live/offline + latency.
  const health: {
    live: boolean;
    latencyMs: number | null;
    status: number | null;
    dbOk: boolean | null;
    jwtConfiguredOnCasino: boolean | null;
    error: string | null;
  } = { live: false, latencyMs: null, status: null, dbOk: null, jwtConfiguredOnCasino: null, error: null };

  const t0 = Date.now();
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 8000);
    const res = await fetch(`${cfg.casinoOrigin}${cfg.healthPath}`, {
      cache: "no-store",
      signal: controller.signal,
    });
    clearTimeout(timer);
    health.latencyMs = Date.now() - t0;
    health.status = res.status;
    health.live = res.ok;
    const body = (await res.json().catch(() => null)) as {
      db?: { ok?: boolean };
      bridge?: { jwtConfigured?: boolean };
    } | null;
    health.dbOk = body?.db?.ok ?? null;
    health.jwtConfiguredOnCasino = body?.bridge?.jwtConfigured ?? null;
  } catch (e) {
    health.latencyMs = Date.now() - t0;
    health.error = e instanceof Error ? e.message : "unreachable";
  }

  // 2 — authenticated whoami with a Governance-signed JWT.
  const whoami: { authenticated: boolean; status: number | null; claims: unknown; error: string | null } = {
    authenticated: false,
    status: null,
    claims: null,
    error: null,
  };
  if (report.privateKeyConfigured && health.live) {
    try {
      const res = await casinoGet("/api/platform/whoami", { timeoutMs: 8000 });
      whoami.status = res.status;
      const body = res.body as { success?: boolean; data?: unknown; claims?: unknown; error?: string } | null;
      whoami.authenticated = res.status === 200 && body?.success !== false;
      whoami.claims = body?.data ?? body?.claims ?? null;
      if (!whoami.authenticated) whoami.error = body?.error ?? `HTTP ${res.status}`;
    } catch (e) {
      whoami.error = e instanceof CasinoBridgeError ? e.message : "whoami failed";
    }
  } else if (!report.privateKeyConfigured) {
    whoami.error = "PLATFORM_JWT_PRIVATE_KEY is not configured";
  }

  // 3 — webhook ping (works even without the shared secret).
  const webhook: { reachable: boolean; pong: boolean; status: number | null } = {
    reachable: false,
    pong: false,
    status: null,
  };
  if (health.live) {
    const ping = await sendCasinoCommand("ping", {}, { timeoutMs: 8000 });
    webhook.status = ping.status;
    webhook.reachable = ping.status > 0 && ping.status < 500;
    webhook.pong = Boolean((ping.body as { type?: string } | null)?.type === "pong");
  }

  return Response.json({
    success: true,
    data: {
      config: report,
      health,
      whoami,
      webhook,
      ts: new Date().toISOString(),
    },
  });
}
