// /api/cms/games — CMS marketable game entries (Governance operator).
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireGovOperator } from "@/lib/governance-auth";

function pub(g: {
  id: string; gameId: string; name: string; tagline: string; description: string;
  provider: string; category: string; imageUrl: string; sortOrder: number;
  featured: boolean; isNew: boolean; active: boolean; createdAt: Date; updatedAt: Date;
}) {
  return {
    id: g.id, gameId: g.gameId, name: g.name, tagline: g.tagline, description: g.description,
    provider: g.provider, category: g.category, imageUrl: g.imageUrl, sortOrder: g.sortOrder,
    featured: g.featured, isNew: g.isNew, active: g.active,
    createdAt: g.createdAt.toISOString(), updatedAt: g.updatedAt.toISOString(),
  };
}

export async function GET(req: NextRequest) {
  const guard = requireGovOperator(req);
  if ("response" in guard) return guard.response;

  const { searchParams } = new URL(req.url);
  const includeInactive = searchParams.get("includeInactive") === "true";
  const rows = await db.cmsGame.findMany({
    where: includeInactive ? {} : { active: true },
    orderBy: [{ sortOrder: "asc" }, { createdAt: "desc" }],
  });
  return NextResponse.json({ success: true, data: rows.map(pub) });
}

export async function POST(req: NextRequest) {
  const guard = requireGovOperator(req);
  if ("response" in guard) return guard.response;

  const body = await req.json().catch(() => null);
  if (!body) return NextResponse.json({ success: false, error: "Invalid body" }, { status: 400 });
  const gameId = String(body.gameId ?? "").trim().toLowerCase();
  if (!gameId) return NextResponse.json({ success: false, error: "gameId required" }, { status: 400 });

  const row = await db.cmsGame.create({
    data: {
      gameId,
      name: String(body.name ?? ""),
      tagline: String(body.tagline ?? ""),
      description: String(body.description ?? ""),
      provider: String(body.provider ?? "TOLS"),
      category: String(body.category ?? "originals"),
      imageUrl: String(body.imageUrl ?? ""),
      sortOrder: Number.isFinite(Number(body.sortOrder)) ? Number(body.sortOrder) : 0,
      featured: body.featured === true,
      isNew: body.isNew === true,
      active: body.active !== false,
    },
  });
  return NextResponse.json({ success: true, data: pub(row) });
}

export async function PUT(req: NextRequest) {
  const guard = requireGovOperator(req);
  if ("response" in guard) return guard.response;

  const body = await req.json().catch(() => null);
  const id = String(body?.id ?? "");
  if (!id) return NextResponse.json({ success: false, error: "id required" }, { status: 400 });

  const data: Record<string, unknown> = {};
  for (const k of ["name", "tagline", "description", "provider", "category", "imageUrl"]) {
    if (typeof body[k] === "string") data[k] = body[k];
  }
  for (const k of ["featured", "isNew", "active"]) {
    if (typeof body[k] === "boolean") data[k] = body[k];
  }
  if (Number.isFinite(Number(body.sortOrder))) data.sortOrder = Number(body.sortOrder);

  const row = await db.cmsGame.update({ where: { id }, data });
  return NextResponse.json({ success: true, data: pub(row) });
}

export async function DELETE(req: NextRequest) {
  const guard = requireGovOperator(req);
  if ("response" in guard) return guard.response;

  const id = new URL(req.url).searchParams.get("id");
  if (!id) return NextResponse.json({ success: false, error: "id required" }, { status: 400 });
  await db.cmsGame.delete({ where: { id } });
  return NextResponse.json({ success: true, data: { deleted: id } });
}
