// /api/cms/promotions — CMS marketing promotions (Governance operator).
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireGovOperator } from "@/lib/governance-auth";

function pub(p: {
  id: string; title: string; subtitle: string; cta: string; imageUrl: string;
  target: string; accent: boolean; sortOrder: number; active: boolean;
  createdAt: Date; updatedAt: Date;
}) {
  return {
    id: p.id, title: p.title, subtitle: p.subtitle, cta: p.cta, imageUrl: p.imageUrl,
    target: p.target, accent: p.accent, sortOrder: p.sortOrder, active: p.active,
    createdAt: p.createdAt.toISOString(), updatedAt: p.updatedAt.toISOString(),
  };
}

export async function GET(req: NextRequest) {
  const guard = requireGovOperator(req);
  if ("response" in guard) return guard.response;

  const { searchParams } = new URL(req.url);
  const includeInactive = searchParams.get("includeInactive") === "true";
  const rows = await db.cmsPromotion.findMany({
    where: includeInactive ? {} : { active: true },
    orderBy: [{ sortOrder: "asc" }, { createdAt: "desc" }],
  });
  return NextResponse.json({ success: true, data: rows.map(pub) });
}

export async function POST(req: NextRequest) {
  const guard = requireGovOperator(req);
  if ("response" in guard) return guard.response;

  const body = await req.json().catch(() => null);
  if (!body) return NextResponse.json({ success: false, error: "Invalid body" }, { status: 400 });

  const row = await db.cmsPromotion.create({
    data: {
      title: String(body.title ?? ""),
      subtitle: String(body.subtitle ?? ""),
      cta: String(body.cta ?? "Play"),
      imageUrl: String(body.imageUrl ?? ""),
      target: String(body.target ?? ""),
      accent: body.accent === true,
      sortOrder: Number.isFinite(Number(body.sortOrder)) ? Number(body.sortOrder) : 0,
      active: body.active !== false,
    },
  });
  return NextResponse.json({ success: true, data: pub(row) });
}

export async function PUT(req: NextRequest) {
  const guard = requireGovOperator(req);
  if ("response" in guard) return guard.response;

  const body = await req.json().catch(() => null);
  const id = String(body?.id ?? "");
  if (!id) return NextResponse.json({ success: false, error: "id required" }, { status: 400 });

  const data: Record<string, unknown> = {};
  for (const k of ["title", "subtitle", "cta", "imageUrl", "target"]) {
    if (typeof body[k] === "string") data[k] = body[k];
  }
  if (typeof body.accent === "boolean") data.accent = body.accent;
  if (typeof body.active === "boolean") data.active = body.active;
  if (Number.isFinite(Number(body.sortOrder))) data.sortOrder = Number(body.sortOrder);

  const row = await db.cmsPromotion.update({ where: { id }, data });
  return NextResponse.json({ success: true, data: pub(row) });
}

export async function DELETE(req: NextRequest) {
  const guard = requireGovOperator(req);
  if ("response" in guard) return guard.response;

  const id = new URL(req.url).searchParams.get("id");
  if (!id) return NextResponse.json({ success: false, error: "id required" }, { status: 400 });
  await db.cmsPromotion.delete({ where: { id } });
  return NextResponse.json({ success: true, data: { deleted: id } });
}
