// /api/financial — financial overview.
//
// Bridge-aware: deposits/withdrawals come from the REAL casino via the signed
// bridge when available, otherwise from the local (demo) database. House
// earnings and the internal ledger are Governance-side (waterfall) data and
// always come from the local DB.
import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import { fetchBridgeDeposits, fetchBridgeWithdrawals } from '@/lib/platform/bridge-data'

export async function GET() {
  const [houseEarnings, ledger] = await Promise.all([
    db.houseEarning.findMany({ orderBy: { netEarning: 'desc' } }),
    db.internalLedger.findMany({ orderBy: { createdAt: 'desc' }, take: 100 }),
  ])

  // 1) Prefer real casino deposits/withdrawals via the bridge.
  const [bridgeDeposits, bridgeWithdrawals] = await Promise.all([
    fetchBridgeDeposits(),
    fetchBridgeWithdrawals(),
  ])
  if (bridgeDeposits !== null || bridgeWithdrawals !== null) {
    const deposits = (bridgeDeposits ?? []).map((d) => ({
      id: d.id,
      playerId: d.userId,
      username: d.username,
      amount: d.amount,
      amountUsd: d.amountUsd,
      currency: d.currency,
      method: d.chain,
      txHash: d.txHash,
      status: d.status,
      createdAt: d.createdAt,
    }))
    const withdrawals = (bridgeWithdrawals ?? []).map((w) => ({
      id: w.id,
      playerId: w.userId,
      username: w.username,
      amount: w.amount,
      currency: w.currency,
      method: w.chain,
      status: w.status,
      txHash: w.txHash,
      createdAt: w.createdAt,
    }))
    return NextResponse.json({ deposits, withdrawals, houseEarnings, ledger, source: 'casino' })
  }

  // 2) Fallback: local demo database.
  try {
    const [deposits, withdrawals] = await Promise.all([
      db.casinoDeposit.findMany({ include: { player: { select: { username: true } } }, orderBy: { createdAt: 'desc' }, take: 50 }),
      db.totalWithdrawal.findMany({ include: { player: { select: { username: true } } }, orderBy: { createdAt: 'desc' }, take: 50 }),
    ])
    return NextResponse.json({ deposits, withdrawals, houseEarnings, ledger, source: 'demo' })
  } catch (error) {
    console.error('financial route error:', error)
    return NextResponse.json({ error: 'Failed to fetch financial data' }, { status: 500 })
  }
}
