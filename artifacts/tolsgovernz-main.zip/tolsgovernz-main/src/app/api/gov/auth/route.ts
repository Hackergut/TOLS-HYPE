// /api/gov/auth — Governance operator sign-in (cookie session).
//   POST   { username, password } → sets the signed httpOnly cookie
//   GET    → current operator (or 401)
//   DELETE → sign out
//
// Credentials come from the environment. Two supported modes:
//   GOVERNANCE_OPERATOR_PASSWORD_HASH — scrypt hash (preferred, prod).
//     Generate with: node scripts/hash-password.mjs <password>
//   GOVERNANCE_OPERATOR_PASSWORD     — plaintext fallback (quickstart / iPad
//     where the scrypt script can't run). The server hashes it with scrypt and
//     verifies against it. Switch to the HASH form for production.
import { NextRequest, NextResponse } from "next/server";
import {
  verifyPassword,
  hashPassword,
  createGovToken,
  verifyGovToken,
  govCookieOptions,
  type GovSession,
} from "@/lib/governance-auth";

function configured() {
  return !!(
    process.env.GOVERNANCE_OPERATOR_USER &&
    (process.env.GOVERNANCE_OPERATOR_PASSWORD_HASH || process.env.GOVERNANCE_OPERATOR_PASSWORD)
  );
}

export async function POST(req: NextRequest) {
  if (!configured()) {
    return NextResponse.json(
      { success: false, error: "Operator credentials are not configured" },
      { status: 503 },
    );
  }

  const body = await req.json().catch(() => null);
  const username = String(body?.username ?? "").trim();
  const password = String(body?.password ?? "");
  const expectedUser = process.env.GOVERNANCE_OPERATOR_USER as string;

  // Same response for "wrong user" and "wrong password" — no account enumeration.
  const storedHash = process.env.GOVERNANCE_OPERATOR_PASSWORD_HASH;
  const plainPassword = process.env.GOVERNANCE_OPERATOR_PASSWORD;
  const okPassword = storedHash
    ? verifyPassword(password, storedHash)
    : plainPassword != null
      ? verifyPassword(password, hashPassword(plainPassword))
      : false;
  if (username !== expectedUser || !okPassword) {
    return NextResponse.json({ success: false, error: "Invalid credentials" }, { status: 401 });
  }

  const token = createGovToken(username);
  const res = NextResponse.json({ success: true, data: { username } });
  res.cookies.set("tols_gov_admin", token, govCookieOptions());
  return res;
}

export async function GET(req: NextRequest) {
  const session: GovSession | null = verifyGovToken(req.cookies.get("tols_gov_admin")?.value);
  return NextResponse.json({
    success: true,
    data: { authenticated: !!session, username: session?.username ?? null },
  });
}

export async function DELETE(req: NextRequest) {
  const res = NextResponse.json({ success: true, data: { signedOut: true } });
  res.cookies.set("tols_gov_admin", "", { ...govCookieOptions(), maxAge: 0 });
  return res;
}
