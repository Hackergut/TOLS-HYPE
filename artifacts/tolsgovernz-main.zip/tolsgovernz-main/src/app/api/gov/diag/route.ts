// GET /api/gov/diag — PUBLIC diagnostic of the operator-auth configuration.
//
// Why this exists: /api/gov/auth returns 503 "Operator credentials are not
// configured" whenever GOVERNANCE_OPERATOR_USER + (PASSWORD_HASH or PASSWORD)
// are missing in the *runtime*. The maddening part is that Vercel env vars only
// reach the runtime after a real Production redeploy AND with the right
// environment scope — so "I set it in the dashboard" can still 503. This route
// shows, with no login required, exactly which operator/session vars are present
// in the current deployment (booleans only — never the secret values).
//
// Safe to expose: /api/gov/auth already leaks configured-or-not via 503 vs 401.
// This only adds the per-var breakdown to help the operator pinpoint the gap.
//
//   GET /api/gov/diag   →  { configured, authMode, env: {…}, missing, hint }

import { NextResponse } from "next/server";

function present(v: string | undefined): boolean {
  return Boolean(v && v.trim().length > 0);
}

export async function GET() {
  const env = {
    GOVERNANCE_OPERATOR_USER: present(process.env.GOVERNANCE_OPERATOR_USER),
    GOVERNANCE_OPERATOR_PASSWORD: present(process.env.GOVERNANCE_OPERATOR_PASSWORD),
    GOVERNANCE_OPERATOR_PASSWORD_HASH: present(process.env.GOVERNANCE_OPERATOR_PASSWORD_HASH),
    GOVERNANCE_SESSION_SECRET:
      present(process.env.GOVERNANCE_SESSION_SECRET) &&
      (process.env.GOVERNANCE_SESSION_SECRET?.length ?? 0) >= 32,
  };

  const hasUser = env.GOVERNANCE_OPERATOR_USER;
  const hasPassword = env.GOVERNANCE_OPERATOR_PASSWORD || env.GOVERNANCE_OPERATOR_PASSWORD_HASH;
  const configured = Boolean(hasUser && hasPassword);

  // Mirrors the exact mode selection in /api/gov/auth.
  const authMode: string = !hasPassword
    ? "none"
    : env.GOVERNANCE_OPERATOR_PASSWORD_HASH
      ? "hash"
      : "plaintext";

  const missing = (Object.keys(env) as Array<keyof typeof env>).filter((k) => !env[k]);

  const hints: string[] = [];
  if (!configured) {
    hints.push(
      "Operator auth is NOT active in this deployment's runtime. POST /api/gov/auth will 503.",
    );
    if (!env.GOVERNANCE_OPERATOR_USER) {
      hints.push("GOVERNANCE_OPERATOR_USER is missing — set it (e.g. 'admin').");
    }
    if (!env.GOVERNANCE_OPERATOR_PASSWORD && !env.GOVERNANCE_OPERATOR_PASSWORD_HASH) {
      hints.push(
        "No operator password set — set GOVERNANCE_OPERATOR_PASSWORD (quickstart) OR _HASH (prod), not both.",
      );
    }
    hints.push(
      "Common cause: env var exists in Vercel but scoped to Development/Preview, or not yet picked up by a Production redeploy.",
    );
  } else if (!env.GOVERNANCE_SESSION_SECRET) {
    hints.push(
      "Credentials are set, but GOVERNANCE_SESSION_SECRET is missing or < 32 chars — login will succeed then fail to sign the cookie. Regenerate it (64 hex).",
    );
  } else {
    hints.push("Operator auth looks ready. If login still fails, the username/password value is wrong (POST returns 401, not 503).");
  }

  return NextResponse.json(
    {
      ok: true,
      configured,
      authMode,
      env, // booleans only — never values
      missing,
      hint: hints,
      note: "Only presence (true/false) is reported. Secret values are never exposed.",
      ts: new Date().toISOString(),
    },
    { headers: { "cache-control": "no-store" } },
  );
}
