// ─────────────────────────────────────────────────────────────────────────────
// GET /api/health — operator monitoring probe (public, minimal).
//
// Reports only liveness and the platform identity, never any sensitive state.
// Point an uptime monitor (UptimeRobot, Better Stack, cron-job.org) here.
// ─────────────────────────────────────────────────────────────────────────────

export async function GET() {
  return Response.json({
    ok: true,
    platform: process.env.PLATFORM_ID ?? "tols-governance",
    ts: new Date().toISOString(),
  });
}
