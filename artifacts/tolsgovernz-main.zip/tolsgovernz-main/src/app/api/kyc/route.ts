// /api/kyc — identity verification queue.
// DB-backed (Prisma `KycCase`); falls back to demo data when the database is
// unavailable (e.g. sandbox where `prisma generate` cannot download engines).
import { NextResponse } from 'next/server'

// Prisma's generated client types are unavailable until `prisma generate` runs,
// so we type the lazy-loaded client loosely here (see src/lib/db.ts).
// eslint-disable-next-line @typescript-eslint/no-explicit-any
type AnyPrisma = any

interface KycRow {
  id: string
  player: string
  email: string
  country: string
  submittedAt: string
  documents: string[]
  status: 'pending' | 'approved' | 'rejected'
  risk: 'low' | 'medium' | 'high'
}

const DEMO: KycRow[] = [
  { id: 'kyc-001', player: 'Marco_Rossi', email: 'marco@example.com', country: 'IT', submittedAt: '2026-08-16T08:10:00Z', documents: ['id_front', 'id_back', 'selfie'], status: 'pending', risk: 'low' },
  { id: 'kyc-002', player: 'Lina_Petrov', email: 'lina@example.com', country: 'DE', submittedAt: '2026-08-15T19:40:00Z', documents: ['passport', 'selfie'], status: 'pending', risk: 'medium' },
  { id: 'kyc-003', player: 'Omar_Hassan', email: 'omar@example.com', country: 'AE', submittedAt: '2026-08-15T14:05:00Z', documents: ['id_front', 'id_back'], status: 'pending', risk: 'high' },
  { id: 'kyc-004', player: 'Sofia_Lee', email: 'sofia@example.com', country: 'KR', submittedAt: '2026-08-14T11:20:00Z', documents: ['passport'], status: 'approved', risk: 'low' },
  { id: 'kyc-005', player: 'Raj_Patel', email: 'raj@example.com', country: 'IN', submittedAt: '2026-08-13T09:00:00Z', documents: ['id_front', 'selfie'], status: 'rejected', risk: 'medium' },
]

function statsOf(queue: KycRow[]) {
  return {
    pending: queue.filter((q) => q.status === 'pending').length,
    approved: queue.filter((q) => q.status === 'approved').length,
    rejected: queue.filter((q) => q.status === 'rejected').length,
    total: queue.length,
  }
}

function safeParse(docs: string): string[] {
  try {
    const parsed = JSON.parse(docs)
    return Array.isArray(parsed) ? parsed : []
  } catch {
    return []
  }
}

async function listFromDb(db: AnyPrisma): Promise<KycRow[]> {
  const rows = await db.kycCase.findMany({ orderBy: { submittedAt: 'desc' } })
  if (rows.length === 0) {
    // First read on an empty volume: seed the demo queue once.
    for (const d of DEMO) {
      await db.kycCase.create({
        data: {
          id: d.id,
          playerName: d.player,
          email: d.email,
          country: d.country,
          status: d.status,
          risk: d.risk,
          documents: JSON.stringify(d.documents),
          submittedAt: new Date(d.submittedAt),
        },
      })
    }
    return listFromDb(db)
  }
  return rows.map((r: any) => ({
    id: r.id,
    player: r.playerName,
    email: r.email,
    country: r.country,
    submittedAt: r.submittedAt.toISOString(),
    documents: safeParse(r.documents),
    status: r.status as KycRow['status'],
    risk: r.risk as KycRow['risk'],
  }))
}

export async function GET() {
  try {
    // Lazy import: if the Prisma client was not generated (sandbox), the import
    // throws here and we fall back to demo data instead of a hard 500.
    const { db } = await import('@/lib/db')
    const queue = await listFromDb(db)
    return NextResponse.json({ stats: statsOf(queue), queue })
  } catch {
    return NextResponse.json({ stats: statsOf(DEMO), queue: DEMO })
  }
}

export async function POST(req: Request) {
  const body = (await req.json().catch(() => ({}))) as {
    id?: string
    action?: 'approve' | 'reject'
    notes?: string
  }
  if (!body.id || (body.action !== 'approve' && body.action !== 'reject')) {
    return NextResponse.json({ error: 'id + action (approve|reject) required' }, { status: 400 })
  }
  try {
    const { db } = await import('@/lib/db')
    await db.kycCase.update({
      where: { id: body.id },
      data: {
        status: body.action === 'approve' ? 'approved' : 'rejected',
        reviewedAt: new Date(),
        notes: body.notes ?? '',
      },
    })
    const queue = await listFromDb(db)
    return NextResponse.json({ stats: statsOf(queue), queue })
  } catch {
    return NextResponse.json({ error: 'Database unavailable' }, { status: 503 })
  }
}
