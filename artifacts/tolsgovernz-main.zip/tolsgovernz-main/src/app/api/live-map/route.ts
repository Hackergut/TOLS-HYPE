// /api/live-map — real geo/activity map. Real data from the local DB
// (PlayerSession / ServerNode / LiveEvent).
import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

const COUNTRY: Record<string, string> = {
  US: 'United States', UK: 'United Kingdom', DE: 'Germany', CA: 'Canada',
  AU: 'Australia', JP: 'Japan', BR: 'Brazil', FR: 'France', IT: 'Italy',
  ES: 'Spain', IN: 'India', MX: 'Mexico', KR: 'South Korea', ZA: 'South Africa',
  SG: 'Singapore', IE: 'Ireland', NZ: 'New Zealand', SE: 'Sweden', NO: 'Norway',
  FI: 'Finland', DK: 'Denmark', PT: 'Portugal', PL: 'Poland', CZ: 'Czech Republic',
}

export async function GET() {
  try {
    const [sessions, nodes, events] = await Promise.all([
      db.playerSession.findMany({
        where: { status: { not: 'ended' } },
        include: { player: { select: { username: true } } },
        orderBy: { lastActivityAt: 'desc' },
      }),
      db.serverNode.findMany(),
      db.liveEvent.findMany({ orderBy: { createdAt: 'desc' }, take: 40 }),
    ])

    const activeSessions = sessions.map((s) => ({
      id: s.id,
      playerId: s.playerId,
      playerName: s.player.username,
      gameId: s.gameId,
      gameName: s.gameName,
      country: COUNTRY[s.country ?? ''] ?? s.country ?? '',
      countryCode: s.country ?? '',
      city: s.city ?? '',
      latitude: s.latitude,
      longitude: s.longitude,
      deviceType: s.deviceType ?? 'desktop',
      wagerAmount: s.wagerAmount,
      winAmount: s.winAmount,
      spinsPlayed: s.spinsPlayed,
      startedAt: s.startedAt.toISOString(),
      status: s.status,
    }))

    const serverNodes = nodes.map((n) => ({
      id: n.id,
      name: n.name,
      region: n.region,
      countryCode: n.countryCode,
      latitude: n.latitude,
      longitude: n.longitude,
      status: n.status,
      activePlayers: n.activePlayers,
      maxPlayers: n.maxPlayers,
      cpuLoad: n.cpuLoad,
      memoryLoad: n.memoryLoad,
      latencyMs: n.latencyMs,
      uptime: n.uptime,
    }))

    const liveEvents = events.map((e) => ({
      id: e.id,
      eventType: e.eventType,
      playerName: e.playerName,
      gameName: e.gameName ?? '',
      amount: e.amount,
      currency: e.currency,
      country: COUNTRY[e.country ?? ''] ?? e.country ?? '',
      countryCode: e.countryCode ?? e.country ?? '',
      city: e.city ?? '',
      latitude: e.latitude,
      longitude: e.longitude,
      createdAt: e.createdAt.toISOString(),
    }))

    const totalOnline = serverNodes.reduce((s, n) => s + n.activePlayers, 0)
    const byRegion: Record<string, number> = {}
    for (const n of serverNodes) byRegion[n.region] = (byRegion[n.region] || 0) + n.activePlayers
    const byGame: Record<string, number> = {}
    const byDevice: Record<string, number> = {}
    const byCountry: Record<string, number> = {}
    for (const s of activeSessions) {
      byGame[s.gameName] = (byGame[s.gameName] || 0) + 1
      byDevice[s.deviceType] = (byDevice[s.deviceType] || 0) + 1
      if (s.countryCode) byCountry[s.countryCode] = (byCountry[s.countryCode] || 0) + 1
    }
    const stats = { totalOnline, byRegion, byGame, byDevice, byCountry }

    return NextResponse.json({ activeSessions, serverNodes, liveEvents, stats })
  } catch (error) {
    console.error('live-map route error:', error)
    return NextResponse.json({ error: 'Failed to fetch live map data' }, { status: 500 })
  }
}
