// /api/live-players — live sessions & events. Real data from the local DB
// (PlayerSession / LiveEvent).
import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

const COUNTRY: Record<string, string> = {
  US: 'United States', UK: 'United Kingdom', DE: 'Germany', CA: 'Canada',
  AU: 'Australia', JP: 'Japan', BR: 'Brazil', FR: 'France', IT: 'Italy',
  ES: 'Spain', IN: 'India', MX: 'Mexico', KR: 'South Korea', ZA: 'South Africa',
  SG: 'Singapore', IE: 'Ireland', NZ: 'New Zealand', SE: 'Sweden', NO: 'Norway',
  FI: 'Finland', DK: 'Denmark', PT: 'Portugal', PL: 'Poland', CZ: 'Czech Republic',
}

export async function GET() {
  try {
    const [sessions, events] = await Promise.all([
      db.playerSession.findMany({
        where: { status: { not: 'ended' } },
        include: { player: { select: { username: true } } },
        orderBy: { lastActivityAt: 'desc' },
      }),
      db.liveEvent.findMany({ orderBy: { createdAt: 'desc' }, take: 40 }),
    ])

    const activeSessions = sessions.map((s) => ({
      id: s.id,
      playerId: s.playerId,
      playerName: s.player.username,
      gameId: s.gameId,
      gameName: s.gameName,
      country: COUNTRY[s.country ?? ''] ?? s.country ?? '',
      countryCode: s.country ?? '',
      city: s.city ?? '',
      latitude: s.latitude,
      longitude: s.longitude,
      deviceType: s.deviceType ?? 'desktop',
      browser: s.browser ?? '',
      os: s.os ?? '',
      entryPoint: s.entryPoint ?? '',
      wagerAmount: s.wagerAmount,
      winAmount: s.winAmount,
      spinsPlayed: s.spinsPlayed,
      startedAt: s.startedAt.toISOString(),
      lastActivityAt: s.lastActivityAt.toISOString(),
      status: s.status,
    }))

    const liveEvents = events.map((e) => ({
      id: e.id,
      eventType: e.eventType,
      playerName: e.playerName,
      gameName: e.gameName ?? '',
      amount: e.amount,
      currency: e.currency,
      country: COUNTRY[e.country ?? ''] ?? e.country ?? '',
      countryCode: e.countryCode ?? e.country ?? '',
      city: e.city ?? '',
      latitude: e.latitude,
      longitude: e.longitude,
      createdAt: e.createdAt.toISOString(),
    }))

    const online = activeSessions.filter((s) => s.status !== 'ended')
    const byDevice: Record<string, number> = { desktop: 0, mobile: 0, tablet: 0 }
    const byCountryMap: Record<string, number> = {}
    const byGameMap: Record<string, number> = {}
    let totalWagered = 0
    let totalWon = 0
    let totalDuration = 0
    for (const s of online) {
      if (s.deviceType in byDevice) byDevice[s.deviceType] += 1
      else byDevice[s.deviceType] = 1
      if (s.countryCode) byCountryMap[s.countryCode] = (byCountryMap[s.countryCode] || 0) + 1
      byGameMap[s.gameName] = (byGameMap[s.gameName] || 0) + 1
      totalWagered += s.wagerAmount
      totalWon += s.winAmount
      totalDuration += Math.max(0, (new Date(s.lastActivityAt).getTime() - new Date(s.startedAt).getTime()) / 60000)
    }
    const byCountry = Object.entries(byCountryMap).map(([country, count]) => ({ country, count })).sort((a, b) => b.count - a.count)
    const byGame = Object.entries(byGameMap).map(([game, count]) => ({ game, count })).sort((a, b) => b.count - a.count)

    const stats = {
      totalOnline: online.length,
      activeGames: byGame.length,
      avgSessionDuration: online.length ? Math.round(totalDuration / online.length) : 0,
      peakConcurrent: online.length,
      totalWageredLive: Math.round(totalWagered * 100) / 100,
      totalWonLive: Math.round(totalWon * 100) / 100,
      byDevice,
      byCountry,
      byGame,
    }

    return NextResponse.json({ activeSessions, liveEvents, stats })
  } catch (error) {
    console.error('live-players route error:', error)
    return NextResponse.json({ error: 'Failed to fetch live players data' }, { status: 500 })
  }
}
