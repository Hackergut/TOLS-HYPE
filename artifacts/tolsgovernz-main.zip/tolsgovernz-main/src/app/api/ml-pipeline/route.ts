// /api/ml-pipeline — ML models, predictions, training jobs, feature stores.
// Real data from the local DB.
import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

const iso = (d: Date | null, fallback: string | null = null) => (d ? d.toISOString() : fallback)

function featureCount(schema: string | null): number {
  if (!schema) return 0
  try {
    const v = JSON.parse(schema)
    if (Array.isArray(v)) return v.length
    if (v && typeof v === 'object') return Object.keys(v).length
    return 0
  } catch {
    return 0
  }
}

export async function GET() {
  try {
    const [models, predictions, jobs, stores] = await Promise.all([
      db.mLModel.findMany({ orderBy: { createdAt: 'asc' } }),
      db.mLPrediction.findMany({ include: { model: { select: { name: true } } }, orderBy: { executedAt: 'desc' } }),
      db.mLTrainingJob.findMany({ include: { model: { select: { name: true } } }, orderBy: { createdAt: 'desc' } }),
      db.mLFeatureStore.findMany(),
    ])

    const modelRows = models.map((m) => ({
      id: m.id,
      name: m.name,
      type: m.type,
      algorithm: m.algorithm,
      version: m.version,
      status: m.status,
      accuracy: m.accuracy,
      precision: m.precision,
      recall: m.recall,
      f1Score: m.f1Score,
      features: m.features,
      hyperparams: m.hyperparams,
      trainingDataSize: m.trainingDataSize,
      lastTrainedAt: iso(m.lastTrainedAt),
      deployedAt: iso(m.deployedAt),
      isActive: m.isActive,
      createdAt: m.createdAt.toISOString(),
    }))

    const predictionRows = predictions.map((p) => ({
      id: p.id,
      modelId: p.modelId,
      modelName: p.model.name,
      entityType: p.entityType,
      entityId: p.entityId,
      input: p.input,
      output: p.output,
      confidence: p.confidence,
      durationMs: p.durationMs,
      executedAt: p.executedAt.toISOString(),
    }))

    const jobRows = jobs.map((j) => ({
      id: j.id,
      modelId: j.modelId,
      modelName: j.model.name,
      status: j.status,
      progress: j.progress,
      startDate: iso(j.startDate),
      endDate: iso(j.endDate),
      duration: j.duration,
      metrics: j.metrics,
      error: j.error || null,
      createdAt: j.createdAt.toISOString(),
    }))

    const storeRows = stores.map((s) => ({
      id: s.id,
      name: s.name,
      description: s.description ?? '',
      featureCount: featureCount(s.schema),
      source: s.source,
      refreshInterval: s.refreshInterval,
      lastRefreshAt: iso(s.lastRefreshAt),
      isActive: s.isActive,
    }))

    return NextResponse.json({ models: modelRows, predictions: predictionRows, trainingJobs: jobRows, featureStores: storeRows })
  } catch (error) {
    console.error('ml-pipeline route error:', error)
    return NextResponse.json({ error: 'Failed to fetch ML pipeline data' }, { status: 500 })
  }
}
