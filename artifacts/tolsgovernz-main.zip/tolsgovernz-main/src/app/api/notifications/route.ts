// /api/notifications — real notifications from the local DB
// (Notification / NotificationPreference / NotificationTemplate / NotificationChannel).
import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

const iso = (d: Date | null, fallback = '') => (d ? d.toISOString() : fallback)

export async function GET() {
  try {
    const [notifications, preferences, templates, channels] = await Promise.all([
      db.notification.findMany({ orderBy: { createdAt: 'desc' } }),
      db.notificationPreference.findMany(),
      db.notificationTemplate.findMany(),
      db.notificationChannel.findMany(),
    ])

    const notificationRows = notifications.map((n) => ({
      id: n.id,
      userId: n.userId ?? '',
      type: n.type,
      category: n.category,
      priority: n.priority,
      title: n.title,
      message: n.message,
      metadata: n.metadata ?? '',
      isRead: n.isRead,
      readAt: iso(n.readAt),
      channel: n.channel,
      createdAt: n.createdAt.toISOString(),
    }))

    const preferenceRows = preferences.map((p) => ({
      id: p.id,
      category: p.category,
      channel: p.channel,
      isEnabled: p.isEnabled,
      minPriority: p.minPriority,
      quietHoursStart: p.quietHoursStart ?? '',
      quietHoursEnd: p.quietHoursEnd ?? '',
    }))

    const templateRows = templates.map((t) => ({
      id: t.id,
      name: t.name,
      category: t.category,
      titleTemplate: t.titleTemplate,
      bodyTemplate: t.bodyTemplate,
      channel: t.channel,
      isActive: t.isActive,
    }))

    const channelRows = channels.map((c) => ({
      id: c.id,
      type: c.type,
      config: c.config,
      isVerified: c.isVerified,
      isActive: c.isActive,
    }))

    const byCategory: Record<string, number> = {}
    let unread = 0
    for (const n of notificationRows) {
      byCategory[n.category] = (byCategory[n.category] || 0) + 1
      if (!n.isRead) unread++
    }
    const stats = { total: notificationRows.length, unread, byCategory }

    return NextResponse.json({
      notifications: notificationRows,
      preferences: preferenceRows,
      templates: templateRows,
      channels: channelRows,
      stats,
    })
  } catch (error) {
    console.error('notifications route error:', error)
    return NextResponse.json({ error: 'Failed to fetch notifications' }, { status: 500 })
  }
}
