// /api/payments — treasury & payments.
//
// Bridge-aware: prefers REAL casino deposits/withdrawals over the signed
// RS256-JWT bridge when configured + reachable; otherwise falls back to the
// local (demo) database. The `source` field tells the caller which is which.
import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { fetchBridgeDeposits, fetchBridgeWithdrawals } from '@/lib/platform/bridge-data'

const iso = (d: Date | null, fallback = '') => (d ? d.toISOString() : fallback)
const parseArr = (s: string | null): string[] => {
  if (!s) return []
  try {
    const v = JSON.parse(s)
    return Array.isArray(v) ? v : []
  } catch {
    return []
  }
}
const LOGO: Record<string, string> = { fiat: '💳', crypto: '₿', hybrid: '🅿️' }

interface DepositRow {
  id: string
  playerId: string
  playerName: string
  walletId: string
  amount: number
  currency: string
  method: string
  provider: string
  status: string
  txHash: string
  feeAmount: number
  netAmount: number
  createdAt: string
  confirmedAt: string
  expiresAt: string
}

interface WithdrawalRow extends DepositRow {
  approvedBy: string
  approvedAt: string
  rejectionReason: string
  processedAt: string
}

type ProviderRow = {
  id: string
  name: string
  type: string
  isActive: boolean
  minDeposit: number
  maxDeposit: number
  minWithdrawal: number
  maxWithdrawal: number
  feePercent: number
  feeFixed: number
  processingTime: string
  supportedCurrencies: string[]
  logo: string
}

function computeStats(depositRows: DepositRow[], withdrawalRows: WithdrawalRow[]) {
  const totalDeposits = depositRows.reduce((s, d) => s + d.amount, 0)
  const totalWithdrawals = withdrawalRows.reduce((s, w) => s + w.amount, 0)
  const totalFees =
    depositRows.reduce((s, d) => s + d.feeAmount, 0) + withdrawalRows.reduce((s, w) => s + w.feeAmount, 0)
  const pendingDeposits = depositRows.filter((d) => ['pending', 'processing'].includes(d.status)).length
  const pendingWithdrawals = withdrawalRows.filter((w) => ['pending', 'under_review', 'processing'].includes(w.status)).length

  const byMethod: Record<string, { count: number; total: number }> = {}
  for (const d of depositRows) {
    if (!byMethod[d.method]) byMethod[d.method] = { count: 0, total: 0 }
    byMethod[d.method].count += 1
    byMethod[d.method].total += d.amount
  }
  const byProvider: Record<string, { count: number; total: number }> = {}
  for (const d of depositRows) {
    if (!byProvider[d.provider]) byProvider[d.provider] = { count: 0, total: 0 }
    byProvider[d.provider].count += 1
    byProvider[d.provider].total += d.amount
  }

  const totalTx = depositRows.length + withdrawalRows.length
  const succeeded = [...depositRows, ...withdrawalRows].filter((t) =>
    ['confirmed', 'completed', 'approved'].includes(t.status),
  ).length
  return {
    totalDeposits: Math.round(totalDeposits * 100) / 100,
    totalWithdrawals: Math.round(totalWithdrawals * 100) / 100,
    pendingDeposits,
    pendingWithdrawals,
    approvalQueue: pendingWithdrawals,
    totalFees: Math.round(totalFees * 100) / 100,
    successRate: totalTx ? Math.round((succeeded / totalTx) * 1000) / 10 : 0,
    avgProcessingTime: 12.4,
    byMethod,
    byProvider,
  }
}

async function loadProviders(): Promise<ProviderRow[]> {
  try {
    const providers = await db.paymentProvider.findMany()
    return providers.map((p) => ({
      id: p.id,
      name: p.name,
      type: p.type,
      isActive: p.isActive,
      minDeposit: p.minDeposit,
      maxDeposit: p.maxDeposit,
      minWithdrawal: p.minWithdrawal,
      maxWithdrawal: p.maxWithdrawal,
      feePercent: p.feePercent,
      feeFixed: p.feeFixed,
      processingTime: p.processingTime,
      supportedCurrencies: parseArr(p.supportedCurrencies),
      logo: p.logo ?? LOGO[p.type] ?? '💳',
    }))
  } catch {
    return []
  }
}

export async function GET() {
  const providerRows = await loadProviders()

  // 1) Prefer real casino data via the bridge.
  const [bridgeDeposits, bridgeWithdrawals] = await Promise.all([
    fetchBridgeDeposits(),
    fetchBridgeWithdrawals(),
  ])
  if (bridgeDeposits !== null || bridgeWithdrawals !== null) {
    const depositRows: DepositRow[] = (bridgeDeposits ?? []).map((d) => ({
      id: d.id,
      playerId: d.userId,
      playerName: d.username,
      walletId: '',
      amount: d.amount,
      currency: d.currency,
      method: d.chain,
      provider: d.chain,
      status: d.status,
      txHash: d.txHash ?? '',
      feeAmount: 0,
      netAmount: d.amountUsd,
      createdAt: d.createdAt,
      confirmedAt: d.status === 'confirmed' ? d.createdAt : '',
      expiresAt: '',
    }))
    const withdrawalRows: WithdrawalRow[] = (bridgeWithdrawals ?? []).map((w) => ({
      id: w.id,
      playerId: w.userId,
      playerName: w.username,
      walletId: '',
      amount: w.amount,
      currency: w.currency,
      method: w.chain,
      provider: w.chain,
      status: w.status,
      txHash: w.txHash ?? '',
      feeAmount: 0,
      netAmount: w.amount,
      createdAt: w.createdAt,
      confirmedAt: '',
      expiresAt: '',
      approvedBy: '',
      approvedAt: w.processedDate ?? '',
      rejectionReason: '',
      processedAt: w.processedDate ?? '',
    }))
    return NextResponse.json({
      deposits: depositRows,
      withdrawals: withdrawalRows,
      providers: providerRows,
      stats: computeStats(depositRows, withdrawalRows),
      source: 'casino',
    })
  }

  // 2) Fallback: local demo database.
  try {
    const [deposits, withdrawals] = await Promise.all([
      db.depositRequest.findMany({ include: { player: { select: { username: true } } }, orderBy: { createdAt: 'desc' } }),
      db.withdrawalRequest.findMany({ include: { player: { select: { username: true } } }, orderBy: { createdAt: 'desc' } }),
    ])

    const depositRows: DepositRow[] = deposits.map((d) => ({
      id: d.id,
      playerId: d.playerId,
      playerName: d.player.username,
      walletId: d.walletId,
      amount: d.amount,
      currency: d.currency,
      method: d.method,
      provider: d.provider,
      status: d.status,
      txHash: d.txHash ?? '',
      feeAmount: d.feeAmount,
      netAmount: d.netAmount,
      createdAt: d.createdAt.toISOString(),
      confirmedAt: iso(d.confirmedAt),
      expiresAt: iso(d.expiresAt),
    }))
    const withdrawalRows: WithdrawalRow[] = withdrawals.map((w) => ({
      id: w.id,
      playerId: w.playerId,
      playerName: w.player.username,
      walletId: w.walletId,
      amount: w.amount,
      currency: w.currency,
      method: w.method,
      provider: w.provider,
      status: w.status,
      txHash: w.txHash ?? '',
      feeAmount: w.feeAmount,
      netAmount: w.netAmount,
      createdAt: w.createdAt.toISOString(),
      confirmedAt: '',
      expiresAt: '',
      approvedBy: w.approvedBy ?? '',
      approvedAt: iso(w.approvedAt),
      rejectionReason: w.rejectionReason ?? '',
      processedAt: iso(w.processedAt),
    }))

    return NextResponse.json({
      deposits: depositRows,
      withdrawals: withdrawalRows,
      providers: providerRows,
      stats: computeStats(depositRows, withdrawalRows),
      source: 'demo',
    })
  } catch (error) {
    console.error('payments route error:', error)
    return NextResponse.json({ error: 'Failed to fetch payments' }, { status: 500 })
  }
}
