// GET /api/platform/connection — Governance controller: probes the Casino
// platform (health + whoami) and reports the link status. This is what the
// Governance UI's "Casino" section calls to show connectivity.
import { NextRequest } from "next/server";
import { getPlatformClient } from "@/lib/platform/client";
import { platformOk, platformErr } from "@/lib/platform/contract";
import { requireGovOperatorOrToken } from "@/lib/governance-auth";

export async function GET(req: NextRequest) {
  const guard = requireGovOperatorOrToken(req);
  if ("response" in guard) return guard.response;

  const result = {
    ok: false,
    configured: false,
    health: null as unknown,
    claims: null as unknown,
    error: null as string | null,
  };

  // getPlatformClient() throws when the bridge env (PLATFORM_*/PARTNER_*) is
  // not configured — surface that as a clean "not configured" state instead of
  // an unhandled 500.
  let client;
  try {
    client = getPlatformClient();
    result.configured = true;
  } catch (e) {
    result.error = e instanceof Error ? e.message : "Platform integration not configured";
    return platformOk(result, 200);
  }

  try {
    const health = await client.request("GET", "/api/platform/health", { scope: "" });
    result.health = health.data;
    result.ok = health.status >= 200 && health.status < 300;
  } catch (e) {
    result.error = e instanceof Error ? e.message : "unreachable";
    return platformOk(result, 200);
  }

  try {
    const whoami = await client.request("GET", "/api/platform/whoami", { scope: "" });
    result.claims = (whoami.data as { data?: unknown })?.data ?? whoami.data;
    if (whoami.status >= 400) {
      result.ok = false;
      result.error = `whoami rejected (HTTP ${whoami.status})`;
    }
  } catch (e) {
    result.error = e instanceof Error ? e.message : "whoami failed";
  }

  return platformOk(result, 200);
}

