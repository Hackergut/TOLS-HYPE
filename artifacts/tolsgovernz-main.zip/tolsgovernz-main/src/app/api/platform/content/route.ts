// GET /api/platform/content — publish marketing content to the Casino.
// Requires a partner JWT with scope `content:read`. Returns ONLY active rows.
import { db } from "@/lib/db";
import { verifyPlatformRequest } from "@/lib/platform/verify";
import { SCOPES } from "@/lib/platform/contract";
import type { PlatformContent } from "@/lib/platform/content";

export async function GET(req: Request) {
  const auth = await verifyPlatformRequest(req, { scope: SCOPES.contentRead });
  if ("response" in auth) return auth.response;

  const [promotions, games] = await Promise.all([
    db.cmsPromotion.findMany({ where: { active: true }, orderBy: [{ sortOrder: "asc" }, { createdAt: "desc" }] }),
    db.cmsGame.findMany({ where: { active: true }, orderBy: [{ sortOrder: "asc" }, { createdAt: "desc" }] }),
  ]);

  const content: PlatformContent = {
    updatedAt: new Date().toISOString(),
    promotions: promotions.map((p) => ({
      id: p.id, title: p.title, subtitle: p.subtitle, cta: p.cta,
      imageUrl: p.imageUrl, target: p.target, accent: p.accent,
      sortOrder: p.sortOrder, active: p.active,
    })),
    games: games.map((g) => ({
      id: g.id, gameId: g.gameId, name: g.name, tagline: g.tagline,
      description: g.description, provider: g.provider, category: g.category,
      imageUrl: g.imageUrl, sortOrder: g.sortOrder,
      featured: g.featured, isNew: g.isNew, active: g.active,
    })),
  };

  return Response.json({ success: true, data: content });
}
