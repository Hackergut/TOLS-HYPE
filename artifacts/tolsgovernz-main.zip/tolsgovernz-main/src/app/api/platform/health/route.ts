// GET /api/platform/health — public liveness probe for ops/monitoring.
export async function GET() {
  return Response.json({
    ok: true,
    platform: process.env.PLATFORM_ID ?? "tols-governance",
    ts: new Date().toISOString(),
  });
}
