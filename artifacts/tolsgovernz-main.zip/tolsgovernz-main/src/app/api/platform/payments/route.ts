// GET /api/platform/payments — Governance controller: proxies the Casino's
// treasury & payments summary (watch-only) for the Governance UI.
import { NextRequest } from "next/server";
import { getPlatformClient } from "@/lib/platform/client";
import { SCOPES, platformOk, platformErr } from "@/lib/platform/contract";
import { requireGovOperatorOrToken } from "@/lib/governance-auth";

export async function GET(req: NextRequest) {
  const gate = requireGovOperatorOrToken(req);
  if ("response" in gate) return gate.response;

  try {
    const res = await getPlatformClient().get("/api/platform/payments", SCOPES.paymentsRead);
    if (res.status >= 400) {
      const d = res.data as { error?: string } | null;
      return platformErr(d?.error ?? `Casino platform error (HTTP ${res.status})`, 502);
    }
    const data = (res.data as { data?: unknown })?.data;
    return platformOk(data);
  } catch {
    return platformErr("Failed to reach casino platform", 502);
  }
}
