// GET /api/platform/stats — Governance controller: proxies the Casino's
// aggregate stats (users, bets, deposits, withdrawals) for the Governance UI
// and the operator Telegram bot.
import { NextRequest } from "next/server";
import { getPlatformClient } from "@/lib/platform/client";
import { SCOPES, platformOk, platformErr } from "@/lib/platform/contract";
import { requireGovOperatorOrToken } from "@/lib/governance-auth";

export async function GET(req: NextRequest) {
  const gate = requireGovOperatorOrToken(req);
  if ("response" in gate) return gate.response;

  try {
    // The casino's /api/platform/stats only requires a valid signed JWT
    // (no scope check); deposits:read is our least-privilege pick.
    const res = await getPlatformClient().get("/api/platform/stats", SCOPES.depositsRead);
    if (res.status >= 400) {
      const d = res.data as { error?: string } | null;
      return platformErr(d?.error ?? `Casino platform error (HTTP ${res.status})`, 502);
    }
    const data = (res.data as { data?: unknown })?.data;
    return platformOk(data);
  } catch {
    return platformErr("Failed to reach casino platform", 502);
  }
}
