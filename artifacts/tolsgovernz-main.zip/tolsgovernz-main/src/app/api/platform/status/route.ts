// GET /api/platform/status — one-shot diagnostic of the Governance ↔ Casino
// bridge. Operator-gated (machine token or operator cookie). Reports, in plain
// fields, exactly what is configured and what is still missing to activate the
// live data path — so an operator can check "is the system wired up?" quickly.
import { NextRequest } from "next/server";
import { platformOk } from "@/lib/platform/contract";
import { requireGovOperatorOrToken } from "@/lib/governance-auth";
import { isBridgeSecretReady } from "@/lib/platform/hmac";

function present(v: string | undefined): boolean {
  return Boolean(v && v.trim().length > 0);
}

export async function GET(req: NextRequest) {
  const gate = requireGovOperatorOrToken(req);
  if ("response" in gate) return gate.response;

  const configured = {
    platformId: present(process.env.PLATFORM_ID),
    platformPrivateKey: present(process.env.PLATFORM_PRIVATE_KEY),
    platformPublicKey: present(process.env.PLATFORM_PUBLIC_KEY),
    partnerPlatformId: present(process.env.PARTNER_PLATFORM_ID),
    partnerPublicKey: present(process.env.PARTNER_PUBLIC_KEY),
    partnerBaseUrl: present(process.env.PARTNER_BASE_URL),
  };

  const missing: string[] = [];
  (Object.keys(configured) as Array<keyof typeof configured>).forEach((k) => {
    if (!configured[k]) missing.push(k);
  });

  const bridgeReady = missing.length === 0;
  const hmacReady = isBridgeSecretReady();

  // Best-effort reachability probe (only if configured).
  let casino: { ok: boolean; error: string | null; health: unknown } = { ok: false, error: null, health: null };
  if (bridgeReady) {
    try {
      const { getPlatformClient } = await import("@/lib/platform/client");
      const res = await getPlatformClient().request("GET", "/api/platform/health", { scope: "", timeoutMs: 5000 });
      casino.ok = res.status >= 200 && res.status < 300;
      casino.health = res.data;
      if (!casino.ok) casino.error = `HTTP ${res.status}`;
    } catch (e) {
      casino.error = e instanceof Error ? e.message : "unreachable";
    }
  }

  return platformOk({
    ts: new Date().toISOString(),
    operatorAuth: present(process.env.GOVERNANCE_OPERATOR_USER) && present(process.env.GOVERNANCE_SESSION_SECRET),
    hmac: {
      ready: hmacReady,
      env: {
        GOVERNANCE_BRIDGE_SECRET: hmacReady,
      },
    },
    bridge: {
      ready: bridgeReady,
      missing,
      env: {
        PLATFORM_ID: process.env.PLATFORM_ID ?? null,
        PARTNER_PLATFORM_ID: process.env.PARTNER_PLATFORM_ID ?? null,
        PARTNER_BASE_URL: process.env.PARTNER_BASE_URL ?? null,
        PLATFORM_PRIVATE_KEY: configured.platformPrivateKey,
        PLATFORM_PUBLIC_KEY: configured.platformPublicKey,
        PARTNER_PUBLIC_KEY: configured.partnerPublicKey,
      },
    },
    casino,
    nextSteps: [
      ...(bridgeReady
        ? casino.ok
          ? ["JWT bridge active — money views read live casino data."]
          : ["Casino unreachable at PARTNER_BASE_URL — check the domain/network."]
        : [
            "Exchange keys: put PLATFORM_PUBLIC_KEY on the casino as PLATFORM_JWT_PUBLIC_KEY.",
            "Put the casino's public key here as PARTNER_PUBLIC_KEY.",
            ...missing.map((k) => `Set ${k}.`),
          ]),
      ...(hmacReady
        ? []
        : [
            "Set GOVERNANCE_BRIDGE_SECRET (openssl rand -hex 32) to the SAME value on tols-casino-next and tolsgovernz Production, then redeploy.",
          ]),
    ],
  });
}
