// Singular alias — Casino `pushBridgeEvent` falls back here on 404.
export { GET, POST, HEAD, OPTIONS } from "@/app/api/platform/webhooks/route";
