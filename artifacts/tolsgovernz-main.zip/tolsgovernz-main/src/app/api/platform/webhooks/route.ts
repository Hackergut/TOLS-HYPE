// /api/platform/webhooks
//   GET  — public reachability probe `{ success: true, reachable: true }`.
//          Operators (cookie / GOVERNANCE_ADMIN_TOKEN) still get the event list
//          for the Casino Link UI. Never requires a cookie for the probe.
//   POST — Casino → Governance events.
//          `{"type":"ping"}` → pong with no cookie (HMAC optional).
//          Every other event is verified ONLY with HMAC GOVERNANCE_BRIDGE_SECRET
//          (`X-Bridge-Signature` + `X-Bridge-Timestamp`). Operator cookies are
//          ignored. Idempotent on event id (explicit, or SHA-256 of the body).
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { platformOk, platformErr } from "@/lib/platform/contract";
import { peekGovOperatorOrToken } from "@/lib/governance-auth";
import {
  bridgeSignatureFromHeaders,
  eventIdFromBody,
  isBridgeSecretReady,
  verifyBridgeSignature,
  verifyBridgeTimestamp,
} from "@/lib/platform/hmac";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET,POST,OPTIONS,HEAD",
  "Access-Control-Allow-Headers":
    "Content-Type, Authorization, X-Bridge-Signature, X-Bridge-Timestamp, X-Webhook-Signature, X-Tower-Signature, X-Governance-Signature, X-Bridge-Source, X-Casino-Origin",
  "Cache-Control": "no-store",
};

function json(body: unknown, status = 200): NextResponse {
  return NextResponse.json(body, { status, headers: CORS });
}

export async function GET(req: NextRequest) {
  const operator = peekGovOperatorOrToken(req);
  if (operator) {
    try {
      const events = await db.platformEvent.findMany({
        orderBy: { receivedAt: "desc" },
        take: 100,
      });
      return platformOk(
        events.map((e) => ({
          id: e.id,
          eventId: e.eventId,
          type: e.type,
          source: e.source,
          payload: safeParse(e.payload),
          receivedAt: e.receivedAt.toISOString(),
        })),
      );
    } catch {
      return platformErr("Failed to load events", 500);
    }
  }

  return json({
    success: true,
    reachable: true,
    service: "tols-governance-bridge-webhook",
    secretReady: isBridgeSecretReady(),
    ts: new Date().toISOString(),
    hint: "POST with X-Bridge-Signature: sha256=<hmac sha256 of raw body using GOVERNANCE_BRIDGE_SECRET>",
  });
}

export async function POST(req: NextRequest) {
  const raw = await req.text();
  const sig = bridgeSignatureFromHeaders(req.headers);
  const hmacOk = verifyBridgeSignature(raw, sig);

  let body: Record<string, unknown>;
  try {
    const parsed: unknown = raw ? JSON.parse(raw) : null;
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
      return json({ success: false, error: "Invalid event body" }, 400);
    }
    body = parsed as Record<string, unknown>;
  } catch {
    return json({ success: false, error: "Invalid JSON" }, 400);
  }

  const type = String(body.type ?? body.event ?? "").trim();
  if (!type) {
    return json({ success: false, error: "Invalid event: missing type" }, 400);
  }

  // Ping is a wiring check — no cookie, HMAC optional (Casino does the same).
  if (type.toLowerCase() === "ping") {
    return json({
      success: true,
      ok: true,
      reachable: true,
      type: "pong",
      ts: new Date().toISOString(),
      note: "Governance bridge is live",
    });
  }

  if (!hmacOk) {
    if (!isBridgeSecretReady()) {
      return json(
        { success: false, error: "GOVERNANCE_BRIDGE_SECRET is not configured" },
        503,
      );
    }
    return json(
      {
        success: false,
        error:
          "Invalid bridge signature. Set the same GOVERNANCE_BRIDGE_SECRET as the Casino and send X-Bridge-Signature: sha256=<hmac>.",
      },
      401,
    );
  }

  if (!verifyBridgeTimestamp(req.headers.get("x-bridge-timestamp"))) {
    return json(
      {
        success: false,
        error: "Missing or stale X-Bridge-Timestamp (maximum clock skew: 5 minutes)",
      },
      401,
    );
  }

  const eventId = eventIdFromBody(body, raw);
  const source =
    (typeof body.source === "string" && body.source.trim()) ||
    req.headers.get("x-bridge-source") ||
    "tols-casino";
  const payload = body.payload ?? body.data ?? {};

  try {
    const saved = await db.platformEvent.upsert({
      where: { eventId },
      create: {
        eventId,
        type: type.slice(0, 80),
        source: String(source).slice(0, 64),
        payload: JSON.stringify(payload),
      },
      update: {}, // idempotent — a retried event changes nothing
    });
    return json(
      {
        success: true,
        ok: true,
        accepted: true,
        received: true,
        type,
        id: saved.id,
        eventId: saved.eventId,
        ts: new Date().toISOString(),
      },
      202,
    );
  } catch {
    return json({ success: false, error: "Failed to persist event" }, 500);
  }
}

export async function HEAD() {
  return new NextResponse(null, { status: 200, headers: CORS });
}

export async function OPTIONS() {
  return new NextResponse(null, { status: 204, headers: CORS });
}

function safeParse(value: string): unknown {
  try {
    return JSON.parse(value);
  } catch {
    return value;
  }
}
