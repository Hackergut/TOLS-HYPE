// GET /api/platform/whoami — authenticated connectivity probe.
// Requires any valid partner JWT and echoes its claims.
import { verifyPlatformRequest } from "@/lib/platform/verify";

export async function GET(req: Request) {
  const auth = await verifyPlatformRequest(req);
  if ("response" in auth) return auth.response;
  return Response.json({
    success: true,
    data: {
      claims: auth.claims,
      serverTime: new Date().toISOString(),
    },
  });
}
