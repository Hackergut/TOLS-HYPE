// POST /api/platform/withdrawals/[id]/reject — Governance controller:
// forwards a rejection decision to the Casino platform.
import { NextRequest } from "next/server";
import { getPlatformClient } from "@/lib/platform/client";
import { SCOPES, platformOk, platformErr } from "@/lib/platform/contract";
import { requireGovOperatorOrToken } from "@/lib/governance-auth";

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const gate = requireGovOperatorOrToken(req);
  if ("response" in gate) return gate.response;

  const { id } = await params;
  const body = await req.json().catch(() => null);

  try {
    const res = await getPlatformClient().post(
      `/api/platform/withdrawals/${encodeURIComponent(id)}/reject`,
      SCOPES.withdrawalsApprove,
      body ?? {},
    );
    if (res.status >= 400) {
      const data = res.data as { error?: string } | null;
      return platformErr(data?.error ?? `Casino platform error (HTTP ${res.status})`, 502);
    }
    const data = res.data as { data?: unknown };
    return platformOk(data?.data);
  } catch {
    return platformErr("Failed to reach casino platform", 502);
  }
}
