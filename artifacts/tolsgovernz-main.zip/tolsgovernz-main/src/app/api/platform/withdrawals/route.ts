// GET /api/platform/withdrawals — Governance controller: proxies the Casino's
// withdrawal list (read-only).
import { NextRequest } from "next/server";
import { getPlatformClient } from "@/lib/platform/client";
import { SCOPES, platformOk, platformErr } from "@/lib/platform/contract";
import { requireGovOperatorOrToken } from "@/lib/governance-auth";

export async function GET(req: NextRequest) {
  const gate = requireGovOperatorOrToken(req);
  if ("response" in gate) return gate.response;

  const { searchParams } = new URL(req.url);
  const status = searchParams.get("status");
  const query = status ? `?status=${encodeURIComponent(status)}` : "";

  try {
    const res = await getPlatformClient().get(`/api/platform/withdrawals${query}`, SCOPES.withdrawalsRead);
    if (res.status >= 400) {
      const data = res.data as { error?: string } | null;
      return platformErr(data?.error ?? `Casino platform error (HTTP ${res.status})`, 502);
    }
    const data = res.data as { data?: unknown };
    return platformOk(data?.data);
  } catch {
    return platformErr("Failed to reach casino platform", 502);
  }
}
