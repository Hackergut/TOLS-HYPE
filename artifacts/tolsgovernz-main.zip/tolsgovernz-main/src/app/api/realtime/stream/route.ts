// /api/realtime/stream — Server-Sent Events (SSE) live feed.
//
// Pushes synthetic live activity (deposits, wins, sessions, registrations),
// aggregate stats and the jackpot ticker over a long-lived stream. This is the
// server-push transport that powers the Governance "Live feed" — a drop-in
// realtime channel that needs no websocket server and works on any Node host.
//
// NOTE: this emits demo/synthetic data. In production, replace the generator
// with events sourced from the casino via the signed `events:write` webhook
// or a message queue.
import { NextRequest } from 'next/server'

export const dynamic = 'force-dynamic'
export const runtime = 'nodejs'

interface LiveEvent {
  id: string
  eventType: 'deposit' | 'win' | 'session' | 'registration'
  playerName: string
  gameName?: string
  amount?: number
  currency?: string
  country: string
  createdAt: string
}

const PLAYERS: { name: string; country: string }[] = [
  { name: 'Marco_Rossi', country: 'IT' },
  { name: 'Lina_Petrov', country: 'DE' },
  { name: 'Omar_Hassan', country: 'AE' },
  { name: 'Sofia_Lee', country: 'KR' },
  { name: 'Raj_Patel', country: 'IN' },
  { name: 'Chris_Jones', country: 'US' },
  { name: 'Ana_Silva', country: 'BR' },
  { name: 'Lukas_Weber', country: 'AT' },
  { name: 'Yuki_Tanaka', country: 'JP' },
  { name: 'Emma_Brown', country: 'GB' },
]

const GAMES = ['Dice', 'Crash', 'Mines', 'Plinko', 'Wheel', 'Coinflip', 'Limbo', 'Keno', 'Shoot', 'Slots']

const pick = <T,>(arr: T[]): T => arr[Math.floor(Math.random() * arr.length)]
const rand = (min: number, max: number) => Math.floor(Math.random() * (max - min + 1)) + min

function makeEvent(): LiveEvent {
  const p = pick(PLAYERS)
  const type = pick<LiveEvent['eventType']>(['deposit', 'win', 'session', 'registration'])
  const base: LiveEvent = {
    id: `ev-${Date.now()}-${rand(1000, 9999)}`,
    eventType: type,
    playerName: p.name,
    country: p.country,
    createdAt: new Date().toISOString(),
  }
  if (type === 'deposit') {
    base.amount = rand(20, 5000)
    base.currency = pick(['USDT', 'BTC', 'ETH', 'EUR'])
  } else if (type === 'win') {
    base.gameName = pick(GAMES)
    base.amount = rand(50, 25000)
    base.currency = 'USD'
  } else if (type === 'session') {
    base.gameName = pick(GAMES)
  }
  return base
}

function makeStats(totalOnline: number) {
  return {
    totalOnline,
    byRegion: { EU: rand(20, 40), AS: rand(10, 30), AM: rand(8, 20), ME: rand(3, 12) },
    byGame: { Crash: rand(10, 30), Dice: rand(10, 25), Plinko: rand(5, 20), Wheel: rand(5, 15) },
    byDevice: { mobile: rand(40, 70), desktop: rand(20, 40), tablet: rand(5, 15) },
  }
}

export async function GET(_req: NextRequest) {
  const encoder = new TextEncoder()
  let closed = false
  let totalOnline = rand(180, 260)
  let jackpot = 50_000_62 + rand(0, 500)
  let cleanup: (() => void) | undefined

  const stream = new ReadableStream<Uint8Array>({
    start(controller) {
      const send = (event: string, data: unknown) => {
        if (closed) return
        controller.enqueue(encoder.encode(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`))
      }

      // Initial snapshot so subscribers render immediately.
      send('stats', makeStats(totalOnline))
      send('jackpot', { id: 'mega', name: 'Mega Jackpot', currentAmount: jackpot })

      const ticker = setInterval(() => {
        totalOnline = Math.max(120, totalOnline + rand(-3, 3))
        jackpot += rand(1, 40)
        send('live-event', makeEvent())
        send('stats', makeStats(totalOnline))
        if (Math.random() < 0.35) {
          send('jackpot', { id: 'mega', name: 'Mega Jackpot', currentAmount: jackpot })
        }
        // Heartbeat comment keeps intermediaries from closing an idle stream.
        controller.enqueue(encoder.encode(`: ping ${Date.now()}\n\n`))
      }, 2000)

      cleanup = () => clearInterval(ticker)
    },
    cancel() {
      closed = true
      if (cleanup) cleanup()
    },
  })

  return new Response(stream, {
    headers: {
      'Content-Type': 'text/event-stream; charset=utf-8',
      'Cache-Control': 'no-cache, no-transform',
      Connection: 'keep-alive',
      'X-Accel-Buffering': 'no',
    },
  })
}
