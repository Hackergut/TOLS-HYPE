// /api/responsible-gaming — self-exclusions & limits. Real data from the DB
// (ResponsibleLimit + PlayerProfile).
import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

const iso = (d: Date | null, fallback = '') => (d ? d.toISOString() : fallback)

export async function GET() {
  try {
    const [limits, players] = await Promise.all([
      db.responsibleLimit.findMany({ orderBy: { createdAt: 'desc' } }),
      db.playerProfile.findMany({ select: { id: true, username: true } }),
    ])
    const playerName = new Map(players.map((p) => [p.id, p.username]))

    const exclusions = limits
      .filter((l) => l.selfExclusionEnd)
      .map((l) => ({
        id: l.id,
        player: playerName.get(l.playerId) ?? 'Unknown',
        type: 'self_exclusion',
        since: l.createdAt.toISOString().slice(0, 10),
        until: (l.selfExclusionEnd as Date).toISOString().slice(0, 10),
        status: (l.selfExclusionEnd as Date).getTime() > Date.now() ? 'active' : 'expired',
      }))

    const limitRows: { id: string; player: string; kind: string; value: number; status: string }[] = []
    for (const l of limits) {
      const status = l.isActive ? 'active' : 'expired'
      if (l.dailyDepositLimit) limitRows.push({ id: `${l.id}-daily`, player: playerName.get(l.playerId) ?? 'Unknown', kind: 'daily_deposit', value: l.dailyDepositLimit, status })
      if (l.weeklyDepositLimit) limitRows.push({ id: `${l.id}-weekly`, player: playerName.get(l.playerId) ?? 'Unknown', kind: 'weekly_deposit', value: l.weeklyDepositLimit, status })
      if (l.monthlyDepositLimit) limitRows.push({ id: `${l.id}-monthly`, player: playerName.get(l.playerId) ?? 'Unknown', kind: 'monthly_deposit', value: l.monthlyDepositLimit, status })
      if (l.sessionTimeLimit) limitRows.push({ id: `${l.id}-session`, player: playerName.get(l.playerId) ?? 'Unknown', kind: 'session_time', value: l.sessionTimeLimit, status })
      if (l.lossLimit) limitRows.push({ id: `${l.id}-loss`, player: playerName.get(l.playerId) ?? 'Unknown', kind: 'loss', value: l.lossLimit, status })
    }

    const stats = {
      selfExcluded: exclusions.filter((e) => e.status === 'active').length,
      activeLimits: limitRows.filter((l) => l.status === 'active').length,
      timeouts: 0,
    }

    return NextResponse.json({ stats, exclusions, limits: limitRows })
  } catch (error) {
    console.error('responsible-gaming route error:', error)
    return NextResponse.json({ error: 'Failed to fetch responsible gaming data' }, { status: 500 })
  }
}
