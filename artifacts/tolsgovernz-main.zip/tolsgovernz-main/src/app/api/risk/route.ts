// /api/risk — risk & fraud / AML flags.
// DB-backed (Prisma `AmlFlag`); falls back to demo data when the database is
// unavailable (e.g. sandbox where `prisma generate` cannot download engines).
import { NextResponse } from 'next/server'

// Prisma's generated client types are unavailable until `prisma generate` runs,
// so we type the lazy-loaded client loosely here (see src/lib/db.ts).
// eslint-disable-next-line @typescript-eslint/no-explicit-any
type AnyPrisma = any

interface RiskFlag {
  id: string
  player: string
  type: string
  severity: 'low' | 'medium' | 'high'
  detail: string
  createdAt: string
  status: 'open' | 'reviewed'
}

const DEMO: RiskFlag[] = [
  { id: 'rk-001', player: 'Omar_Hassan', type: 'aml', severity: 'high', detail: 'Deposit pattern matches structured smurfing (7 tx < $1k in 30m)', createdAt: '2026-08-16T09:30:00Z', status: 'open' },
  { id: 'rk-002', player: 'Lina_Petrov', type: 'multi_account', severity: 'medium', detail: 'Shared device + IP with 2 other accounts', createdAt: '2026-08-15T22:10:00Z', status: 'open' },
  { id: 'rk-003', player: 'Raj_Patel', type: 'chargeback', severity: 'high', detail: 'Deposit charged back by issuing bank', createdAt: '2026-08-14T16:45:00Z', status: 'open' },
  { id: 'rk-004', player: 'Sofia_Lee', type: 'bonus_abuse', severity: 'low', detail: 'Multiple accounts claiming welcome bonus', createdAt: '2026-08-13T10:00:00Z', status: 'reviewed' },
  { id: 'rk-005', player: 'Chris_Jones', type: 'aml', severity: 'medium', detail: 'Withdrawal to a wallet linked to a sanctioned list', createdAt: '2026-08-12T14:20:00Z', status: 'reviewed' },
]

function statsOf(flags: RiskFlag[]) {
  return {
    flaggedPlayers: new Set(flags.map((f) => f.player)).size,
    suspiciousTx: flags.filter((f) => f.type === 'aml' || f.type === 'chargeback').length,
    open: flags.filter((f) => f.status === 'open').length,
  }
}

async function listFromDb(db: AnyPrisma): Promise<RiskFlag[]> {
  const rows = await db.amlFlag.findMany({ orderBy: { createdAt: 'desc' } })
  if (rows.length === 0) {
    // First read on an empty volume: seed the demo flags once.
    for (const d of DEMO) {
      await db.amlFlag.create({
        data: {
          id: d.id,
          playerName: d.player,
          type: d.type,
          severity: d.severity,
          detail: d.detail,
          status: d.status,
          createdAt: new Date(d.createdAt),
        },
      })
    }
    return listFromDb(db)
  }
  return rows.map((r: any) => ({
    id: r.id,
    player: r.playerName,
    type: r.type,
    severity: r.severity as RiskFlag['severity'],
    detail: r.detail,
    createdAt: r.createdAt.toISOString(),
    status: r.status as RiskFlag['status'],
  }))
}

export async function GET() {
  try {
    // Lazy import: if the Prisma client was not generated (sandbox), the import
    // throws here and we fall back to demo data instead of a hard 500.
    const { db } = await import('@/lib/db')
    const flags = await listFromDb(db)
    return NextResponse.json({ stats: statsOf(flags), flags })
  } catch {
    return NextResponse.json({ stats: statsOf(DEMO), flags: DEMO })
  }
}

export async function POST(req: Request) {
  const body = (await req.json().catch(() => ({}))) as {
    id?: string
    action?: 'review'
  }
  if (!body.id || body.action !== 'review') {
    return NextResponse.json({ error: 'id + action (review) required' }, { status: 400 })
  }
  try {
    const { db } = await import('@/lib/db')
    await db.amlFlag.update({
      where: { id: body.id },
      data: { status: 'reviewed' },
    })
    const flags = await listFromDb(db)
    return NextResponse.json({ stats: statsOf(flags), flags })
  } catch {
    return NextResponse.json({ error: 'Database unavailable' }, { status: 503 })
  }
}
