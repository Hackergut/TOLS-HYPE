// /api/rtp — return-to-player monitor & game controls. Real data from the DB
// (GameControl).
import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

const THEORETICAL_RTP: Record<string, number> = {
  dice: 99, crash: 99, mines: 99, limbo: 99, plinko: 99, coinflip: 98,
  wheel: 98, keno: 97, slots: 97, roulette: 97.3, blackjack: 99.5, baccarat: 98.94,
}

export async function GET() {
  try {
    const controls = await db.gameControl.findMany()

    const games = controls.map((c) => {
      const theoretical = THEORETICAL_RTP[c.gameId] ?? 97
      const actual = c.totalWagered > 0 ? Math.round((c.totalWon / c.totalWagered) * 1000) / 10 : theoretical
      const diff = actual - theoretical
      const rule = diff > 1 ? 'hot' : diff < -1.5 ? 'cold' : 'normal'
      return {
        game: c.gameId,
        name: c.gameName,
        theoreticalRtp: theoretical,
        actualRtp: actual,
        wagered: Math.round(c.totalWagered),
        returned: Math.round(c.totalWon),
        winRate: c.totalWagered > 0 ? Math.round((c.totalWon / c.totalWagered) * 1000) / 10 : 0,
        rule,
      }
    })

    const offTarget = games.filter((g) => Math.abs(g.actualRtp - g.theoreticalRtp) > 1.5).length
    const avgActual = games.length ? Math.round((games.reduce((s, g) => s + g.actualRtp, 0) / games.length) * 10) / 10 : 0

    return NextResponse.json({
      summary: { gamesMonitored: games.length, avgActualRtp: avgActual, offTarget },
      games,
    })
  } catch (error) {
    console.error('rtp route error:', error)
    return NextResponse.json({ error: 'Failed to fetch RTP data' }, { status: 500 })
  }
}
