// /api/wallets — wallet ecosystem.
//
// Bridge-aware: prefers REAL casino wallet balances over the signed RS256-JWT
// bridge (`wallets:read`, added to the casino with the
// docs/casino-platform-wallets-telegram.patch), falling back to the local demo
// database when the bridge/casino is not configured or reachable.
import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { fetchBridgeWallets, type CasinoWalletRecord } from '@/lib/platform/bridge-data'

const iso = (d: Date | null, fallback = '') => (d ? d.toISOString() : fallback)
const parseArr = (s: string | null): string[] => {
  if (!s) return []
  try {
    const v = JSON.parse(s)
    return Array.isArray(v) ? v : []
  } catch {
    return []
  }
}

export async function GET() {
  // 1) Prefer real casino wallet balances via the bridge.
  const bridge = await fetchBridgeWallets()
  if (bridge !== null) {
    const wallets = bridge.wallets.map((w: CasinoWalletRecord) => ({
      id: w.id,
      playerId: w.userId,
      playerName: w.username ?? w.userId,
      currency: w.currency,
      balance: w.balance,
      availableBalance: w.balance,
      lockedBalance: 0,
      bonusBalance: 0,
      isPrimary: true,
      status: 'active',
      vipLevel: w.vipLevel,
      kycStatus: w.kycStatus,
      totalWagered: w.totalWagered,
      totalWon: w.totalWon,
      lastDepositAt: '',
      lastWithdrawAt: '',
    }))
    const byCurrency: Record<string, { balance: number; count: number }> = {}
    for (const w of wallets) {
      if (!byCurrency[w.currency]) byCurrency[w.currency] = { balance: 0, count: 0 }
      byCurrency[w.currency].balance += w.balance
      byCurrency[w.currency].count += 1
    }
    return NextResponse.json({
      wallets,
      transactions: [],
      currencyRates: [],
      totals: {
        totalBalance: Math.round((bridge.totals.balance ?? 0) * 100) / 100,
        totalAvailable: Math.round((bridge.totals.balance ?? 0) * 100) / 100,
        totalLocked: 0,
        totalBonus: 0,
        byCurrency,
      },
      paymentMethods: [],
      source: 'casino',
    })
  }

  // 2) Fallback: local demo database.
  try {
    const [wallets, transactions, currencyRates, paymentMethods, players] = await Promise.all([
      db.wallet.findMany({
        include: { player: { select: { username: true } } },
        orderBy: { createdAt: 'asc' },
      }),
      db.walletTransaction.findMany({ orderBy: { createdAt: 'desc' } }),
      db.currencyRate.findMany(),
      db.paymentMethod.findMany({ include: { player: { select: { username: true } } } }),
      db.playerProfile.findMany({ select: { id: true, username: true } }),
    ])

    // currency → USD rate lookup
    const usdRate: Record<string, number> = { USD: 1 }
    for (const r of currencyRates) {
      if (r.toCurrency === 'USD') usdRate[r.fromCurrency] = r.rate
    }

    const walletRows = wallets.map((w) => ({
      id: w.id,
      playerId: w.playerId,
      playerName: w.player.username,
      currency: w.currency,
      balance: w.balance,
      availableBalance: w.availableBalance,
      lockedBalance: w.lockedBalance,
      bonusBalance: w.bonusBalance,
      isPrimary: w.isPrimary,
      status: w.status,
      lastDepositAt: iso(w.lastDepositAt),
      lastWithdrawAt: iso(w.lastWithdrawAt),
    }))

    const txRows = transactions.map((t) => ({
      id: t.id,
      walletId: t.walletId,
      type: t.type,
      amount: t.amount,
      balanceBefore: t.balanceBefore,
      balanceAfter: t.balanceAfter,
      currency: t.currency,
      status: t.status,
      reference: t.reference ?? '',
      gameId: t.gameId ?? '',
      gameName: t.gameName ?? '',
      createdAt: t.createdAt.toISOString(),
    }))

    const rateRows = currencyRates.map((r) => ({ from: r.fromCurrency, to: r.toCurrency, rate: r.rate }))

    const pmRows = paymentMethods.map((m) => ({
      id: m.id,
      playerId: m.playerId,
      playerName: m.player.username,
      type: m.type,
      provider: m.provider,
      label: m.label,
      identifier: m.identifier ?? '',
      isDefault: m.isDefault,
      isActive: m.isActive,
      currency: m.currency,
    }))

    // totals in USD
    let totalBalance = 0
    let totalAvailable = 0
    let totalLocked = 0
    let totalBonus = 0
    const byCurrency: Record<string, { balance: number; count: number }> = {}
    for (const w of walletRows) {
      const rate = usdRate[w.currency] ?? 1
      totalBalance += w.balance * rate
      totalAvailable += w.availableBalance * rate
      totalLocked += w.lockedBalance * rate
      totalBonus += w.bonusBalance * rate
      if (!byCurrency[w.currency]) byCurrency[w.currency] = { balance: 0, count: 0 }
      byCurrency[w.currency].balance += w.balance
      byCurrency[w.currency].count += 1
    }
    const totals = {
      totalBalance: Math.round(totalBalance * 100) / 100,
      totalAvailable: Math.round(totalAvailable * 100) / 100,
      totalLocked: Math.round(totalLocked * 100) / 100,
      totalBonus: Math.round(totalBonus * 100) / 100,
      byCurrency,
    }

    return NextResponse.json({
      wallets: walletRows,
      transactions: txRows,
      currencyRates: rateRows,
      totals,
      paymentMethods: pmRows,
      source: 'demo',
    })
  } catch (error) {
    console.error('wallets route error:', error)
    return NextResponse.json({ error: 'Failed to fetch wallet data' }, { status: 500 })
  }
}
