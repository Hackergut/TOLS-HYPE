import type { Metadata } from 'next'
import Link from 'next/link'
import { DOCS_SECTIONS } from '@/lib/api-docs'

export const metadata: Metadata = {
  title: 'API Docs — TOLS Governance',
  description: 'Documentazione del bridge RS256-JWT e dei collegamenti API tra TOLS Governance e TOLS Casino.',
}

export default function DocsLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-bg text-foreground">
      <header className="sticky top-0 z-10 border-b border-border bg-bg/90 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
          <div className="flex items-center gap-2">
            <span className="flex size-7 items-center justify-center rounded-md bg-lime font-mono text-sm font-bold text-bg">
              T
            </span>
            <div className="leading-tight">
              <p className="text-sm font-semibold">TOLS Governance</p>
              <p className="text-[10px] text-muted-foreground">API &amp; Platform Docs</p>
            </div>
          </div>
          <div className="flex items-center gap-3 text-xs">
            <span className="hidden rounded-full border border-lime/30 bg-lime/10 px-2.5 py-1 text-lime sm:inline">
              Pubblico — nessun login richiesto
            </span>
            <Link
              href="/"
              className="rounded-md border border-border px-2.5 py-1 text-muted-foreground transition-colors hover:text-foreground"
            >
              Console →
            </Link>
          </div>
        </div>
      </header>

      <div className="mx-auto flex max-w-6xl gap-10 px-4 py-8">
        <nav className="hidden w-60 shrink-0 lg:block">
          <p className="mb-2 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
            Sezioni
          </p>
          <ul className="flex flex-col gap-0.5">
            {DOCS_SECTIONS.map((s) => (
              <li key={s.id}>
                <a
                  href={`#${s.id}`}
                  className="block rounded-md px-2.5 py-1.5 text-xs text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
                >
                  {s.title}
                </a>
              </li>
            ))}
          </ul>
        </nav>
        <main className="min-w-0 flex-1">{children}</main>
      </div>

      <footer className="border-t border-border">
        <div className="mx-auto max-w-6xl px-4 py-4 text-[10px] text-muted-foreground">
          TOLS Governance · bridge RS256-JWT · tenere sincronizzato con{' '}
          <code className="font-mono">src/lib/platform/contract.ts</code> e{' '}
          <code className="font-mono">docs/PLATFORM_INTEGRATION.md</code>
        </div>
      </footer>
    </div>
  )
}
