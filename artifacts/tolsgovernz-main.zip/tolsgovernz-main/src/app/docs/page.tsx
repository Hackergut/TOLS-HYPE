import type { Metadata } from 'next'
import ReactMarkdown from 'react-markdown'
import { DOCS_SECTIONS } from '@/lib/api-docs'

export const metadata: Metadata = {
  title: 'API Docs — TOLS Governance',
}

export default function DocsPage() {
  return (
    <div className="api-docs flex flex-col gap-12">
      {DOCS_SECTIONS.map((s) => (
        <section key={s.id} id={s.id} className="scroll-mt-20">
          <h2 className="mb-3 border-b border-border pb-2 text-lg font-semibold">
            {s.title}
          </h2>
          <ReactMarkdown>{s.body}</ReactMarkdown>
        </section>
      ))}
    </div>
  )
}
