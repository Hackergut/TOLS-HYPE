import type { Metadata } from "next";
import { GeistSans } from "geist/font/sans";
import { GeistMono } from "geist/font/mono";
import "./globals.css";
import { Toaster } from "@/components/ui/sonner";
import { ThemeApplier } from "@/components/theme-applier";

export const metadata: Metadata = {
  title: "TOLS Governance — Casino Control Tower",
  description:
    "Comprehensive casino management platform with Waterfall Protocol, Escrow Engine, Player Intelligence, and AI Tutor.",
  icons: {
    icon: "/logo.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <body
        className={`${GeistSans.variable} ${GeistMono.variable} antialiased bg-background text-foreground`}
      >
        <ThemeApplier />
        {children}
        <Toaster richColors position="top-right" />
      </body>
    </html>
  );
}
