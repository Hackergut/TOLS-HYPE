'use client'

import { useState, useEffect, useCallback } from 'react'
import { useAppStore, type Section } from '@/lib/store'
import { SECTIONS } from '@/lib/sections'
import { AppSidebar } from '@/components/app-sidebar'
import { CasinoOverviewView } from '@/components/casino-overview-view'
import { FinancialView } from '@/components/financial-view'
import { LiveMapView } from '@/components/live-map-view'
import { LivePlayersView } from '@/components/live-players-view'
import { CasinoUsersView } from '@/components/casino-users-view'
import { SegmentsView } from '@/components/segments-view'
import { CasinoPromotionsView } from '@/components/casino-promotions-view'
import { AffiliatesView } from '@/components/affiliates-view'
import { CasinoWalletsView } from '@/components/casino-wallets-view'
import { CasinoCashflowView } from '@/components/casino-cashflow-view'
import { CasinoBetsView } from '@/components/casino-bets-view'
import { AiTutorView } from '@/components/ai-tutor-view'
import { ApiHubView } from '@/components/api-hub-view'
import { LegalView } from '@/components/legal-view'
import { NotificationsView } from '@/components/notifications-view'
import { VendorsView } from '@/components/vendors-view'
import { AuthView } from '@/components/auth-view'
import { BlockchainView } from '@/components/blockchain-view'
import { MLPipelineView } from '@/components/ml-pipeline-view'
import { CasinoLinkView } from '@/components/casino-link-view'
import { CmsView } from '@/components/cms-view'
import { LobbyView } from '@/components/lobby-view'
import { CasinoRtpView } from '@/components/casino-rtp-view'
import { KycView } from '@/components/kyc-view'
import { ResponsibleView } from '@/components/responsible-view'
import { RiskView } from '@/components/risk-view'
import { OperatorGate, fetchOperator, signOutOperator, type Operator } from '@/components/operator-gate'
import {
  SidebarProvider,
  SidebarInset,
  SidebarTrigger,
} from '@/components/ui/sidebar'
import { Separator } from '@/components/ui/separator'
import { Badge } from '@/components/ui/badge'
import { Settings, Shield, LogOut, Loader2 } from 'lucide-react'
import { NotificationPanel } from '@/components/notification-panel'
import { SettingsDialog } from '@/components/settings-dialog'
import { SectionInfo } from '@/components/section-info'

function SectionContent({ section }: { section: Section }) {
  const def = SECTIONS[section]
  return (
    <div className="flex flex-col gap-4">
      {/* Uniform info panel on every section except the overview lobby. */}
      {section !== 'lobby' && <SectionInfo def={def} />}
      {renderView(section)}
    </div>
  )
}

function renderView(section: Section) {
  switch (section) {
    case 'lobby': return <LobbyView />
    case 'dashboard': return <CasinoOverviewView />
    case 'financial': return <FinancialView />
    case 'live-map': return <LiveMapView />
    case 'live-players': return <LivePlayersView />
    case 'players': return <CasinoUsersView />
    case 'segments': return <SegmentsView />
    case 'promotions': return <CasinoPromotionsView />
    case 'affiliates': return <AffiliatesView />
    case 'wallets': return <CasinoWalletsView />
    case 'payments': return <CasinoCashflowView />
    case 'bets': return <CasinoBetsView />
    case 'vendors': return <VendorsView />
    case 'notifications': return <NotificationsView />
    case 'api-hub': return <ApiHubView />
    case 'ai-tutor': return <AiTutorView />
    case 'legal': return <LegalView />
    case 'auth': return <AuthView />
    case 'blockchain': return <BlockchainView />
    case 'ml-pipeline': return <MLPipelineView />
    case 'rtp': return <CasinoRtpView />
    case 'kyc': return <KycView />
    case 'responsible': return <ResponsibleView />
    case 'risk': return <RiskView />
    case 'casino': return <CasinoLinkView />
    case 'cms': return <CmsView />
  }
}

export default function Home() {
  const { activeSection, activeRole } = useAppStore()
  const meta = SECTIONS[activeSection]
  const Icon = meta.icon
  const [settingsOpen, setSettingsOpen] = useState(false)
  const [operator, setOperator] = useState<Operator | null | undefined>(undefined)

  // Resolve the operator session once on load — the whole app is gated.
  useEffect(() => {
    let alive = true
    fetchOperator().then((op) => {
      if (alive) setOperator(op)
    })
    return () => {
      alive = false
    }
  }, [])

  const handleSignOut = useCallback(async () => {
    await signOutOperator()
    setOperator(null)
  }, [])

  // Still checking the session — render nothing (no data flash before auth).
  if (operator === undefined) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-bg">
        <Loader2 className="size-6 animate-spin text-lime" />
      </div>
    )
  }

  // Not signed in — the operator gate blocks the entire control tower.
  if (operator === null) {
    return <OperatorGate onAuthenticated={setOperator} />
  }

  return (
    <SidebarProvider>
      <AppSidebar />
      <SidebarInset>
        {/* Header */}
        <header className="flex h-12 shrink-0 items-center gap-1.5 sm:gap-2 border-b border-border px-2 sm:px-4">
          <SidebarTrigger className="-ml-1" />
          <Separator orientation="vertical" className="mr-1 sm:mr-2 !h-4" />
          <div className="flex items-center gap-2 flex-1 min-w-0">
            <Icon className="size-4 text-primary shrink-0" />
            <div className="min-w-0">
              <h1 className="text-xs sm:text-sm font-semibold truncate">{meta.label}</h1>
              <p className="text-[10px] text-muted-foreground truncate hidden sm:block">{meta.description}</p>
            </div>
          </div>
          <div className="flex items-center gap-1 shrink-0">
            <Badge variant="outline" className="text-[9px] border-primary/30 text-primary h-5 hidden sm:flex">
              {activeRole === 'super_admin' ? 'SUPER ADMIN' : activeRole.toUpperCase()}
            </Badge>
            {operator && (
              <span className="hidden md:flex items-center gap-1 text-[10px] text-muted-foreground">
                <Shield className="size-3 text-lime" />
                {operator.username}
              </span>
            )}
            <NotificationPanel />
            <button className="p-2 sm:p-2.5 rounded-md hover:bg-muted transition-colors" onClick={() => setSettingsOpen(true)}>
              <Settings className="size-4 text-muted-foreground" />
            </button>
            <button
              className="p-2 sm:p-2.5 rounded-md hover:bg-muted transition-colors"
              onClick={handleSignOut}
              aria-label="Sign out"
              title="Sign out"
            >
              <LogOut className="size-4 text-muted-foreground" />
            </button>
          </div>
        </header>

        {/* Content */}
        <main className="flex-1 p-4 sm:p-6 overflow-y-auto">
          <SectionContent section={activeSection} />
        </main>

        {/* Sticky Footer */}
        <footer className="mt-auto shrink-0 border-t border-border px-2 sm:px-4 py-1.5 sm:py-2">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2 sm:gap-3 text-[10px] text-muted-foreground">
              <span className="font-medium text-primary/80">TOLS</span>
              <span className="hidden sm:inline">v2.0</span>
              <span className="hidden md:inline">© 2025 TOLS Operations</span>
            </div>
            <div className="flex items-center gap-2 sm:gap-3 text-[10px]">
              <span className="flex items-center gap-1">
                <span className="size-1.5 rounded-full bg-lime" />
                <span className="text-muted-foreground hidden xs:inline">DB</span>
              </span>
              <span className="flex items-center gap-1">
                <span className="size-1.5 rounded-full bg-lime" />
                <span className="text-muted-foreground hidden sm:inline">API</span>
              </span>
              <span className="flex items-center gap-1">
                <span className="size-1.5 rounded-full bg-lime animate-pulse" />
                <span className="text-muted-foreground hidden sm:inline">Live</span>
              </span>
              <span className="flex items-center gap-1">
                <span className="size-1.5 rounded-full bg-primary" />
                <span className="text-muted-foreground hidden md:inline">Escrow</span>
              </span>
            </div>
          </div>
        </footer>
      </SidebarInset>
      <SettingsDialog open={settingsOpen} onOpenChange={setSettingsOpen} />
    </SidebarProvider>
  )
}
