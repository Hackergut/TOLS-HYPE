'use client'

// /tools/keys — TWO complete env blocks, TWO copy buttons. Nothing else.
//
// Block 1 → tolsgovernz (gov.tols.fun) on Vercel
// Block 2 → tols-casino-next (www.tols.fun) on Vercel
//
// Each block is full and self-contained: generate BOTH RSA keypairs here, then
// cross-distribute the public keys (same logic as scripts/bridge-setup.mjs).
// 100% in the browser (Web Crypto). Edit only DATABASE_URL, then copy each block
// into the right Vercel project's bulk-edit box.

import { useCallback, useEffect, useMemo, useState, type ReactNode } from 'react'
import { KeyRound, Copy, Check, RefreshCw, ShieldCheck } from 'lucide-react'

// ── crypto helpers (identical formats to scripts/generate-keys.mjs) ──

function toBase64(bytes: Uint8Array): string {
  let bin = ''
  const chunk = 0x8000
  for (let i = 0; i < bytes.length; i += chunk) {
    bin += String.fromCharCode(...bytes.subarray(i, i + chunk))
  }
  return btoa(bin)
}

function wrapPem(label: string, der: Uint8Array): string {
  const b64 = toBase64(der)
  const lines = b64.match(/.{1,64}/g)?.join('\n') ?? b64
  return `-----BEGIN ${label}-----\n${lines}\n-----END ${label}-----`
}

const pemToEnv = (pem: string) => btoa(pem) // base64(PEM) — what the server reads

function randomHex(bytes: number): string {
  const a = new Uint8Array(bytes)
  crypto.getRandomValues(a)
  return Array.from(a, (b) => b.toString(16).padStart(2, '0')).join('')
}

const PWD =
  'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789'
function randomPassword(len = 20): string {
  const a = new Uint8Array(len)
  crypto.getRandomValues(a)
  return Array.from(a, (b) => PWD[b % PWD.length]).join('')
}

async function keypair() {
  const kp = await crypto.subtle.generateKey(
    {
      name: 'RSASSA-PKCS1-v1_5',
      modulusLength: 3072,
      publicExponent: new Uint8Array([1, 0, 1]),
      hash: 'SHA-256',
    },
    true,
    ['sign', 'verify'],
  )
  const priv = new Uint8Array(await crypto.subtle.exportKey('pkcs8', kp.privateKey))
  const pub = new Uint8Array(await crypto.subtle.exportKey('spki', kp.publicKey))
  return {
    private: pemToEnv(wrapPem('PRIVATE KEY', priv)),
    public: pemToEnv(wrapPem('PUBLIC KEY', pub)),
  }
}

interface Material {
  gov: { private: string; public: string }
  casino: { private: string; public: string }
  bridgeSecret: string
  sessionSecret: string
  adminToken: string
  password: string
}

async function generateAll(): Promise<Material> {
  return {
    gov: await keypair(),
    casino: await keypair(),
    bridgeSecret: randomHex(32),
    sessionSecret: randomHex(32),
    adminToken: randomHex(32),
    password: randomPassword(20),
  }
}

export default function KeysPage() {
  const [m, setM] = useState<Material | null>(null)
  const [databaseUrl, setDatabaseUrl] = useState('')
  const [operatorUser, setOperatorUser] = useState('admin')
  const [password, setPassword] = useState('')
  const [busy, setBusy] = useState(false)

  const run = useCallback(async () => {
    setBusy(true)
    try {
      const material = await generateAll()
      setM(material)
      setPassword(material.password) // pre-fill, user can edit
    } finally {
      setBusy(false)
    }
  }, [])

  useEffect(() => {
    void run()
  }, [run])

  // Block 1 — tolsgovernz (Governance). DATABASE_URL + credentials are editable.
  const governanceBlock = useMemo(() => {
    if (!m) return ''
    return [
      `DATABASE_URL=${databaseUrl.trim()}`,
      `APP_URL=https://www.tols.fun`,
      `GOVERNANCE_TOWER_URL=https://gov.tols.fun`,
      `GOVERNANCE_BRIDGE_SECRET=${m.bridgeSecret}`,
      `GOVERNANCE_SESSION_SECRET=${m.sessionSecret}`,
      `GOVERNANCE_OPERATOR_USER=${operatorUser || 'admin'}`,
      `GOVERNANCE_OPERATOR_PASSWORD=${password}`,
      `PLATFORM_JWT_PRIVATE_KEY=${m.gov.private}`,
      `PLATFORM_JWT_ISSUER=tols-governance`,
      `PLATFORM_JWT_AUDIENCE=tols-casino`,
      `PLATFORM_ID=tols-governance`,
      `PARTNER_PLATFORM_ID=tols-casino`,
      `PARTNER_PUBLIC_KEY=${m.casino.public}`,
      `PARTNER_BASE_URL=https://www.tols.fun`,
      `GOVERNANCE_ADMIN_TOKEN=${m.adminToken}`,
    ].join('\n')
  }, [m, databaseUrl, operatorUser, password])

  // Block 2 — tols-casino-next (Casino). No DATABASE_URL (use the casino's own).
  const casinoBlock = useMemo(() => {
    if (!m) return ''
    return [
      `PLATFORM_ID=tols-casino`,
      `PLATFORM_PRIVATE_KEY=${m.casino.private}`,
      `PLATFORM_PUBLIC_KEY=${m.casino.public}`,
      `PARTNER_PLATFORM_ID=tols-governance`,
      `PARTNER_PUBLIC_KEY=${m.gov.public}`,
      `PARTNER_BASE_URL=https://gov.tols.fun`,
      `GOVERNANCE_BRIDGE_SECRET=${m.bridgeSecret}`,
      `PLATFORM_JWT_PUBLIC_KEY=${m.gov.public}`,
      `PLATFORM_JWT_ISSUER=tols-governance`,
      `PLATFORM_JWT_AUDIENCE=tols-casino`,
    ].join('\n')
  }, [m])

  return (
    <div className="mx-auto flex max-w-2xl flex-col gap-5 px-4 py-8">
      <div className="flex items-start gap-3">
        <div className="flex size-10 items-center justify-center rounded-lg border border-lime/30 bg-lime/10 text-lime">
          <KeyRound className="size-5" />
        </div>
        <div>
          <h1 className="text-base font-semibold">Vercel keys — two blocks, two copies</h1>
          <p className="text-xs text-muted-foreground">
            Generate once → copy block&nbsp;1 into <strong>tolsgovernz</strong>, block&nbsp;2 into{' '}
            <strong>tols-casino-next</strong>. Everything runs in your browser; nothing is sent
            anywhere.
          </p>
        </div>
      </div>

      <button
        onClick={run}
        disabled={busy}
        className="flex items-center justify-center gap-2 self-start rounded-lg border border-border bg-surface px-3.5 py-2 text-xs font-semibold text-muted-foreground transition-colors hover:text-foreground disabled:opacity-60"
      >
        <RefreshCw className={`size-3.5 ${busy ? 'animate-spin' : ''}`} />
        {busy ? 'Generating…' : 'Regenerate everything'}
      </button>

      {/* The values you choose — credentials + database */}
      <section className="flex flex-col gap-3 rounded-lg border border-border bg-surface p-4">
        <p className="text-xs font-semibold text-foreground">Your values</p>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <Field
            label="GOVERNANCE_OPERATOR_USER"
            value={operatorUser}
            onChange={setOperatorUser}
            placeholder="admin"
          />
          <Field
            label="GOVERNANCE_OPERATOR_PASSWORD"
            value={password}
            onChange={setPassword}
            mono
            hint="Your login password."
            trailing={
              <button
                type="button"
                onClick={() => setPassword(randomPassword(20))}
                title="Generate a new password"
                className="flex items-center gap-1 text-[11px] text-muted-foreground transition-colors hover:text-foreground"
              >
                <RefreshCw className="size-3.5" />
                New
              </button>
            }
          />
        </div>
        <Field
          label="DATABASE_URL"
          value={databaseUrl}
          onChange={setDatabaseUrl}
          mono
          placeholder="postgresql://USER:PASSWORD@HOST:5432/governance?sslmode=require"
          hint="Postgres connection string (Supabase / Neon / Vercel Postgres). The only value we can't generate."
        />
      </section>

      {m && (
        <>
          <Block
            tag="Block 1"
            title="tolsgovernz — gov.tols.fun"
            subtitle="Vercel → hackguts-projects → tolsgovernz"
            accent
            block={governanceBlock}
          />
          <Block
            tag="Block 2"
            title="tols-casino-next — www.tols.fun"
            subtitle="Vercel → the casino project"
            block={casinoBlock}
          />

          <div className="flex items-start gap-2 rounded-lg border border-border bg-surface p-3 text-[11px] text-muted-foreground">
            <ShieldCheck className="size-4 shrink-0 text-lime" />
            <div className="flex flex-col gap-1.5">
              <p>
                For each project: Vercel → Settings → Environment Variables →{' '}
                <strong className="text-foreground">Edit → bulk edit</strong> → paste the block →
                save → <strong className="text-foreground">Redeploy</strong>. The two blocks share
                the same <code className="font-mono">GOVERNANCE_BRIDGE_SECRET</code> — that&apos;s
                what links them. Operator login is <code className="font-mono">admin</code> + the
                password in block&nbsp;1.
              </p>
              <p>
                Login still says “not configured” after redeploy? Open{' '}
                <a
                  href="/api/gov/diag"
                  target="_blank"
                  rel="noreferrer"
                  className="font-mono text-lime underline underline-offset-2"
                >
                  /api/gov/diag
                </a>{' '}
                on the deployed site — it shows exactly which operator env var is missing in the
                runtime (503 = vars not reaching production; 401 = vars are there, wrong password).
              </p>
            </div>
          </div>
        </>
      )}
    </div>
  )
}

function Field({
  label,
  value,
  onChange,
  placeholder,
  mono,
  hint,
  trailing,
}: {
  label: string
  value: string
  onChange: (v: string) => void
  placeholder?: string
  mono?: boolean
  hint?: string
  trailing?: ReactNode
}) {
  return (
    <label className="flex flex-col gap-1">
      <span className="flex items-center justify-between gap-2">
        <span className="text-xs font-semibold">{label}</span>
        {trailing}
      </span>
      {hint && <span className="text-[10px] text-muted-foreground">{hint}</span>}
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        spellCheck={false}
        autoComplete="off"
        className={`w-full rounded-md border border-border bg-bg px-2.5 py-2 text-xs text-foreground outline-none transition-colors placeholder:text-muted-foreground/60 focus:border-lime/60 ${
          mono ? 'font-mono' : ''
        }`}
      />
    </label>
  )
}

function Block({
  tag,
  title,
  subtitle,
  block,
  accent,
}: {
  tag: string
  title: string
  subtitle: string
  block: string
  accent?: boolean
}) {
  const [copied, setCopied] = useState(false)
  const copy = useCallback(async () => {
    try {
      await navigator.clipboard.writeText(block)
      setCopied(true)
      setTimeout(() => setCopied(false), 1800)
    } catch {
      /* clipboard unavailable */
    }
  }, [block])

  return (
    <section
      className={`flex flex-col gap-3 rounded-lg border p-4 ${
        accent ? 'border-lime/40 bg-lime/[0.04]' : 'border-border bg-surface'
      }`}
    >
      <div className="flex items-center justify-between gap-2">
        <div>
          <p className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
            {tag}
          </p>
          <p className="text-sm font-semibold text-foreground">{title}</p>
          <p className="text-[11px] text-muted-foreground">{subtitle}</p>
        </div>
      </div>

      <textarea
        readOnly
        value={block}
        spellCheck={false}
        onClick={(e) => e.currentTarget.select()}
        className="h-52 w-full resize-y rounded-md border border-border bg-bg p-3 font-mono text-[10px] leading-relaxed text-muted-foreground outline-none"
      />

      <button
        onClick={copy}
        className={`flex items-center justify-center gap-2 rounded-lg px-4 py-3 text-sm font-semibold transition-colors ${
          accent
            ? 'bg-lime text-bg hover:bg-lime-400'
            : 'border border-border bg-bg text-foreground hover:bg-surface'
        }`}
      >
        {copied ? <Check className="size-4" /> : <Copy className="size-4" />}
        {copied ? 'Copied!' : `Copy all — ${title.split(' ')[0]}`}
      </button>
    </section>
  )
}
