'use client'

// /tools/setup — generate the production secrets from the browser.
//
// Runs 100% client-side with the Web Crypto API (no server, nothing leaves the
// device). Produces exactly the same formats the app expects:
//   • RSA-3072 keypair (PKCS#8 private / SPKI public), base64(PEM) — identical
//     to `node scripts/generate-keys.mjs` output.
//   • Random hex (for GOVERNANCE_SESSION_SECRET / GOVERNANCE_ADMIN_TOKEN).
//
// Use case: operators on iPad/phone with no terminal can generate the keys,
// then paste them into Vercel environment variables.

import { useCallback, useState } from 'react'
import Link from 'next/link'
import { KeyRound, Copy, Check, RefreshCw, ShieldAlert, Wand2 } from 'lucide-react'

const PRIVATE_LABEL = 'PRIVATE KEY'
const PUBLIC_LABEL = 'PUBLIC KEY'

function toBase64(bytes: Uint8Array): string {
  let bin = ''
  const chunk = 0x8000
  for (let i = 0; i < bytes.length; i += chunk) {
    bin += String.fromCharCode(...bytes.subarray(i, i + chunk))
  }
  return btoa(bin)
}

function wrapPem(label: string, der: Uint8Array): string {
  const b64 = toBase64(der)
  const lines = b64.match(/.{1,64}/g)?.join('\n') ?? b64
  return `-----BEGIN ${label}-----\n${lines}\n-----END ${label}-----`
}

function pemToEnv(pem: string): string {
  // Matches generate-keys.mjs: Buffer.from(pem, "utf8").toString("base64")
  return btoa(pem)
}

function randomHex(bytes: number): string {
  const a = new Uint8Array(bytes)
  crypto.getRandomValues(a)
  return Array.from(a, (b) => b.toString(16).padStart(2, '0')).join('')
}

interface Generated {
  platformPrivateKey: string
  platformPublicKey: string
  sessionSecret: string
  adminToken: string
}

async function generate(): Promise<Generated> {
  const kp = await crypto.subtle.generateKey(
    {
      name: 'RSASSA-PKCS1-v1_5',
      modulusLength: 3072,
      publicExponent: new Uint8Array([1, 0, 1]),
      hash: 'SHA-256',
    },
    true,
    ['sign', 'verify'],
  )
  const privDer = new Uint8Array(await crypto.subtle.exportKey('pkcs8', kp.privateKey))
  const pubDer = new Uint8Array(await crypto.subtle.exportKey('spki', kp.publicKey))
  return {
    platformPrivateKey: pemToEnv(wrapPem(PRIVATE_LABEL, privDer)),
    platformPublicKey: pemToEnv(wrapPem(PUBLIC_LABEL, pubDer)),
    sessionSecret: randomHex(32),
    adminToken: randomHex(32),
  }
}

function CopyField({ label, value, hint }: { label: string; value: string; hint?: string }) {
  const [copied, setCopied] = useState(false)
  const copy = useCallback(async () => {
    try {
      await navigator.clipboard.writeText(value)
      setCopied(true)
      setTimeout(() => setCopied(false), 1500)
    } catch {
      // clipboard may be unavailable — user can select manually
    }
  }, [value])

  return (
    <div className="rounded-lg border border-border bg-surface p-3">
      <div className="mb-1.5 flex items-center justify-between gap-2">
        <div>
          <p className="text-xs font-semibold">{label}</p>
          {hint && <p className="text-[10px] text-muted-foreground">{hint}</p>}
        </div>
        <button
          onClick={copy}
          className="flex items-center gap-1 rounded-md border border-border px-2 py-1 text-[11px] text-muted-foreground transition-colors hover:text-foreground"
        >
          {copied ? <Check className="size-3 text-lime" /> : <Copy className="size-3" />}
          {copied ? 'Copied' : 'Copy'}
        </button>
      </div>
      <code className="block max-h-20 overflow-auto break-all rounded bg-bg p-2 font-mono text-[10px] leading-relaxed text-muted-foreground">
        {value}
      </code>
    </div>
  )
}

export default function SetupPage() {
  const [data, setData] = useState<Generated | null>(null)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const run = useCallback(async () => {
    setBusy(true)
    setError(null)
    try {
      setData(await generate())
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Generation failed')
    } finally {
      setBusy(false)
    }
  }, [])

  return (
    <div className="mx-auto flex max-w-2xl flex-col gap-5 px-4 py-8">
      <div className="flex items-start gap-3">
        <div className="flex size-10 items-center justify-center rounded-lg border border-lime/30 bg-lime/10 text-lime">
          <KeyRound className="size-5" />
        </div>
        <div>
          <h1 className="text-base font-semibold">Setup — generate production secrets</h1>
          <p className="text-xs text-muted-foreground">
            Everything runs in your browser (Web Crypto). Nothing is sent to any server. Copy the
            values into Vercel → Settings → Environment Variables.
          </p>
        </div>
      </div>

      <Link
        href="/tools/keys"
        className="flex items-center justify-between gap-2 rounded-lg border border-lime/40 bg-lime/[0.06] px-3 py-2.5 text-xs transition-colors hover:bg-lime/10"
      >
        <span className="flex items-center gap-2">
          <Wand2 className="size-4 text-lime" />
          <span>
            <strong className="text-foreground">Want the easy way?</strong> Get the two complete
            Vercel blocks (Governance + Casino) with one copy each →
          </span>
        </span>
        <span className="shrink-0 text-lime">/tools/keys</span>
      </Link>

      <div className="flex items-start gap-2 rounded-lg border border-pending/30 bg-pending/10 p-3">
        <ShieldAlert className="size-4 shrink-0 text-pending" />
        <p className="text-[11px] text-muted-foreground">
          These are <strong className="text-foreground">secrets</strong>. Generate them once, paste
          them into Vercel, and don&apos;t share them. For a real production launch, regenerate on a
          machine with <code className="font-mono">node scripts/generate-keys.mjs</code>.
        </p>
      </div>

      <button
        onClick={run}
        disabled={busy}
        className="flex items-center justify-center gap-2 rounded-lg bg-lime px-4 py-2.5 text-sm font-semibold text-bg transition-colors hover:bg-lime-400 disabled:opacity-60"
      >
        {busy ? <RefreshCw className="size-4 animate-spin" /> : <KeyRound className="size-4" />}
        {busy ? 'Generating…' : data ? 'Regenerate' : 'Generate keys & secrets'}
      </button>

      {error && (
        <div className="rounded-lg border border-destructive/40 p-3 text-xs text-loss">{error}</div>
      )}

      {data && (
        <div className="flex flex-col gap-3">
          <CopyField
            label="PLATFORM_PRIVATE_KEY"
            hint="Governance private key — keep secret (this platform only)"
            value={data.platformPrivateKey}
          />
          <CopyField
            label="PLATFORM_PUBLIC_KEY"
            hint="Governance public key — give this to the Casino (its PARTNER_PUBLIC_KEY)"
            value={data.platformPublicKey}
          />
          <CopyField
            label="GOVERNANCE_SESSION_SECRET"
            hint="Signs the operator session cookie"
            value={data.sessionSecret}
          />
          <CopyField
            label="GOVERNANCE_ADMIN_TOKEN"
            hint="Optional — machine bearer token for scripted/CI calls"
            value={data.adminToken}
          />
        </div>
      )}

      <div className="rounded-lg border border-border bg-surface p-3 text-[11px] text-muted-foreground">
        <p className="mb-1 font-semibold text-foreground">Where each value goes (Vercel)</p>
        <p>• <code className="font-mono">PLATFORM_PRIVATE_KEY</code> / <code className="font-mono">PLATFORM_PUBLIC_KEY</code> → Governance project</p>
        <p>• <code className="font-mono">PLATFORM_PUBLIC_KEY</code> → Casino project as <code className="font-mono">PARTNER_PUBLIC_KEY</code></p>
        <p>• Casino&apos;s public key → Governance as <code className="font-mono">PARTNER_PUBLIC_KEY</code></p>
        <p>• <code className="font-mono">GOVERNANCE_SESSION_SECRET</code> / <code className="font-mono">GOVERNANCE_ADMIN_TOKEN</code> → Governance project</p>
      </div>
    </div>
  )
}
