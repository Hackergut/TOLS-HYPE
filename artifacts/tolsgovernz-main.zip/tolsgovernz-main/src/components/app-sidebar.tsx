'use client'

import { DollarSign, TrendingUp, Shield, Crown } from 'lucide-react'
import { useAppStore, type Section } from '@/lib/store'
import { sectionsByGroup, type UserRole } from '@/lib/sections'
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarRail,
  SidebarSeparator,
  useSidebar,
} from '@/components/ui/sidebar'
import { Badge } from '@/components/ui/badge'
import { cn } from '@/lib/utils'

const ROLE_OPTIONS: { role: UserRole; label: string; icon: React.ElementType }[] = [
  { role: 'finance', label: 'Finance', icon: DollarSign },
  { role: 'controller', label: 'Controller', icon: TrendingUp },
  { role: 'super_admin', label: 'Admin', icon: Crown },
]

export function AppSidebar() {
  const { activeSection, setActiveSection, activeRole, setActiveRole } = useAppStore()
  const { isMobile, setOpenMobile } = useSidebar()

  const groups = sectionsByGroup(activeRole)

  const handleSectionClick = (section: Section) => {
    setActiveSection(section)
    if (isMobile) setOpenMobile(false)
  }

  return (
    <Sidebar collapsible="icon">
      <SidebarHeader className="p-4">
        <div className="flex items-center gap-2 group-data-[collapsible=icon]:justify-center">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-primary-foreground font-bold text-sm shrink-0">
            T
          </div>
          <div className="flex flex-col group-data-[collapsible=icon]:hidden">
            <span className="text-sm font-bold text-primary tracking-wider">TOLS</span>
            <span className="text-[10px] text-muted-foreground leading-none">Governance</span>
          </div>
        </div>
      </SidebarHeader>

      <SidebarSeparator />

      <SidebarContent>
        {groups.map((group) => (
          <SidebarGroup key={group.group}>
            <SidebarGroupLabel>{group.label}</SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {group.items.map((item) => (
                  <SidebarMenuItem key={item.id}>
                    <SidebarMenuButton
                      isActive={activeSection === item.id}
                      onClick={() => handleSectionClick(item.id)}
                      tooltip={item.label}
                      className="gap-3"
                    >
                      <item.icon className="size-4 shrink-0" />
                      <span className="flex-1">{item.label}</span>
                      {item.badge && (
                        <Badge
                          variant="secondary"
                          className="h-4 px-1 text-[9px] font-bold group-data-[collapsible=icon]:hidden bg-lime/15 text-lime border-lime/30"
                        >
                          {item.badge}
                        </Badge>
                      )}
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        ))}
      </SidebarContent>

      <SidebarFooter>
        <SidebarSeparator />
        <div className="flex flex-col gap-2 p-2 group-data-[collapsible=icon]:items-center group-data-[collapsible=icon]:p-0">
          <span className="flex items-center gap-2 px-1 text-[10px] uppercase tracking-wider text-muted-foreground group-data-[collapsible=icon]:hidden">
            <Shield className="size-3.5" /> Role
          </span>
          <div className="grid grid-cols-3 gap-1 rounded-lg bg-secondary p-1 group-data-[collapsible=icon]:hidden">
            {ROLE_OPTIONS.map(({ role, label, icon: Icon }) => (
              <button
                key={role}
                onClick={() => setActiveRole(role)}
                className={cn(
                  'flex flex-col items-center gap-0.5 rounded-md px-1 py-1.5 text-[10px] font-semibold transition-colors',
                  activeRole === role ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground',
                )}
              >
                <Icon className="size-3.5" />
                {label}
              </button>
            ))}
          </div>
          <div className="group-data-[collapsible=icon]:hidden">
            <Badge variant="outline" className="text-[9px] border-primary/30 text-primary">
              {activeRole === 'super_admin' ? 'SUPER ADMIN' : activeRole.toUpperCase()}
            </Badge>
          </div>
        </div>
      </SidebarFooter>

      <SidebarRail />
    </Sidebar>
  )
}
