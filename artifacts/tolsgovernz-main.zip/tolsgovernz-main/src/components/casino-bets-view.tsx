'use client'

// Bets — LIVE settled wagers from GET /api/platform/bets.
// Filters: gameId, userId, result (win|lose|push).
import { useMemo, useState } from 'react'
import { Dice5, TrendingUp, TrendingDown, RefreshCw, Search } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import { StatCard } from '@/components/stat-card'
import { useCasino, formatUsd, formatWhen } from '@/hooks/use-casino'
import { cn } from '@/lib/utils'

interface BetRow {
  id: string
  userId: string
  username: string | null
  gameId: string
  gameName: string
  amount: number
  multiplier: number
  payout: number
  result: string
  createdAt: string
}

const GAMES = [
  'crash', 'dice', 'mines', 'wheel', 'keno', 'limbo', 'plinko', 'coinflip',
  'shoot', 'poolrush', 'blackjack', 'roulette', 'slots', 'scopa',
]

const PAGE = 50

export function CasinoBetsView() {
  const [game, setGame] = useState('all')
  const [result, setResult] = useState('all')
  const [userInput, setUserInput] = useState('')
  const [userId, setUserId] = useState('')
  const [offset, setOffset] = useState(0)

  const path = useMemo(() => {
    const p = new URLSearchParams({ limit: String(PAGE), offset: String(offset) })
    if (game !== 'all') p.set('gameId', game)
    if (result !== 'all') p.set('result', result)
    if (userId) p.set('userId', userId)
    return `/api/casino/bets?${p.toString()}`
  }, [game, result, userId, offset])

  const { data, envelope, loading, error, refetch } = useCasino<BetRow[]>(path, 30_000)

  const rows = data ?? []
  const staked = rows.reduce((s, b) => s + b.amount, 0)
  const paid = rows.reduce((s, b) => s + b.payout, 0)

  return (
    <div className="flex flex-col gap-4">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <StatCard icon={Dice5} label="Bets (filter)" value={String(envelope?.pagination?.total ?? rows.length)} />
        <StatCard icon={TrendingUp} label="Staked (page)" value={formatUsd(staked)} />
        <StatCard icon={TrendingDown} label="Paid out (page)" value={formatUsd(paid)} />
        <StatCard
          icon={TrendingUp}
          label="Hold (page)"
          value={formatUsd(staked - paid)}
          tone={staked - paid >= 0 ? 'text-lime' : 'text-loss'}
        />
      </div>

      <Card className="border-border bg-surface">
        <CardContent className="flex flex-col gap-3 p-4">
          <div className="flex flex-wrap items-center gap-2">
            <Select value={game} onValueChange={(v) => { setGame(v); setOffset(0) }}>
              <SelectTrigger className="w-36"><SelectValue placeholder="Game" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All games</SelectItem>
                {GAMES.map((g) => <SelectItem key={g} value={g} className="capitalize">{g}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={result} onValueChange={(v) => { setResult(v); setOffset(0) }}>
              <SelectTrigger className="w-32"><SelectValue placeholder="Result" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All results</SelectItem>
                <SelectItem value="win">Win</SelectItem>
                <SelectItem value="lose">Lose</SelectItem>
                <SelectItem value="push">Push</SelectItem>
              </SelectContent>
            </Select>
            <form
              className="flex flex-1 items-center gap-2"
              onSubmit={(e) => { e.preventDefault(); setOffset(0); setUserId(userInput.trim()) }}
            >
              <div className="relative min-w-44 flex-1">
                <Search className="absolute left-2.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
                <Input value={userInput} onChange={(e) => setUserInput(e.target.value)} placeholder="Filter by user id…" className="pl-8" />
              </div>
              <Button type="submit" variant="secondary" size="sm">Filter</Button>
            </form>
            <Button variant="outline" size="sm" onClick={refetch}><RefreshCw className="size-4" /> Refresh</Button>
          </div>

          {error && !data ? (
            <p className="p-6 text-center text-sm text-muted-foreground">Could not load Casino bets: {error}</p>
          ) : loading && !data ? (
            <Skeleton className="h-64 w-full" />
          ) : (
            <div className="overflow-x-auto rounded-lg border border-border">
              <Table>
                <TableHeader>
                  <TableRow className="hover:bg-transparent">
                    <TableHead className="text-[11px] text-muted-foreground">Player</TableHead>
                    <TableHead className="text-[11px] text-muted-foreground">Game</TableHead>
                    <TableHead className="text-[11px] text-muted-foreground">Stake</TableHead>
                    <TableHead className="text-[11px] text-muted-foreground">Multiplier</TableHead>
                    <TableHead className="text-[11px] text-muted-foreground">Payout</TableHead>
                    <TableHead className="text-[11px] text-muted-foreground">Result</TableHead>
                    <TableHead className="text-[11px] text-muted-foreground">When</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {rows.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={7} className="p-8 text-center text-sm text-muted-foreground">
                        No settled bets match this filter on the Casino yet.
                      </TableCell>
                    </TableRow>
                  ) : (
                    rows.map((b) => (
                      <TableRow key={b.id} className="border-border">
                        <TableCell className="text-sm">{b.username ?? b.userId}</TableCell>
                        <TableCell className="capitalize text-muted-foreground">{b.gameName || b.gameId}</TableCell>
                        <TableCell className="font-mono tabular-nums">{formatUsd(b.amount)}</TableCell>
                        <TableCell className="font-mono tabular-nums text-muted-foreground">{b.multiplier ? `${b.multiplier.toFixed(2)}×` : '—'}</TableCell>
                        <TableCell className={cn('font-mono font-bold tabular-nums', b.payout > 0 ? 'text-lime' : 'text-muted-foreground')}>
                          {formatUsd(b.payout)}
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant="outline"
                            className={cn(
                              'border capitalize',
                              b.result === 'win'
                                ? 'bg-lime/15 text-lime border-lime/30'
                                : b.result === 'lose'
                                  ? 'bg-loss/15 text-loss border-loss/30'
                                  : 'bg-secondary text-muted-foreground border-border',
                            )}
                          >
                            {b.result}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-xs text-muted-foreground">{formatWhen(b.createdAt)}</TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          )}

          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>
              {(envelope?.pagination?.total ?? 0) > 0
                ? `${offset + 1}–${offset + rows.length} of ${envelope?.pagination?.total}`
                : 'No results'}
            </span>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" disabled={offset === 0} onClick={() => setOffset(Math.max(0, offset - PAGE))}>Previous</Button>
              <Button variant="outline" size="sm" disabled={!envelope?.pagination?.hasMore} onClick={() => setOffset(offset + PAGE)}>Next</Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
