'use client'

// Cash flow — LIVE from GET /api/platform/cashflow, /deposits and
// /withdrawals. The withdrawals queue approves/rejects straight back to the
// Casino (POST /api/platform/withdrawals/:id/approve|reject).
import { useMemo, useState } from 'react'
import { toast } from 'sonner'
import {
  ArrowDownLeft, ArrowUpRight, Landmark, TrendingUp, RefreshCw, Loader2,
  CheckCircle2, XCircle,
} from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { StatCard } from '@/components/stat-card'
import { useCasino, casinoFetch, formatUsd, formatWhen } from '@/hooks/use-casino'
import { cn } from '@/lib/utils'

interface CashflowData {
  deposits: { status: string; count: number; amount: number }[]
  withdrawals: { status: string; count: number; amount: number }[]
  house: { bets: number; wagered: number; paid: number; profit: number }
  wagers: { count: number; staked: number; returned: number }
}

interface DepositRow {
  id: string
  userId: string
  username: string | null
  email: string | null
  chain: string
  currency: string
  amount: number
  txHash: string
  status: string
  credited: boolean
  createdAt: string
}

interface WithdrawalRow {
  id: string
  userId: string
  username: string | null
  email: string | null
  amount: number
  currency: string
  chain: string
  walletAddress: string
  status: string
  txHash: string
  processedDate: string | null
  createdAt: string
}

function statusBadge(status: string) {
  const tone =
    status === 'confirmed' || status === 'approved' || status === 'completed'
      ? 'bg-lime/15 text-lime border-lime/30'
      : status === 'pending' || status === 'processing'
        ? 'bg-pending/15 text-pending border-pending/30'
        : status === 'rejected' || status === 'failed'
          ? 'bg-loss/15 text-loss border-loss/30'
          : 'bg-secondary text-muted-foreground border-border'
  return <Badge variant="outline" className={cn('border capitalize', tone)}>{status}</Badge>
}

function shortHash(v: string | null | undefined, n = 12): string {
  if (!v) return '—'
  return v.length > n ? `${v.slice(0, n)}…` : v
}

export function CasinoCashflowView() {
  const [depositStatus, setDepositStatus] = useState('all')
  const [withdrawalStatus, setWithdrawalStatus] = useState('pending')
  const [decision, setDecision] = useState<{ w: WithdrawalRow; action: 'approve' | 'reject' } | null>(null)
  const [txHash, setTxHash] = useState('')
  const [note, setNote] = useState('')
  const [busy, setBusy] = useState(false)

  const cashflow = useCasino<CashflowData>('/api/casino/cashflow', 30_000)

  const depositsPath = useMemo(() => {
    const p = new URLSearchParams({ limit: '50' })
    if (depositStatus !== 'all') p.set('status', depositStatus)
    return `/api/casino/deposits?${p.toString()}`
  }, [depositStatus])
  const deposits = useCasino<DepositRow[]>(depositsPath)

  const withdrawalsPath = useMemo(() => {
    const p = new URLSearchParams({ limit: '50' })
    p.set('status', withdrawalStatus)
    return `/api/casino/withdrawals?${p.toString()}`
  }, [withdrawalStatus])
  const withdrawals = useCasino<WithdrawalRow[]>(withdrawalsPath)

  const cf = cashflow.data
  const depositsConfirmed = cf?.deposits.find((d) => d.status === 'confirmed')
  const totalDeposits = (cf?.deposits ?? []).reduce((s, d) => s + d.amount, 0)
  const approvedWithdrawals = cf?.withdrawals.find((w) => w.status === 'approved')
  const pendingWithdrawals = cf?.withdrawals.find((w) => w.status === 'pending')

  async function submitDecision(e: React.FormEvent) {
    e.preventDefault()
    if (!decision) return
    setBusy(true)
    try {
      const body =
        decision.action === 'approve'
          ? { txHash: txHash.trim() || undefined }
          : { reason: note.trim() || 'rejected by governance operator' }
      await casinoFetch(`/api/casino/withdrawals/${encodeURIComponent(decision.w.id)}/${decision.action}`, {
        method: 'POST',
        body: JSON.stringify(body),
      })
      toast.success(
        `Withdrawal ${decision.action === 'approve' ? 'approved' : 'rejected'} for ${decision.w.username ?? decision.w.userId}`,
      )
      setDecision(null)
      setTxHash('')
      setNote('')
      withdrawals.refetch()
      cashflow.refetch()
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Decision failed')
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <StatCard
          icon={ArrowDownLeft}
          label="Deposits (all)"
          value={formatUsd(totalDeposits)}
          sub={depositsConfirmed ? `${depositsConfirmed.count} confirmed` : undefined}
          tone="text-lime"
        />
        <StatCard
          icon={ArrowUpRight}
          label="Withdrawals paid"
          value={formatUsd(approvedWithdrawals?.amount ?? 0)}
          sub={`${approvedWithdrawals?.count ?? 0} approved`}
        />
        <StatCard
          icon={Landmark}
          label="Pending queue"
          value={formatUsd(pendingWithdrawals?.amount ?? 0)}
          sub={`${pendingWithdrawals?.count ?? 0} waiting`}
          tone={(pendingWithdrawals?.count ?? 0) > 0 ? 'text-pending' : 'text-foreground'}
        />
        <StatCard
          icon={TrendingUp}
          label="House P&L"
          value={formatUsd(cf?.house.profit ?? 0)}
          sub={cf ? `${cf.house.bets} settled bets` : undefined}
          tone={(cf?.house.profit ?? 0) >= 0 ? 'text-lime' : 'text-loss'}
        />
      </div>

      {cashflow.error && !cf && (
        <Card className="border-destructive/40">
          <CardContent className="flex items-center justify-between p-4 text-sm text-muted-foreground">
            <span>Could not load Casino cash flow: {cashflow.error}</span>
            <Button variant="outline" size="sm" onClick={cashflow.refetch}><RefreshCw className="size-4" /> Retry</Button>
          </CardContent>
        </Card>
      )}

      <Tabs defaultValue="withdrawals">
        <TabsList>
          <TabsTrigger value="withdrawals">Withdrawals queue</TabsTrigger>
          <TabsTrigger value="deposits">Deposits</TabsTrigger>
          <TabsTrigger value="pnl">House P&L</TabsTrigger>
        </TabsList>

        <TabsContent value="withdrawals">
          <Card className="border-border bg-surface">
            <CardHeader className="flex flex-row items-center justify-between px-4 py-3">
              <div>
                <CardTitle className="text-sm">Withdrawal requests</CardTitle>
                <CardDescription className="text-xs">Approve or reject — the decision settles on the Casino immediately.</CardDescription>
              </div>
              <div className="flex items-center gap-2">
                <Select value={withdrawalStatus} onValueChange={setWithdrawalStatus}>
                  <SelectTrigger className="w-32"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="approved">Approved</SelectItem>
                    <SelectItem value="rejected">Rejected</SelectItem>
                    <SelectItem value="all">All</SelectItem>
                  </SelectContent>
                </Select>
                <Button variant="outline" size="sm" onClick={withdrawals.refetch}><RefreshCw className="size-4" /></Button>
              </div>
            </CardHeader>
            <CardContent className="px-4 pb-4">
              {withdrawals.error && !withdrawals.data ? (
                <p className="p-6 text-center text-sm text-muted-foreground">Could not load withdrawals: {withdrawals.error}</p>
              ) : withdrawals.loading && !withdrawals.data ? (
                <Skeleton className="h-48 w-full" />
              ) : (
                <div className="overflow-x-auto rounded-lg border border-border">
                  <Table>
                    <TableHeader>
                      <TableRow className="hover:bg-transparent">
                        <TableHead className="text-[11px] text-muted-foreground">Player</TableHead>
                        <TableHead className="text-[11px] text-muted-foreground">Amount</TableHead>
                        <TableHead className="text-[11px] text-muted-foreground">Chain</TableHead>
                        <TableHead className="text-[11px] text-muted-foreground">Address</TableHead>
                        <TableHead className="text-[11px] text-muted-foreground">Status</TableHead>
                        <TableHead className="text-[11px] text-muted-foreground">Requested</TableHead>
                        <TableHead className="text-right text-[11px] text-muted-foreground">Decision</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {(withdrawals.data ?? []).length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={7} className="p-8 text-center text-sm text-muted-foreground">
                            No {withdrawalStatus === 'all' ? '' : `${withdrawalStatus} `}withdrawals on the Casino right now.
                          </TableCell>
                        </TableRow>
                      ) : (
                        (withdrawals.data ?? []).map((w) => (
                          <TableRow key={w.id} className="border-border">
                            <TableCell>
                              <p className="text-sm font-medium">{w.username ?? w.userId}</p>
                              <p className="text-[11px] text-muted-foreground">{w.email ?? '—'}</p>
                            </TableCell>
                            <TableCell className="font-mono font-bold tabular-nums">{formatUsd(w.amount)}</TableCell>
                            <TableCell className="capitalize text-muted-foreground">{w.chain}</TableCell>
                            <TableCell className="font-mono text-xs text-muted-foreground">{shortHash(w.walletAddress)}</TableCell>
                            <TableCell>{statusBadge(w.status)}</TableCell>
                            <TableCell className="text-xs text-muted-foreground">{formatWhen(w.createdAt)}</TableCell>
                            <TableCell className="text-right">
                              {w.status === 'pending' ? (
                                <div className="flex justify-end gap-2">
                                  <Button size="sm" onClick={() => setDecision({ w, action: 'approve' })} className="active:scale-[0.97]">
                                    <CheckCircle2 className="size-4" /> Approve
                                  </Button>
                                  <Button size="sm" variant="destructive" onClick={() => setDecision({ w, action: 'reject' })} className="active:scale-[0.97]">
                                    <XCircle className="size-4" /> Reject
                                  </Button>
                                </div>
                              ) : (
                                <span className="text-xs text-muted-foreground">{shortHash(w.txHash)}</span>
                              )}
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="deposits">
          <Card className="border-border bg-surface">
            <CardHeader className="flex flex-row items-center justify-between px-4 py-3">
              <div>
                <CardTitle className="text-sm">Deposit ledger</CardTitle>
                <CardDescription className="text-xs">On-chain deposits credited to player wallets.</CardDescription>
              </div>
              <div className="flex items-center gap-2">
                <Select value={depositStatus} onValueChange={setDepositStatus}>
                  <SelectTrigger className="w-32"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="confirmed">Confirmed</SelectItem>
                    <SelectItem value="failed">Failed</SelectItem>
                  </SelectContent>
                </Select>
                <Button variant="outline" size="sm" onClick={deposits.refetch}><RefreshCw className="size-4" /></Button>
              </div>
            </CardHeader>
            <CardContent className="px-4 pb-4">
              {deposits.error && !deposits.data ? (
                <p className="p-6 text-center text-sm text-muted-foreground">Could not load deposits: {deposits.error}</p>
              ) : deposits.loading && !deposits.data ? (
                <Skeleton className="h-48 w-full" />
              ) : (
                <div className="overflow-x-auto rounded-lg border border-border">
                  <Table>
                    <TableHeader>
                      <TableRow className="hover:bg-transparent">
                        <TableHead className="text-[11px] text-muted-foreground">Player</TableHead>
                        <TableHead className="text-[11px] text-muted-foreground">Amount</TableHead>
                        <TableHead className="text-[11px] text-muted-foreground">Chain</TableHead>
                        <TableHead className="text-[11px] text-muted-foreground">Tx hash</TableHead>
                        <TableHead className="text-[11px] text-muted-foreground">Status</TableHead>
                        <TableHead className="text-[11px] text-muted-foreground">Credited</TableHead>
                        <TableHead className="text-[11px] text-muted-foreground">When</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {(deposits.data ?? []).length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={7} className="p-8 text-center text-sm text-muted-foreground">
                            No {depositStatus === 'all' ? '' : `${depositStatus} `}deposits on the Casino yet.
                          </TableCell>
                        </TableRow>
                      ) : (
                        (deposits.data ?? []).map((d) => (
                          <TableRow key={d.id} className="border-border">
                            <TableCell>
                              <p className="text-sm font-medium">{d.username ?? d.userId}</p>
                              <p className="text-[11px] text-muted-foreground">{d.email ?? '—'}</p>
                            </TableCell>
                            <TableCell className="font-mono font-bold tabular-nums">
                              {d.amount.toLocaleString('en-US', { maximumFractionDigits: 6 })} {d.currency}
                            </TableCell>
                            <TableCell className="capitalize text-muted-foreground">{d.chain}</TableCell>
                            <TableCell className="font-mono text-xs text-muted-foreground">{shortHash(d.txHash)}</TableCell>
                            <TableCell>{statusBadge(d.status)}</TableCell>
                            <TableCell>
                              {d.credited
                                ? <Badge variant="outline" className="border bg-lime/15 text-lime border-lime/30">yes</Badge>
                                : <Badge variant="outline" className="border bg-secondary text-muted-foreground border-border">no</Badge>}
                            </TableCell>
                            <TableCell className="text-xs text-muted-foreground">{formatWhen(d.createdAt)}</TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="pnl">
          <Card className="border-border bg-surface">
            <CardHeader className="px-4 py-3">
              <CardTitle className="text-sm">House profit & loss</CardTitle>
              <CardDescription className="text-xs">Settled wagers vs payouts, straight from the Casino ledger.</CardDescription>
            </CardHeader>
            <CardContent className="px-4 pb-4">
              {cf ? (
                <div className="grid gap-3 sm:grid-cols-2">
                  <div className="rounded-lg border border-border p-4">
                    <p className="text-[11px] uppercase text-muted-foreground">House engine</p>
                    <dl className="mt-2 grid grid-cols-2 gap-3 text-sm">
                      <div><dt className="text-[11px] text-muted-foreground">Settled bets</dt><dd className="font-mono font-bold tabular-nums">{cf.house.bets.toLocaleString('en-US')}</dd></div>
                      <div><dt className="text-[11px] text-muted-foreground">Wagered</dt><dd className="font-mono font-bold tabular-nums">{formatUsd(cf.house.wagered)}</dd></div>
                      <div><dt className="text-[11px] text-muted-foreground">Paid out</dt><dd className="font-mono font-bold tabular-nums">{formatUsd(cf.house.paid)}</dd></div>
                      <div><dt className="text-[11px] text-muted-foreground">Profit</dt><dd className={cn('font-mono font-bold tabular-nums', cf.house.profit >= 0 ? 'text-lime' : 'text-loss')}>{formatUsd(cf.house.profit)}</dd></div>
                    </dl>
                  </div>
                  <div className="rounded-lg border border-border p-4">
                    <p className="text-[11px] uppercase text-muted-foreground">Money in / out by status</p>
                    <div className="mt-2 flex flex-col gap-1.5 text-sm">
                      {cf.deposits.map((d) => (
                        <div key={`d-${d.status}`} className="flex items-center justify-between">
                          <span className="text-muted-foreground">Deposits · {d.status} ({d.count})</span>
                          <span className="font-mono tabular-nums text-lime">{formatUsd(d.amount)}</span>
                        </div>
                      ))}
                      {cf.withdrawals.map((w) => (
                        <div key={`w-${w.status}`} className="flex items-center justify-between">
                          <span className="text-muted-foreground">Withdrawals · {w.status} ({w.count})</span>
                          <span className="font-mono tabular-nums">{formatUsd(w.amount)}</span>
                        </div>
                      ))}
                      {cf.deposits.length === 0 && cf.withdrawals.length === 0 && (
                        <p className="text-muted-foreground">No money movement recorded on the Casino yet.</p>
                      )}
                    </div>
                  </div>
                </div>
              ) : (
                <Skeleton className="h-40 w-full" />
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Dialog open={Boolean(decision)} onOpenChange={(open) => { if (!open) setDecision(null) }}>
        <DialogContent className="border-border bg-surface sm:max-w-md">
          <DialogHeader>
            <DialogTitle>
              {decision?.action === 'approve' ? 'Approve withdrawal' : 'Reject withdrawal'}
            </DialogTitle>
            <DialogDescription>
              {decision ? (
                <>
                  {decision.w.username ?? decision.w.userId} · <span className="font-mono">{formatUsd(decision.w.amount)}</span> on {decision.w.chain} to{' '}
                  <span className="font-mono">{shortHash(decision.w.walletAddress, 20)}</span>
                </>
              ) : null}
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={submitDecision} className="flex flex-col gap-4">
            {decision?.action === 'approve' ? (
              <div className="flex flex-col gap-2">
                <Label htmlFor="dec-tx" className="text-xs text-muted-foreground">Payout tx hash (optional)</Label>
                <Input id="dec-tx" value={txHash} onChange={(e) => setTxHash(e.target.value)} placeholder="0x…" />
              </div>
            ) : (
              <div className="flex flex-col gap-2">
                <Label htmlFor="dec-note" className="text-xs text-muted-foreground">Rejection reason</Label>
                <Input id="dec-note" value={note} onChange={(e) => setNote(e.target.value)} placeholder="Suspicious activity" />
              </div>
            )}
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setDecision(null)}>Cancel</Button>
              <Button
                type="submit"
                variant={decision?.action === 'reject' ? 'destructive' : 'default'}
                disabled={busy}
                className="active:scale-[0.97]"
              >
                {busy && <Loader2 className="size-4 animate-spin" />}
                {decision?.action === 'approve' ? 'Approve on Casino' : 'Reject on Casino'}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  )
}
