'use client'

// Casino Link — the single env-backed connection panel for the twin project
// bridge (Governance = gov.tols.fun ⇄ Casino = www.tols.fun).
//
//   • Live/offline + latency from GET CASINO/api/platform/health
//   • JWT check: GET CASINO/api/platform/whoami with a Governance-signed RS256 JWT
//   • HMAC check: POST CASINO/api/bridge/webhook { type: "ping" } → pong
//   • Inbound event feed: everything the Casino delivered to
//     /api/platform/webhooks on this project
import { useState } from 'react'
import { toast } from 'sonner'
import {
  PlugZap, ShieldCheck, ShieldAlert, Radio, RefreshCw, Loader2, Zap, KeyRound,
  Webhook, Activity,
} from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import { useCasino, casinoCommand, formatWhen } from '@/hooks/use-casino'
import { cn } from '@/lib/utils'

interface ConnectionData {
  config: {
    casinoOrigin: string
    governanceOrigin: string
    issuer: string
    audience: string
    privateKeyConfigured: boolean
    bridgeSecretConfigured: boolean
    missing: string[]
  }
  health: {
    live: boolean
    latencyMs: number | null
    status: number | null
    dbOk: boolean | null
    jwtConfiguredOnCasino: boolean | null
    error: string | null
  }
  whoami: { authenticated: boolean; status: number | null; claims: unknown; error: string | null }
  webhook: { reachable: boolean; pong: boolean; status: number | null }
  ts: string
}

interface StoredEvent {
  id: string
  eventId: string
  type: string
  source: string
  payload: unknown
  receivedAt: string
}

function CheckBadge({ ok, okLabel, badLabel }: { ok: boolean; okLabel: string; badLabel: string }) {
  return (
    <Badge
      variant="outline"
      className={cn('border', ok ? 'bg-lime/15 text-lime border-lime/30' : 'bg-loss/15 text-loss border-loss/30')}
    >
      {ok ? okLabel : badLabel}
    </Badge>
  )
}

export function CasinoLinkView() {
  const connection = useCasino<ConnectionData>('/api/casino/connection', 60_000)
  const events = useCasino<StoredEvent[]>('/api/platform/webhooks?limit=100', 20_000)
  const [pinging, setPinging] = useState(false)

  const c = connection.data

  async function sendPing() {
    setPinging(true)
    try {
      const res = (await casinoCommand('ping', {})) as { type?: string } | null
      if (res?.type === 'pong') toast.success('Casino answered: pong')
      else toast.success('Casino webhook reached')
      connection.refetch()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Ping failed')
    } finally {
      setPinging(false)
    }
  }

  return (
    <div className="flex flex-col gap-4">
      <Card className="border-border bg-surface">
        <CardHeader className="flex flex-row items-center justify-between px-4 py-3">
          <div>
            <CardTitle className="flex items-center gap-2 text-sm">
              <PlugZap className="size-4 text-lime" /> Casino connection
            </CardTitle>
            <CardDescription className="text-xs">
              Env-backed configuration — set on Vercel (Production) and redeploy; nothing is stored in the browser.
            </CardDescription>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={connection.refetch}>
              <RefreshCw className="size-4" /> Re-check
            </Button>
            <Button size="sm" onClick={sendPing} disabled={pinging} className="active:scale-[0.97]">
              {pinging ? <Loader2 className="size-4 animate-spin" /> : <Zap className="size-4" />}
              Ping webhook
            </Button>
          </div>
        </CardHeader>
        <CardContent className="px-4 pb-4">
          {connection.loading && !c ? (
            <Skeleton className="h-40 w-full" />
          ) : connection.error && !c ? (
            <p className="p-4 text-center text-sm text-muted-foreground">Could not run the connection check: {connection.error}</p>
          ) : c ? (
            <div className="grid gap-3 lg:grid-cols-3">
              {/* Health */}
              <div className="rounded-lg border border-border p-4">
                <div className="flex items-center justify-between">
                  <p className="flex items-center gap-2 text-sm font-medium"><Activity className="size-4" /> Casino health</p>
                  <CheckBadge ok={c.health.live} okLabel="LIVE" badLabel="OFFLINE" />
                </div>
                <dl className="mt-3 flex flex-col gap-1.5 text-xs text-muted-foreground">
                  <div className="flex justify-between"><dt>Origin</dt><dd className="font-mono">{c.config.casinoOrigin}</dd></div>
                  <div className="flex justify-between"><dt>Latency</dt><dd className="font-mono">{c.health.latencyMs !== null ? `${c.health.latencyMs} ms` : '—'}</dd></div>
                  <div className="flex justify-between"><dt>Casino DB</dt><dd>{c.health.dbOk === null ? '—' : c.health.dbOk ? 'ok' : 'error'}</dd></div>
                  <div className="flex justify-between"><dt>Public key on Casino</dt><dd>{c.health.jwtConfiguredOnCasino === null ? '—' : c.health.jwtConfiguredOnCasino ? 'configured' : 'missing'}</dd></div>
                  {c.health.error && <div className="text-loss">{c.health.error}</div>}
                </dl>
              </div>

              {/* JWT */}
              <div className="rounded-lg border border-border p-4">
                <div className="flex items-center justify-between">
                  <p className="flex items-center gap-2 text-sm font-medium"><KeyRound className="size-4" /> REST auth (RS256 JWT)</p>
                  <CheckBadge ok={c.whoami.authenticated} okLabel="AUTHENTICATED" badLabel="REJECTED" />
                </div>
                <dl className="mt-3 flex flex-col gap-1.5 text-xs text-muted-foreground">
                  <div className="flex justify-between"><dt>Issuer</dt><dd className="font-mono">{c.config.issuer}</dd></div>
                  <div className="flex justify-between"><dt>Audience</dt><dd className="font-mono">{c.config.audience}</dd></div>
                  <div className="flex justify-between"><dt>Private key</dt><dd>{c.config.privateKeyConfigured ? 'configured' : 'missing'}</dd></div>
                  <div className="flex justify-between"><dt>whoami</dt><dd className="font-mono">{c.whoami.status ? `HTTP ${c.whoami.status}` : '—'}</dd></div>
                  {c.whoami.error && <div className="text-loss">{c.whoami.error}</div>}
                </dl>
              </div>

              {/* Webhook */}
              <div className="rounded-lg border border-border p-4">
                <div className="flex items-center justify-between">
                  <p className="flex items-center gap-2 text-sm font-medium"><Webhook className="size-4" /> Command channel (HMAC)</p>
                  <CheckBadge ok={c.webhook.pong} okLabel="PONG" badLabel={c.webhook.reachable ? 'NO PONG' : 'UNREACHABLE'} />
                </div>
                <dl className="mt-3 flex flex-col gap-1.5 text-xs text-muted-foreground">
                  <div className="flex justify-between"><dt>Endpoint</dt><dd className="font-mono">/api/bridge/webhook</dd></div>
                  <div className="flex justify-between"><dt>Shared secret</dt><dd>{c.config.bridgeSecretConfigured ? 'configured' : 'missing'}</dd></div>
                  <div className="flex justify-between"><dt>Inbound endpoint</dt><dd className="font-mono">/api/platform/webhooks</dd></div>
                  <div className="flex justify-between"><dt>Governance origin</dt><dd className="font-mono">{c.config.governanceOrigin}</dd></div>
                </dl>
              </div>
            </div>
          ) : null}

          {c && c.config.missing.length > 0 && (
            <div className="mt-3 flex items-start gap-2 rounded-lg border border-pending/30 bg-pending/10 p-3 text-xs text-pending">
              <ShieldAlert className="mt-0.5 size-4 shrink-0" />
              <div>
                <p className="font-medium">Missing environment variables on this project:</p>
                <p className="font-mono">{c.config.missing.join(', ')}</p>
                <p className="mt-1 text-pending/80">
                  Set them in Vercel → tolsgovernz → Settings → Environment Variables (Production), then redeploy.
                  Never set PLATFORM_JWT_PUBLIC_KEY here — the public key belongs on the Casino.
                </p>
              </div>
            </div>
          )}

          {c && c.config.missing.length === 0 && c.whoami.authenticated && (
            <div className="mt-3 flex items-center gap-2 rounded-lg border border-lime/30 bg-lime/10 p-3 text-xs text-lime">
              <ShieldCheck className="size-4 shrink-0" />
              Bridge fully wired — every operator screen reads and writes live Casino data.
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="border-border bg-surface">
        <CardHeader className="flex flex-row items-center justify-between px-4 py-3">
          <div>
            <CardTitle className="flex items-center gap-2 text-sm">
              <Radio className="size-4 text-lime" /> Casino event feed
            </CardTitle>
            <CardDescription className="text-xs">
              Signed events the Casino delivered to this project (casino.bet, casino.win, deposits, withdrawals, sessions…).
            </CardDescription>
          </div>
          <Button variant="outline" size="sm" onClick={events.refetch}><RefreshCw className="size-4" /> Refresh</Button>
        </CardHeader>
        <CardContent className="px-4 pb-4">
          {events.loading && !events.data ? (
            <Skeleton className="h-40 w-full" />
          ) : events.error && !events.data ? (
            <p className="p-4 text-center text-sm text-muted-foreground">Could not load stored events: {events.error}</p>
          ) : (
            <div className="overflow-x-auto rounded-lg border border-border">
              <Table>
                <TableHeader>
                  <TableRow className="hover:bg-transparent">
                    <TableHead className="text-[11px] text-muted-foreground">Type</TableHead>
                    <TableHead className="text-[11px] text-muted-foreground">Source</TableHead>
                    <TableHead className="text-[11px] text-muted-foreground">Payload</TableHead>
                    <TableHead className="text-[11px] text-muted-foreground">Received</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {(events.data ?? []).length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={4} className="p-8 text-center text-sm text-muted-foreground">
                        No events stored yet. They appear here as soon as the Casino pushes its first signed webhook.
                      </TableCell>
                    </TableRow>
                  ) : (
                    (events.data ?? []).map((e) => (
                      <TableRow key={e.id} className="border-border">
                        <TableCell>
                          <Badge variant="outline" className="border bg-secondary font-mono text-[11px] text-foreground border-border">
                            {e.type}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-xs text-muted-foreground">{e.source}</TableCell>
                        <TableCell className="max-w-96 truncate font-mono text-[11px] text-muted-foreground">
                          {typeof e.payload === 'string' ? e.payload : JSON.stringify(e.payload)}
                        </TableCell>
                        <TableCell className="text-xs text-muted-foreground">{formatWhen(e.receivedAt)}</TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
