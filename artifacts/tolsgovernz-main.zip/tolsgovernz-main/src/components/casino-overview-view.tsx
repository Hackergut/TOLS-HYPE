'use client'

// Overview — LIVE Casino KPIs from GET /api/platform/overview + /stats
// (via the Governance controller proxy /api/casino/*). No mock data.
import {
  Users, UserPlus, Wallet, ArrowDownLeft, ArrowUpRight, Dice5, TrendingUp, RefreshCw,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import { StatCard } from '@/components/stat-card'
import { useCasino, formatUsd } from '@/hooks/use-casino'

interface Overview {
  users: { total: number; signups24h: number }
  wallets: { balance: number; bonus: number; wagered: number; won: number }
  deposits: { count: number; amount: number }
  withdrawals: { pendingCount: number; pendingAmount: number }
  last24h: { bets: number; wagered: number; paid: number; houseProfit: number }
  ts: string
}

interface Stats {
  users: number
  bets: { count: number; wagered: number; payout: number }
  deposits: { count: number; total: number }
  withdrawals: { pendingCount: number; pendingAmount: number }
}

function LoadingGrid() {
  return (
    <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
      {Array.from({ length: 8 }).map((_, i) => (
        <Card key={i}><CardContent className="p-6"><Skeleton className="h-14 w-full" /></CardContent></Card>
      ))}
    </div>
  )
}

export function CasinoOverviewView() {
  const overview = useCasino<Overview>('/api/casino/overview', 30_000)
  const stats = useCasino<Stats>('/api/casino/stats', 60_000)

  if (overview.loading && !overview.data) return <LoadingGrid />

  if (overview.error && !overview.data) {
    return (
      <Card className="border-destructive/40">
        <CardContent className="flex flex-col items-center gap-3 p-8 text-center">
          <p className="text-sm text-muted-foreground">
            Could not load live Casino data: {overview.error}
          </p>
          <Button variant="outline" size="sm" onClick={overview.refetch}>
            <RefreshCw className="size-4" /> Retry
          </Button>
        </CardContent>
      </Card>
    )
  }

  const o = overview.data
  const s = stats.data
  if (!o) return <LoadingGrid />

  const lifetimeHold = s ? s.bets.wagered - s.bets.payout : null

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <p className="text-xs text-muted-foreground">
          Live from www.tols.fun · updated {new Date(o.ts).toLocaleTimeString('en-US', { hour12: false })}
        </p>
        <Button variant="outline" size="sm" onClick={() => { overview.refetch(); stats.refetch() }}>
          <RefreshCw className="size-4" /> Refresh
        </Button>
      </div>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <StatCard icon={Users} label="Players" value={String(o.users.total)} sub="registered accounts" />
        <StatCard icon={UserPlus} label="Signups 24h" value={String(o.users.signups24h)} tone="text-lime" />
        <StatCard icon={Wallet} label="Player balances" value={formatUsd(o.wallets.balance)} sub={`bonus ${formatUsd(o.wallets.bonus)}`} />
        <StatCard icon={ArrowDownLeft} label="Deposits" value={formatUsd(o.deposits.amount)} sub={`${o.deposits.count} total`} />
        <StatCard
          icon={ArrowUpRight}
          label="Pending withdrawals"
          value={formatUsd(o.withdrawals.pendingAmount)}
          sub={`${o.withdrawals.pendingCount} in queue`}
          tone={o.withdrawals.pendingCount > 0 ? 'text-pending' : 'text-foreground'}
        />
        <StatCard icon={Dice5} label="Bets 24h" value={String(o.last24h.bets)} sub={`wagered ${formatUsd(o.last24h.wagered)}`} />
        <StatCard
          icon={TrendingUp}
          label="House profit 24h"
          value={formatUsd(o.last24h.houseProfit)}
          tone={o.last24h.houseProfit >= 0 ? 'text-lime' : 'text-loss'}
        />
        <StatCard icon={TrendingUp} label="Paid out 24h" value={formatUsd(o.last24h.paid)} />
      </div>

      <div className="grid gap-3 md:grid-cols-2">
        <Card className="border-border bg-surface">
          <CardHeader className="px-4 py-3">
            <CardTitle className="text-sm">Lifetime wagering</CardTitle>
            <CardDescription className="text-xs">All settled bets on the Casino.</CardDescription>
          </CardHeader>
          <CardContent className="px-4 pb-4">
            {s ? (
              <dl className="grid grid-cols-2 gap-3 text-sm">
                <div><dt className="text-[11px] uppercase text-muted-foreground">Bets</dt><dd className="font-mono font-bold tabular-nums">{s.bets.count.toLocaleString('en-US')}</dd></div>
                <div><dt className="text-[11px] uppercase text-muted-foreground">Wagered</dt><dd className="font-mono font-bold tabular-nums">{formatUsd(s.bets.wagered)}</dd></div>
                <div><dt className="text-[11px] uppercase text-muted-foreground">Paid out</dt><dd className="font-mono font-bold tabular-nums">{formatUsd(s.bets.payout)}</dd></div>
                <div>
                  <dt className="text-[11px] uppercase text-muted-foreground">House hold</dt>
                  <dd className={`font-mono font-bold tabular-nums ${lifetimeHold !== null && lifetimeHold >= 0 ? 'text-lime' : 'text-loss'}`}>
                    {lifetimeHold !== null ? formatUsd(lifetimeHold) : '—'}
                  </dd>
                </div>
              </dl>
            ) : (
              <Skeleton className="h-16 w-full" />
            )}
          </CardContent>
        </Card>

        <Card className="border-border bg-surface">
          <CardHeader className="px-4 py-3">
            <CardTitle className="text-sm">Player pool</CardTitle>
            <CardDescription className="text-xs">Wallet aggregates across all accounts.</CardDescription>
          </CardHeader>
          <CardContent className="px-4 pb-4">
            <dl className="grid grid-cols-2 gap-3 text-sm">
              <div><dt className="text-[11px] uppercase text-muted-foreground">Real balance</dt><dd className="font-mono font-bold tabular-nums">{formatUsd(o.wallets.balance)}</dd></div>
              <div><dt className="text-[11px] uppercase text-muted-foreground">Bonus balance</dt><dd className="font-mono font-bold tabular-nums">{formatUsd(o.wallets.bonus)}</dd></div>
              <div><dt className="text-[11px] uppercase text-muted-foreground">Total wagered</dt><dd className="font-mono font-bold tabular-nums">{formatUsd(o.wallets.wagered)}</dd></div>
              <div><dt className="text-[11px] uppercase text-muted-foreground">Total won</dt><dd className="font-mono font-bold tabular-nums">{formatUsd(o.wallets.won)}</dd></div>
            </dl>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
