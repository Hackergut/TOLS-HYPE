'use client'

// Promotions / lobby cards — LIVE from GET /api/platform/promotions.
// Edits upsert straight back to the Casino with
// PUT /api/platform/promotions { entity: "promo"|"game", key, ... }.
import { useState } from 'react'
import { toast } from 'sonner'
import { Gift, Gamepad2, Eye, EyeOff, RefreshCw, Loader2, Pencil, Plus } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import { Skeleton } from '@/components/ui/skeleton'
import { Switch } from '@/components/ui/switch'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import { StatCard } from '@/components/stat-card'
import { useCasino, casinoFetch } from '@/hooks/use-casino'
import { cn } from '@/lib/utils'

interface CmsCard {
  id: string
  entity: string // "promo" | "game"
  key: string
  title: string | null
  tagline: string | null
  reward: string | null
  badge: string | null
  cta: string | null
  target: string | null
  accent: string | null
  imageUrl: string | null
  enabled: boolean
  sortOrder: number
}

interface Draft {
  entity: 'promo' | 'game'
  key: string
  title: string
  tagline: string
  reward: string
  badge: string
  enabled: boolean
  isNew: boolean
}

const EMPTY_DRAFT: Draft = {
  entity: 'promo', key: '', title: '', tagline: '', reward: '', badge: '', enabled: true, isNew: true,
}

export function CasinoPromotionsView() {
  const { data, loading, error, refetch } = useCasino<CmsCard[]>('/api/casino/promotions')
  const [draft, setDraft] = useState<Draft | null>(null)
  const [busy, setBusy] = useState(false)

  const cards = data ?? []
  const promos = cards.filter((c) => c.entity === 'promo')
  const gameCards = cards.filter((c) => c.entity === 'game')

  function edit(card: CmsCard) {
    setDraft({
      entity: card.entity === 'game' ? 'game' : 'promo',
      key: card.key,
      title: card.title ?? '',
      tagline: card.tagline ?? '',
      reward: card.reward ?? '',
      badge: card.badge ?? '',
      enabled: card.enabled,
      isNew: false,
    })
  }

  async function save(e: React.FormEvent) {
    e.preventDefault()
    if (!draft) return
    if (!draft.key.trim()) {
      toast.error('A card key is required (e.g. "welcome")')
      return
    }
    setBusy(true)
    try {
      await casinoFetch('/api/casino/promotions', {
        method: 'PUT',
        body: JSON.stringify({
          entity: draft.entity,
          key: draft.key.trim(),
          title: draft.title.trim() || undefined,
          tagline: draft.tagline.trim() || undefined,
          reward: draft.reward.trim() || undefined,
          badge: draft.badge.trim() || undefined,
          enabled: draft.enabled,
        }),
      })
      toast.success(`"${draft.key}" published to the Casino lobby`)
      setDraft(null)
      refetch()
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Save failed')
    } finally {
      setBusy(false)
    }
  }

  async function toggle(card: CmsCard) {
    try {
      await casinoFetch('/api/casino/promotions', {
        method: 'PUT',
        body: JSON.stringify({
          entity: card.entity,
          key: card.key,
          title: card.title ?? undefined,
          tagline: card.tagline ?? undefined,
          reward: card.reward ?? undefined,
          badge: card.badge ?? undefined,
          enabled: !card.enabled,
          sortOrder: card.sortOrder,
        }),
      })
      toast.success(`"${card.key}" is now ${card.enabled ? 'hidden' : 'visible'} on the Casino`)
      refetch()
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Toggle failed')
    }
  }

  function renderCardTable(rows: CmsCard[], kind: string) {
    return (
      <div className="overflow-x-auto rounded-lg border border-border">
        <Table>
          <TableHeader>
            <TableRow className="hover:bg-transparent">
              <TableHead className="text-[11px] text-muted-foreground">Key</TableHead>
              <TableHead className="text-[11px] text-muted-foreground">Title</TableHead>
              <TableHead className="text-[11px] text-muted-foreground">Tagline</TableHead>
              <TableHead className="text-[11px] text-muted-foreground">Reward</TableHead>
              <TableHead className="text-[11px] text-muted-foreground">Visible</TableHead>
              <TableHead className="text-right text-[11px] text-muted-foreground">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {rows.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} className="p-8 text-center text-sm text-muted-foreground">
                  No {kind} cards on the Casino yet — create one to publish it to the lobby.
                </TableCell>
              </TableRow>
            ) : (
              rows.map((c) => (
                <TableRow key={c.id} className="border-border">
                  <TableCell className="font-mono text-xs">{c.key}</TableCell>
                  <TableCell className="text-sm font-medium">{c.title ?? '—'}</TableCell>
                  <TableCell className="max-w-56 truncate text-xs text-muted-foreground">{c.tagline ?? '—'}</TableCell>
                  <TableCell className="text-xs text-muted-foreground">{c.reward ?? '—'}</TableCell>
                  <TableCell>
                    <Badge variant="outline" className={cn('border', c.enabled ? 'bg-lime/15 text-lime border-lime/30' : 'bg-secondary text-muted-foreground border-border')}>
                      {c.enabled ? 'live' : 'hidden'}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Button size="sm" variant="secondary" onClick={() => edit(c)} className="active:scale-[0.97]">
                        <Pencil className="size-4" /> Edit
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => toggle(c)} className="active:scale-[0.97]">
                        {c.enabled ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
                        {c.enabled ? 'Hide' : 'Show'}
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    )
  }

  if (loading && !data) {
    return (
      <div className="flex flex-col gap-3">
        <Skeleton className="h-24 w-full" />
        <Skeleton className="h-64 w-full" />
      </div>
    )
  }

  if (error && !data) {
    return (
      <Card className="border-destructive/40">
        <CardContent className="flex flex-col items-center gap-3 p-8 text-center">
          <p className="text-sm text-muted-foreground">Could not load Casino promotions: {error}</p>
          <Button variant="outline" size="sm" onClick={refetch}><RefreshCw className="size-4" /> Retry</Button>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <StatCard icon={Gift} label="Promo cards" value={String(promos.length)} sub={`${promos.filter((p) => p.enabled).length} live`} />
        <StatCard icon={Gamepad2} label="Game cards" value={String(gameCards.length)} sub={`${gameCards.filter((g) => g.enabled).length} live`} />
        <StatCard icon={Eye} label="Visible total" value={String(cards.filter((c) => c.enabled).length)} tone="text-lime" />
        <StatCard icon={EyeOff} label="Hidden" value={String(cards.filter((c) => !c.enabled).length)} />
      </div>

      <Card className="border-border bg-surface">
        <CardHeader className="flex flex-row items-center justify-between px-4 py-3">
          <div>
            <CardTitle className="text-sm">Casino lobby cards</CardTitle>
            <CardDescription className="text-xs">
              Everything here is the Casino&apos;s live CMS — publishing updates www.tols.fun instantly.
            </CardDescription>
          </div>
          <div className="flex gap-2">
            <Button size="sm" onClick={() => setDraft({ ...EMPTY_DRAFT })} className="active:scale-[0.97]">
              <Plus className="size-4" /> New card
            </Button>
            <Button variant="outline" size="sm" onClick={refetch}><RefreshCw className="size-4" /></Button>
          </div>
        </CardHeader>
        <CardContent className="flex flex-col gap-4 px-4 pb-4">
          <div>
            <p className="mb-2 text-[11px] uppercase tracking-wide text-muted-foreground">Promotions</p>
            {renderCardTable(promos, 'promo')}
          </div>
          <div>
            <p className="mb-2 text-[11px] uppercase tracking-wide text-muted-foreground">Games</p>
            {renderCardTable(gameCards, 'game')}
          </div>
        </CardContent>
      </Card>

      <Dialog open={Boolean(draft)} onOpenChange={(open) => { if (!open) setDraft(null) }}>
        <DialogContent className="border-border bg-surface sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>{draft?.isNew ? 'New lobby card' : `Edit "${draft?.key}"`}</DialogTitle>
            <DialogDescription>Published straight to the Casino lobby via the platform bridge.</DialogDescription>
          </DialogHeader>
          {draft && (
            <form onSubmit={save} className="flex flex-col gap-4">
              <div className="grid grid-cols-2 gap-3">
                <div className="flex flex-col gap-2">
                  <Label className="text-xs text-muted-foreground">Type</Label>
                  <Select
                    value={draft.entity}
                    onValueChange={(v) => setDraft({ ...draft, entity: v as 'promo' | 'game' })}
                    disabled={!draft.isNew}
                  >
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="promo">Promotion</SelectItem>
                      <SelectItem value="game">Game card</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex flex-col gap-2">
                  <Label htmlFor="card-key" className="text-xs text-muted-foreground">Key</Label>
                  <Input
                    id="card-key"
                    value={draft.key}
                    onChange={(e) => setDraft({ ...draft, key: e.target.value })}
                    placeholder="welcome"
                    disabled={!draft.isNew}
                    required
                  />
                </div>
              </div>
              <div className="flex flex-col gap-2">
                <Label htmlFor="card-title" className="text-xs text-muted-foreground">Title</Label>
                <Input id="card-title" value={draft.title} onChange={(e) => setDraft({ ...draft, title: e.target.value })} placeholder="Welcome Bonus" />
              </div>
              <div className="flex flex-col gap-2">
                <Label htmlFor="card-tagline" className="text-xs text-muted-foreground">Tagline</Label>
                <Input id="card-tagline" value={draft.tagline} onChange={(e) => setDraft({ ...draft, tagline: e.target.value })} placeholder="Double your first deposit" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="flex flex-col gap-2">
                  <Label htmlFor="card-reward" className="text-xs text-muted-foreground">Reward</Label>
                  <Input id="card-reward" value={draft.reward} onChange={(e) => setDraft({ ...draft, reward: e.target.value })} placeholder="100% up to $500" />
                </div>
                <div className="flex flex-col gap-2">
                  <Label htmlFor="card-badge" className="text-xs text-muted-foreground">Badge</Label>
                  <Input id="card-badge" value={draft.badge} onChange={(e) => setDraft({ ...draft, badge: e.target.value })} placeholder="HOT" />
                </div>
              </div>
              <div className="flex items-center justify-between rounded-lg border border-border p-3">
                <div>
                  <p className="text-sm font-medium">Visible in the lobby</p>
                  <p className="text-xs text-muted-foreground">Disabled cards stay saved but hidden from players.</p>
                </div>
                <Switch checked={draft.enabled} onCheckedChange={(v) => setDraft({ ...draft, enabled: v })} />
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setDraft(null)}>Cancel</Button>
                <Button type="submit" disabled={busy} className="active:scale-[0.97]">
                  {busy && <Loader2 className="size-4 animate-spin" />}
                  Publish to Casino
                </Button>
              </DialogFooter>
            </form>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
