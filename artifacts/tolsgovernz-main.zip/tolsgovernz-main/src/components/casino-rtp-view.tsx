'use client'

// RTP & game controls — LIVE from GET /api/platform/rtp; PUT writes the
// house-edge bias back to the Casino (1 = fair, <1 colder, >1 hotter, 0..2).
import { useState } from 'react'
import { toast } from 'sonner'
import { Percent, Activity, SlidersHorizontal, Flame, Snowflake, RefreshCw, Loader2, RotateCcw } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from '@/components/ui/dialog'
import { Label } from '@/components/ui/label'
import { Skeleton } from '@/components/ui/skeleton'
import { Slider } from '@/components/ui/slider'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import { StatCard } from '@/components/stat-card'
import { useCasino, casinoFetch } from '@/hooks/use-casino'
import { cn } from '@/lib/utils'

interface RtpGame {
  gameId: string
  gameName: string
  baseRtp: number
  rtpTarget: number
  enabled: boolean
  ruleId: string | null
  recentBets: number
  actualRtp: number | null
}

function biasLabel(target: number, enabled: boolean): { label: string; tone: string } {
  if (!enabled || target === 1) return { label: 'fair', tone: 'bg-lime/15 text-lime border-lime/30' }
  if (target < 1) return { label: 'colder', tone: 'bg-sky-500/15 text-sky-400 border-sky-500/30' }
  return { label: 'hotter', tone: 'bg-pending/15 text-pending border-pending/30' }
}

export function CasinoRtpView() {
  const { data, loading, error, refetch } = useCasino<{ games: RtpGame[] }>('/api/casino/rtp')
  const [target, setTarget] = useState<RtpGame | null>(null)
  const [bias, setBias] = useState(1)
  const [busy, setBusy] = useState(false)

  const games = data?.games ?? []
  const activeRules = games.filter((g) => g.enabled && g.rtpTarget !== 1).length
  const monitored = games.filter((g) => g.recentBets > 0).length

  function openEditor(g: RtpGame) {
    setTarget(g)
    setBias(g.rtpTarget)
  }

  async function applyBias(e: React.FormEvent) {
    e.preventDefault()
    if (!target) return
    setBusy(true)
    try {
      await casinoFetch('/api/casino/rtp', {
        method: 'PUT',
        body: JSON.stringify({ gameId: target.gameId, rtpTarget: bias, enabled: true }),
      })
      toast.success(`${target.gameName}: RTP bias set to ${bias.toFixed(2)} on the Casino`)
      setTarget(null)
      refetch()
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'RTP update failed')
    } finally {
      setBusy(false)
    }
  }

  async function resetBias(g: RtpGame) {
    try {
      await casinoFetch('/api/casino/rtp', {
        method: 'PUT',
        body: JSON.stringify({ gameId: g.gameId, action: 'reset' }),
      })
      toast.success(`${g.gameName}: bias rule disabled — back to fair play`)
      refetch()
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Reset failed')
    }
  }

  if (loading && !data) {
    return (
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {Array.from({ length: 4 }).map((_, i) => (
          <Card key={i}><CardContent className="p-6"><Skeleton className="h-14 w-full" /></CardContent></Card>
        ))}
      </div>
    )
  }

  if (error && !data) {
    return (
      <Card className="border-destructive/40">
        <CardContent className="flex flex-col items-center gap-3 p-8 text-center">
          <p className="text-sm text-muted-foreground">Could not load live RTP data: {error}</p>
          <Button variant="outline" size="sm" onClick={refetch}><RefreshCw className="size-4" /> Retry</Button>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <StatCard icon={Percent} label="Games" value={String(games.length)} sub={`${monitored} with recent bets`} />
        <StatCard icon={SlidersHorizontal} label="Active bias rules" value={String(activeRules)} tone={activeRules > 0 ? 'text-pending' : 'text-lime'} />
        <StatCard
          icon={Flame}
          label="Hotter"
          value={String(games.filter((g) => g.enabled && g.rtpTarget > 1).length)}
        />
        <StatCard
          icon={Snowflake}
          label="Colder"
          value={String(games.filter((g) => g.enabled && g.rtpTarget < 1).length)}
        />
      </div>

      <Card className="border-border bg-surface">
        <CardHeader className="flex flex-row items-center justify-between px-4 py-3">
          <div>
            <CardTitle className="text-sm">Game RTP controls</CardTitle>
            <CardDescription className="text-xs">
              Bias 1.00 = fair · below 1 runs colder · above 1 runs hotter (range 0–2). Changes apply to the live Casino.
            </CardDescription>
          </div>
          <Button variant="outline" size="sm" onClick={refetch}><RefreshCw className="size-4" /> Refresh</Button>
        </CardHeader>
        <CardContent className="px-4 pb-4">
          <div className="overflow-x-auto rounded-lg border border-border">
            <Table>
              <TableHeader>
                <TableRow className="hover:bg-transparent">
                  <TableHead className="text-[11px] text-muted-foreground">Game</TableHead>
                  <TableHead className="text-[11px] text-muted-foreground">Base RTP</TableHead>
                  <TableHead className="text-[11px] text-muted-foreground">Actual RTP (last 1000)</TableHead>
                  <TableHead className="text-[11px] text-muted-foreground">Recent bets</TableHead>
                  <TableHead className="text-[11px] text-muted-foreground">Bias</TableHead>
                  <TableHead className="text-[11px] text-muted-foreground">Mode</TableHead>
                  <TableHead className="text-right text-[11px] text-muted-foreground">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {games.map((g) => {
                  const mode = biasLabel(g.rtpTarget, g.enabled)
                  return (
                    <TableRow key={g.gameId} className="border-border">
                      <TableCell className="text-sm font-medium">{g.gameName}</TableCell>
                      <TableCell className="font-mono tabular-nums text-muted-foreground">{(g.baseRtp * 100).toFixed(2)}%</TableCell>
                      <TableCell className={cn('font-mono font-bold tabular-nums', g.actualRtp === null ? 'text-muted-foreground' : g.actualRtp >= 100 ? 'text-pending' : 'text-lime')}>
                        {g.actualRtp === null ? 'no data' : `${g.actualRtp.toFixed(2)}%`}
                      </TableCell>
                      <TableCell className="tabular-nums text-muted-foreground">{g.recentBets}</TableCell>
                      <TableCell className="font-mono tabular-nums">{g.enabled ? g.rtpTarget.toFixed(2) : '1.00'}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className={cn('border capitalize', mode.tone)}>{mode.label}</Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button size="sm" variant="secondary" onClick={() => openEditor(g)} className="active:scale-[0.97]">
                            <SlidersHorizontal className="size-4" /> Set bias
                          </Button>
                          {g.enabled && g.ruleId && (
                            <Button size="sm" variant="outline" onClick={() => resetBias(g)} className="active:scale-[0.97]">
                              <RotateCcw className="size-4" /> Reset
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      <Dialog open={Boolean(target)} onOpenChange={(open) => { if (!open) setTarget(null) }}>
        <DialogContent className="border-border bg-surface sm:max-w-md">
          <DialogHeader>
            <DialogTitle>RTP bias — {target?.gameName}</DialogTitle>
            <DialogDescription>
              1.00 plays fair. Lower runs colder (house keeps more), higher runs hotter (players win more).
              Applies to the live Casino immediately.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={applyBias} className="flex flex-col gap-5">
            <div className="flex flex-col gap-3">
              <div className="flex items-center justify-between">
                <Label className="text-xs text-muted-foreground">Bias target</Label>
                <span className={cn('font-mono text-lg font-bold tabular-nums', bias === 1 ? 'text-lime' : bias < 1 ? 'text-sky-400' : 'text-pending')}>
                  {bias.toFixed(2)}
                </span>
              </div>
              <Slider
                value={[bias]}
                min={0}
                max={2}
                step={0.05}
                onValueChange={(v) => setBias(v[0] ?? 1)}
              />
              <div className="flex justify-between text-[10px] uppercase text-muted-foreground">
                <span className="flex items-center gap-1"><Snowflake className="size-3" /> Colder</span>
                <span>Fair (1.00)</span>
                <span className="flex items-center gap-1">Hotter <Flame className="size-3" /></span>
              </div>
            </div>
            <div className="rounded-lg border border-border p-3 text-xs text-muted-foreground">
              <Activity className="mr-1 inline size-3.5" />
              Base RTP {(Number(target?.baseRtp ?? 0) * 100).toFixed(2)}% · actual{' '}
              {target?.actualRtp === null || target?.actualRtp === undefined ? 'no data' : `${target.actualRtp.toFixed(2)}%`} over the last{' '}
              {target?.recentBets ?? 0} live wagers.
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setTarget(null)}>Cancel</Button>
              <Button type="submit" disabled={busy} className="active:scale-[0.97]">
                {busy && <Loader2 className="size-4 animate-spin" />}
                Apply to Casino
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  )
}
