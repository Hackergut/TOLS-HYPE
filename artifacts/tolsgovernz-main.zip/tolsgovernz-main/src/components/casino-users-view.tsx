'use client'

// Users / signups — LIVE from GET /api/platform/users. Block/unblock writes
// back to the Casino with PATCH /api/platform/users/:id.
import { useMemo, useState } from 'react'
import { toast } from 'sonner'
import { Users, UserPlus, Ban, ShieldCheck, Search, RefreshCw, Loader2 } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import { StatCard } from '@/components/stat-card'
import { useCasino, casinoFetch, formatUsd, formatWhen } from '@/hooks/use-casino'
import { cn } from '@/lib/utils'

interface CasinoUser {
  id: string
  username: string
  email: string
  role: string
  status: string
  level: number
  kycStatus: string | null
  googleLinked: boolean
  registeredAt: string
  wallet: { balance: number; bonusBalance: number; vipLevel: number; totalWagered: number; currency: string } | null
}

const PAGE = 50

export function CasinoUsersView() {
  const [q, setQ] = useState('')
  const [query, setQuery] = useState('')
  const [status, setStatus] = useState('all')
  const [offset, setOffset] = useState(0)
  const [busyId, setBusyId] = useState<string | null>(null)

  const path = useMemo(() => {
    const p = new URLSearchParams()
    p.set('limit', String(PAGE))
    p.set('offset', String(offset))
    if (query) p.set('q', query)
    if (status !== 'all') p.set('status', status)
    return `/api/casino/users?${p.toString()}`
  }, [query, status, offset])

  const { data, envelope, loading, error, refetch } = useCasino<CasinoUser[]>(path)

  async function setBlocked(user: CasinoUser, blocked: boolean) {
    setBusyId(user.id)
    try {
      await casinoFetch(`/api/casino/users/${encodeURIComponent(user.id)}`, {
        method: 'PATCH',
        body: JSON.stringify({ action: blocked ? 'block' : 'unblock' }),
      })
      toast.success(`${user.username} is now ${blocked ? 'blocked' : 'active'} on the Casino`)
      refetch()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Update failed')
    } finally {
      setBusyId(null)
    }
  }

  const total = envelope?.pagination?.total ?? data?.length ?? 0
  const blockedCount = data?.filter((u) => u.status === 'blocked').length ?? 0

  return (
    <div className="flex flex-col gap-4">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <StatCard icon={Users} label="Players (filter)" value={String(total)} sub="matching accounts" />
        <StatCard icon={UserPlus} label="On this page" value={String(data?.length ?? 0)} />
        <StatCard icon={Ban} label="Blocked (page)" value={String(blockedCount)} tone={blockedCount > 0 ? 'text-loss' : 'text-foreground'} />
        <StatCard icon={ShieldCheck} label="Source" value="LIVE" sub="www.tols.fun" tone="text-lime" />
      </div>

      <Card className="border-border bg-surface">
        <CardContent className="flex flex-col gap-3 p-4">
          <div className="flex flex-wrap items-center gap-2">
            <form
              className="flex flex-1 items-center gap-2"
              onSubmit={(e) => { e.preventDefault(); setOffset(0); setQuery(q.trim()) }}
            >
              <div className="relative flex-1 min-w-48">
                <Search className="absolute left-2.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  value={q}
                  onChange={(e) => setQ(e.target.value)}
                  placeholder="Search username, email or user id…"
                  className="pl-8"
                />
              </div>
              <Button type="submit" variant="secondary" size="sm">Search</Button>
            </form>
            <Select value={status} onValueChange={(v) => { setStatus(v); setOffset(0) }}>
              <SelectTrigger className="w-36"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All statuses</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="blocked">Blocked</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" size="sm" onClick={refetch}>
              <RefreshCw className="size-4" /> Refresh
            </Button>
          </div>

          {error && !data ? (
            <p className="p-6 text-center text-sm text-muted-foreground">Could not load Casino users: {error}</p>
          ) : loading && !data ? (
            <Skeleton className="h-64 w-full" />
          ) : (
            <div className="overflow-x-auto rounded-lg border border-border">
              <Table>
                <TableHeader>
                  <TableRow className="hover:bg-transparent">
                    <TableHead className="text-[11px] text-muted-foreground">Player</TableHead>
                    <TableHead className="text-[11px] text-muted-foreground">Status</TableHead>
                    <TableHead className="text-[11px] text-muted-foreground">KYC</TableHead>
                    <TableHead className="text-[11px] text-muted-foreground">Balance</TableHead>
                    <TableHead className="text-[11px] text-muted-foreground">Wagered</TableHead>
                    <TableHead className="text-[11px] text-muted-foreground">VIP</TableHead>
                    <TableHead className="text-[11px] text-muted-foreground">Registered</TableHead>
                    <TableHead className="text-right text-[11px] text-muted-foreground">Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {(data ?? []).length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={8} className="p-8 text-center text-sm text-muted-foreground">
                        No players match this filter on the Casino yet.
                      </TableCell>
                    </TableRow>
                  ) : (
                    (data ?? []).map((u) => {
                      const blocked = u.status === 'blocked'
                      return (
                        <TableRow key={u.id} className="border-border">
                          <TableCell>
                            <p className="text-sm font-medium">{u.username}</p>
                            <p className="text-[11px] text-muted-foreground">{u.email}</p>
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline" className={cn('border capitalize', blocked ? 'bg-loss/15 text-loss border-loss/30' : 'bg-lime/15 text-lime border-lime/30')}>
                              {u.status}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-xs capitalize text-muted-foreground">{u.kycStatus ?? '—'}</TableCell>
                          <TableCell className="font-mono tabular-nums">{formatUsd(u.wallet?.balance)}</TableCell>
                          <TableCell className="font-mono tabular-nums text-muted-foreground">{formatUsd(u.wallet?.totalWagered)}</TableCell>
                          <TableCell className="text-muted-foreground">{u.wallet?.vipLevel ?? 0}</TableCell>
                          <TableCell className="text-xs text-muted-foreground">{formatWhen(u.registeredAt)}</TableCell>
                          <TableCell className="text-right">
                            <Button
                              variant={blocked ? 'secondary' : 'destructive'}
                              size="sm"
                              disabled={busyId === u.id}
                              onClick={() => setBlocked(u, !blocked)}
                              className="active:scale-[0.97]"
                            >
                              {busyId === u.id ? <Loader2 className="size-4 animate-spin" /> : blocked ? <ShieldCheck className="size-4" /> : <Ban className="size-4" />}
                              {blocked ? 'Unblock' : 'Block'}
                            </Button>
                          </TableCell>
                        </TableRow>
                      )
                    })
                  )}
                </TableBody>
              </Table>
            </div>
          )}

          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>
              {total > 0 ? `${offset + 1}–${offset + (data?.length ?? 0)} of ${total}` : 'No results'}
            </span>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" disabled={offset === 0} onClick={() => setOffset(Math.max(0, offset - PAGE))}>Previous</Button>
              <Button variant="outline" size="sm" disabled={!envelope?.pagination?.hasMore} onClick={() => setOffset(offset + PAGE)}>Next</Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
