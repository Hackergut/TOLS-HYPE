'use client'

// Wallets — LIVE from GET /api/platform/wallets. Manual credit/debit writes
// back with POST /api/platform/wallets/adjust (real balance, not bonus).
import { useMemo, useState } from 'react'
import { toast } from 'sonner'
import { Wallet, Coins, TrendingUp, Search, RefreshCw, Loader2, Diff } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import { StatCard } from '@/components/stat-card'
import { useCasino, casinoFetch, formatUsd, formatWhen } from '@/hooks/use-casino'
import { cn } from '@/lib/utils'

interface CasinoWallet {
  userId: string
  username: string
  email: string
  status: string
  balance: number
  bonusBalance: number
  wageringRemaining: number
  currency: string
  vipLevel: number
  xp: number
  totalWagered: number
  totalWon: number
  updatedAt: string
}

const PAGE = 50

export function CasinoWalletsView() {
  const [q, setQ] = useState('')
  const [query, setQuery] = useState('')
  const [offset, setOffset] = useState(0)
  const [target, setTarget] = useState<CasinoWallet | null>(null)
  const [amount, setAmount] = useState('')
  const [reason, setReason] = useState('')
  const [busy, setBusy] = useState(false)

  const path = useMemo(() => {
    const p = new URLSearchParams()
    p.set('limit', String(PAGE))
    p.set('offset', String(offset))
    if (query) p.set('q', query)
    return `/api/casino/wallets?${p.toString()}`
  }, [query, offset])

  const { data, envelope, loading, error, refetch } = useCasino<CasinoWallet[]>(path)

  const pageBalance = (data ?? []).reduce((s, w) => s + w.balance, 0)
  const pageBonus = (data ?? []).reduce((s, w) => s + w.bonusBalance, 0)

  async function submitAdjust(e: React.FormEvent) {
    e.preventDefault()
    if (!target) return
    const value = Number(amount)
    if (!Number.isFinite(value) || value === 0) {
      toast.error('Enter a non-zero amount (negative to debit)')
      return
    }
    setBusy(true)
    try {
      const res = await casinoFetch<{ userId: string; balance: number }>('/api/casino/wallets/adjust', {
        method: 'POST',
        body: JSON.stringify({ userId: target.userId, amount: value, reason: reason.trim() || 'manual adjustment' }),
      })
      toast.success(`${target.username}: new balance ${formatUsd(res.data.balance)}`)
      setTarget(null)
      setAmount('')
      setReason('')
      refetch()
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Adjustment failed')
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <StatCard icon={Wallet} label="Wallets (filter)" value={String(envelope?.pagination?.total ?? data?.length ?? 0)} />
        <StatCard icon={Coins} label="Balance (page)" value={formatUsd(pageBalance)} tone="text-lime" />
        <StatCard icon={Coins} label="Bonus (page)" value={formatUsd(pageBonus)} />
        <StatCard icon={TrendingUp} label="Source" value="LIVE" sub="www.tols.fun" tone="text-lime" />
      </div>

      <Card className="border-border bg-surface">
        <CardContent className="flex flex-col gap-3 p-4">
          <div className="flex flex-wrap items-center gap-2">
            <form
              className="flex flex-1 items-center gap-2"
              onSubmit={(e) => { e.preventDefault(); setOffset(0); setQuery(q.trim()) }}
            >
              <div className="relative min-w-48 flex-1">
                <Search className="absolute left-2.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
                <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search username, email or user id…" className="pl-8" />
              </div>
              <Button type="submit" variant="secondary" size="sm">Search</Button>
            </form>
            <Button variant="outline" size="sm" onClick={refetch}><RefreshCw className="size-4" /> Refresh</Button>
          </div>

          {error && !data ? (
            <p className="p-6 text-center text-sm text-muted-foreground">Could not load Casino wallets: {error}</p>
          ) : loading && !data ? (
            <Skeleton className="h-64 w-full" />
          ) : (
            <div className="overflow-x-auto rounded-lg border border-border">
              <Table>
                <TableHeader>
                  <TableRow className="hover:bg-transparent">
                    <TableHead className="text-[11px] text-muted-foreground">Player</TableHead>
                    <TableHead className="text-[11px] text-muted-foreground">Real balance</TableHead>
                    <TableHead className="text-[11px] text-muted-foreground">Bonus</TableHead>
                    <TableHead className="text-[11px] text-muted-foreground">Wagering left</TableHead>
                    <TableHead className="text-[11px] text-muted-foreground">Wagered</TableHead>
                    <TableHead className="text-[11px] text-muted-foreground">Won</TableHead>
                    <TableHead className="text-[11px] text-muted-foreground">VIP</TableHead>
                    <TableHead className="text-[11px] text-muted-foreground">Updated</TableHead>
                    <TableHead className="text-right text-[11px] text-muted-foreground">Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {(data ?? []).length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={9} className="p-8 text-center text-sm text-muted-foreground">
                        No wallets match this filter on the Casino yet.
                      </TableCell>
                    </TableRow>
                  ) : (
                    (data ?? []).map((w) => (
                      <TableRow key={w.userId} className="border-border">
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <div>
                              <p className="text-sm font-medium">{w.username}</p>
                              <p className="text-[11px] text-muted-foreground">{w.email}</p>
                            </div>
                            {w.status === 'blocked' && (
                              <Badge variant="outline" className="border bg-loss/15 text-loss border-loss/30">blocked</Badge>
                            )}
                          </div>
                        </TableCell>
                        <TableCell className={cn('font-mono font-bold tabular-nums', w.balance > 0 ? 'text-lime' : 'text-foreground')}>
                          {formatUsd(w.balance)}
                        </TableCell>
                        <TableCell className="font-mono tabular-nums text-muted-foreground">{formatUsd(w.bonusBalance)}</TableCell>
                        <TableCell className="font-mono tabular-nums text-muted-foreground">{formatUsd(w.wageringRemaining)}</TableCell>
                        <TableCell className="font-mono tabular-nums text-muted-foreground">{formatUsd(w.totalWagered)}</TableCell>
                        <TableCell className="font-mono tabular-nums text-muted-foreground">{formatUsd(w.totalWon)}</TableCell>
                        <TableCell className="text-muted-foreground">{w.vipLevel}</TableCell>
                        <TableCell className="text-xs text-muted-foreground">{formatWhen(w.updatedAt)}</TableCell>
                        <TableCell className="text-right">
                          <Button variant="secondary" size="sm" onClick={() => setTarget(w)} className="active:scale-[0.97]">
                            <Diff className="size-4" /> Adjust
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          )}

          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>
              {(envelope?.pagination?.total ?? 0) > 0
                ? `${offset + 1}–${offset + (data?.length ?? 0)} of ${envelope?.pagination?.total}`
                : 'No results'}
            </span>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" disabled={offset === 0} onClick={() => setOffset(Math.max(0, offset - PAGE))}>Previous</Button>
              <Button variant="outline" size="sm" disabled={!envelope?.pagination?.hasMore} onClick={() => setOffset(offset + PAGE)}>Next</Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Dialog open={Boolean(target)} onOpenChange={(open) => { if (!open) setTarget(null) }}>
        <DialogContent className="border-border bg-surface sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Adjust wallet — {target?.username}</DialogTitle>
            <DialogDescription>
              Credits or debits the REAL balance on the Casino immediately. Use a negative amount to debit.
              Current balance: <span className="font-mono">{formatUsd(target?.balance)}</span>
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={submitAdjust} className="flex flex-col gap-4">
            <div className="flex flex-col gap-2">
              <Label htmlFor="adj-amount" className="text-xs text-muted-foreground">Amount (USD, negative = debit)</Label>
              <Input
                id="adj-amount"
                type="number"
                step="0.01"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="10.50"
                required
              />
            </div>
            <div className="flex flex-col gap-2">
              <Label htmlFor="adj-reason" className="text-xs text-muted-foreground">Reason</Label>
              <Input
                id="adj-reason"
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder="manual credit"
              />
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setTarget(null)}>Cancel</Button>
              <Button type="submit" disabled={busy} className="active:scale-[0.97]">
                {busy && <Loader2 className="size-4 animate-spin" />}
                Apply to Casino
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  )
}
