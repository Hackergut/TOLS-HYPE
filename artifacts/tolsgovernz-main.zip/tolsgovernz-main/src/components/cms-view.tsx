'use client'

// ─────────────────────────────────────────────────────────────────────────────
// CmsView — Governance marketing CMS.
//
// Operators manage the content the Casino lobby renders: promotions (hero
// carousel + promo strip) and marketable game entries (ordering, tagline,
// image, featured flags). Everything is persisted in the Governance DB and
// published to the Casino through /api/platform/content (JWT `content:read`).
// ─────────────────────────────────────────────────────────────────────────────

import { useCallback, useEffect, useState } from 'react'
import { toast } from 'sonner'
import {
  Plus, Pencil, Trash2, ArrowUp, ArrowDown, Megaphone, Gamepad2, Loader2, Rocket,
} from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Switch } from '@/components/ui/switch'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from '@/components/ui/dialog'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import { Skeleton } from '@/components/ui/skeleton'
import { cn } from '@/lib/utils'

interface Promotion {
  id: string
  title: string
  subtitle: string
  cta: string
  imageUrl: string
  target: string
  accent: boolean
  sortOrder: number
  active: boolean
}

interface GameEntry {
  id: string
  gameId: string
  name: string
  tagline: string
  description: string
  provider: string
  category: string
  imageUrl: string
  sortOrder: number
  featured: boolean
  isNew: boolean
  active: boolean
}

async function jf<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    ...init,
    headers: { 'Content-Type': 'application/json', ...(init?.headers ?? {}) },
  })
  const body = await res.json().catch(() => ({}))
  if (!res.ok) throw new Error((body as { error?: string })?.error ?? `HTTP ${res.status}`)
  return body as T
}

type Row<T> = { data: T }

// ── Promotions tab ───────────────────────────────────────────────────────────
const EMPTY_PROMO = { id: '', title: '', subtitle: '', cta: 'Play', imageUrl: '', target: '', accent: false, sortOrder: 0, active: true }

function PromotionsTab() {
  const [rows, setRows] = useState<Promotion[] | null>(null)
  const [editing, setEditing] = useState<Promotion | null>(null)
  const [busy, setBusy] = useState(false)

  const load = useCallback(async () => {
    const res = await jf<Row<Promotion[]>>('/api/cms/promotions?includeInactive=true')
    setRows(res.data)
  }, [])

  useEffect(() => { load().catch(() => setRows([])) }, [load])

  async function save(p: Promotion) {
    setBusy(true)
    try {
      if (p.id) {
        await jf('/api/cms/promotions', { method: 'PUT', body: JSON.stringify(p) })
        toast.success('Promotion updated')
      } else {
        await jf('/api/cms/promotions', { method: 'POST', body: JSON.stringify(p) })
        toast.success('Promotion created')
      }
      setEditing(null)
      await load()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Save failed')
    } finally {
      setBusy(false)
    }
  }

  async function remove(id: string) {
    await jf(`/api/cms/promotions?id=${encodeURIComponent(id)}`, { method: 'DELETE' })
    toast.success('Promotion deleted')
    await load()
  }

  async function move(id: string, dir: -1 | 1) {
    const list = [...(rows ?? [])].sort((a, b) => a.sortOrder - b.sortOrder)
    const i = list.findIndex((r) => r.id === id)
    const j = i + dir
    if (i < 0 || j < 0 || j >= list.length) return
    const [a, b] = [list[i], list[j]]
    await jf('/api/cms/promotions', { method: 'PUT', body: JSON.stringify({ id: a.id, sortOrder: b.sortOrder }) })
    await jf('/api/cms/promotions', { method: 'PUT', body: JSON.stringify({ id: b.id, sortOrder: a.sortOrder }) })
    await load()
  }

  async function toggle(id: string, active: boolean) {
    await jf('/api/cms/promotions', { method: 'PUT', body: JSON.stringify({ id, active }) })
    await load()
  }

  if (rows === null) return <Skeleton className="h-40 w-full rounded-xl" />

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <p className="text-xs text-muted-foreground">
          Published to the Casino via <span className="font-mono text-lime">/api/platform/content</span> (JWT content:read)
        </p>
        <Button size="sm" className="bg-lime text-bg hover:bg-lime-400 active:scale-[0.97]" onClick={() => setEditing({ ...EMPTY_PROMO })}>
          <Plus className="size-4" /> New promotion
        </Button>
      </div>

      <div className="overflow-x-auto rounded-lg border border-border">
        <Table>
          <TableHeader>
            <TableRow className="hover:bg-transparent">
              <TableHead className="text-[11px] text-muted-foreground">Order</TableHead>
              <TableHead className="text-[11px] text-muted-foreground">Promotion</TableHead>
              <TableHead className="text-[11px] text-muted-foreground">CTA / Target</TableHead>
              <TableHead className="text-[11px] text-muted-foreground">Accent</TableHead>
              <TableHead className="text-[11px] text-muted-foreground">Status</TableHead>
              <TableHead className="text-right text-[11px] text-muted-foreground">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {rows.map((p) => (
              <TableRow key={p.id} className="border-border">
                <TableCell>
                  <div className="flex items-center gap-1">
                    <Button variant="ghost" size="icon" className="size-6" onClick={() => move(p.id, -1)}><ArrowUp className="size-3" /></Button>
                    <Button variant="ghost" size="icon" className="size-6" onClick={() => move(p.id, 1)}><ArrowDown className="size-3" /></Button>
                    <span className="ml-1 text-xs tabular-nums text-muted-foreground">{p.sortOrder}</span>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="text-sm font-medium">{p.title || '—'}</div>
                  <div className="text-[11px] text-muted-foreground">{p.subtitle}</div>
                </TableCell>
                <TableCell className="text-xs text-muted-foreground">
                  <span className="font-medium text-foreground">{p.cta}</span> → {p.target || '—'}
                </TableCell>
                <TableCell>{p.accent ? <Badge className="bg-lime/15 text-lime border-lime/30 border">lime</Badge> : <span className="text-xs text-muted-foreground">—</span>}</TableCell>
                <TableCell>
                  <Switch checked={p.active} onCheckedChange={(v) => toggle(p.id, v)} />
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-1">
                    <Button variant="ghost" size="icon" className="size-7" onClick={() => setEditing(p)}><Pencil className="size-3.5" /></Button>
                    <Button variant="ghost" size="icon" className="size-7 text-loss" onClick={() => remove(p.id)}><Trash2 className="size-3.5" /></Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
            {rows.length === 0 && (
              <TableRow><TableCell colSpan={6} className="py-8 text-center text-sm text-muted-foreground">No promotions yet.</TableCell></TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      <Dialog open={!!editing} onOpenChange={(o) => !o && setEditing(null)}>
        <DialogContent className="bg-overlay">
          <DialogHeader>
            <DialogTitle>{editing?.id ? 'Edit promotion' : 'New promotion'}</DialogTitle>
            <DialogDescription>Shown in the casino hero carousel and promo strip.</DialogDescription>
          </DialogHeader>
          {editing && <PromoForm initial={editing} busy={busy} onCancel={() => setEditing(null)} onSave={save} />}
        </DialogContent>
      </Dialog>
    </div>
  )
}

function PromoForm({ initial, busy, onCancel, onSave }: {
  initial: Promotion; busy: boolean; onCancel: () => void; onSave: (p: Promotion) => void;
}) {
  const [f, setF] = useState<Promotion>(initial)
  const set = (k: keyof Promotion, v: unknown) => setF((p) => ({ ...p, [k]: v }))
  return (
    <div className="flex flex-col gap-3">
      <div className="flex flex-col gap-2">
        <Label className="text-xs text-muted-foreground">Title</Label>
        <Input value={f.title} onChange={(e) => set('title', e.target.value)} placeholder="$100,000 Weekly Race" />
      </div>
      <div className="flex flex-col gap-2">
        <Label className="text-xs text-muted-foreground">Subtitle</Label>
        <Input value={f.subtitle} onChange={(e) => set('subtitle', e.target.value)} placeholder="Live leaderboard" />
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div className="flex flex-col gap-2">
          <Label className="text-xs text-muted-foreground">CTA label</Label>
          <Input value={f.cta} onChange={(e) => set('cta', e.target.value)} placeholder="Play" />
        </div>
        <div className="flex flex-col gap-2">
          <Label className="text-xs text-muted-foreground">Target (game or section)</Label>
          <Input value={f.target} onChange={(e) => set('target', e.target.value)} placeholder="dice / rewards / affiliate" />
        </div>
      </div>
      <div className="flex flex-col gap-2">
        <Label className="text-xs text-muted-foreground">Image URL</Label>
        <Input value={f.imageUrl} onChange={(e) => set('imageUrl', e.target.value)} placeholder="/brand/hero.jpg or https://…" />
      </div>
      <div className="flex items-center justify-between rounded-lg border border-border bg-bg px-3 py-2">
        <Label className="text-xs text-muted-foreground">Lime accent gradient</Label>
        <Switch checked={f.accent} onCheckedChange={(v) => set('accent', v)} />
      </div>
      <DialogFooter>
        <Button variant="ghost" onClick={onCancel}>Cancel</Button>
        <Button disabled={busy} className="bg-lime text-bg hover:bg-lime-400 active:scale-[0.97]" onClick={() => onSave(f)}>
          {busy && <Loader2 className="size-4 animate-spin" />} Save
        </Button>
      </DialogFooter>
    </div>
  )
}

// ── Games tab ────────────────────────────────────────────────────────────────
const EMPTY_GAME = { id: '', gameId: '', name: '', tagline: '', description: '', provider: 'TOLS', category: 'originals', imageUrl: '', sortOrder: 0, featured: false, isNew: false, active: true }

function GamesTab() {
  const [rows, setRows] = useState<GameEntry[] | null>(null)
  const [editing, setEditing] = useState<GameEntry | null>(null)
  const [busy, setBusy] = useState(false)

  const load = useCallback(async () => {
    const res = await jf<Row<GameEntry[]>>('/api/cms/games?includeInactive=true')
    setRows(res.data)
  }, [])

  useEffect(() => { load().catch(() => setRows([])) }, [load])

  async function save(g: GameEntry) {
    setBusy(true)
    try {
      if (g.id) {
        await jf('/api/cms/games', { method: 'PUT', body: JSON.stringify(g) })
        toast.success('Game updated')
      } else {
        await jf('/api/cms/games', { method: 'POST', body: JSON.stringify(g) })
        toast.success('Game created')
      }
      setEditing(null)
      await load()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Save failed')
    } finally {
      setBusy(false)
    }
  }

  async function remove(id: string) {
    await jf(`/api/cms/games?id=${encodeURIComponent(id)}`, { method: 'DELETE' })
    toast.success('Game deleted')
    await load()
  }

  async function move(id: string, dir: -1 | 1) {
    const list = [...(rows ?? [])].sort((a, b) => a.sortOrder - b.sortOrder)
    const i = list.findIndex((r) => r.id === id)
    const j = i + dir
    if (i < 0 || j < 0 || j >= list.length) return
    const [a, b] = [list[i], list[j]]
    await jf('/api/cms/games', { method: 'PUT', body: JSON.stringify({ id: a.id, sortOrder: b.sortOrder }) })
    await jf('/api/cms/games', { method: 'PUT', body: JSON.stringify({ id: b.id, sortOrder: a.sortOrder }) })
    await load()
  }

  async function toggleField(id: string, field: 'active' | 'featured' | 'isNew', value: boolean) {
    await jf('/api/cms/games', { method: 'PUT', body: JSON.stringify({ id, [field]: value }) })
    await load()
  }

  if (rows === null) return <Skeleton className="h-40 w-full rounded-xl" />

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <p className="text-xs text-muted-foreground">
          Marketing layer for the casino catalogue — order, tagline, image, featured flags.
        </p>
        <Button size="sm" className="bg-lime text-bg hover:bg-lime-400 active:scale-[0.97]" onClick={() => setEditing({ ...EMPTY_GAME })}>
          <Plus className="size-4" /> New game entry
        </Button>
      </div>

      <div className="overflow-x-auto rounded-lg border border-border">
        <Table>
          <TableHeader>
            <TableRow className="hover:bg-transparent">
              <TableHead className="text-[11px] text-muted-foreground">Order</TableHead>
              <TableHead className="text-[11px] text-muted-foreground">Game</TableHead>
              <TableHead className="text-[11px] text-muted-foreground">Category</TableHead>
              <TableHead className="text-[11px] text-muted-foreground">Flags</TableHead>
              <TableHead className="text-[11px] text-muted-foreground">Active</TableHead>
              <TableHead className="text-right text-[11px] text-muted-foreground">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {rows.map((g) => (
              <TableRow key={g.id} className="border-border">
                <TableCell>
                  <div className="flex items-center gap-1">
                    <Button variant="ghost" size="icon" className="size-6" onClick={() => move(g.id, -1)}><ArrowUp className="size-3" /></Button>
                    <Button variant="ghost" size="icon" className="size-6" onClick={() => move(g.id, 1)}><ArrowDown className="size-3" /></Button>
                    <span className="ml-1 text-xs tabular-nums text-muted-foreground">{g.sortOrder}</span>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-[11px] text-lime">{g.gameId}</span>
                    <span className="text-sm font-medium">{g.name || '—'}</span>
                  </div>
                  <div className="text-[11px] text-muted-foreground">{g.tagline}</div>
                </TableCell>
                <TableCell className="text-xs text-muted-foreground">{g.category}</TableCell>
                <TableCell>
                  <div className="flex gap-1">
                    <Badge variant="outline" className={cn('border', g.featured ? 'bg-lime/15 text-lime border-lime/30' : 'border-border text-muted-foreground')}>★</Badge>
                    <Badge variant="outline" className={cn('border', g.isNew ? 'bg-pending/15 text-pending border-pending/30' : 'border-border text-muted-foreground')}>NEW</Badge>
                  </div>
                </TableCell>
                <TableCell>
                  <Switch checked={g.active} onCheckedChange={(v) => toggleField(g.id, 'active', v)} />
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-1">
                    <Button variant="ghost" size="icon" className="size-7" onClick={() => setEditing(g)}><Pencil className="size-3.5" /></Button>
                    <Button variant="ghost" size="icon" className="size-7 text-loss" onClick={() => remove(g.id)}><Trash2 className="size-3.5" /></Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
            {rows.length === 0 && (
              <TableRow><TableCell colSpan={6} className="py-8 text-center text-sm text-muted-foreground">No game entries yet.</TableCell></TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      <Dialog open={!!editing} onOpenChange={(o) => !o && setEditing(null)}>
        <DialogContent className="bg-overlay">
          <DialogHeader>
            <DialogTitle>{editing?.id ? 'Edit game' : 'New game entry'}</DialogTitle>
            <DialogDescription>The casino merges this over its own catalogue.</DialogDescription>
          </DialogHeader>
          {editing && <GameForm initial={editing} busy={busy} onCancel={() => setEditing(null)} onSave={save} />}
        </DialogContent>
      </Dialog>
    </div>
  )
}

function GameForm({ initial, busy, onCancel, onSave }: {
  initial: GameEntry; busy: boolean; onCancel: () => void; onSave: (g: GameEntry) => void;
}) {
  const [f, setF] = useState<GameEntry>(initial)
  const set = (k: keyof GameEntry, v: unknown) => setF((g) => ({ ...g, [k]: v }))
  return (
    <div className="flex flex-col gap-3">
      <div className="grid grid-cols-2 gap-3">
        <div className="flex flex-col gap-2">
          <Label className="text-xs text-muted-foreground">Game ID (slug)</Label>
          <Input value={f.gameId} disabled={!!f.id} onChange={(e) => set('gameId', e.target.value.toLowerCase())} placeholder="dice" />
        </div>
        <div className="flex flex-col gap-2">
          <Label className="text-xs text-muted-foreground">Name</Label>
          <Input value={f.name} onChange={(e) => set('name', e.target.value)} placeholder="Dice" />
        </div>
      </div>
      <div className="flex flex-col gap-2">
        <Label className="text-xs text-muted-foreground">Tagline</Label>
        <Input value={f.tagline} onChange={(e) => set('tagline', e.target.value)} placeholder="Roll over or under your target" />
      </div>
      <div className="flex flex-col gap-2">
        <Label className="text-xs text-muted-foreground">Description</Label>
        <Textarea value={f.description} onChange={(e) => set('description', e.target.value)} rows={3} />
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div className="flex flex-col gap-2">
          <Label className="text-xs text-muted-foreground">Provider</Label>
          <Input value={f.provider} onChange={(e) => set('provider', e.target.value)} />
        </div>
        <div className="flex flex-col gap-2">
          <Label className="text-xs text-muted-foreground">Category</Label>
          <Select value={f.category} onValueChange={(v) => set('category', v)}>
            <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
            <SelectContent>
              {['originals', 'slots', 'live', 'table'].map((c) => (
                <SelectItem key={c} value={c}>{c}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>
      <div className="flex flex-col gap-2">
        <Label className="text-xs text-muted-foreground">Image URL (optional override)</Label>
        <Input value={f.imageUrl} onChange={(e) => set('imageUrl', e.target.value)} placeholder="/games/originals/dice.jpg" />
      </div>
      <div className="flex items-center justify-between rounded-lg border border-border bg-bg px-3 py-2">
        <Label className="text-xs text-muted-foreground">Featured (star on card)</Label>
        <Switch checked={f.featured} onCheckedChange={(v) => set('featured', v)} />
      </div>
      <div className="flex items-center justify-between rounded-lg border border-border bg-bg px-3 py-2">
        <Label className="text-xs text-muted-foreground">Mark as new</Label>
        <Switch checked={f.isNew} onCheckedChange={(v) => set('isNew', v)} />
      </div>
      <DialogFooter>
        <Button variant="ghost" onClick={onCancel}>Cancel</Button>
        <Button disabled={busy} className="bg-lime text-bg hover:bg-lime-400 active:scale-[0.97]" onClick={() => onSave(f)}>
          {busy && <Loader2 className="size-4 animate-spin" />} Save
        </Button>
      </DialogFooter>
    </div>
  )
}

// ── Root view ────────────────────────────────────────────────────────────────
export function CmsView() {
  return (
    <div className="flex flex-col gap-4">
      <Card className="border-border bg-surface">
        <CardHeader className="flex flex-row items-center gap-3 space-y-0 px-4 py-3">
          <div className="flex size-10 items-center justify-center rounded-lg border border-lime/30 bg-lime/10 text-lime">
            <Rocket className="size-5" />
          </div>
          <div>
            <CardTitle className="text-sm">Marketing CMS</CardTitle>
            <CardDescription className="text-xs">
              Promotions &amp; game content published live to the Casino lobby
            </CardDescription>
          </div>
        </CardHeader>
        <CardContent className="px-4 pb-4">
          <Tabs defaultValue="promotions">
            <TabsList className="bg-surface-raised">
              <TabsTrigger value="promotions" className="data-[state=active]:bg-overlay"><Megaphone className="size-4" /> Promotions</TabsTrigger>
              <TabsTrigger value="games" className="data-[state=active]:bg-overlay"><Gamepad2 className="size-4" /> Games</TabsTrigger>
            </TabsList>
            <TabsContent value="promotions" className="mt-4"><PromotionsTab /></TabsContent>
            <TabsContent value="games" className="mt-4"><GamesTab /></TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}
