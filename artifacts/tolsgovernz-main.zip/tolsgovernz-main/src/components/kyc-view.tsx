'use client'

import { useCallback, useState } from 'react'
import { useApi } from '@/hooks/use-api'
import { api } from '@/services/api'
import { BadgeCheck, Clock, CheckCircle2, XCircle } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import { StatCard } from '@/components/stat-card'

interface KycRow {
  id: string
  player: string
  email: string
  country: string
  submittedAt: string
  documents: string[]
  status: 'pending' | 'approved' | 'rejected'
  risk: 'low' | 'medium' | 'high'
}

interface KycData {
  stats: { pending: number; approved: number; rejected: number; total: number }
  queue: KycRow[]
}

const statusBadge: Record<KycRow['status'], string> = {
  pending: 'bg-pending/15 text-pending border-pending/30',
  approved: 'bg-lime/15 text-lime border-lime/30',
  rejected: 'bg-loss/15 text-loss border-loss/30',
}

const riskBadge: Record<KycRow['risk'], string> = {
  low: 'bg-lime/15 text-lime border-lime/30',
  medium: 'bg-pending/15 text-pending border-pending/30',
  high: 'bg-loss/15 text-loss border-loss/30',
}

export function KycView() {
  const { data, loading, error, refetch } = useApi<KycData>(() => api.kyc.get())
  const [busyId, setBusyId] = useState<string | null>(null)

  const handleAction = useCallback(async (id: string, action: 'approve' | 'reject') => {
    setBusyId(id)
    try {
      await api.kyc.update(id, action)
      await refetch()
    } catch {
      // DB may be offline in dev/sandbox — keep the UI responsive.
    } finally {
      setBusyId(null)
    }
  }, [refetch])

  if (loading) {
    return (
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {Array.from({ length: 4 }).map((_, i) => (
          <Card key={i}><CardContent className="p-6"><Skeleton className="h-14 w-full" /></CardContent></Card>
        ))}
      </div>
    )
  }

  if (error || !data) {
    return (
      <Card className="border-destructive/40">
        <CardContent className="p-6 text-center text-sm text-muted-foreground">Failed to load KYC data: {error}</CardContent>
      </Card>
    )
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <StatCard icon={Clock} label="Pending" value={String(data.stats.pending)} tone="text-pending" />
        <StatCard icon={CheckCircle2} label="Approved" value={String(data.stats.approved)} tone="text-lime" />
        <StatCard icon={XCircle} label="Rejected" value={String(data.stats.rejected)} tone="text-loss" />
        <StatCard icon={BadgeCheck} label="Total" value={String(data.stats.total)} />
      </div>

      <Card className="border-border bg-surface">
        <CardHeader className="px-4 py-3">
          <CardTitle className="text-sm">Verification queue</CardTitle>
          <CardDescription className="text-xs">Approve or reject identity documents. Only verified players can withdraw real money.</CardDescription>
        </CardHeader>
        <CardContent className="px-4 pb-4">
          <div className="overflow-x-auto rounded-lg border border-border">
            <Table>
              <TableHeader>
                <TableRow className="hover:bg-transparent">
                  <TableHead className="text-[11px] text-muted-foreground">Player</TableHead>
                  <TableHead className="text-[11px] text-muted-foreground">Country</TableHead>
                  <TableHead className="text-[11px] text-muted-foreground">Documents</TableHead>
                  <TableHead className="text-[11px] text-muted-foreground">Risk</TableHead>
                  <TableHead className="text-[11px] text-muted-foreground">Status</TableHead>
                  <TableHead className="text-right text-[11px] text-muted-foreground">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.queue.map((row) => (
                  <TableRow key={row.id} className="border-border">
                    <TableCell>
                      <div className="text-sm font-medium">{row.player}</div>
                      <div className="text-[11px] text-muted-foreground">{row.email}</div>
                    </TableCell>
                    <TableCell className="text-xs uppercase text-muted-foreground">{row.country}</TableCell>
                    <TableCell className="text-xs text-muted-foreground">{row.documents.join(', ').replace(/_/g, ' ')}</TableCell>
                    <TableCell><Badge variant="outline" className={`border uppercase ${riskBadge[row.risk]}`}>{row.risk}</Badge></TableCell>
                    <TableCell><Badge variant="outline" className={`border capitalize ${statusBadge[row.status]}`}>{row.status}</Badge></TableCell>
                    <TableCell className="text-right">
                      {row.status === 'pending' ? (
                        <div className="flex justify-end gap-1.5">
                          <Button size="sm" className="h-7 bg-lime text-bg hover:bg-lime-400" disabled={busyId === row.id} onClick={() => handleAction(row.id, 'approve')}>Approve</Button>
                          <Button size="sm" variant="destructive" className="h-7" disabled={busyId === row.id} onClick={() => handleAction(row.id, 'reject')}>Reject</Button>
                        </div>
                      ) : (
                        <span className="text-xs text-muted-foreground">—</span>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
