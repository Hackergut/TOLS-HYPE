'use client'

// ─────────────────────────────────────────────────────────────────────────────
// LiveFeed — realtime activity stream (SSE) shown on the Governance overview.
// A "LIVE" indicator reflects transport health; the list streams deposits,
// wins, sessions and registrations as they arrive.
// ─────────────────────────────────────────────────────────────────────────────

import { ArrowDownToLine, Trophy, Gamepad2, UserPlus } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { useRealtime, type LiveEvent } from '@/hooks/use-realtime'
import { cn } from '@/lib/utils'

const iconFor: Record<LiveEvent['eventType'], typeof Gamepad2> = {
  deposit: ArrowDownToLine,
  win: Trophy,
  session: Gamepad2,
  registration: UserPlus,
}

const toneFor: Record<LiveEvent['eventType'], string> = {
  deposit: 'text-lime',
  win: 'text-vip',
  session: 'text-muted-foreground',
  registration: 'text-sky-400',
}

const labelFor: Record<LiveEvent['eventType'], string> = {
  deposit: 'deposit',
  win: 'win',
  session: 'playing',
  registration: 'joined',
}

function timeAgo(iso: string): string {
  const s = Math.max(0, Math.round((Date.now() - new Date(iso).getTime()) / 1000))
  if (s < 60) return `${s}s`
  if (s < 3600) return `${Math.floor(s / 60)}m`
  return `${Math.floor(s / 3600)}h`
}

export function LiveFeed() {
  const { connected, events, stats, jackpot } = useRealtime()

  return (
    <Card className="border-border bg-surface">
      <CardContent className="p-3.5">
        <div className="mb-2 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className={cn('size-1.5 rounded-full', connected ? 'bg-lime animate-pulse' : 'bg-muted-foreground')} />
            <p className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
              Live feed {connected ? '' : '(connecting…)'}
            </p>
          </div>
          <p className="font-mono text-[11px] tabular-nums text-muted-foreground">
            {stats ? `${stats.totalOnline.toLocaleString('en-US')} online` : '— online'}
            {jackpot != null && (
              <span className="ml-2 text-vip">JP ${jackpot.toLocaleString('en-US')}</span>
            )}
          </p>
        </div>

        {events.length === 0 ? (
          <p className="py-6 text-center text-xs text-muted-foreground">Waiting for events…</p>
        ) : (
          <ul className="flex max-h-56 flex-col gap-1 overflow-hidden">
            {events.slice(0, 9).map((ev) => {
              const Icon = iconFor[ev.eventType]
              return (
                <li key={ev.id} className="flex items-center gap-2 rounded-md px-2 py-1 text-xs hover:bg-muted/50">
                  <Icon className={cn('size-3.5 shrink-0', toneFor[ev.eventType])} />
                  <span className="truncate">
                    <span className="font-medium text-foreground">{ev.playerName}</span>{' '}
                    <span className="text-muted-foreground">
                      {labelFor[ev.eventType]}
                      {ev.gameName ? ` ${ev.gameName}` : ''}
                    </span>
                  </span>
                  {ev.amount != null && (
                    <span className={cn('ml-auto font-mono tabular-nums', toneFor[ev.eventType])}>
                      {ev.currency === 'USD' ? '$' : ''}
                      {ev.amount.toLocaleString('en-US')}
                      {ev.currency && ev.currency !== 'USD' ? ` ${ev.currency}` : ''}
                    </span>
                  )}
                  <span className="shrink-0 text-[10px] tabular-nums text-muted-foreground/70">
                    {timeAgo(ev.createdAt)}
                  </span>
                </li>
              )
            })}
          </ul>
        )}
      </CardContent>
    </Card>
  )
}
