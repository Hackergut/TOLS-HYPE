'use client'

import { useState, useEffect, useMemo, useCallback } from 'react'
import { useApi } from '@/hooks/use-api'
import { api } from '@/services/api'
import type { LiveMapData, LiveEvent } from '@/types/live-map'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Globe, Users, Server, Activity, Wifi, Zap,
  RefreshCw, MapPin, Monitor, Smartphone, ChevronDown,
} from 'lucide-react'

import dynamic from 'next/dynamic'
const WorldMap = dynamic(() => import('@/components/world-map').then((m) => m.WorldMap), { ssr: false })

/* ─── Region Colors ─── */
const REGION_COLORS: Record<string, string> = {
  'Europe': '#3b82f6',
  'North America': '#10b981',
  'Asia Pacific': '#f59e0b',
  'South America': '#ef4444',
  'Oceania': '#8b5cf6',
  'Africa': '#f97316',
}

/* ─── Format Helpers ─── */
function formatCurrency(n: number): string {
  return `$${n.toLocaleString('en-US')}`
}

/* ─── Animated Counter Hook ─── */
function useAnimatedCounter(target: number, duration = 1000): number {
  const [value, setValue] = useState(0)
  useEffect(() => {
    const start = value
    const diff = target - start
    if (diff === 0) return
    const startTime = performance.now()
    let raf: number
    const step = (now: number) => {
      const elapsed = now - startTime
      const progress = Math.min(elapsed / duration, 1)
      const eased = 1 - Math.pow(1 - progress, 3)
      setValue(Math.round(start + diff * eased))
      if (progress < 1) raf = requestAnimationFrame(step)
    }
    raf = requestAnimationFrame(step)
    return () => cancelAnimationFrame(raf)
  }, [target, duration])
  return value
}

/* ─── Event Ticker ─── */
function EventTicker({ events }: { events: LiveEvent[] }) {
  const [scrollOffset, setScrollOffset] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setScrollOffset(prev => prev + 1)
    }, 30)
    return () => clearInterval(interval)
  }, [])

  const eventTexts = useMemo(() => {
    return events.map(e => {
      const emoji = e.eventType === 'jackpot_hit' ? '🎰' : e.eventType === 'big_win' ? '🏆' : e.eventType === 'deposit' ? '💰' : '🆕'
      const action = e.eventType === 'jackpot_hit' ? 'hit jackpot' : e.eventType === 'big_win' ? 'won' : e.eventType === 'deposit' ? 'deposited' : 'joined'
      const amountStr = e.amount > 0 ? ` ${formatCurrency(e.amount)} on` : ''
      return `${emoji} ${e.playerName} ${action}${amountStr} ${e.gameName} • ${e.city}, ${e.countryCode}`
    })
  }, [events])

  const fullText = eventTexts.join('    ◆    ') + '    ◆    ' + eventTexts.join('    ◆    ')

  return (
    <div className="relative overflow-hidden h-8 bg-gradient-to-r from-[#0a0e1a] via-[#111827] to-[#0a0e1a] border-t border-amber-900/30">
      <div className="absolute inset-0 flex items-center whitespace-nowrap" style={{ transform: `translateX(-${scrollOffset % (fullText.length * 6)}px)` }}>
        <span className="text-xs text-amber-200/80 font-mono tracking-wide px-4">
          {fullText}
        </span>
      </div>
      <div className="absolute left-0 top-0 bottom-0 w-12 bg-gradient-to-r from-[#0a0e1a] to-transparent z-10" />
      <div className="absolute right-0 top-0 bottom-0 w-12 bg-gradient-to-l from-[#0a0e1a] to-transparent z-10" />
    </div>
  )
}

/* ─── Collapsible data panel ─── */
function CollapsiblePanel({ icon: Icon, title, badge, defaultOpen = false, children }: {
  icon: React.ElementType
  title: string
  badge?: React.ReactNode
  defaultOpen?: boolean
  children: React.ReactNode
}) {
  const [open, setOpen] = useState(defaultOpen)
  return (
    <div className="rounded-lg border border-amber-900/40 bg-[#0a0e1a]/70 overflow-hidden">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-expanded={open}
        className="flex w-full items-center gap-2 px-3 py-2.5 text-left transition-colors hover:bg-amber-900/15"
      >
        <Icon className="w-4 h-4 text-amber-400 shrink-0" />
        <span className="flex-1 text-xs font-semibold text-slate-200">{title}</span>
        {badge}
        <ChevronDown className={`w-4 h-4 text-slate-500 transition-transform duration-200 ${open ? 'rotate-180' : ''}`} />
      </button>
      {open && <div className="px-3 pb-3">{children}</div>}
    </div>
  )
}

/* ─── Online stats (collapsed by default) ─── */
function OnlineStats({ stats }: { stats: LiveMapData['stats'] }) {
  const totalOnline = useAnimatedCounter(stats.totalOnline, 800)
  const regionCount = Object.keys(stats.byRegion).length
  const peakConcurrent = Math.round(stats.totalOnline * 1.15)
  const peakAnimated = useAnimatedCounter(peakConcurrent, 1000)
  const avgSession = 23

  const rows = [
    { icon: Users, tint: 'bg-lime-300/20 text-lime-300', label: 'Online Now', value: totalOnline.toLocaleString() },
    { icon: Globe, tint: 'bg-blue-500/20 text-blue-400', label: 'Active Regions', value: String(regionCount) },
    { icon: Zap, tint: 'bg-amber-500/20 text-amber-400', label: 'Peak Today', value: peakAnimated.toLocaleString() },
    { icon: Activity, tint: 'bg-violet-500/20 text-violet-400', label: 'Avg Session', value: `${avgSession}m` },
  ]

  return (
    <div className="grid grid-cols-2 gap-2">
      {rows.map((r) => (
        <div key={r.label} className="flex items-center gap-2 rounded-lg bg-white/[0.03] px-2.5 py-2">
          <div className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-lg ${r.tint}`}>
            <r.icon className="h-4 w-4" />
          </div>
          <div className="min-w-0">
            <p className="text-[10px] text-slate-400 uppercase tracking-wider truncate">{r.label}</p>
            <p className="text-base font-bold tabular-nums text-foreground">{r.value}</p>
          </div>
        </div>
      ))}
    </div>
  )
}

/* ─── Regions list ─── */
function RegionsList({ byRegion }: { byRegion: Record<string, number> }) {
  return (
    <div className="flex flex-col gap-1.5">
      {Object.entries(byRegion).sort((a, b) => b[1] - a[1]).map(([region, count]) => (
        <div key={region} className="flex items-center gap-2 text-xs">
          <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: REGION_COLORS[region] || '#64748b' }} />
          <span className="text-slate-300 w-24 truncate">{region}</span>
          <span className="text-slate-500 tabular-nums">{count}</span>
        </div>
      ))}
    </div>
  )
}

/* ─── Devices list ─── */
function DevicesList({ byDevice }: { byDevice: Record<string, number> }) {
  const total = Object.values(byDevice).reduce((a, b) => a + b, 0)
  return (
    <div className="flex flex-col gap-1.5">
      {Object.entries(byDevice).sort((a, b) => b[1] - a[1]).map(([device, count]) => {
        const pct = total > 0 ? Math.round((count / total) * 100) : 0
        const Icon = device === 'desktop' ? Monitor : device === 'mobile' ? Smartphone : MapPin
        return (
          <div key={device} className="flex items-center gap-2 text-xs">
            <Icon className="w-3.5 h-3.5 text-slate-400" />
            <span className="text-slate-300 w-16 capitalize">{device}</span>
            <div className="flex-1 h-1.5 bg-slate-800 rounded-full overflow-hidden">
              <div className="h-full bg-amber-500/70 rounded-full" style={{ width: `${pct}%` }} />
            </div>
            <span className="text-slate-500 tabular-nums w-7 text-right">{pct}%</span>
          </div>
        )
      })}
    </div>
  )
}

/* ─── Player status legend ─── */
function StatusLegend() {
  const items = [
    { color: '#10b981', label: 'Active' },
    { color: '#d4a017', label: 'Big Win' },
    { color: '#ef4444', label: 'High Value' },
    { color: '#3b82f6', label: 'New Session' },
  ]
  return (
    <div className="flex flex-col gap-1.5">
      {items.map(({ color, label }) => (
        <div key={label} className="flex items-center gap-2 text-xs">
          <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: color, boxShadow: `0 0 6px ${color}` }} />
          <span className="text-slate-300">{label}</span>
        </div>
      ))}
    </div>
  )
}

/* ═══════════════════════════════════════════════════════════════
   Main Component
   ═══════════════════════════════════════════════════════════════ */
export function LiveMapView() {
  const { data, loading, error, refetch } = useApi(() => api.liveMap.get())
  const [refreshing, setRefreshing] = useState(false)

  const handleRefresh = useCallback(async () => {
    setRefreshing(true)
    await refetch()
    setTimeout(() => setRefreshing(false), 600)
  }, [refetch])

  if (loading) {
    return (
      <div className="w-full h-full min-h-[400px] sm:min-h-[600px] bg-[#0a0e1a] rounded-xl border border-amber-900/30 p-4">
        <div className="flex flex-col gap-3">
          <Skeleton className="h-8 w-48 bg-slate-800" />
          <Skeleton className="h-[300px] sm:h-[400px] w-full bg-slate-800/50" />
          <Skeleton className="h-8 w-full bg-slate-800" />
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="w-full h-full min-h-[600px] bg-[#0a0e1a] rounded-xl border border-red-900/30 p-6 flex flex-col items-center justify-center gap-4">
        <Wifi className="w-10 h-10 text-red-400" />
        <p className="text-red-400 text-sm">Failed to load live map data</p>
        <p className="text-slate-500 text-xs">{error}</p>
        <Button variant="outline" size="sm" onClick={handleRefresh} className="border-amber-900/40 text-amber-300 hover:bg-amber-900/20">
          <RefreshCw className="w-3.5 h-3.5 mr-1.5" /> Retry
        </Button>
      </div>
    )
  }

  if (!data) return null

  return (
    <div className="flex flex-col w-full h-full min-h-[400px] sm:min-h-[600px] bg-[#0a0e1a] rounded-xl border border-amber-900/30 overflow-hidden">
      {/* ─── Header ─── */}
      <div className="flex items-center justify-between px-3 sm:px-4 py-2.5 border-b border-amber-900/30 bg-[#0a0e1a]/80">
        <div className="flex items-center gap-2.5">
          <div className="relative">
            <Globe className="w-5 h-5 text-amber-400" />
            <span className="absolute -top-0.5 -right-0.5 w-2 h-2 bg-lime-300 rounded-full animate-pulse" />
          </div>
          <h2 className="text-sm font-semibold text-amber-200 tracking-wide">Live World Map</h2>
          <Badge variant="outline" className="text-[9px] h-4 px-1.5 border-lime-400 text-lime-300 bg-lime-600/40">
            <span className="w-1.5 h-1.5 bg-lime-300 rounded-full mr-1 animate-pulse" />
            LIVE
          </Badge>
        </div>
        <div className="flex items-center gap-2">
          <div className="hidden sm:flex items-center gap-1.5 text-[10px] text-slate-400 mr-2">
            <Server className="w-3 h-3" />
            <span>{data.serverNodes.length} servers</span>
            <span className="text-slate-600">•</span>
            <Users className="w-3 h-3" />
            <span>{data.stats.totalOnline.toLocaleString()} online</span>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleRefresh}
            className="h-7 w-7 p-0 text-amber-400 hover:text-amber-300 hover:bg-amber-900/20"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${refreshing ? 'animate-spin' : ''}`} />
          </Button>
        </div>
      </div>

      {/* ─── Real Map (Leaflet + real coordinates) ─── */}
      <div className="relative flex-1" style={{ minHeight: 360 }}>
        <WorldMap sessions={data.activeSessions} nodes={data.serverNodes} events={data.liveEvents} />
      </div>

      {/* ─── Collapsible data panels (click to expand) ─── */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2 border-t border-amber-900/30 bg-[#0a0e1a]/85 p-3">
        <CollapsiblePanel icon={Users} title="Online Now" badge={<Badge variant="outline" className="text-[9px] h-4 border-lime-400 text-lime-300 bg-lime-600/40">{data.stats.totalOnline.toLocaleString()}</Badge>}>
          <OnlineStats stats={data.stats} />
        </CollapsiblePanel>
        <CollapsiblePanel icon={Globe} title="Regions" badge={<Badge variant="outline" className="text-[9px] h-4 border-slate-500 text-slate-300">{Object.keys(data.stats.byRegion).length}</Badge>}>
          <RegionsList byRegion={data.stats.byRegion} />
        </CollapsiblePanel>
        <CollapsiblePanel icon={Monitor} title="Devices">
          <DevicesList byDevice={data.stats.byDevice} />
        </CollapsiblePanel>
        <CollapsiblePanel icon={Activity} title="Player Status">
          <StatusLegend />
        </CollapsiblePanel>
      </div>

      {/* ─── Live Event Ticker ─── */}
      <EventTicker events={data.liveEvents} />
    </div>
  )
}
