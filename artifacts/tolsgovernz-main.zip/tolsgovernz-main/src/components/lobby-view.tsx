'use client'

// ─────────────────────────────────────────────────────────────────────────────
// LobbyView — the Governance front page (overview dashboard).
//
// A KPI strip with the platform's most critical live numbers, then every
// section organised into category groups with a search box and group filter
// chips. Clicking a card jumps to that section. Sections are role-filtered
// (same visibility as the sidebar) and metrics are wired to live data with
// static fallbacks, so the overview never blanks out.
// ─────────────────────────────────────────────────────────────────────────────

import { useMemo, useState, useCallback } from 'react'
import { ArrowUpRight, Gauge, RefreshCw, Search } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { useAppStore, type Section } from '@/lib/store'
import { sectionsByGroup, GROUP_ORDER, type SectionGroup } from '@/lib/sections'
import { useLobbyData, type LobbyValues } from '@/hooks/use-lobby-data'
import { LiveFeed } from '@/components/live-feed'
import { cn } from '@/lib/utils'

// ── KPI strip (top-level headline numbers) ───────────────────────────────────
function buildKpis(v: LobbyValues) {
  const fmtInt = (n: number) => n.toLocaleString('en-US')
  return [
    { label: 'Players online', value: v.playersOnline != null ? fmtInt(v.playersOnline) : '—', sub: 'live map', tone: 'text-lime' },
    { label: 'Active sessions', value: v.activeSessions != null ? fmtInt(v.activeSessions) : '—', sub: 'live players', tone: 'text-lime' },
    { label: 'Pending withdrawals', value: v.pendingWithdrawals != null ? fmtInt(v.pendingWithdrawals) : '—', sub: 'awaiting approval', tone: 'text-pending' },
    { label: 'Unread alerts', value: v.unread != null ? fmtInt(v.unread) : '—', sub: 'notification center', tone: 'text-loss' },
    { label: 'Casino link', value: 'Connected', sub: 'JWT RS256 bridge', tone: 'text-lime' },
  ]
}

// ── Section → headline metrics (live value with static fallback) ─────────────
function metricsFor(section: Section, v: LobbyValues): { label: string; value: string; hot?: boolean }[] {
  const int = (n?: number, fb = '—') => (n != null ? n.toLocaleString('en-US') : fb)
  const money = (n?: number, fb = '—') => {
    if (n == null) return fb
    if (n >= 1_000_000) return `$${(n / 1_000_000).toFixed(2)}M`
    if (n >= 1_000) return `$${(n / 1_000).toFixed(1)}K`
    return `$${n.toLocaleString('en-US')}`
  }

  switch (section) {
    case 'dashboard': return [ { label: 'House earnings', value: '$2.87M' }, { label: 'Jackpot', value: '$5.60M' }, { label: 'Alerts', value: int(v.unread), hot: true } ]
    case 'financial': return [ { label: 'Escrow', value: '$4.60M' }, { label: 'Waterfall tiers', value: '4' }, { label: 'Ledger', value: '128' } ]
    case 'live-map': return [ { label: 'Online', value: int(v.playersOnline) }, { label: 'Servers', value: '9' }, { label: 'Regions', value: '6' } ]
    case 'live-players': return [ { label: 'Sessions', value: int(v.activeSessions) }, { label: 'Avg session', value: '12m' }, { label: 'Avg wager', value: '$1.4K' } ]
    case 'players': return [ { label: 'Total', value: '20' }, { label: 'VIP', value: '5' }, { label: 'Churn risk', value: '89', hot: true } ]
    case 'segments': return [ { label: 'Segments', value: '5' }, { label: 'Dynamic', value: '5' }, { label: 'High rollers', value: '47' } ]
    case 'promotions': return [ { label: 'Active', value: '6' }, { label: 'Types', value: '3' }, { label: 'Redemptions', value: '2.4K' } ]
    case 'affiliates': return [ { label: 'Affiliates', value: '24' }, { label: 'Paid', value: '$128K' }, { label: 'Active', value: '19' } ]
    case 'wallets': return [ { label: 'Wallets', value: int(v.wallets) }, { label: 'Balance', value: money(v.totalBalance, '$9.20M') } ]
    case 'payments': return [ { label: 'Pending WD', value: int(v.pendingWithdrawals) }, { label: 'Deposits', value: int(v.depositsToday) }, { label: 'Providers', value: '6' } ]
    case 'vendors': return [ { label: 'Vendors', value: int(v.vendors) }, { label: 'Active', value: int(v.activeVendors) }, { label: 'Callbacks', value: '96%' } ]
    case 'notifications': return [ { label: 'Unread', value: int(v.unread) }, { label: 'Channels', value: '4' } ]
    case 'api-hub': return [ { label: 'Tokens', value: int(v.apiTokens) }, { label: 'Webhooks', value: '3' }, { label: 'Rate', value: '1K/min' } ]
    case 'ai-tutor': return [ { label: 'Assistant', value: 'Online' }, { label: 'Languages', value: 'en / it' } ]
    case 'auth': return [ { label: 'Users', value: int(v.users) }, { label: 'Roles', value: '3' }, { label: '2FA', value: 'On' } ]
    case 'blockchain': return [ { label: 'Wallets', value: int(v.blockchainWallets) }, { label: 'Networks', value: '6' }, { label: 'Txs', value: '2.3K' } ]
    case 'ml-pipeline': return [ { label: 'Models', value: int(v.models) }, { label: 'Predictions', value: '12.4K' }, { label: 'Accuracy', value: '92%' } ]
    case 'rtp': return [ { label: 'Games', value: '11' }, { label: 'Avg RTP', value: '97.9%' }, { label: 'Off target', value: '3', hot: true } ]
    case 'kyc': return [ { label: 'Pending', value: '3' }, { label: 'Approved', value: '1' }, { label: 'High risk', value: '1', hot: true } ]
    case 'responsible': return [ { label: 'Self-excluded', value: '2' }, { label: 'Limits', value: '4' } ]
    case 'risk': return [ { label: 'Flagged', value: '5' }, { label: 'Open', value: '3', hot: true } ]
    case 'legal': return [ { label: 'Contracts', value: '38' }, { label: 'Pending', value: '5', hot: true }, { label: 'Compliance', value: '100%' } ]
    case 'casino': return [ { label: 'Status', value: 'Connected' }, { label: 'Pending WD', value: int(v.pendingWithdrawals) }, { label: 'Events', value: '12' } ]
    case 'cms': return [ { label: 'Promotions', value: '5' }, { label: 'Games', value: '11' } ]
    default: return []
  }
}

export function LobbyView() {
  const { activeSection, setActiveSection, activeRole } = useAppStore()
  const { values, refresh } = useLobbyData()
  const [query, setQuery] = useState('')
  const [groupFilter, setGroupFilter] = useState<'all' | SectionGroup>('all')
  const [refreshing, setRefreshing] = useState(false)

  const handleRefresh = useCallback(() => {
    setRefreshing(true)
    refresh()
    setTimeout(() => setRefreshing(false), 600)
  }, [refresh])

  const kpis = useMemo(() => buildKpis(values), [values])

  const groups = useMemo(() => {
    const all = sectionsByGroup(activeRole).map((g) => ({
      ...g,
      items: g.items.filter((s) => s.id !== 'lobby'),
    }))
    const q = query.trim().toLowerCase()
    const filtered = all
      .map((g) => ({
        ...g,
        items: g.items.filter((s) => {
          const matchesGroup = groupFilter === 'all' || g.group === groupFilter
          const matchesQuery = !q || s.label.toLowerCase().includes(q) || s.description.toLowerCase().includes(q)
          return matchesGroup && matchesQuery
        }),
      }))
      .filter((g) => g.items.length > 0)
    return filtered
  }, [activeRole, query, groupFilter])

  const filterChips: { id: 'all' | SectionGroup; label: string }[] = [
    { id: 'all', label: 'All' },
    ...GROUP_ORDER.filter((g) => g.id !== 'overview').map((g) => ({ id: g.id, label: g.label })),
  ]

  const totalShown = groups.reduce((n, g) => n + g.items.length, 0)

  return (
    <div className="flex flex-col gap-5">
      {/* Header + search */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <div className="flex size-10 items-center justify-center rounded-lg border border-lime/30 bg-lime/10 text-lime">
            <Gauge className="size-5" />
          </div>
          <div>
            <h2 className="text-sm font-semibold">Governance Overview</h2>
            <p className="text-xs text-muted-foreground">
              {totalShown} sections · {activeRole === 'super_admin' ? 'Super admin' : activeRole}
            </p>
          </div>
        </div>
        <div className="relative w-full sm:w-64">
          <Search className="pointer-events-none absolute left-2.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Filter sections…"
            className="pl-8"
          />
        </div>
        <button
          onClick={handleRefresh}
          className="flex size-8 shrink-0 items-center justify-center rounded-md border border-border text-muted-foreground transition-colors hover:text-foreground"
          aria-label="Refresh"
          title="Refresh"
        >
          <RefreshCw className={cn('size-4', refreshing && 'animate-spin')} />
        </button>
      </div>

      {/* KPI strip */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
        {kpis.map((k) => (
          <Card key={k.label} className="border-border bg-surface">
            <CardContent className="p-3.5">
              <p className="text-[11px] uppercase tracking-wide text-muted-foreground">{k.label}</p>
              <p className={cn('mt-1.5 font-mono text-xl font-bold tabular-nums', k.tone)}>{k.value}</p>
              <p className="text-[10px] text-muted-foreground">{k.sub}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Realtime activity stream (SSE) */}
      <LiveFeed />

      {/* Filter chips */}
      <div className="flex flex-wrap gap-1.5">
        {filterChips.map((c) => (
          <button
            key={c.id}
            onClick={() => setGroupFilter(c.id)}
            className={cn(
              'rounded-full px-3 py-1 text-xs font-semibold transition-colors',
              groupFilter === c.id
                ? 'bg-lime text-bg'
                : 'border border-border bg-surface text-muted-foreground hover:text-foreground',
            )}
          >
            {c.label}
          </button>
        ))}
      </div>

      {/* Section cards, grouped */}
      {groups.length === 0 ? (
        <div className="rounded-xl border border-dashed border-border px-5 py-10 text-center">
          <p className="text-sm text-muted-foreground">No sections match “{query}”</p>
        </div>
      ) : (
        groups.map((group) => (
          <section key={group.group} className="flex flex-col gap-2.5">
            <div className="flex items-center gap-2">
              <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                {group.label}
              </h3>
              <span className="text-[10px] text-muted-foreground/60">{group.items.length}</span>
              <div className="h-px flex-1 bg-border" />
            </div>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
              {group.items.map((s) => {
                const active = activeSection === s.id
                const metrics = metricsFor(s.id, values)
                return (
                  <Card
                    key={s.id}
                    onClick={() => setActiveSection(s.id)}
                    className={cn(
                      'group cursor-pointer border-border bg-surface transition-all hover:-translate-y-0.5 hover:border-lime/40',
                      active && 'border-lime/50 bg-lime/5',
                    )}
                  >
                    <CardContent className="flex h-full flex-col gap-2.5 p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex size-8 items-center justify-center rounded-lg bg-secondary text-lime">
                          <s.icon className="size-4" />
                        </div>
                        <ArrowUpRight className="size-4 text-muted-foreground opacity-0 transition-opacity group-hover:opacity-100" />
                      </div>
                      <div>
                        <p className="text-sm font-semibold">{s.label}</p>
                        <p className="text-[11px] text-muted-foreground">{s.description}</p>
                      </div>
                      <div className="mt-auto grid grid-cols-3 gap-1.5 border-t border-border pt-2.5">
                        {metrics.map((m) => (
                          <div key={m.label} className="min-w-0">
                            <p className={cn('truncate font-mono text-sm font-bold tabular-nums', m.hot ? 'text-pending' : 'text-foreground')}>
                              {m.value}
                            </p>
                            <p className="truncate text-[10px] text-muted-foreground">{m.label}</p>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          </section>
        ))
      )}
    </div>
  )
}
