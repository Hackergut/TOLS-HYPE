'use client'

// ─────────────────────────────────────────────────────────────────────────────
// OperatorGate — whole-app authentication for the Governance control tower.
//
// The Governance holds casino financial and player data, so the ENTIRE app is
// gated behind the operator session (signed httpOnly cookie via /api/gov/auth).
// No data is reachable before sign-in. The browser never holds a secret: it
// posts username/password once and the server sets the cookie.
// ─────────────────────────────────────────────────────────────────────────────

import { useEffect, useState } from 'react'
import { Loader2, Lock, ShieldCheck, User } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'

export interface Operator {
  username: string
}

async function jsonFetch<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    ...init,
    headers: { 'Content-Type': 'application/json', ...(init?.headers ?? {}) },
  })
  const body = await res.json().catch(() => ({}))
  if (!res.ok) throw new Error((body as { error?: string })?.error ?? `HTTP ${res.status}`)
  return body as T
}

/** Resolve the current operator, or null when logged out / not configured. */
export async function fetchOperator(): Promise<Operator | null> {
  try {
    const res = await jsonFetch<{ success: boolean; data: { authenticated: boolean; username: string | null } }>(
      '/api/gov/auth',
    )
    return res.data.authenticated && res.data.username ? { username: res.data.username } : null
  } catch {
    return null
  }
}

export async function signOutOperator(): Promise<void> {
  await fetch('/api/gov/auth', { method: 'DELETE' }).catch(() => {})
}

export function OperatorGate({ onAuthenticated }: { onAuthenticated: (op: Operator) => void }) {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    if (busy) return
    setBusy(true)
    setError('')
    try {
      const res = await jsonFetch<{ success: boolean; data: { username: string } }>('/api/gov/auth', {
        method: 'POST',
        body: JSON.stringify({ username, password }),
      })
      onAuthenticated({ username: res.data.username })
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Sign-in failed')
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-bg px-4">
      <div className="w-full max-w-sm">
        <div className="mb-6 text-center">
          <h1 className="font-wordmark text-4xl text-lime">TOLS</h1>
          <p className="mt-2 text-sm text-muted-foreground">Governance Control Tower</p>
        </div>

        <form onSubmit={submit} className="space-y-4 rounded-2xl border border-border bg-surface p-6 shadow-2xl">
          <div className="mb-2 flex items-center gap-2">
            <div className="flex size-8 items-center justify-center rounded-lg bg-lime/12">
              <Lock className="size-4 text-lime" />
            </div>
            <div>
              <h2 className="text-sm font-semibold">Operator sign-in</h2>
              <p className="text-[11px] text-muted-foreground">Restricted access</p>
            </div>
          </div>

          <div className="flex flex-col gap-2">
            <Label htmlFor="op-user" className="text-xs text-muted-foreground">Username</Label>
            <Input
              id="op-user"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              autoComplete="username"
              autoFocus
              placeholder="operator"
            />
          </div>
          <div className="flex flex-col gap-2">
            <Label htmlFor="op-pass" className="text-xs text-muted-foreground">Password</Label>
            <Input
              id="op-pass"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete="current-password"
              placeholder="••••••••"
            />
          </div>

          {error && (
            <p className="rounded-lg border border-loss/25 bg-loss/10 px-3 py-2 text-xs text-loss">{error}</p>
          )}

          <Button type="submit" disabled={busy} className="w-full bg-lime text-bg hover:bg-lime-400 active:scale-[0.97]">
            {busy && <Loader2 className="size-4 animate-spin" />}
            Sign in
          </Button>
        </form>

        <p className="mt-4 flex items-center justify-center gap-1.5 text-center text-[11px] text-muted-foreground/60">
          <ShieldCheck className="size-3.5 text-lime" />
          Signed sessions use an httpOnly cookie · HS256-signed server-side
        </p>
      </div>
    </div>
  )
}
