'use client'

import { useApi } from '@/hooks/use-api'
import { api } from '@/services/api'
import { LifeBuoy, UserX, Timer, ShieldCheck } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import { StatCard } from '@/components/stat-card'

interface Exclusion {
  id: string
  player: string
  type: string
  since: string
  until: string
  status: string
}

interface Limit {
  id: string
  player: string
  kind: string
  value: number
  status: string
}

interface ResponsibleData {
  stats: { selfExcluded: number; activeLimits: number; timeouts: number }
  exclusions: Exclusion[]
  limits: Limit[]
}

const LIMIT_UNITS: Record<string, string> = {
  daily_deposit: 'USDT/day',
  loss: 'USDT',
  session_time: 'min',
  wager: 'USDT',
}

export function ResponsibleView() {
  const { data, loading, error } = useApi<ResponsibleData>(() => api.responsibleGaming.get())

  if (loading) {
    return (
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
        {Array.from({ length: 3 }).map((_, i) => (
          <Card key={i}><CardContent className="p-6"><Skeleton className="h-14 w-full" /></CardContent></Card>
        ))}
      </div>
    )
  }

  if (error || !data) {
    return (
      <Card className="border-destructive/40">
        <CardContent className="p-6 text-center text-sm text-muted-foreground">Failed to load responsible-gaming data: {error}</CardContent>
      </Card>
    )
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
        <StatCard icon={UserX} label="Self-excluded" value={String(data.stats.selfExcluded)} tone="text-loss" />
        <StatCard icon={Timer} label="Timeouts" value={String(data.stats.timeouts)} tone="text-pending" />
        <StatCard icon={ShieldCheck} label="Active limits" value={String(data.stats.activeLimits)} tone="text-lime" />
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card className="border-border bg-surface">
          <CardHeader className="px-4 py-3">
            <CardTitle className="text-sm">Self-exclusions</CardTitle>
            <CardDescription className="text-xs">Players currently blocked from playing.</CardDescription>
          </CardHeader>
          <CardContent className="px-4 pb-4">
            <Table>
              <TableHeader>
                <TableRow className="hover:bg-transparent">
                  <TableHead className="text-[11px] text-muted-foreground">Player</TableHead>
                  <TableHead className="text-[11px] text-muted-foreground">Type</TableHead>
                  <TableHead className="text-[11px] text-muted-foreground">Until</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.exclusions.map((e) => (
                  <TableRow key={e.id} className="border-border">
                    <TableCell className="text-sm font-medium">{e.player}</TableCell>
                    <TableCell className="text-xs capitalize text-muted-foreground">{e.type.replace(/_/g, ' ')}</TableCell>
                    <TableCell className="text-xs tabular-nums text-muted-foreground">{e.until}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Card className="border-border bg-surface">
          <CardHeader className="px-4 py-3">
            <CardTitle className="text-sm">Active limits</CardTitle>
            <CardDescription className="text-xs">Deposit, loss, wager and session limits.</CardDescription>
          </CardHeader>
          <CardContent className="px-4 pb-4">
            <Table>
              <TableHeader>
                <TableRow className="hover:bg-transparent">
                  <TableHead className="text-[11px] text-muted-foreground">Player</TableHead>
                  <TableHead className="text-[11px] text-muted-foreground">Limit</TableHead>
                  <TableHead className="text-[11px] text-muted-foreground">Value</TableHead>
                  <TableHead className="text-[11px] text-muted-foreground">Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.limits.map((l) => (
                  <TableRow key={l.id} className="border-border">
                    <TableCell className="text-sm font-medium">{l.player}</TableCell>
                    <TableCell className="text-xs capitalize text-muted-foreground">{l.kind.replace(/_/g, ' ')}</TableCell>
                    <TableCell className="text-xs tabular-nums text-muted-foreground">
                      {l.value.toLocaleString()} {LIMIT_UNITS[l.kind] ?? ''}
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className={`border capitalize ${l.status === 'active' ? 'bg-lime/15 text-lime border-lime/30' : 'bg-secondary text-muted-foreground border-border'}`}>
                        {l.status}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
