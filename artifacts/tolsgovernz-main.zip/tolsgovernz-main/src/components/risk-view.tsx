'use client'

import { useCallback, useState } from 'react'
import { useApi } from '@/hooks/use-api'
import { api } from '@/services/api'
import { ShieldAlert, UserSearch, AlertTriangle, Flag } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import { StatCard } from '@/components/stat-card'

interface RiskFlag {
  id: string
  player: string
  type: string
  severity: 'low' | 'medium' | 'high'
  detail: string
  createdAt: string
  status: 'open' | 'reviewed'
}

interface RiskData {
  stats: { flaggedPlayers: number; suspiciousTx: number; open: number }
  flags: RiskFlag[]
}

const severityBadge: Record<RiskFlag['severity'], string> = {
  low: 'bg-lime/15 text-lime border-lime/30',
  medium: 'bg-pending/15 text-pending border-pending/30',
  high: 'bg-loss/15 text-loss border-loss/30',
}

export function RiskView() {
  const { data, loading, error, refetch } = useApi<RiskData>(() => api.risk.get())
  const [busyId, setBusyId] = useState<string | null>(null)

  const handleReview = useCallback(async (id: string) => {
    setBusyId(id)
    try {
      await api.risk.review(id)
      await refetch()
    } catch {
      // DB may be offline in dev/sandbox — keep the UI responsive.
    } finally {
      setBusyId(null)
    }
  }, [refetch])

  if (loading) {
    return (
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
        {Array.from({ length: 3 }).map((_, i) => (
          <Card key={i}><CardContent className="p-6"><Skeleton className="h-14 w-full" /></CardContent></Card>
        ))}
      </div>
    )
  }

  if (error || !data) {
    return (
      <Card className="border-destructive/40">
        <CardContent className="p-6 text-center text-sm text-muted-foreground">Failed to load risk data: {error}</CardContent>
      </Card>
    )
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
        <StatCard icon={UserSearch} label="Flagged players" value={String(data.stats.flaggedPlayers)} tone="text-pending" />
        <StatCard icon={ShieldAlert} label="Suspicious tx" value={String(data.stats.suspiciousTx)} tone="text-loss" />
        <StatCard icon={Flag} label="Open cases" value={String(data.stats.open)} tone={data.stats.open > 0 ? 'text-loss' : 'text-lime'} />
      </div>

      <Card className="border-border bg-surface">
        <CardHeader className="px-4 py-3">
          <CardTitle className="text-sm">AML &amp; fraud flags</CardTitle>
          <CardDescription className="text-xs">Review suspicious activity and escalate to compliance.</CardDescription>
        </CardHeader>
        <CardContent className="px-4 pb-4">
          <div className="overflow-x-auto rounded-lg border border-border">
            <Table>
              <TableHeader>
                <TableRow className="hover:bg-transparent">
                  <TableHead className="text-[11px] text-muted-foreground">Player</TableHead>
                  <TableHead className="text-[11px] text-muted-foreground">Type</TableHead>
                  <TableHead className="text-[11px] text-muted-foreground">Severity</TableHead>
                  <TableHead className="text-[11px] text-muted-foreground">Detail</TableHead>
                  <TableHead className="text-[11px] text-muted-foreground">Status</TableHead>
                  <TableHead className="text-right text-[11px] text-muted-foreground">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.flags.map((f) => (
                  <TableRow key={f.id} className="border-border">
                    <TableCell className="text-sm font-medium">{f.player}</TableCell>
                    <TableCell className="text-xs capitalize text-muted-foreground">{f.type.replace(/_/g, ' ')}</TableCell>
                    <TableCell><Badge variant="outline" className={`border uppercase ${severityBadge[f.severity]}`}>{f.severity}</Badge></TableCell>
                    <TableCell className="max-w-[320px] text-xs text-muted-foreground">{f.detail}</TableCell>
                    <TableCell><Badge variant="outline" className={`border capitalize ${f.status === 'open' ? 'bg-pending/15 text-pending border-pending/30' : 'bg-secondary text-muted-foreground border-border'}`}>{f.status}</Badge></TableCell>
                    <TableCell className="text-right">
                      {f.status === 'open' ? (
                        <Button size="sm" variant="outline" className="h-7 text-xs" disabled={busyId === f.id} onClick={() => handleReview(f.id)}>Review</Button>
                      ) : (
                        <span className="text-xs text-muted-foreground">—</span>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
