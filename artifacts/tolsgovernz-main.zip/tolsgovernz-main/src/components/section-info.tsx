'use client'

// ─────────────────────────────────────────────────────────────────────────────
// SectionInfo — the uniform "About & connections" panel shown at the top of
// every section. Explains what the section is for (how to operate it) and which
// data sources / APIs feed it. Collapsed by default so it never gets in the
// way, one click to expand.
// ─────────────────────────────────────────────────────────────────────────────

import { useState } from 'react'
import { Info, ChevronDown, PlugZap, Database } from 'lucide-react'
import type { SectionDef } from '@/lib/sections'
import { cn } from '@/lib/utils'

export function SectionInfo({ def }: { def: SectionDef }) {
  const [open, setOpen] = useState(false)

  return (
    <div className="rounded-xl border border-border bg-surface/60">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-expanded={open}
        className="flex w-full items-center gap-2.5 px-4 py-2.5 text-left transition-colors hover:bg-secondary/30"
      >
        <Info className="size-4 shrink-0 text-lime" />
        <span className="flex-1 text-xs font-semibold text-foreground">
          About this section &amp; connections
        </span>
        <ChevronDown className={cn('size-4 text-muted-foreground transition-transform duration-200', open && 'rotate-180')} />
      </button>

      {open && (
        <div className="grid gap-4 border-t border-border px-4 py-3 sm:grid-cols-2">
          {/* What it does / how to use it */}
          <div className="flex items-start gap-2.5">
            <Info className="mt-0.5 size-4 shrink-0 text-muted-foreground" />
            <div className="min-w-0">
              <p className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">Use</p>
              <p className="mt-1 text-xs leading-relaxed text-foreground/80">{def.use}</p>
            </div>
          </div>

          {/* Connections */}
          <div className="flex items-start gap-2.5">
            <PlugZap className="mt-0.5 size-4 shrink-0 text-muted-foreground" />
            <div className="min-w-0 flex-1">
              <p className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">Connections</p>
              <ul className="mt-1 space-y-1">
                {def.connections.map((c) => (
                  <li key={c} className="flex items-start gap-1.5 text-xs">
                    <Database className="mt-0.5 size-3 shrink-0 text-lime/70" />
                    <span className="font-mono text-[11px] leading-relaxed text-foreground/70 break-all">{c}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
