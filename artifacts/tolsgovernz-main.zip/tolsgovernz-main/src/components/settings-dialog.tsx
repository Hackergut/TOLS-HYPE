'use client'

// ─────────────────────────────────────────────────────────────────────────────
// SettingsDialog — operator preferences. Every control is bound to the
// persisted settings store (localStorage), and every change is applied
// immediately: theme toggles the dark class, compact mode changes density,
// currency drives the formatters, etc. No "fake save" — there is a reset and a
// status line, but the values are live the moment they change.
// ─────────────────────────────────────────────────────────────────────────────

import {
  Settings, Palette, Globe2, Bell, Shield, Monitor, Clock, Database,
  RotateCcw,
} from 'lucide-react'
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Switch } from '@/components/ui/switch'
import { Label } from '@/components/ui/label'
import { Input } from '@/components/ui/input'
import { Separator } from '@/components/ui/separator'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'
import { ScrollArea } from '@/components/ui/scroll-area'
import { useAppStore } from '@/lib/store'
import { useSettingsStore } from '@/lib/settings-store'
import { toast } from 'sonner'

interface SettingsDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

function SettingRow({ title, hint, children }: { title: string; hint: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-3 rounded-lg bg-muted/40 p-3">
      <div className="space-y-0.5">
        <Label className="text-xs font-medium">{title}</Label>
        <p className="text-[10px] text-muted-foreground">{hint}</p>
      </div>
      {children}
    </div>
  )
}

export function SettingsDialog({ open, onOpenChange }: SettingsDialogProps) {
  const { activeRole, setActiveRole } = useAppStore()
  const s = useSettingsStore()

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] p-0">
        <DialogHeader className="px-6 pt-6 pb-2">
          <DialogTitle className="flex items-center gap-2">
            <Settings className="size-5 text-primary" />
            Platform Settings
          </DialogTitle>
          <DialogDescription>
            Preferences are saved to this device and applied immediately.
          </DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="general" className="w-full">
          <div className="px-6 border-b border-border">
            <TabsList className="grid grid-cols-4 w-full h-9">
              <TabsTrigger value="general" className="text-xs gap-1"><Palette className="size-3.5" /><span className="hidden sm:inline">General</span></TabsTrigger>
              <TabsTrigger value="platform" className="text-xs gap-1"><Monitor className="size-3.5" /><span className="hidden sm:inline">Platform</span></TabsTrigger>
              <TabsTrigger value="notifications" className="text-xs gap-1"><Bell className="size-3.5" /><span className="hidden sm:inline">Alerts</span></TabsTrigger>
              <TabsTrigger value="security" className="text-xs gap-1"><Shield className="size-3.5" /><span className="hidden sm:inline">Security</span></TabsTrigger>
            </TabsList>
          </div>

          <ScrollArea className="h-[55vh]">
            {/* ─── General ─── */}
            <TabsContent value="general" className="px-6 py-4 space-y-5">
              <div className="space-y-3">
                <div className="flex items-center gap-2"><Palette className="size-4 text-muted-foreground" /><h4 className="text-sm font-semibold">Appearance</h4></div>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { value: 'dark', label: 'Dark', hint: 'Casino brand look' },
                    { value: 'light', label: 'Light', hint: 'Bright operator view' },
                  ].map((opt) => (
                    <button
                      key={opt.value}
                      onClick={() => s.set('theme', opt.value as 'dark' | 'light')}
                      className={`rounded-lg border p-3 text-left transition-colors ${
                        s.theme === opt.value ? 'border-primary bg-primary/10 text-primary' : 'border-border hover:border-muted-foreground/40'
                      }`}
                    >
                      <span className="text-xs font-semibold">{opt.label}</span>
                      <span className="block text-[10px] text-muted-foreground">{opt.hint}</span>
                    </button>
                  ))}
                </div>
              </div>

              <Separator />

              <div className="space-y-3">
                <div className="flex items-center gap-2"><Globe2 className="size-4 text-muted-foreground" /><h4 className="text-sm font-semibold">Language &amp; Region</h4></div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <Label className="text-xs">Language</Label>
                    <Select value={s.language} onValueChange={(v) => s.set('language', v)}>
                      <SelectTrigger className="h-9 text-xs"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="en">English</SelectItem>
                        <SelectItem value="it">Italiano</SelectItem>
                        <SelectItem value="de">Deutsch</SelectItem>
                        <SelectItem value="fr">Français</SelectItem>
                        <SelectItem value="es">Español</SelectItem>
                        <SelectItem value="pt">Português</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs">Timezone</Label>
                    <Select value={s.timezone} onValueChange={(v) => s.set('timezone', v)}>
                      <SelectTrigger className="h-9 text-xs"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="UTC">UTC</SelectItem>
                        <SelectItem value="Europe/Rome">Europe/Rome</SelectItem>
                        <SelectItem value="Europe/Berlin">Europe/Berlin</SelectItem>
                        <SelectItem value="Europe/London">Europe/London</SelectItem>
                        <SelectItem value="America/New_York">America/New_York</SelectItem>
                        <SelectItem value="Asia/Dubai">Asia/Dubai</SelectItem>
                        <SelectItem value="Asia/Tokyo">Asia/Tokyo</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs">Date Format</Label>
                    <Select value={s.dateFormat} onValueChange={(v) => s.set('dateFormat', v)}>
                      <SelectTrigger className="h-9 text-xs"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="YYYY-MM-DD">YYYY-MM-DD</SelectItem>
                        <SelectItem value="DD/MM/YYYY">DD/MM/YYYY</SelectItem>
                        <SelectItem value="MM/DD/YYYY">MM/DD/YYYY</SelectItem>
                        <SelectItem value="DD.MM.YYYY">DD.MM.YYYY</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs">Default Currency</Label>
                    <Select value={s.currency} onValueChange={(v) => s.set('currency', v as typeof s.currency)}>
                      <SelectTrigger className="h-9 text-xs"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="USD">USD ($)</SelectItem>
                        <SelectItem value="EUR">EUR (€)</SelectItem>
                        <SelectItem value="GBP">GBP (£)</SelectItem>
                        <SelectItem value="BTC">BTC (₿)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-3">
                <div className="flex items-center gap-2"><Shield className="size-4 text-muted-foreground" /><h4 className="text-sm font-semibold">Active Role</h4></div>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { value: 'finance', label: 'Finance', color: 'text-primary' },
                    { value: 'controller', label: 'Controller', color: 'text-lime-300' },
                    { value: 'super_admin', label: 'Super Admin', color: 'text-amber-400' },
                  ].map((role) => (
                    <button
                      key={role.value}
                      onClick={() => setActiveRole(role.value as typeof activeRole)}
                      className={`flex flex-col items-center gap-1 rounded-lg border p-2.5 text-xs transition-colors ${
                        activeRole === role.value ? 'border-primary bg-primary/5' : 'border-border hover:border-muted-foreground/30'
                      }`}
                    >
                      <span className={`font-semibold ${role.color}`}>{role.label}</span>
                    </button>
                  ))}
                </div>
              </div>
            </TabsContent>

            {/* ─── Platform ─── */}
            <TabsContent value="platform" className="px-6 py-4 space-y-5">
              <div className="space-y-3">
                <div className="flex items-center gap-2"><Monitor className="size-4 text-muted-foreground" /><h4 className="text-sm font-semibold">Display &amp; Data</h4></div>
                <SettingRow title="Compact Mode" hint="Reduce spacing across the console">
                  <Switch checked={s.compact} onCheckedChange={(v) => s.set('compact', v)} />
                </SettingRow>
                <SettingRow title="Show Decimals" hint="Full decimal precision in amounts">
                  <Switch checked={s.showDecimals} onCheckedChange={(v) => s.set('showDecimals', v)} />
                </SettingRow>
                <SettingRow title="Auto-refresh" hint="Re-poll live data automatically">
                  <Switch checked={s.autoRefresh} onCheckedChange={(v) => s.set('autoRefresh', v)} />
                </SettingRow>
                <div className="space-y-1.5">
                  <Label className="text-xs">Refresh interval (seconds)</Label>
                  <Input
                    type="number" min={5} max={300}
                    value={s.refreshInterval}
                    onChange={(e) => s.set('refreshInterval', Math.max(5, Number(e.target.value) || 15))}
                    className="h-9 text-xs w-full sm:w-[160px]"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs">Rows per page (tables)</Label>
                  <Select value={String(s.rowsPerPage)} onValueChange={(v) => s.set('rowsPerPage', Number(v))}>
                    <SelectTrigger className="h-9 text-xs w-full sm:w-[160px]"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="10">10 rows</SelectItem>
                      <SelectItem value="25">25 rows</SelectItem>
                      <SelectItem value="50">50 rows</SelectItem>
                      <SelectItem value="100">100 rows</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </TabsContent>

            {/* ─── Notifications ─── */}
            <TabsContent value="notifications" className="px-6 py-4 space-y-5">
              <div className="space-y-3">
                <div className="flex items-center gap-2"><Bell className="size-4 text-muted-foreground" /><h4 className="text-sm font-semibold">Notification Channels</h4></div>
                <SettingRow title="Email Notifications" hint="Receive alerts via email">
                  <Switch checked={s.emailNotifs} onCheckedChange={(v) => s.set('emailNotifs', v)} />
                </SettingRow>
                <SettingRow title="Push Notifications" hint="Browser push notifications">
                  <Switch checked={s.pushNotifs} onCheckedChange={(v) => s.set('pushNotifs', v)} />
                </SettingRow>
                <SettingRow title="Sound Alerts" hint="Play sound on critical events">
                  <Switch checked={s.soundNotifs} onCheckedChange={(v) => s.set('soundNotifs', v)} />
                </SettingRow>
              </div>
              <Separator />
              <div className="space-y-3">
                <div className="flex items-center gap-2"><Shield className="size-4 text-muted-foreground" /><h4 className="text-sm font-semibold">Alert Filtering</h4></div>
                <SettingRow title="Critical Only" hint="Only critical/urgent alerts">
                  <Switch checked={s.criticalOnly} onCheckedChange={(v) => s.set('criticalOnly', v)} />
                </SettingRow>
                <SettingRow title="Variance Alerts" hint="Alert on RTP/variance anomalies">
                  <Switch checked={s.varianceAlerts} onCheckedChange={(v) => s.set('varianceAlerts', v)} />
                </SettingRow>
              </div>
            </TabsContent>

            {/* ─── Security ─── */}
            <TabsContent value="security" className="px-6 py-4 space-y-5">
              <div className="space-y-3">
                <div className="flex items-center gap-2"><Clock className="size-4 text-muted-foreground" /><h4 className="text-sm font-semibold">Session</h4></div>
                <div className="space-y-1.5">
                  <Label className="text-xs">Session Timeout (minutes)</Label>
                  <Select value={String(s.sessionTimeout)} onValueChange={(v) => s.set('sessionTimeout', Number(v))}>
                    <SelectTrigger className="h-9 text-xs w-full sm:w-[160px]"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="15">15 minutes</SelectItem>
                      <SelectItem value="30">30 minutes</SelectItem>
                      <SelectItem value="60">1 hour</SelectItem>
                      <SelectItem value="120">2 hours</SelectItem>
                      <SelectItem value="480">8 hours</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <Separator />
              <div className="space-y-3">
                <div className="flex items-center gap-2"><Database className="size-4 text-muted-foreground" /><h4 className="text-sm font-semibold">Audit</h4></div>
                <SettingRow title="Audit Logging" hint="Log all operator actions for compliance">
                  <Switch checked={s.auditLog} onCheckedChange={(v) => s.set('auditLog', v)} />
                </SettingRow>
              </div>
            </TabsContent>
          </ScrollArea>
        </Tabs>

        <DialogFooter className="px-6 pb-6 pt-2">
          <div className="flex w-full items-center gap-2">
            <span className="text-[11px] text-muted-foreground">Saved to this device automatically</span>
            <div className="flex-1" />
            <Button
              variant="outline"
              size="sm"
              className="h-8 text-xs gap-1.5"
              onClick={() => { s.reset(); toast.success('Settings reset to defaults') }}
            >
              <RotateCcw className="size-3.5" /> Reset
            </Button>
            <Button size="sm" className="h-8 text-xs" onClick={() => { toast.success('Settings saved'); onOpenChange(false) }}>
              Done
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
