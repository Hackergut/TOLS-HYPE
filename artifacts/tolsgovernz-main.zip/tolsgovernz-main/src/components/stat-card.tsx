'use client'

// Shared KPI card for section views — keeps every section visually consistent.
import type { LucideIcon } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { cn } from '@/lib/utils'

export function StatCard({ icon: Icon, label, value, sub, tone = 'text-foreground' }: {
  icon: LucideIcon
  label: string
  value: string
  sub?: string
  tone?: string
}) {
  return (
    <Card className="border-border bg-surface">
      <CardContent className="p-3.5">
        <div className="flex items-center gap-2 text-muted-foreground">
          <Icon className="size-4 shrink-0" />
          <span className="truncate text-[11px] uppercase tracking-wide">{label}</span>
        </div>
        <p className={cn('mt-1.5 font-mono text-xl font-bold tabular-nums', tone)}>{value}</p>
        {sub && <p className="text-[10px] text-muted-foreground">{sub}</p>}
      </CardContent>
    </Card>
  )
}
