'use client'

// ─────────────────────────────────────────────────────────────────────────────
// ThemeApplier — applies the operator's persisted preferences to the document.
//
//  • theme      → toggles the `dark` class on <html> (light theme = no class)
//  • compact    → adds `compact-ui` on <html> so dense spacing is applied
// This is the single place where settings touch the DOM.
// ─────────────────────────────────────────────────────────────────────────────

import { useEffect } from 'react'
import { useSettingsStore } from '@/lib/settings-store'

export function ThemeApplier() {
  const theme = useSettingsStore((s) => s.theme)
  const compact = useSettingsStore((s) => s.compact)

  useEffect(() => {
    const root = document.documentElement
    root.classList.toggle('dark', theme === 'dark')
    root.classList.toggle('compact-ui', compact)
    root.style.colorScheme = theme
  }, [theme, compact])

  return null
}
