"use client";

// ─────────────────────────────────────────────────────────────────────────────
// WorldMap — a REAL interactive map (Leaflet + CARTO dark tiles) plotting the
// platform's live sessions, server nodes and recent events at their real
// latitude/longitude. Loaded client-side only (dynamic import, ssr:false)
// because Leaflet touches `window`.
//
// Tiles: configurable via NEXT_PUBLIC_MAP_TILE_URL. Defaults to CARTO dark
// matter (free, matches the TOLS theme). For production volume, point it at a
// paid tile provider (MapTiler/Mapbox) or a self-hosted tile server.
// ─────────────────────────────────────────────────────────────────────────────

import { MapContainer, TileLayer, Marker, CircleMarker, Popup, Tooltip } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { sessionColor, sessionLabel, serverColor } from "@/lib/map-colors";
import type { ActiveSession, ServerNode, LiveEvent } from "@/types/live-map";

const TILE_URL =
  process.env.NEXT_PUBLIC_MAP_TILE_URL ??
  "https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png";
const ATTRIBUTION =
  '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> &copy; <a href="https://carto.com/attributions">CARTO</a>';

// Server nodes render as rotated diamonds (divIcon) — avoids Leaflet's default
// marker PNGs, which break under bundlers and clash with the dark theme.
function nodeIcon(status: string): L.DivIcon {
  const c = serverColor(status);
  return L.divIcon({
    className: "tols-node-icon",
    html: `<div style="--node-c:${c}"></div>`,
    iconSize: [16, 16],
    iconAnchor: [8, 8],
  });
}

function sessionRadius(s: ActiveSession): number {
  if (s.wagerAmount > 5000) return 7;
  if (s.winAmount > s.wagerAmount * 2) return 6;
  return 4;
}

export function WorldMap({
  sessions,
  nodes,
  events,
  children,
}: {
  sessions: ActiveSession[];
  nodes: ServerNode[];
  events: LiveEvent[];
  children?: React.ReactNode;
}) {
  const now = Date.now();
  const recentEvents = events.filter((e) => now - new Date(e.createdAt).getTime() < 60_000);

  return (
    <div className="absolute inset-0 z-0 overflow-hidden rounded-xl">
      <MapContainer
        center={[24, 10]}
        zoom={2}
        minZoom={2}
        maxZoom={10}
        scrollWheelZoom={false}
        worldCopyJump
        className="h-full w-full"
        style={{ background: "#0a0e1a" }}
      >
        <TileLayer url={TILE_URL} attribution={ATTRIBUTION} />

        {/* Server nodes */}
        {nodes.map((node) => (
          <Marker
            key={`node-${node.id}`}
            position={[node.latitude, node.longitude]}
            icon={nodeIcon(node.status)}
          >
            <Tooltip direction="top" offset={[0, -12]} opacity={1}>
              <span className="font-semibold">{node.name}</span>
            </Tooltip>
            <Popup>
              <div className="min-w-[180px] space-y-1 text-xs">
                <p className="font-bold">{node.name}</p>
                <p>
                  {node.region} · {node.activePlayers}/{node.maxPlayers} players
                </p>
                <p>
                  CPU {node.cpuLoad}% · MEM {node.memoryLoad}% · {node.latencyMs}ms
                </p>
                <p className="uppercase" style={{ color: serverColor(node.status) }}>
                  {node.status}
                </p>
              </div>
            </Popup>
          </Marker>
        ))}

        {/* Active player sessions */}
        {sessions.map((s) => {
          const c = sessionColor(s, now);
          return (
            <CircleMarker
              key={`session-${s.id}`}
              center={[s.latitude, s.longitude]}
              radius={sessionRadius(s)}
              pathOptions={{ color: c, fillColor: c, fillOpacity: 0.9, weight: 1.5 }}
            >
              <Tooltip direction="top" offset={[0, -8]} opacity={1}>
                <span>
                  {s.playerName} · {s.city}
                </span>
              </Tooltip>
              <Popup>
                <div className="min-w-[180px] space-y-1 text-xs">
                  <p className="font-bold">{s.playerName}</p>
                  <p>
                    {s.gameName} · {s.city}, {s.country}
                  </p>
                  <p>
                    Wager ${s.wagerAmount.toLocaleString()} · Win $
                    {s.winAmount.toLocaleString()}
                  </p>
                  <p className="uppercase" style={{ color: c }}>
                    {sessionLabel(s, now)}
                  </p>
                </div>
              </Popup>
            </CircleMarker>
          );
        })}

        {/* Recent event bursts (last 60s) */}
        {recentEvents.map((e) => {
          const c =
            e.eventType === "jackpot_hit" ? "#d4a017" : e.eventType === "big_win" ? "#10b981" : "#3b82f6";
          return (
            <CircleMarker
              key={`event-${e.id}`}
              center={[e.latitude, e.longitude]}
              radius={3}
              pathOptions={{ color: c, fillColor: c, fillOpacity: 0.6, weight: 1 }}
            >
              <Popup>
                <div className="min-w-[160px] space-y-1 text-xs">
                  <p className="font-bold">{e.playerName}</p>
                  <p>
                    {e.eventType.replace(/_/g, " ")} · {e.gameName}
                  </p>
                  {e.amount > 0 && <p className="text-lime">${e.amount.toLocaleString()}</p>}
                </div>
              </Popup>
            </CircleMarker>
          );
        })}
      </MapContainer>

      {/* Legend / stats overlays rendered by the caller on top of the map. */}
      {children}
    </div>
  );
}
