'use client'

// ─────────────────────────────────────────────────────────────────────────────
// use-casino — data hook for LIVE Casino data via the Governance controller
// proxy (/api/casino/*). The browser only ever talks same-origin with the
// operator cookie; the server mints the RS256 JWT and forwards to
// https://www.tols.fun/api/platform/*. No mock fallbacks: errors surface as
// errors, an empty list renders as an empty list.
// ─────────────────────────────────────────────────────────────────────────────

import { useCallback, useEffect, useRef, useState } from 'react'

export interface CasinoEnvelope<T> {
  success: boolean
  data: T
  error?: string
  pagination?: { total: number; limit: number; offset: number; hasMore: boolean }
  pending?: { count: number; amount: number }
}

export class CasinoApiError extends Error {
  constructor(message: string, readonly status: number) {
    super(message)
    this.name = 'CasinoApiError'
  }
}

/** JSON fetch against the same-origin controller routes. Throws on !success. */
export async function casinoFetch<T>(path: string, init?: RequestInit): Promise<CasinoEnvelope<T>> {
  const res = await fetch(path, {
    ...init,
    headers: { 'Content-Type': 'application/json', ...(init?.headers ?? {}) },
    cache: 'no-store',
  })
  const body = (await res.json().catch(() => null)) as CasinoEnvelope<T> | null
  if (!res.ok || !body || body.success === false) {
    throw new CasinoApiError(body?.error ?? `HTTP ${res.status}`, res.status)
  }
  return body
}

/** Send a fire-and-forget HMAC command through the bridge webhook. */
export async function casinoCommand(type: string, payload: Record<string, unknown>): Promise<unknown> {
  const res = await fetch('/api/casino/command', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ type, payload }),
  })
  const body = await res.json().catch(() => null)
  if (!res.ok || (body as { success?: boolean })?.success === false) {
    throw new CasinoApiError((body as { error?: string })?.error ?? `HTTP ${res.status}`, res.status)
  }
  return body
}

interface UseCasinoState<T> {
  data: T | null
  envelope: CasinoEnvelope<T> | null
  loading: boolean
  error: string | null
  refetch: () => void
}

/**
 * Fetch a /api/casino/* endpoint. `path` is reactive — changing it refetches.
 * Pass `pollMs` to keep the screen fresh from live Casino data.
 */
export function useCasino<T>(path: string | null, pollMs?: number): UseCasinoState<T> {
  const [data, setData] = useState<T | null>(null)
  const [envelope, setEnvelope] = useState<CasinoEnvelope<T> | null>(null)
  const [loading, setLoading] = useState(Boolean(path))
  const [error, setError] = useState<string | null>(null)
  const seq = useRef(0)

  const load = useCallback(async (silent = false) => {
    if (!path) return
    const id = ++seq.current
    if (!silent) {
      // Deferred so the state updates never run synchronously inside an effect.
      await Promise.resolve()
      if (seq.current !== id) return
      setLoading(true)
      setError(null)
    }
    try {
      const body = await casinoFetch<T>(path)
      if (seq.current !== id) return
      setData(body.data)
      setEnvelope(body)
      setError(null)
    } catch (e) {
      if (seq.current !== id) return
      setError(e instanceof Error ? e.message : 'Request failed')
    } finally {
      if (seq.current === id) setLoading(false)
    }
  }, [path])

  useEffect(() => {
    // All state updates inside `load` happen after an await (async boundary),
    // so nothing sets state synchronously during the effect body.
    // eslint-disable-next-line react-hooks/set-state-in-effect
    void load()
  }, [load])

  useEffect(() => {
    if (!pollMs || !path) return
    const t = setInterval(() => load(true), pollMs)
    return () => clearInterval(t)
  }, [pollMs, path, load])

  return { data, envelope, loading, error, refetch: () => load() }
}

export function formatUsd(n: number | null | undefined, digits = 2): string {
  const v = typeof n === 'number' && Number.isFinite(n) ? n : 0
  return v.toLocaleString('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: digits,
    maximumFractionDigits: digits,
  })
}

export function formatWhen(iso: string | null | undefined): string {
  if (!iso) return '—'
  const d = new Date(iso)
  if (Number.isNaN(d.getTime())) return '—'
  return d.toLocaleString('en-US', {
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  })
}
