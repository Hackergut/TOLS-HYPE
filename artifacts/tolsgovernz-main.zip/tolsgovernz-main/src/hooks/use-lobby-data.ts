'use client'

// ─────────────────────────────────────────────────────────────────────────────
// useLobbyData — live values for the Governance overview.
//
// Fetches the lightweight, always-available endpoints in parallel and reduces
// them to the headline numbers each section card shows. Any endpoint that
// fails (e.g. a DB-backed route while the database is offline) simply leaves
// its key undefined, and the lobby falls back to its static default. Exposes
// `refresh` for the manual refresh button and re-polls every 30s.
// ─────────────────────────────────────────────────────────────────────────────

import { useCallback, useEffect, useState } from 'react'

export interface LobbyValues {
  playersOnline?: number
  activeSessions?: number
  wallets?: number
  totalBalance?: number
  unread?: number
  apiTokens?: number
  vendors?: number
  activeVendors?: number
  blockchainWallets?: number
  models?: number
  users?: number
  pendingWithdrawals?: number
  depositsToday?: number
}

const EMPTY: LobbyValues = {}

async function j<T>(url: string): Promise<T | null> {
  try {
    const r = await fetch(url)
    if (!r.ok) return null
    return (await r.json()) as T
  } catch {
    return null
  }
}

export function useLobbyData() {
  const [values, setValues] = useState<LobbyValues>(EMPTY)
  const [tick, setTick] = useState(0)

  const refresh = useCallback(() => setTick((t) => t + 1), [])

  useEffect(() => {
    let alive = true
    ;(async () => {
      const [
        liveMap, livePlayers, wallets, notifications, apiHub, vendors,
        blockchain, ml, auth, payments,
      ] = await Promise.all([
        j<{ stats?: { totalOnline?: number } }>('/api/live-map'),
        j<{ activeSessions?: unknown[] }>('/api/live-players'),
        j<{ wallets?: Array<{ availableBalance?: number; balance?: number }> }>('/api/wallets'),
        j<{ notifications?: Array<{ isRead?: boolean }> }>('/api/notifications'),
        j<{ tokens?: unknown[] }>('/api/api-hub'),
        j<{ platforms?: Array<{ status?: string }> }>('/api/vendors'),
        j<{ wallets?: unknown[] }>('/api/blockchain'),
        j<{ models?: unknown[] }>('/api/ml-pipeline'),
        j<{ users?: unknown[] }>('/api/auth'),
        j<{ deposits?: unknown[]; stats?: { pendingWithdrawals?: number } }>('/api/payments'),
      ])

      if (!alive) return

      const next: LobbyValues = {}
      if (liveMap?.stats?.totalOnline != null) next.playersOnline = liveMap.stats.totalOnline
      if (livePlayers?.activeSessions) next.activeSessions = livePlayers.activeSessions.length
      if (wallets?.wallets) {
        next.wallets = wallets.wallets.length
        next.totalBalance = wallets.wallets.reduce((s, w) => s + (w.availableBalance ?? w.balance ?? 0), 0)
      }
      if (notifications?.notifications) next.unread = notifications.notifications.filter((n) => !n.isRead).length
      if (apiHub?.tokens) next.apiTokens = apiHub.tokens.length
      if (vendors?.platforms) {
        next.vendors = vendors.platforms.length
        next.activeVendors = vendors.platforms.filter((p) => p.status === 'active').length
      }
      if (blockchain?.wallets) next.blockchainWallets = blockchain.wallets.length
      if (ml?.models) next.models = ml.models.length
      if (auth?.users) next.users = auth.users.length
      if (payments?.deposits) next.depositsToday = payments.deposits.length
      if (payments?.stats?.pendingWithdrawals != null) next.pendingWithdrawals = payments.stats.pendingWithdrawals

      setValues(next)
    })()
    return () => {
      alive = false
    }
  }, [tick])

  // Light periodic re-poll (30s) so the overview stays fresh while open.
  useEffect(() => {
    const id = setInterval(refresh, 30_000)
    return () => clearInterval(id)
  }, [refresh])

  return { values, refresh }
}
