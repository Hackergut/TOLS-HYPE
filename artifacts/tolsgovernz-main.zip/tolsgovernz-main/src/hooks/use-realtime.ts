'use client'

// ─────────────────────────────────────────────────────────────────────────────
// useRealtime — subscribe to the SSE live feed at /api/realtime/stream.
//
// Server-Sent Events over a plain GET: no websocket server required, works
// behind the Arena preview proxy and on any Node host. Reconnects
// automatically (EventSource built-in). Consumers get the rolling event list
// plus aggregate stats; `connected` reflects the live transport state.
// ─────────────────────────────────────────────────────────────────────────────

import { useEffect, useRef, useState } from 'react'

export interface LiveEvent {
  id: string
  eventType: 'deposit' | 'win' | 'session' | 'registration'
  playerName: string
  gameName?: string
  amount?: number
  currency?: string
  country: string
  createdAt: string
}

export interface LiveStats {
  totalOnline: number
  byRegion: Record<string, number>
  byGame: Record<string, number>
  byDevice: Record<string, number>
}

export function useRealtime() {
  const [connected, setConnected] = useState(false)
  const [events, setEvents] = useState<LiveEvent[]>([])
  const [stats, setStats] = useState<LiveStats | null>(null)
  const [jackpot, setJackpot] = useState<number | null>(null)
  const esRef = useRef<EventSource | null>(null)

  useEffect(() => {
    if (typeof window === 'undefined' || typeof EventSource === 'undefined') return

    const es = new EventSource('/api/realtime/stream')
    esRef.current = es

    es.onopen = () => setConnected(true)
    es.onerror = () => setConnected(false)

    es.addEventListener('live-event', (e) => {
      try {
        const ev = JSON.parse((e as MessageEvent).data) as LiveEvent
        setEvents((prev) => [ev, ...prev].slice(0, 40))
      } catch {
        /* ignore malformed frame */
      }
    })

    es.addEventListener('stats', (e) => {
      try {
        setStats(JSON.parse((e as MessageEvent).data) as LiveStats)
      } catch {
        /* ignore */
      }
    })

    es.addEventListener('jackpot', (e) => {
      try {
        const j = JSON.parse((e as MessageEvent).data) as { currentAmount?: number }
        if (typeof j.currentAmount === 'number') setJackpot(j.currentAmount)
      } catch {
        /* ignore */
      }
    })

    return () => {
      es.close()
      esRef.current = null
    }
  }, [])

  return { connected, events, stats, jackpot }
}
