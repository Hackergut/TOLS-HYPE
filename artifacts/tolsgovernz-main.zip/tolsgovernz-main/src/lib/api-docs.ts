// ─────────────────────────────────────────────────────────────────────────────
// api-docs.ts — single source of truth for the public API documentation.
//
// Rendered by /docs (a public route, outside the operator gate). The prose is
// CommonMark; code blocks use `~~~` fences so the content can live in a JS
// template literal without escaping backticks. Keep this in sync with
// src/lib/platform/contract.ts and docs/PLATFORM_INTEGRATION.md.
// ─────────────────────────────────────────────────────────────────────────────

export interface DocSection {
  id: string
  title: string
  body: string
}

export const DOCS_SECTIONS: DocSection[] = [
  {
    id: 'overview',
    title: 'Architettura',
    body: `
**TOLS Governance** è la torre di controllo operativa della piattaforma casino.
È un'app **separata** dal casino player-facing (\`tols-casino-next\`) e si collega
ad esso **solo** tramite un bridge API firmato con JWT **RS256**.

Non c'è database condiviso, né sessione condivisa, né cookie cross-origin: ogni
lato firma le richieste in uscita con la **propria** chiave privata e verifica
le richieste in ingresso con la chiave **pubblica del partner**.

~~~text
[Browser operatore] ──HTTPS + cookie──▶  TOLS GOVERNANCE  (Next.js 16)
                                              │  RS256 JWT
                                              ▼
                                         TOLS CASINO  (Next.js 16)
~~~

Nota importante: un documento di piano precedente descriveva uno stack
**Vite + Refine + Supabase + Edge Functions + Netlify**. L'implementazione
reale usa **Next.js 16 (App Router) + Prisma (SQLite) + route handlers + Docker
(Hetzner/Dokploy)**. Vedi la sezione \`stack\` per il confronto completo.
`,
  },
  {
    id: 'stack',
    title: 'Stack reale vs piano precedente',
    body: `
**Confronto stack** (piano precedente → implementazione reale):

- **Frontend**: Vite + React + Refine → **Next.js 16 (App Router) + React 19**
- **UI**: shadcn/ui + Tailwind → **shadcn/ui + Tailwind** (invariata)
- **Backend**: Supabase + Edge Functions → **route handler Next.js + Prisma**
- **Database**: PostgreSQL (Supabase) → **PostgreSQL** (Supabase/Neon/Vercel, anche per Governance)
- **Realtime**: Supabase Realtime → **SSE** (\`/api/realtime/stream\`)
- **Deploy**: Netlify + Supabase → **Docker + Dokploy/Hetzner**
- **Bridge col casino**: (non previsto) → **RS256 JWT** (aggiunto)

Funzionalità presenti **in più** rispetto al piano: bridge JWT col casino,
Live Map geografico, Affiliates, Marketing CMS pubblicato al casino,
Responsible Gaming, Legal/Audit, Escrow/Waterfall/Variance, AI Tutor, API Hub,
gate operatore globale con ruoli.
`,
  },
  {
    id: 'auth',
    title: 'Autenticazione',
    body: `
Quattro livelli di autenticazione, indipendenti:

1. **Gate operatore (UI)** — l'intero pannello è protetto da un login.
   \`POST /api/gov/auth\` verifica la password (scrypt) e imposta un cookie
   httpOnly firmato. Il browser non conserva mai segreti.
2. **Bearer token macchina** — \`GOVERNANCE_ADMIN_TOKEN\` (header
   \`Authorization: Bearer <token>\`) per chiamate scriptate/CI alle route del
   controller. Generazione: \`openssl rand -hex 32\`.
3. **JWT di piattaforma (RS256)** — per il traffico Governance → Casino
   (letture, approvazioni). Cuore del bridge in uscita (sezione \`bridge\`).
4. **HMAC del bridge** — \`GOVERNANCE_BRIDGE_SECRET\` (header
   \`X-Bridge-Signature\`) per gli eventi Casino → Governance. I cookie
   operatore **non** autenticano questo path.
`,
  },
  {
    id: 'bridge',
    title: 'Il bridge JWT (RS256)',
    body: `
Il contratto è definito in \`src/lib/platform/contract.ts\` (identico nei due
repo). Ogni richiesta porta un JWT firmato con **RS256** come bearer token.

**Claim del token**

~~~text
iss   → platformId del chiamante (es. tols-governance)
sub   → principal ("system" per job automatici, o id operatore)
aud   → platformId del destinatario (es. tols-casino)
scope → scope separati da spazio (vedi sotto)
iat / nbf / exp → finestra temporale (TTL 60 secondi di default)
jti   → id univoco del token (protezione replay)
~~~

**Scope disponibili**

~~~text
deposits:read         leggi la lista depositi del partner
deposits:approve      approva/rifiuta depositi del partner
withdrawals:read      leggi la lista prelievi del partner
withdrawals:approve   approva/rifiuta prelievi del partner
events:write          invia eventi firmati al webhook del partner
content:read          leggi i contenuti CMS pubblicati
payments:read         leggi tesoreria/riepilogo pagamenti
~~~

**Proprietà di sicurezza**

- \`alg:none\` e algoritmi diversi da RS256 vengono **rifiutati**.
- \`jti\` univoco + TTL 60s → **protezione replay**.
- Scopes **verificati su ogni richiesta**.
- Fail-closed: chiavi mancanti o mal configurate → **503**, mai fall-open.
- \`iss\` e \`aud\` validati contro \`PARTNER_PLATFORM_ID\`.
`,
  },
  {
    id: 'gov-inbound',
    title: 'Endpoint Governance — chiamati dal Casino',
    body: `
Questi endpoint vivono su Governance e rispondono al Casino.

**\`GET /api/platform/health\`** — probe di liveness, **pubblico**.

~~~json
{ "ok": true, "platform": "tols-governance", "ts": "2026-08-16T…" }
~~~

**\`GET /api/platform/whoami\`** — richiede un JWT partner valido; restituisce i
claim del chiamante. Serve come probe di connettività autenticato.

**\`GET /api/platform/content\`** — scope \`content:read\`. Pubblica al Casino i
contenuti CMS attivi (promozioni + giochi). Risposta:

~~~json
{ "success": true, "data": { "updatedAt": "…", "promotions": [ … ], "games": [ … ] } }
~~~

**\`POST /api/platform/webhooks\`** — HMAC \`GOVERNANCE_BRIDGE_SECRET\` (mai cookie
operatore). Riceve eventi dal Casino. \`{"type":"ping"}\` risponde **pong** senza
autenticazione. Gli altri eventi richiedono \`X-Bridge-Signature\` +
\`X-Bridge-Timestamp\`. **Idempotente** su \`event.id\` (o hash del body).

~~~json
{ "type": "casino.bet", "payload": { "…" }, "ts": "2026-08-21T…", "source": "casino" }
~~~

**\`GET /api/platform/webhooks\`** — probe pubblico \`{ success: true, reachable: true }\`.
Con cookie operatore / \`GOVERNANCE_ADMIN_TOKEN\` elenca gli eventi ricevuti.
`,
  },
  {
    id: 'gov-outbound',
    title: 'Endpoint Casino — chiamati da Governance',
    body: `
Governance firma richieste come \`tols-governance\` verso \`PARTNER_BASE_URL\`
del Casino. Sono endpoint **simmetrici** implementati dal Casino:

**\`GET /api/platform/health\`** — probe liveness (pubblico).

**\`GET /api/platform/whoami\`** — verifica autenticata della connettività.

**\`GET /api/platform/deposits\`** — scope \`deposits:read\`. Lista depositi
(filtro opzionale \`?status=pending|confirmed|failed\`).

**\`GET /api/platform/withdrawals\`** — scope \`withdrawals:read\`. Lista prelievi.

**\`POST /api/platform/withdrawals/:id/approve\`** — scope \`withdrawals:approve\`.

**\`POST /api/platform/withdrawals/:id/reject\`** — scope \`withdrawals:approve\`.

**\`GET /api/platform/payments\`** — scope \`payments:read\`. Tesoreria e riepilogo
pagamenti (watch-only).

**\`POST /api/platform/webhooks\`** — scope \`events:write\`. Governance può
notificare eventi al Casino.

Le route del controller Governance (\`/api/platform/deposits\`,
\`/api/platform/withdrawals\`, …) **proxano** queste chiamate verso il Casino
dopo il gate operatore.
`,
  },
  {
    id: 'controller',
    title: 'Route interne del controller',
    body: `
Endpoint chiamati dal frontend Governance (dietro gate operatore). Ognuna
restituisce JSON; le route \`/api/platform/*\` richiedono la sessione operatore o
\`GOVERNANCE_ADMIN_TOKEN\`.

~~~text
POST /api/gov/auth          login operatore (scrypt) → cookie httpOnly
POST /api/gov/logout        termina la sessione
GET  /api/health            probe monitoraggio (pubblico)
GET  /api/platform/connection   stato del link verso il Casino
GET  /api/platform/deposits     proxy → Casino deposits:read
GET  /api/platform/withdrawals  proxy → Casino withdrawals:read
POST /api/platform/withdrawals/:id/approve|reject  proxy → Casino
GET  /api/platform/payments     proxy → Casino payments:read
GET  /api/platform/webhooks     probe pubblico / eventi (se operatore)
~~~

Sezioni dati (riepilogo): \`/api/dashboard\`, \`/api/financial\`, \`/api/escrow\`,
\`/api/waterfall\`, \`/api/variance\`, \`/api/budget\`, \`/api/forecast\`,
\`/api/jackpots\`, \`/api/players\`, \`/api/segments\`, \`/api/promotions\`,
\`/api/affiliates\`, \`/api/wallets\`, \`/api/payments\`, \`/api/blockchain\`,
\`/api/rtp\`, \`/api/kyc\`, \`/api/risk\`, \`/api/responsible-gaming\`,
\`/api/vendors\`, \`/api/legal\`, \`/api/ml-pipeline\`, \`/api/ai-tutor\`,
\`/api/notifications\`, \`/api/api-hub\`, \`/api/auth\`, \`/api/live-map\`,
\`/api/live-players\`, \`/api/player-tracking\`, \`/api/cms/promotions\`,
\`/api/cms/games\`.

Le route **DB-backed** (dashboard, financial, players, cms, …) leggono da
Prisma/SQLite; le altre servono dati demo/mock in attesa delle integrazioni
reali. \`/api/kyc\` e \`/api/risk\` sono ora **DB-backed** con fallback demo
(modelli \`KycCase\` e \`AmlFlag\`).
`,
  },
  {
    id: 'realtime',
    title: 'Realtime (SSE)',
    body: `
**\`GET /api/realtime/stream\`** — feed **Server-Sent Events** per l'attività
live. Nessun server websocket richiesto: funziona su qualsiasi host Node.

Eventi emessi:

~~~text
event: stats        { totalOnline, byRegion, byGame, byDevice }
event: live-event   { id, eventType, playerName, gameName?, amount?, currency?, country, createdAt }
event: jackpot      { id, name, currentAmount }
~~~

\`eventType\` ∈ \`deposit | win | session | registration\`.

> Oggi emette **dati sintetici** di demo. In produzione sostituire il
> generatore con eventi reali provenienti dal Casino (webhook firmato
> \`events:write\` o coda messaggi).
`,
  },
  {
    id: 'keys',
    title: 'Scambio chiavi e configurazione',
    body: `
Genera una coppia RSA **per piattaforma** e scambia le chiavi **pubbliche**:

~~~bash
node scripts/generate-keys.mjs      # su Governance → tieni la privata, dai la pubblica al Casino
node scripts/generate-keys.mjs      # sul Casino    → tieni la privata, dai la pubblica a Governance
~~~

Variabili d'ambiente principali (vedi \`.env.example\` per l'elenco completo):

~~~text
DATABASE_URL                    file:/app/db/governance.db
PLATFORM_ID                     tols-governance
PLATFORM_PRIVATE_KEY            privata Governance (base64) — segreta
PLATFORM_PUBLIC_KEY             pubblica Governance
PARTNER_PLATFORM_ID             tols-casino
PARTNER_PUBLIC_KEY              pubblica Casino
PARTNER_BASE_URL                https://<casino-host>
GOVERNANCE_SESSION_SECRET       openssl rand -hex 32
GOVERNANCE_OPERATOR_USER        admin
GOVERNANCE_OPERATOR_PASSWORD_HASH  node scripts/hash-password.mjs <password>
GOVERNANCE_ADMIN_TOKEN          openssl rand -hex 32
GOVERNANCE_BRIDGE_SECRET        openssl rand -hex 32  (STESSO valore sul Casino)
~~~

Il formato dell'hash password è \`scrypt:salt:hash\` (due punti, **non** \`\$\`,
perché \`\$\` viene espanso dal loader \`.env\` di Next.js).
`,
  },
  {
    id: 'errors',
    title: 'Errori e codici di stato',
    body: `
Il bridge usa un envelope coerente:

~~~json
{ "success": false, "error": "messaggio", … }
~~~

~~~text
200  OK
400  richiesta malformata / evento non valido
401  JWT assente o non valido
403  scope insufficiente per l'operazione
503  chiavi mancanti o configurata male (fail-closed)
502  il partner non è raggiungibile / errore lato partner
500  errore interno
~~~

In caso di verifica fallita la risposta è sempre **esplicita**: nessuna
operazione viene eseguita in assenza dello scope corretto.
`,
  },
  {
    id: 'examples',
    title: 'Esempi',
    body: `
**Probe autenticato (whoami)** — il chiamante firma un JWT RS256 e lo invia:

~~~bash
curl -H "Authorization: Bearer <jwt>" https://gov.tols.gg/api/platform/whoami
~~~

~~~js
// node --input-type=module — firma e verifica con src/lib/platform/jwt.ts
import { signPlatformToken } from './src/lib/platform/jwt.ts'
const token = signPlatformToken({
  privateKey: process.env.PLATFORM_PRIVATE_KEY,
  issuer: 'tols-governance',
  audience: 'tols-casino',
  subject: 'system',
  scope: 'deposits:read',
})
console.log(token)
~~~

**Lettura depositi dal Casino (via proxy controller Governance)**:

~~~bash
curl -H "Authorization: Bearer $GOVERNANCE_ADMIN_TOKEN" \
  "https://gov.tols.gg/api/platform/deposits?status=pending"
~~~

**Invio evento HMAC (Casino → Governance)** — il test corretto è un POST firmato,
non un GET dal browser:

~~~bash
BODY='{"type":"ping"}'
SIG=$(node -e "const {createHmac}=require('crypto');process.stdout.write(createHmac('sha256',process.env.GOVERNANCE_BRIDGE_SECRET).update(process.argv[1]).digest('hex'))" "$BODY")
curl -X POST https://gov.tols.fun/api/platform/webhooks \
  -H "Content-Type: application/json" \
  -H "X-Bridge-Signature: sha256=$SIG" \
  -H "X-Bridge-Timestamp: $(date +%s)" \
  -d "$BODY"
~~~
`,
  },
  {
    id: 'deploy',
    title: 'Deploy',
    body: `
Guida operativa completa in **\`docs/DEPLOY.md\`**: due percorsi — **Vercel
(Postgres)** e **Hetzner/Dokploy (Postgres)**. Il database è **PostgreSQL**
(non SQLite, che non è compatibile con Vercel).

Riepilogo: \`npm install\` (esegue \`prisma generate\` via postinstall) →
\`npx prisma db push\` (una volta, contro il Postgres) → \`next build\`.
\`vercel.json\` imposta già \`prisma generate && next build\`.
`,
  },
]
