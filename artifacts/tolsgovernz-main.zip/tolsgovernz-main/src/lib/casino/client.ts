// ─────────────────────────────────────────────────────────────────────────────
// Casino REST client (Governance → Casino).
//
// Every call mints a fresh short-lived RS256 JWT and attaches it as a bearer
// token. Envelopes from the Casino are { success: true, data, pagination? } or
// { success: false, error } — this client passes them through untouched so the
// Governance controller routes can re-serve exactly what the Casino said.
// ─────────────────────────────────────────────────────────────────────────────

import { getCasinoConfig } from "./config";
import { mintCasinoJwt } from "./jwt";

export interface CasinoResponse {
  status: number;
  /** Parsed JSON body (null when the body was not JSON). */
  body: unknown;
}

export class CasinoBridgeError extends Error {
  constructor(
    message: string,
    readonly kind: "not_configured" | "unreachable",
  ) {
    super(message);
    this.name = "CasinoBridgeError";
  }
}

export async function casinoRequest(
  method: string,
  path: string,
  opts: { body?: unknown; scope?: string | string[]; timeoutMs?: number } = {},
): Promise<CasinoResponse> {
  const cfg = getCasinoConfig();

  let token: string;
  try {
    token = mintCasinoJwt({ scope: opts.scope });
  } catch (e) {
    throw new CasinoBridgeError(
      e instanceof Error ? e.message : "JWT signing failed",
      "not_configured",
    );
  }

  const url = `${cfg.casinoOrigin}${path.startsWith("/") ? path : `/${path}`}`;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), opts.timeoutMs ?? 12_000);
  try {
    const res = await fetch(url, {
      method,
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: opts.body === undefined ? undefined : JSON.stringify(opts.body),
      cache: "no-store",
      signal: controller.signal,
    });
    const body = await res.json().catch(() => null);
    return { status: res.status, body };
  } catch (e) {
    throw new CasinoBridgeError(
      e instanceof Error ? e.message : "Casino unreachable",
      "unreachable",
    );
  } finally {
    clearTimeout(timer);
  }
}

export const casinoGet = (path: string, opts?: { scope?: string | string[]; timeoutMs?: number }) =>
  casinoRequest("GET", path, opts);

export const casinoPost = (path: string, body?: unknown, opts?: { scope?: string | string[] }) =>
  casinoRequest("POST", path, { ...opts, body });

export const casinoPut = (path: string, body?: unknown, opts?: { scope?: string | string[] }) =>
  casinoRequest("PUT", path, { ...opts, body });

export const casinoPatch = (path: string, body?: unknown, opts?: { scope?: string | string[] }) =>
  casinoRequest("PATCH", path, { ...opts, body });

/**
 * Re-serve a Casino response from a Governance controller route, preserving
 * the Casino's JSON envelope and status code where sensible.
 */
export function relayCasinoResponse(res: CasinoResponse): Response {
  const body =
    res.body && typeof res.body === "object"
      ? res.body
      : { success: false, error: `Casino returned a non-JSON response (HTTP ${res.status})` };
  // 502 for casino-side 5xx so the UI can distinguish "casino broke" from "we broke".
  const status = res.status >= 500 ? 502 : res.status;
  return Response.json(body, { status });
}

export function bridgeErrorResponse(e: unknown): Response {
  if (e instanceof CasinoBridgeError) {
    return Response.json(
      { success: false, error: e.message, kind: e.kind },
      { status: e.kind === "not_configured" ? 503 : 502 },
    );
  }
  return Response.json(
    { success: false, error: e instanceof Error ? e.message : "Bridge request failed" },
    { status: 502 },
  );
}
