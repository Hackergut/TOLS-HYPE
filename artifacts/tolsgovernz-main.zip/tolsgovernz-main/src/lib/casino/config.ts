// ─────────────────────────────────────────────────────────────────────────────
// Casino bridge configuration — the SINGLE connection config for the twin
// Vercel project (hackguts-projects):
//
//   Casino     = tols-casino-next → https://www.tols.fun
//   Governance = THIS project     → https://gov.tols.fun
//
// Everything is env-backed (Vercel → Settings → Environment Variables), never
// localStorage. Two auth channels:
//
//   1) READ/WRITE REST  — RS256 JWT signed with PLATFORM_JWT_PRIVATE_KEY
//      (iss=tols-governance, aud=tols-casino, role=platform, exp ≤ 10 min).
//      The Casino verifies with PLATFORM_JWT_PUBLIC_KEY (set on tols-casino-next
//      ONLY — never here).
//   2) COMMANDS — HMAC SHA256 over the raw JSON body with
//      GOVERNANCE_BRIDGE_SECRET (alias GOVERNANCE_WEBHOOK_SECRET), same secret
//      on both projects, POSTed to CASINO/api/bridge/webhook.
// ─────────────────────────────────────────────────────────────────────────────

/** Canonical Casino origin. Overridable with APP_URL. Never Base44. */
export const CASINO = "https://www.tols.fun";

export interface CasinoBridgeConfig {
  /** Casino origin, e.g. https://www.tols.fun */
  casinoOrigin: string;
  /** This project's public origin, e.g. https://gov.tols.fun */
  governanceOrigin: string;
  /** Public Casino heartbeat (no auth). */
  healthPath: string;
  /** Command webhook on the Casino (HMAC). */
  webhookPath: string;
  /** JWT issuer — env PLATFORM_JWT_ISSUER, default tols-governance. */
  issuer: string;
  /** JWT audience — env PLATFORM_JWT_AUDIENCE, default tols-casino. */
  audience: string;
  /** RS256 private PEM (or base64 of the PEM). null when not configured. */
  privateKey: string | null;
  /** Shared HMAC secret. null when not configured. */
  bridgeSecret: string | null;
}

function pickEnv(...keys: string[]): string | undefined {
  for (const k of keys) {
    const v = process.env[k]?.trim();
    if (v) return v;
  }
  return undefined;
}

function stripTrailingSlash(s: string): string {
  return s.replace(/\/+$/, "");
}

/** Guard against ever pointing the bridge at a retired host. */
function isAllowedCasinoOrigin(value: string): boolean {
  try {
    const host = new URL(value).hostname.toLowerCase();
    if (host.endsWith("base44.app")) return false;
    return true;
  } catch {
    return false;
  }
}

/**
 * Read the bridge configuration from the environment. Never throws — routes
 * surface missing pieces as clean "not configured" states instead of 500s.
 */
export function getCasinoConfig(): CasinoBridgeConfig {
  const rawOrigin = pickEnv("APP_URL", "CASINO_URL", "PARTNER_BASE_URL");
  const casinoOrigin =
    rawOrigin && isAllowedCasinoOrigin(rawOrigin) ? stripTrailingSlash(rawOrigin) : CASINO;

  return {
    casinoOrigin,
    governanceOrigin: stripTrailingSlash(
      pickEnv("GOVERNANCE_TOWER_URL", "TOWER_URL") ?? "https://gov.tols.fun",
    ),
    healthPath: "/api/platform/health",
    webhookPath: "/api/bridge/webhook",
    issuer: pickEnv("PLATFORM_JWT_ISSUER", "PLATFORM_ID") ?? "tols-governance",
    audience: pickEnv("PLATFORM_JWT_AUDIENCE", "PARTNER_PLATFORM_ID") ?? "tols-casino",
    privateKey: pickEnv("PLATFORM_JWT_PRIVATE_KEY", "PLATFORM_PRIVATE_KEY") ?? null,
    bridgeSecret: pickEnv("GOVERNANCE_BRIDGE_SECRET", "GOVERNANCE_WEBHOOK_SECRET") ?? null,
  };
}

/** Which env pieces are present — used by the connection panel. */
export function casinoConfigReport(): {
  casinoOrigin: string;
  governanceOrigin: string;
  issuer: string;
  audience: string;
  privateKeyConfigured: boolean;
  bridgeSecretConfigured: boolean;
  missing: string[];
} {
  const cfg = getCasinoConfig();
  const missing: string[] = [];
  if (!cfg.privateKey) missing.push("PLATFORM_JWT_PRIVATE_KEY");
  if (!cfg.bridgeSecret) missing.push("GOVERNANCE_BRIDGE_SECRET");
  return {
    casinoOrigin: cfg.casinoOrigin,
    governanceOrigin: cfg.governanceOrigin,
    issuer: cfg.issuer,
    audience: cfg.audience,
    privateKeyConfigured: Boolean(cfg.privateKey),
    bridgeSecretConfigured: Boolean(cfg.bridgeSecret),
    missing,
  };
}
