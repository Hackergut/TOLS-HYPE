// ─────────────────────────────────────────────────────────────────────────────
// RS256 JWT minting for Governance → Casino REST calls.
//
// The Casino (tols-casino-next, src/lib/platform-jwt.ts) verifies with
// PLATFORM_JWT_PUBLIC_KEY and expects:
//   header  { alg: "RS256", typ: "JWT" }
//   claims  { iss: "tols-governance", aud: "tols-casino", iat, exp (≤ 10 min),
//             sub?, jti?, role: "platform", scope?: string[] }
// Empty/absent scope is treated by the Casino as "all scopes".
//
// Dependency-free: node:crypto only.
// ─────────────────────────────────────────────────────────────────────────────

import { createPrivateKey, randomBytes, sign, type KeyObject } from "node:crypto";
import { getCasinoConfig } from "./config";

const MAX_TTL_SECONDS = 600; // Casino rejects exp further than 10 minutes out

/** Accepts a PEM (possibly with literal \n) or base64(PEM|DER). */
export function loadCasinoPrivateKey(value: string): KeyObject {
  const v = (value ?? "").trim();
  if (!v) throw new Error("PLATFORM_JWT_PRIVATE_KEY is empty");
  if (v.includes("-----BEGIN")) {
    return createPrivateKey(v.replace(/\\n/g, "\n"));
  }
  // Vercel env vars are often the base64 of the PEM (newline-less).
  return createPrivateKey(Buffer.from(v, "base64"));
}

export interface MintOptions {
  /** Space-separated string or list of scopes. Empty = all (Casino default). */
  scope?: string | string[];
  subject?: string;
  ttlSeconds?: number;
}

/**
 * Mint a short-lived RS256 JWT for the Casino platform API.
 * Throws when PLATFORM_JWT_PRIVATE_KEY is missing/malformed.
 */
export function mintCasinoJwt(opts: MintOptions = {}): string {
  const cfg = getCasinoConfig();
  if (!cfg.privateKey) {
    throw new Error("PLATFORM_JWT_PRIVATE_KEY is not configured on this project");
  }

  const now = Math.floor(Date.now() / 1000);
  const ttl = Math.min(Math.max(opts.ttlSeconds ?? 300, 30), MAX_TTL_SECONDS);

  const scopeList = Array.isArray(opts.scope)
    ? opts.scope.filter(Boolean)
    : (opts.scope ?? "").split(" ").filter(Boolean);

  const header = { alg: "RS256", typ: "JWT" };
  const claims: Record<string, unknown> = {
    iss: cfg.issuer,
    aud: cfg.audience,
    sub: opts.subject ?? "tols-governance",
    iat: now,
    exp: now + ttl,
    jti: randomBytes(12).toString("hex"),
    role: "platform",
  };
  // Empty scope is allowed — the Casino treats it as "all". Only attach when set.
  if (scopeList.length > 0) claims.scope = scopeList;

  const encode = (o: unknown) => Buffer.from(JSON.stringify(o)).toString("base64url");
  const signingInput = `${encode(header)}.${encode(claims)}`;
  const key = loadCasinoPrivateKey(cfg.privateKey);
  const signature = sign("RSA-SHA256", Buffer.from(signingInput), key);
  return `${signingInput}.${signature.toString("base64url")}`;
}

export function isJwtConfigured(): boolean {
  const cfg = getCasinoConfig();
  if (!cfg.privateKey) return false;
  try {
    loadCasinoPrivateKey(cfg.privateKey);
    return true;
  } catch {
    return false;
  }
}
