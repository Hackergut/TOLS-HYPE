// ─────────────────────────────────────────────────────────────────────────────
// HMAC command channel (Governance → Casino /api/bridge/webhook) and inbound
// event verification (Casino → Governance /api/platform/webhooks).
//
// Wire format (both directions):
//   Headers  X-Bridge-Signature: sha256=<hex(HMAC_SHA256(rawBody, secret))>
//            X-Bridge-Timestamp: <unix seconds>   (max skew 5 minutes)
//   Body     { type, payload, ts, source }
// Same secret on both Vercel projects: GOVERNANCE_BRIDGE_SECRET
// (alias GOVERNANCE_WEBHOOK_SECRET).
// ─────────────────────────────────────────────────────────────────────────────

import { createHmac, timingSafeEqual } from "node:crypto";
import { getCasinoConfig } from "./config";

export const OUTBOUND_COMMANDS = [
  "governance.rtp_update",
  "governance.wallet_adjust",
  "governance.player_block",
  "governance.bonus_credit",
  "governance.session_invalidate",
  "governance.support_reply",
  "governance.support_close",
  "governance.limits_update",
  "governance.feature_flag",
  "ping",
] as const;

export type OutboundCommand = (typeof OUTBOUND_COMMANDS)[number];

export const INBOUND_EVENTS = [
  "casino.bet",
  "casino.win",
  "casino.deposit_pending",
  "casino.deposit_confirmed",
  "casino.withdrawal_pending",
  "casino.withdrawal_settled",
  "casino.session_start",
  "casino.session_end",
  "casino.health",
  "casino.support_message",
  "casino.support_ticket",
  "casino.bonus_released",
  "bridge.sync_request",
] as const;

export type InboundEvent = (typeof INBOUND_EVENTS)[number];

export function isInboundEventType(v: unknown): v is InboundEvent {
  return typeof v === "string" && (INBOUND_EVENTS as readonly string[]).includes(v);
}

export function signBridgePayload(rawBody: string, secret: string): string {
  return createHmac("sha256", secret).update(rawBody).digest("hex");
}

/** Constant-time check of an X-Bridge-Signature header (with/without sha256=). */
export function verifyBridgeSignature(rawBody: string, signature: string | null): boolean {
  const secret = getCasinoConfig().bridgeSecret;
  if (!secret || !signature) return false;
  const expected = signBridgePayload(rawBody, secret);
  const got = signature.trim().toLowerCase().replace(/^sha256=/, "");
  const a = Buffer.from(expected, "utf8");
  const b = Buffer.from(got, "utf8");
  return a.length === b.length && timingSafeEqual(a, b);
}

/** Max clock skew for X-Bridge-Timestamp: 5 minutes, matching the Casino. */
export function isFreshTimestamp(header: string | null): boolean {
  const ts = Number(header);
  if (!Number.isFinite(ts)) return false;
  return Math.abs(Date.now() / 1000 - ts) <= 300;
}

export interface CommandResult {
  ok: boolean;
  status: number;
  body: unknown;
}

/**
 * POST a signed command to the Casino webhook. `ping` needs no secret (the
 * Casino accepts unauthenticated pings); every other command requires
 * GOVERNANCE_BRIDGE_SECRET.
 */
export async function sendCasinoCommand(
  type: OutboundCommand | string,
  payload: Record<string, unknown> = {},
  opts: { timeoutMs?: number } = {},
): Promise<CommandResult> {
  const cfg = getCasinoConfig();
  const body = JSON.stringify({
    type,
    payload,
    ts: new Date().toISOString(),
    source: "governance",
  });

  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    Accept: "application/json",
  };
  if (cfg.bridgeSecret) {
    headers["X-Bridge-Signature"] = `sha256=${signBridgePayload(body, cfg.bridgeSecret)}`;
    headers["X-Bridge-Timestamp"] = String(Math.floor(Date.now() / 1000));
  } else if (type !== "ping") {
    return {
      ok: false,
      status: 503,
      body: { success: false, error: "GOVERNANCE_BRIDGE_SECRET is not configured on this project" },
    };
  }

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), opts.timeoutMs ?? 10_000);
  try {
    const res = await fetch(`${cfg.casinoOrigin}${cfg.webhookPath}`, {
      method: "POST",
      headers,
      body,
      cache: "no-store",
      signal: controller.signal,
    });
    const parsed = await res.json().catch(() => null);
    return { ok: res.ok, status: res.status, body: parsed };
  } catch (e) {
    return {
      ok: false,
      status: 502,
      body: { success: false, error: e instanceof Error ? e.message : "Casino webhook unreachable" },
    };
  } finally {
    clearTimeout(timer);
  }
}
