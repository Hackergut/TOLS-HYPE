import { PrismaClient } from '@prisma/client'
import { PGlite } from '@electric-sql/pglite'
import { PrismaPGliteAdapterFactory } from 'prisma-pglite/dist/adapter/prisma-pglite-adapter/pglite.js'

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

// Local/testing mode: when PGLITE_DATABASE_DIR is set, run on an embedded
// WASM Postgres (PGlite) via the Prisma driver adapter — no native engine
// binaries and no external Postgres server required. When unset (e.g. Vercel +
// Postgres), the default native-engine client is used unchanged.
function createClient(): PrismaClient {
  const pgliteDir = process.env.PGLITE_DATABASE_DIR
  if (pgliteDir) {
    const pglite = new PGlite(pgliteDir)
    const adapter = new PrismaPGliteAdapterFactory(pglite)
    return new PrismaClient({ adapter })
  }
  return new PrismaClient({
    log: ['query'],
  })
}

export const db = globalForPrisma.prisma ?? createClient()

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = db
