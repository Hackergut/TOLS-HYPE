// ─────────────────────────────────────────────────────────────────────────────
// Governance operator session (cookie) + machine bearer token.
//
// The Governance UI is same-origin with its own server, so the browser never
// holds a secret: it authenticates once with username/password, the server
// verifies against bcrypt-style (scrypt) hashes, and sets a signed httpOnly
// cookie. Controller routes (`/api/platform/*`) accept EITHER that operator
// cookie OR a machine bearer token (`GOVERNANCE_ADMIN_TOKEN`).
//
// Mirrors tols-casino-next's `src/lib/admin-auth.ts`.
// ─────────────────────────────────────────────────────────────────────────────

import { createHmac, timingSafeEqual, randomBytes, scryptSync } from "node:crypto";
import type { NextRequest } from "next/server";

const COOKIE = "tols_gov_admin";
const MAX_AGE_SECONDS = 60 * 60 * 8; // an operator shift

// ── Password hashing (scrypt — no external bcrypt dependency) ───────────────
// NOTE: the stored format uses ":" separators (scrypt:salt:hash), NOT "$".
// "$" is expanded as a variable reference by Next.js's .env loader, which would
// corrupt the hash the moment it is placed in an environment file.
export function hashPassword(plain: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(plain, salt, 64).toString("hex");
  return `scrypt:${salt}:${hash}`;
}

export function verifyPassword(plain: string, stored: string): boolean {
  try {
    const [scheme, salt, hash] = stored.split(":");
    if (scheme !== "scrypt" || !salt || !hash) return false;
    const candidate = scryptSync(plain, salt, 64);
    const expected = Buffer.from(hash, "hex");
    return candidate.length === expected.length && timingSafeEqual(candidate, expected);
  } catch {
    return false;
  }
}

// ── Signed session token ────────────────────────────────────────────────────
function secret(): string {
  const s = process.env.GOVERNANCE_SESSION_SECRET;
  if (!s || s.length < 32) {
    throw new Error("GOVERNANCE_SESSION_SECRET missing or shorter than 32 chars");
  }
  return s;
}

function sign(payload: string): string {
  return createHmac("sha256", secret()).update(payload).digest("hex");
}

function safeEqual(a: string, b: string): boolean {
  const ba = Buffer.from(a);
  const bb = Buffer.from(b);
  return ba.length === bb.length && timingSafeEqual(ba, bb);
}

export interface GovSession {
  username: string;
  issuedAt: number;
}

export function createGovToken(username: string): string {
  const payload = JSON.stringify({ username, issuedAt: Date.now() });
  const b64 = Buffer.from(payload).toString("base64url");
  return `${b64}.${sign(b64)}`;
}

export function verifyGovToken(token: string | undefined): GovSession | null {
  if (!token) return null;
  const [b64, sig] = token.split(".");
  if (!b64 || !sig) return null;
  if (!safeEqual(sig, sign(b64))) return null;
  try {
    const s = JSON.parse(Buffer.from(b64, "base64url").toString()) as GovSession;
    if (Date.now() - s.issuedAt > MAX_AGE_SECONDS * 1000) return null;
    return s;
  } catch {
    return null;
  }
}

export function getGovSession(req: NextRequest): GovSession | null {
  return verifyGovToken(req.cookies.get(COOKIE)?.value);
}

export interface GovCookieOptions {
  httpOnly: boolean;
  secure: boolean;
  sameSite: "strict";
  path: string;
  maxAge: number;
}

export function govCookieOptions(): GovCookieOptions {
  return {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "strict",
    path: "/",
    maxAge: MAX_AGE_SECONDS,
  };
}

// ── Guards ──────────────────────────────────────────────────────────────────
export type GuardResult = { session: GovSession } | { response: Response };

function notConfigured(): { response: Response } {
  return {
    response: Response.json(
      { success: false, error: "Governance auth is not configured" },
      { status: 503 },
    ),
  };
}

function unauthorized(): { response: Response } {
  return {
    response: Response.json({ success: false, error: "Unauthorized" }, { status: 401 }),
  };
}

/** Operator cookie only. */
export function requireGovOperator(req: NextRequest): GuardResult {
  let session: GovSession | null = null;
  try {
    session = getGovSession(req);
  } catch {
    return notConfigured();
  }
  if (!session) return unauthorized();
  return { session };
}

function machineSessionFromBearer(req: NextRequest): GovSession | null {
  const expected = process.env.GOVERNANCE_ADMIN_TOKEN;
  const auth = req.headers.get("authorization") ?? "";
  const bearer = auth.startsWith("Bearer ") ? auth.slice(7).trim() : "";

  if (expected && bearer) {
    const a = Buffer.from(bearer);
    const b = Buffer.from(expected);
    if (a.length === b.length && timingSafeEqual(a, b)) {
      return { username: "machine", issuedAt: Date.now() };
    }
  }
  return null;
}

/** Operator cookie OR machine bearer token (GOVERNANCE_ADMIN_TOKEN). */
export function requireGovOperatorOrToken(req: NextRequest): GuardResult {
  const machine = machineSessionFromBearer(req);
  if (machine) return { session: machine };
  return requireGovOperator(req);
}

/**
 * Same credentials as `requireGovOperatorOrToken`, but never 401s — used by
 * dual-mode public routes (unauthenticated callers get the public payload).
 */
export function peekGovOperatorOrToken(req: NextRequest): GovSession | null {
  const machine = machineSessionFromBearer(req);
  if (machine) return machine;
  try {
    return getGovSession(req);
  } catch {
    return null;
  }
}

export function generateSecret(): string {
  return randomBytes(32).toString("hex");
}
