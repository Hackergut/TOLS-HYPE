// Shared marker color logic for the live map (pure, no leaflet dependency).
// Kept in one place so the Leaflet map and any legend/tooltip stay in sync.

export interface SessionLike {
  wagerAmount: number
  winAmount: number
  startedAt: string
}

export function sessionColor(session: SessionLike, now: number): string {
  const age = now - new Date(session.startedAt).getTime()
  if (session.wagerAmount > 5000) return '#ef4444'
  if (session.winAmount > session.wagerAmount * 2) return '#d4a017'
  if (age < 5 * 60 * 1000) return '#3b82f6'
  return '#10b981'
}

export function sessionLabel(session: SessionLike, now: number): string {
  const age = now - new Date(session.startedAt).getTime()
  if (session.wagerAmount > 5000) return 'High Value'
  if (session.winAmount > session.wagerAmount * 2) return 'Big Win'
  if (age < 5 * 60 * 1000) return 'New Session'
  return 'Active'
}

export function serverColor(status: string): string {
  if (status === 'online') return '#10b981'
  if (status === 'degraded') return '#f59e0b'
  return '#ef4444'
}
