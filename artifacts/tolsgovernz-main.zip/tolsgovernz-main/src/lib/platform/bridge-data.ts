// ─────────────────────────────────────────────────────────────────────────────
// Bridge-aware data helpers.
//
// The Governance "money" views (payments / financial / wallets) prefer REAL
// casino data when the RS256-JWT bridge is configured and reachable, and fall
// back to the local (demo) database otherwise. These helpers wrap the best-
// effort fetch so callers can do:
//
//   const deposits = await fetchBridgeDeposits()   // DepositRecord[] | null
//   if (deposits !== null) { …use casino data… } else { …use local DB… }
//
// They return `null` (never throw) in every failure mode: bridge not
// configured, casino unreachable, HTTP error, or shape mismatch. A short
// timeout + a failure cooldown keeps the fallback path fast when the casino
// is down.
// ─────────────────────────────────────────────────────────────────────────────

import { getPlatformConfig } from "./env";
import { getPlatformClient } from "./client";
import { SCOPES } from "./contract";
import type { DepositRecord, WithdrawalRecord } from "./contract";

const TIMEOUT_MS = 3_000; // best-effort: keep fallback snappy
const COOLDOWN_MS = 15_000; // don't retry a down bridge on every request

let lastDownAt = 0;

export function isBridgeConfigured(): boolean {
  try {
    getPlatformConfig(); // throws if any PLATFORM_* / PARTNER_* env is missing
    return true;
  } catch {
    return false;
  }
}

function inCooldown(): boolean {
  return Date.now() - lastDownAt < COOLDOWN_MS;
}

async function getList<T>(path: string, scope: string): Promise<T[] | null> {
  if (!isBridgeConfigured() || inCooldown()) return null;
  try {
    const res = await getPlatformClient().request("GET", path, { scope, timeoutMs: TIMEOUT_MS });
    if (res.status >= 500) {
      lastDownAt = Date.now();
      return null;
    }
    if (res.status >= 400) return null; // auth/scope issue — not a reachability failure
    const data = (res.data as { data?: unknown } | null)?.data;
    return Array.isArray(data) ? (data as T[]) : null;
  } catch {
    lastDownAt = Date.now();
    return null;
  }
}

export async function fetchBridgeDeposits(): Promise<DepositRecord[] | null> {
  return getList<DepositRecord>("/api/platform/deposits", SCOPES.depositsRead);
}

export async function fetchBridgeWithdrawals(): Promise<WithdrawalRecord[] | null> {
  return getList<WithdrawalRecord>("/api/platform/withdrawals", SCOPES.withdrawalsRead);
}

export async function fetchBridgePayments(): Promise<Record<string, unknown> | null> {
  if (!isBridgeConfigured() || inCooldown()) return null;
  try {
    const res = await getPlatformClient().request("GET", "/api/platform/payments", {
      scope: SCOPES.paymentsRead,
      timeoutMs: TIMEOUT_MS,
    });
    if (res.status >= 500) {
      lastDownAt = Date.now();
      return null;
    }
    if (res.status >= 400) return null;
    const data = (res.data as { data?: unknown } | null)?.data;
    return data && typeof data === "object" && !Array.isArray(data)
      ? (data as Record<string, unknown>)
      : null;
  } catch {
    lastDownAt = Date.now();
    return null;
  }
}

// /api/platform/wallets returns { data: WalletRecord[], totals, pagination }.
export interface CasinoWalletRecord {
  id: string;
  userId: string;
  username: string | null;
  email: string | null;
  kycStatus: string | null;
  currency: string;
  balance: number;
  vipLevel: number;
  totalWagered: number;
  totalWon: number;
  updatedAt: string;
}

export interface BridgeWallets {
  wallets: CasinoWalletRecord[];
  totals: { balance: number; wallets: number };
}

export async function fetchBridgeWallets(): Promise<BridgeWallets | null> {
  if (!isBridgeConfigured() || inCooldown()) return null;
  try {
    const res = await getPlatformClient().request("GET", "/api/platform/wallets", {
      scope: SCOPES.walletsRead,
      timeoutMs: TIMEOUT_MS,
    });
    if (res.status >= 500) {
      lastDownAt = Date.now();
      return null;
    }
    if (res.status >= 400) return null; // casino without wallets endpoint / scope
    const envelope = res.data as { data?: unknown; totals?: unknown } | null;
    if (!Array.isArray(envelope?.data)) return null;
    return {
      wallets: envelope.data as CasinoWalletRecord[],
      totals: (envelope.totals as BridgeWallets["totals"]) ?? { balance: 0, wallets: 0 },
    };
  } catch {
    lastDownAt = Date.now();
    return null;
  }
}
