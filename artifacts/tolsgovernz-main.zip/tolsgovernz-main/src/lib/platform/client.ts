// ─────────────────────────────────────────────────────────────────────────────
// Outbound platform client (shared, byte-identical).
// Signs every request with a fresh RS256 JWT and attaches it as a bearer token.
// ─────────────────────────────────────────────────────────────────────────────

import { getPlatformConfig, type PlatformConfig } from "./env";
import { signPlatformToken } from "./jwt";

export interface PlatformResponse {
  status: number;
  data: unknown;
}

export class PlatformClient {
  constructor(private readonly cfg: PlatformConfig) {}

  private sign(scope: string, subject = "system"): string {
    return signPlatformToken({
      privateKey: this.cfg.privateKey,
      issuer: this.cfg.platformId,
      audience: this.cfg.partnerPlatformId,
      subject,
      scope,
    });
  }

  async request(
    method: string,
    path: string,
    opts: { scope: string; body?: unknown; timeoutMs?: number },
  ): Promise<PlatformResponse> {
    const url = `${this.cfg.partnerBaseUrl.replace(/\/+$/, "")}${path}`;
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), opts.timeoutMs ?? 10_000);
    try {
      const res = await fetch(url, {
        method,
        headers: {
          Authorization: `Bearer ${this.sign(opts.scope)}`,
          "Content-Type": "application/json",
          Accept: "application/json",
        },
        body: opts.body === undefined ? undefined : JSON.stringify(opts.body),
        cache: "no-store",
        signal: controller.signal,
      });
      const data = await res.json().catch(() => null);
      return { status: res.status, data };
    } finally {
      clearTimeout(timer);
    }
  }

  get(path: string, scope: string): Promise<PlatformResponse> {
    return this.request("GET", path, { scope });
  }

  post(path: string, scope: string, body?: unknown): Promise<PlatformResponse> {
    return this.request("POST", path, { scope, body });
  }

  /** Send an event to the partner's webhook endpoint (scope events:write). */
  notify(event: unknown): Promise<PlatformResponse> {
    return this.post("/api/platform/webhooks", "events:write", event);
  }
}

let singleton: PlatformClient | null = null;

export function getPlatformClient(): PlatformClient {
  if (!singleton) singleton = new PlatformClient(getPlatformConfig());
  return singleton;
}
