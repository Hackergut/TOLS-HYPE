// ─────────────────────────────────────────────────────────────────────────────
// Marketing content contract (shared, byte-identical across TOLS repos).
//
// The Governance CMS owns the marketing layer — promotions (hero carousel,
// promo strip) and marketable game entries — and publishes it to the Casino
// through the platform bridge. The Casino pulls this with a signed RS256 JWT
// (scope `content:read`) and merges it over its local defaults, so the lobby
// keeps rendering even if the CMS is unreachable.
// ─────────────────────────────────────────────────────────────────────────────

export interface CmsPromotion {
  id: string;
  title: string;
  subtitle: string;
  /** Call-to-action label, e.g. "Play" / "Enter". */
  cta: string;
  /** Image URL (relative to the casino, or absolute). */
  imageUrl: string;
  /** Target: a game id (dice, crash, …) or a section (rewards, affiliate…). */
  target: string;
  /** Whether the strip entry uses the lime accent gradient. */
  accent: boolean;
  /** Ascending order in the carousel / strip. */
  sortOrder: number;
  active: boolean;
}

export interface CmsGame {
  id: string;
  /** Slug matching the casino engine / catalogue (dice, crash, …). */
  gameId: string;
  name: string;
  /** Short marketing line shown under the title. */
  tagline: string;
  description: string;
  provider: string;
  category: string;
  /** Thumbnail override; falls back to the casino's tile when empty. */
  imageUrl: string;
  sortOrder: number;
  featured: boolean;
  isNew: boolean;
  active: boolean;
}

export interface PlatformContent {
  promotions: CmsPromotion[];
  games: CmsGame[];
  /** ISO-8601 — the Casino uses it for cache freshness. */
  updatedAt: string;
}
