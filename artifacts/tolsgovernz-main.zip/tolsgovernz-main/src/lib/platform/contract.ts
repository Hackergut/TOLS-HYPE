// ─────────────────────────────────────────────────────────────────────────────
// Platform-to-platform contract (shared, byte-identical across TOLS repos).
//
// These types + constants describe the wire format between the TOLS Governance
// control tower and a TOLS Casino instance. The two projects run on separate
// platforms and are connected ONLY through this API contract, authenticated
// with RS256 JWTs — there is no shared database, no shared cookie, no
// cross-origin session. Keep this file in sync in BOTH repositories: it is the
// API "contract" between them.
// ─────────────────────────────────────────────────────────────────────────────

// ── Machine-to-machine scopes ───────────────────────────────────────────────
// A scope must be present in the JWT `scope` claim for the matching operation.
// Scopes are additive: grant the smallest set needed for each integration.
export const SCOPES = {
  depositsRead: "deposits:read",
  depositsApprove: "deposits:approve",
  withdrawalsRead: "withdrawals:read",
  withdrawalsApprove: "withdrawals:approve",
  eventsWrite: "events:write",
  contentRead: "content:read",
  paymentsRead: "payments:read",
  walletsRead: "wallets:read",
} as const;

export const ALL_SCOPES: readonly string[] = Object.freeze(Object.values(SCOPES));

export type Scope = (typeof SCOPES)[keyof typeof SCOPES];

// ── Issuer / audience identifiers ───────────────────────────────────────────
// Canonical values. Overridable via PLATFORM_ID / PARTNER_PLATFORM_ID.
export const PLATFORM_GOVERNANCE = "tols-governance";
export const PLATFORM_CASINO = "tols-casino";

// ── Data transfer objects (Deposits / Withdrawals slice) ────────────────────

export interface DepositRecord {
  id: string;
  userId: string;
  username: string;
  email: string;
  chain: string;
  txHash: string;
  /** Amount in the chain's native unit (BTC/ETH/SOL…) — what on-chain verification matches. */
  amount: number;
  /** USD-equivalent actually credited to the wallet. */
  amountUsd: number;
  currency: string;
  /** pending | confirmed | failed */
  status: string;
  credited: boolean;
  /** ISO-8601 */
  createdAt: string;
}

export interface WithdrawalRecord {
  id: string;
  userId: string;
  username: string;
  email: string;
  amount: number;
  currency: string;
  chain: string;
  walletAddress: string;
  /** pending | approved | rejected | completed */
  status: string;
  txHash: string;
  balanceBefore: number;
  balanceAfter: number;
  /** ISO-8601 or null */
  processedDate: string | null;
  /** ISO-8601 */
  createdAt: string;
}

export type WithdrawalDecision = "approve" | "reject";

// ── Events (casino → governance webhooks) ───────────────────────────────────
export const EVENT_TYPES = [
  "deposit.confirmed",
  "deposit.failed",
  "withdrawal.requested",
  "withdrawal.approved",
  "withdrawal.rejected",
] as const;

export type PlatformEventType = (typeof EVENT_TYPES)[number];

export function isPlatformEventType(v: unknown): v is PlatformEventType {
  return typeof v === "string" && (EVENT_TYPES as readonly string[]).includes(v);
}

export interface PlatformEvent<T = Record<string, unknown>> {
  type: PlatformEventType;
  /** Unique event id — the receiver uses it for idempotent dedupe. */
  id: string;
  /** ISO-8601 */
  occurredAt: string;
  data: T;
}

// ── Response envelope helpers ───────────────────────────────────────────────
// `Response.json` is a Web standard available in Next route handlers and Node 18+.
export function platformOk(data: unknown, status = 200): Response {
  return Response.json({ success: true, data }, { status });
}

export function platformErr(
  message: string,
  status = 400,
  extra?: Record<string, unknown>,
): Response {
  return Response.json({ success: false, error: message, ...extra }, { status });
}
