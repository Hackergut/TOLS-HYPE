// ─────────────────────────────────────────────────────────────────────────────
// Platform integration configuration (shared, byte-identical).
// Reads the RS256 keypair + partner credentials from the environment and fails
// closed (throws) when anything is missing or malformed.
// ─────────────────────────────────────────────────────────────────────────────

import { loadPrivateKey, loadPublicKey } from "./jwt";

export interface PlatformConfig {
  /** Our platform id (iss when we sign, aud when the partner signs). */
  platformId: string;
  /** The partner's platform id (aud when we sign, iss when the partner signs). */
  partnerPlatformId: string;
  /** Our RSA private key (PEM or base64) — signs outbound requests. */
  privateKey: string;
  /** Our RSA public key (optional) — used only for key exchange/docs. */
  publicKey?: string;
  /** The partner's RSA public key — verifies inbound requests. */
  partnerPublicKey: string;
  /** Base URL of the partner platform (e.g. https://casino.example.com). */
  partnerBaseUrl: string;
}

export function getPlatformConfig(): PlatformConfig {
  const c = {
    platformId: process.env.PLATFORM_ID,
    partnerPlatformId: process.env.PARTNER_PLATFORM_ID,
    privateKey: process.env.PLATFORM_PRIVATE_KEY,
    publicKey: process.env.PLATFORM_PUBLIC_KEY,
    partnerPublicKey: process.env.PARTNER_PUBLIC_KEY,
    partnerBaseUrl: process.env.PARTNER_BASE_URL,
  };

  const required: Array<keyof typeof c> = [
    "platformId",
    "partnerPlatformId",
    "privateKey",
    "partnerPublicKey",
    "partnerBaseUrl",
  ];
  const missing = required.filter((k) => !c[k]);
  if (missing.length > 0) {
    throw new Error(
      `Platform integration not configured. Missing env: ${missing.join(", ")}`,
    );
  }

  // Eagerly validate key material so misconfiguration fails fast and loudly.
  loadPrivateKey(c.privateKey as string);
  loadPublicKey(c.partnerPublicKey as string);

  return c as PlatformConfig;
}
