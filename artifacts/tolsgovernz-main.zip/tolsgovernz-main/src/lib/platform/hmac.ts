// ─────────────────────────────────────────────────────────────────────────────
// Shared HMAC for the Casino → Governance event bridge.
//
// The live Casino (`tols-casino-next`) signs outbound events with
// `GOVERNANCE_BRIDGE_SECRET` (alias `GOVERNANCE_WEBHOOK_SECRET`) and sends:
//
//   X-Bridge-Signature: sha256=<hex>   (raw hex also accepted)
//   X-Bridge-Timestamp: <unix seconds>
//
// Governance verifies the same way. This is independent of the operator
// cookie and of the RS256 JWT used on /api/platform/* reads. Fail closed:
// a missing secret never authenticates an event.
// ─────────────────────────────────────────────────────────────────────────────

import { createHash, createHmac, timingSafeEqual } from "node:crypto";

const SECRET_ENV = ["GOVERNANCE_BRIDGE_SECRET", "GOVERNANCE_WEBHOOK_SECRET"] as const;

/** Maximum |now - X-Bridge-Timestamp| accepted, matching the Casino. */
export const BRIDGE_MAX_SKEW_SECONDS = 300;

/** Casino treats a secret shorter than this as "not configured". */
export const BRIDGE_SECRET_MIN_LENGTH = 16;

function pickEnv(...keys: readonly string[]): string {
  for (const k of keys) {
    const v = process.env[k]?.trim();
    if (v) return v;
  }
  return "";
}

export function getBridgeSecret(): string {
  return pickEnv(...SECRET_ENV);
}

export function isBridgeSecretReady(secret = getBridgeSecret()): boolean {
  return secret.length >= BRIDGE_SECRET_MIN_LENGTH;
}

export function signBridgePayload(payload: string, secretOverride?: string): string {
  const secret = secretOverride ?? getBridgeSecret();
  if (!secret) {
    throw new Error(
      "GOVERNANCE_BRIDGE_SECRET not configured — set the same secret on Casino and Governance",
    );
  }
  return createHmac("sha256", secret).update(payload).digest("hex");
}

export function normalizeBridgeSignature(signature: string): string {
  return signature.trim().toLowerCase().replace(/^sha256=/, "");
}

export function verifyBridgeSignature(
  rawBody: string,
  signature: string | null,
  secretOverride?: string,
): boolean {
  const secret = secretOverride ?? getBridgeSecret();
  if (!secret || !signature) return false;
  const expected = createHmac("sha256", secret).update(rawBody).digest("hex");
  const a = Buffer.from(expected, "utf8");
  const b = Buffer.from(normalizeBridgeSignature(signature), "utf8");
  if (a.length !== b.length) return false;
  return timingSafeEqual(a, b);
}

export function verifyBridgeTimestamp(
  header: string | null,
  nowMs = Date.now(),
): boolean {
  const timestamp = Number(header);
  if (!Number.isFinite(timestamp)) return false;
  return Math.abs(nowMs / 1000 - timestamp) <= BRIDGE_MAX_SKEW_SECONDS;
}

export function bridgeSignatureFromHeaders(headers: Headers): string | null {
  return (
    headers.get("x-bridge-signature") ||
    headers.get("x-webhook-signature") ||
    headers.get("x-tower-signature") ||
    headers.get("x-governance-signature") ||
    null
  );
}

/** Stable idempotency key: explicit id, else SHA-256 of the raw body. */
export function eventIdFromBody(body: Record<string, unknown>, raw: string): string {
  if (typeof body.id === "string" && body.id.trim()) return body.id.trim().slice(0, 128);
  if (typeof body.eventId === "string" && body.eventId.trim()) {
    return body.eventId.trim().slice(0, 128);
  }
  return createHash("sha256").update(raw).digest("hex");
}
