// ─────────────────────────────────────────────────────────────────────────────
// RS256 JWT primitives for platform-to-platform auth (shared, byte-identical).
//
// Dependency-free: uses `node:crypto` only, so it runs in the Next.js Node
// runtime and is directly unit-testable with `node --test` (erasable TS only —
// no enums/namespaces, and no local imports, so Node's type stripping can load
// this file on its own).
//
// Trust model: the caller signs with its OWN RSA private key; the receiver
// verifies with the CALLER's public key. Each side therefore holds its own
// private key (to sign outbound requests) and the partner's public key (to
// verify inbound requests). No shared symmetric secret exists anywhere.
// ─────────────────────────────────────────────────────────────────────────────

import {
  createPrivateKey,
  createPublicKey,
  generateKeyPairSync,
  randomBytes,
  sign,
  verify,
} from "node:crypto";

// ── Claims ──────────────────────────────────────────────────────────────────
export interface PlatformClaims {
  /** Who signed — the caller's platform id (e.g. "tols-governance"). */
  iss: string;
  /** Principal — operator id, or "system" for unattended jobs. */
  sub: string;
  /** Who must accept — the receiver's platform id (e.g. "tols-casino"). */
  aud: string;
  /** Space-separated scopes (see contract.ts). */
  scope: string;
  /** Issued-at, seconds since epoch. */
  iat: number;
  /** Not-before, seconds since epoch. */
  nbf: number;
  /** Expires-at, seconds since epoch. */
  exp: number;
  /** Unique token id — used for replay protection. */
  jti: string;
}

export interface SignOptions {
  /** PEM text (possibly with literal \n) or base64(DER|PEM). */
  privateKey: string | Buffer;
  issuer: string;
  audience: string;
  subject?: string;
  scope?: string | string[];
  /** Default 60s. Keep short — these tokens are per-request. */
  ttlSeconds?: number;
  now?: Date;
}

export interface VerifyOptions {
  /** The CALLER's public key (PEM text or base64). */
  publicKey: string | Buffer;
  /** Expected `iss` (the partner's platform id). */
  issuer?: string;
  /** Expected `aud` (our own platform id). */
  audience?: string;
  clockSkewSeconds?: number;
  now?: Date;
}

export type VerifyResult =
  | { valid: true; claims: PlatformClaims }
  | { valid: false; reason: string };

// ── base64url helpers (no padding, URL-safe) ────────────────────────────────
function b64urlEncode(input: Buffer | string): string {
  const buf = Buffer.isBuffer(input) ? input : Buffer.from(input);
  return buf.toString("base64url");
}

function b64urlDecode(input: string): Buffer {
  return Buffer.from(input, "base64url");
}

// ── Key loading (accepts PEM text or base64(DER|PEM)) ───────────────────────
export function loadPrivateKey(value: string) {
  const v = (value ?? "").trim();
  if (!v) throw new Error("private key is empty");
  if (v.includes("-----BEGIN")) {
    return createPrivateKey(v.replace(/\\n/g, "\n"));
  }
  // base64: either DER (PKCS#8) binary or PEM text — createPrivateKey sniffs both.
  return createPrivateKey(Buffer.from(v, "base64"));
}

export function loadPublicKey(value: string) {
  const v = (value ?? "").trim();
  if (!v) throw new Error("public key is empty");
  if (v.includes("-----BEGIN")) {
    return createPublicKey(v.replace(/\\n/g, "\n"));
  }
  return createPublicKey(Buffer.from(v, "base64"));
}

/** Generate an RSA keypair (PEM). Used by scripts/tests; prod keys come from a KMS/secret store. */
export function generateRsaKeyPair(modulusLength = 3072): {
  privateKey: string;
  publicKey: string;
} {
  const { privateKey, publicKey } = generateKeyPairSync("rsa", {
    modulusLength,
    publicKeyEncoding: { type: "spki", format: "pem" },
    privateKeyEncoding: { type: "pkcs8", format: "pem" },
  });
  return { privateKey: privateKey as string, publicKey: publicKey as string };
}

// ── Token signing ───────────────────────────────────────────────────────────
export function signPlatformToken(opts: SignOptions): string {
  const now = opts.now ?? new Date();
  const nowSec = Math.floor(now.getTime() / 1000);
  const ttl = opts.ttlSeconds ?? 60;
  if (ttl <= 0) throw new Error("ttlSeconds must be positive");

  const scope = Array.isArray(opts.scope)
    ? opts.scope.filter(Boolean).join(" ")
    : (opts.scope ?? "");

  const header = { alg: "RS256", typ: "JWT" };
  const claims: PlatformClaims = {
    iss: opts.issuer,
    sub: opts.subject ?? "system",
    aud: opts.audience,
    scope,
    iat: nowSec,
    nbf: nowSec,
    exp: nowSec + ttl,
    jti: randomBytes(16).toString("hex"),
  };

  const signingInput = `${b64urlEncode(JSON.stringify(header))}.${b64urlEncode(
    JSON.stringify(claims),
  )}`;
  const key = loadPrivateKey(String(opts.privateKey));
  const signature = sign("RSA-SHA256", Buffer.from(signingInput), key);
  return `${signingInput}.${b64urlEncode(signature)}`;
}

// ── Replay protection (best-effort, in-process) ─────────────────────────────
// A token may be replayed as long as it is valid. jti + this in-memory cache
// rejects a second use of the same token within its lifetime. Per-instance only:
// in a multi-instance deployment, back this with a shared store (Redis etc.).
const replayCache = new Map<string, number>(); // jti -> exp (seconds)
const REPLAY_MAX = 10_000;

function pruneReplay(nowSec: number): void {
  for (const [jti, exp] of replayCache) {
    if (exp <= nowSec) replayCache.delete(jti);
  }
}

function isReplay(jti: string, expSec: number): boolean {
  const nowSec = Math.floor(Date.now() / 1000);
  if (replayCache.size > REPLAY_MAX) pruneReplay(nowSec);
  const seen = replayCache.get(jti);
  if (seen !== undefined && seen > nowSec) return true; // already accepted & still live
  replayCache.set(jti, expSec);
  return false;
}

// ── Token verification ──────────────────────────────────────────────────────
export function verifyPlatformToken(
  token: string,
  opts: VerifyOptions,
): VerifyResult {
  const parts = token.split(".");
  if (parts.length !== 3) return { valid: false, reason: "malformed token" };

  const [headerB64, payloadB64, sigB64] = parts;
  const signingInput = `${headerB64}.${payloadB64}`;

  let header: { alg?: string; typ?: string };
  let claims: PlatformClaims;
  try {
    header = JSON.parse(b64urlDecode(headerB64).toString("utf8"));
    claims = JSON.parse(b64urlDecode(payloadB64).toString("utf8")) as PlatformClaims;
  } catch {
    return { valid: false, reason: "invalid header/payload encoding" };
  }

  if (header.alg !== "RS256") {
    return { valid: false, reason: "unsupported algorithm" };
  }

  let sigBuf: Buffer;
  try {
    sigBuf = b64urlDecode(sigB64);
  } catch {
    return { valid: false, reason: "invalid signature encoding" };
  }

  const key = loadPublicKey(String(opts.publicKey));
  if (!verify("RSA-SHA256", Buffer.from(signingInput), key, sigBuf)) {
    return { valid: false, reason: "signature mismatch" };
  }

  if (opts.issuer && claims.iss !== opts.issuer) {
    return { valid: false, reason: "issuer mismatch" };
  }
  if (opts.audience && claims.aud !== opts.audience) {
    return { valid: false, reason: "audience mismatch" };
  }

  const now = opts.now ?? new Date();
  const nowSec = Math.floor(now.getTime() / 1000);
  const skew = opts.clockSkewSeconds ?? 5;

  if (typeof claims.nbf === "number" && nowSec < claims.nbf - skew) {
    return { valid: false, reason: "token not yet valid" };
  }
  if (typeof claims.exp !== "number" || nowSec > claims.exp + skew) {
    return { valid: false, reason: "token expired" };
  }

  if (claims.jti && isReplay(claims.jti, claims.exp)) {
    return { valid: false, reason: "replay detected" };
  }

  return { valid: true, claims };
}

// ── Scope checks ────────────────────────────────────────────────────────────
export function scopeHas(
  claims: Pick<PlatformClaims, "scope">,
  required: string,
): boolean {
  const granted = new Set((claims.scope ?? "").split(/\s+/).filter(Boolean));
  if (granted.has("*")) return true;
  return required
    .split(/\s+/)
    .filter(Boolean)
    .every((s) => granted.has(s));
}
