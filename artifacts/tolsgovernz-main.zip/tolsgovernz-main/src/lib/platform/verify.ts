// ─────────────────────────────────────────────────────────────────────────────
// Inbound request verification (shared, byte-identical).
// Every platform endpoint calls `verifyPlatformRequest` before touching data.
// ─────────────────────────────────────────────────────────────────────────────

import { getPlatformConfig } from "./env";
import { verifyPlatformToken, scopeHas, type PlatformClaims } from "./jwt";

export interface VerifyPlatformOptions {
  /** Required scope, e.g. "withdrawals:approve". Omit for "any valid token". */
  scope?: string;
}

export type PlatformAuthResult =
  | { claims: PlatformClaims }
  | { response: Response };

/**
 * Verify `Authorization: Bearer <JWT>` against the partner's public key.
 * Returns `{ claims }` on success, or `{ response }` (401/403/503) to return
 * as-is from the route. Never throws for auth problems.
 */
export async function verifyPlatformRequest(
  req: Request,
  opts: VerifyPlatformOptions = {},
): Promise<PlatformAuthResult> {
  let cfg;
  try {
    cfg = getPlatformConfig();
  } catch {
    return {
      response: Response.json(
        { success: false, error: "Platform auth is not configured" },
        { status: 503 },
      ),
    };
  }

  const auth = req.headers.get("authorization") ?? "";
  const token = auth.startsWith("Bearer ") ? auth.slice(7).trim() : "";
  if (!token) {
    return {
      response: Response.json(
        { success: false, error: "Missing bearer token" },
        { status: 401 },
      ),
    };
  }

  const result = verifyPlatformToken(token, {
    publicKey: cfg.partnerPublicKey,
    issuer: cfg.partnerPlatformId,
    audience: cfg.platformId,
  });

  if (!result.valid) {
    return {
      response: Response.json(
        { success: false, error: `Invalid token: ${result.reason}` },
        { status: 401 },
      ),
    };
  }

  if (opts.scope && !scopeHas(result.claims, opts.scope)) {
    return {
      response: Response.json(
        { success: false, error: `Missing required scope: ${opts.scope}` },
        { status: 403 },
      ),
    };
  }

  return { claims: result.claims };
}
