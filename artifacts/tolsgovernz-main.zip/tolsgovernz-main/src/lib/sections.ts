// ─────────────────────────────────────────────────────────────────────────────
// sections.ts — the SINGLE source of truth for every Governance section.
//
// One definition per section: identity, category group, role visibility, and
// explanatory copy (`use` + `connections`). The sidebar, header, overview
// lobby and the per-section info panel all read from here.
// ─────────────────────────────────────────────────────────────────────────────

import type { LucideIcon } from "lucide-react";
import {
  LayoutDashboard, DollarSign, Globe, Activity, Users, PieChart, Gift, Link2,
  Wallet, CreditCard, Bot, Scale, Zap, Bell, Server, Shield, Brain, PlugZap,
  Megaphone, Gauge, Blocks, SlidersHorizontal, BadgeCheck, LifeBuoy, ShieldAlert,
  Dice5,
} from "lucide-react";

export type UserRole = "finance" | "controller" | "super_admin";

export type Section =
  | "lobby"
  | "dashboard"
  | "financial"
  | "live-map"
  | "live-players"
  | "players"
  | "segments"
  | "promotions"
  | "affiliates"
  | "wallets"
  | "payments"
  | "bets"
  | "blockchain"
  | "rtp"
  | "kyc"
  | "responsible"
  | "risk"
  | "vendors"
  | "ml-pipeline"
  | "ai-tutor"
  | "notifications"
  | "legal"
  | "auth"
  | "api-hub"
  | "casino"
  | "cms";

export type SectionGroup =
  | "overview"
  | "core"
  | "live"
  | "marketing"
  | "money"
  | "operations"
  | "compliance"
  | "bridge"
  | "system";

export interface SectionDef {
  id: Section;
  label: string;
  description: string;
  icon: LucideIcon;
  group: SectionGroup;
  roles: UserRole[];
  badge?: string;
  use: string;
  connections: string[];
}

export const GROUP_ORDER: { id: SectionGroup; label: string }[] = [
  { id: "overview", label: "Overview" },
  { id: "core", label: "Core" },
  { id: "live", label: "Live & Players" },
  { id: "marketing", label: "Marketing" },
  { id: "money", label: "Money" },
  { id: "operations", label: "Game Ops" },
  { id: "compliance", label: "Compliance" },
  { id: "bridge", label: "Casino Bridge" },
  { id: "system", label: "System" },
];

const ALL: UserRole[] = ["finance", "controller", "super_admin"];

export const SECTIONS: Record<Section, SectionDef> = {
  lobby: {
    id: "lobby", label: "Overview", description: "Cross-platform summary & quick navigation", icon: Gauge, group: "overview", roles: ALL,
    use: "Landing view of the whole platform. Click any card to jump to that section; use the search box and category chips to narrow the grid. The KPI strip shows the most critical live numbers.",
    connections: ["/api/live-map", "/api/live-players", "/api/wallets", "/api/notifications", "/api/api-hub", "/api/vendors", "/api/blockchain", "/api/ml-pipeline", "/api/auth", "/api/payments"],
  },
  dashboard: {
    id: "dashboard", label: "Dashboard", description: "Live Casino KPIs — players, cash, bets, house profit", icon: LayoutDashboard, group: "core", roles: ALL, badge: "LIVE",
    use: "Top-level health of the live Casino at www.tols.fun: registered players, signups in the last 24 hours, wallet balances, deposits, the pending withdrawal queue, recent betting volume and house profit. Every number is fetched from the Casino platform API in real time.",
    connections: ["Casino GET /api/platform/overview", "Casino GET /api/platform/stats"],
  },
  financial: {
    id: "financial", label: "Financial", description: "Escrow, waterfall & variance alerts", icon: DollarSign, group: "core", roles: ["finance", "super_admin"],
    use: "The money engine: escrow settlement schedule, waterfall distribution across tiers, internal ledger, budget targets and variance alerts against expected values.",
    connections: ["/api/financial", "/api/escrow", "/api/waterfall", "/api/budget", "/api/variance"],
  },

  "live-map": {
    id: "live-map", label: "Live Map", description: "Real-time geo activity on a real map", icon: Globe, group: "live", roles: ["controller", "super_admin"], badge: "LIVE",
    use: "A real Leaflet map plotting live sessions, server nodes and recent events at their true coordinates. The data panels below the map are collapsed by default — click each to expand.",
    connections: ["/api/live-map", "CARTO dark-matter tiles (NEXT_PUBLIC_MAP_TILE_URL)"],
  },
  "live-players": {
    id: "live-players", label: "Live Players", description: "Sessions, devices & engagement", icon: Activity, group: "live", roles: ["controller", "super_admin"], badge: "LIVE",
    use: "Who is playing right now: active sessions, device/browser split, engagement and session duration.",
    connections: ["/api/live-players", "/api/player-tracking"],
  },
  players: {
    id: "players", label: "Players", description: "Live Casino accounts — search, block, unblock", icon: Users, group: "live", roles: ALL, badge: "LIVE",
    use: "Registrations and player management straight from the Casino: search by username, email or id, filter by status, and block or unblock an account. Blocking takes effect on www.tols.fun immediately (active sessions are terminated).",
    connections: ["Casino GET /api/platform/users", "Casino PATCH /api/platform/users/:id"],
  },

  segments: {
    id: "segments", label: "Segments", description: "Player segmentation & rules", icon: PieChart, group: "marketing", roles: ALL,
    use: "Build dynamic player segments with rule filters; segment membership drives promotions and CRM targeting.",
    connections: ["/api/segments"],
  },
  promotions: {
    id: "promotions", label: "Promotions", description: "Casino lobby cards — publish live", icon: Gift, group: "marketing", roles: ALL, badge: "LIVE",
    use: "The Casino's live promotion and game cards. Edit titles, taglines and rewards, toggle visibility, or create new cards — every save publishes straight to the www.tols.fun lobby through the platform bridge.",
    connections: ["Casino GET /api/platform/promotions", "Casino PUT /api/platform/promotions"],
  },
  affiliates: {
    id: "affiliates", label: "Affiliates", description: "Partners & commissions", icon: Link2, group: "marketing", roles: ["finance", "super_admin"],
    use: "Manage affiliate partners, commission tiers and payout tracking.",
    connections: ["/api/affiliates"],
  },
  cms: {
    id: "cms", label: "Marketing CMS", description: "Content published to the casino lobby", icon: Megaphone, group: "marketing", roles: ["super_admin"], badge: "CMS",
    use: "Edit the promotions (hero carousel / promo strip) and game entries the casino lobby renders. Published live over the JWT bridge — the casino pulls with content:read.",
    connections: ["/api/cms/promotions", "/api/cms/games", "Casino /api/platform/content (scope content:read)"],
  },

  wallets: {
    id: "wallets", label: "Wallets", description: "Live Casino balances — credit & debit", icon: Wallet, group: "money", roles: ["finance", "super_admin"], badge: "LIVE",
    use: "Every player wallet on the Casino: real balance, bonus balance, wagering remaining, VIP level and lifetime volume. Manual adjustments credit or debit the REAL balance on www.tols.fun instantly, with a reason recorded in the Casino audit trail.",
    connections: ["Casino GET /api/platform/wallets", "Casino POST /api/platform/wallets/adjust"],
  },
  payments: {
    id: "payments", label: "Cash Flow", description: "Deposits, withdrawals queue & house P&L", icon: CreditCard, group: "money", roles: ["finance", "super_admin"], badge: "LIVE",
    use: "The Casino's money engine in one place: the on-chain deposit ledger, the withdrawal queue with approve/reject decisions that settle on the Casino immediately (rejections refund the wallet), and house profit & loss from settled wagers.",
    connections: ["Casino GET /api/platform/cashflow", "Casino GET /api/platform/deposits", "Casino GET /api/platform/withdrawals", "Casino POST /api/platform/withdrawals/:id/approve|reject"],
  },
  bets: {
    id: "bets", label: "Bets", description: "Settled wagers from the live Casino", icon: Dice5, group: "money", roles: ["finance", "controller", "super_admin"], badge: "LIVE",
    use: "Every settled wager on the Casino: stake, multiplier, payout and result, filterable by game, player and outcome. Use it to audit game behaviour and cross-check RTP.",
    connections: ["Casino GET /api/platform/bets"],
  },
  blockchain: {
    id: "blockchain", label: "Blockchain", description: "Crypto wallets, txs & smart contracts", icon: Blocks, group: "money", roles: ["controller", "super_admin"],
    use: "On-chain view: hot/cold wallets, networks, transactions and smart contracts.",
    connections: ["/api/blockchain"],
  },

  rtp: {
    id: "rtp", label: "RTP & Game Controls", description: "Live house-edge bias per game", icon: SlidersHorizontal, group: "operations", roles: ["controller", "super_admin"], badge: "LIVE",
    use: "Monitor and steer every Casino game: base RTP vs actual over the last 1000 bets, and the house-edge bias control (1 = fair, below 1 colder, above 1 hotter, range 0–2). Setting or resetting a bias updates the live game engine on www.tols.fun.",
    connections: ["Casino GET /api/platform/rtp", "Casino PUT /api/platform/rtp"],
  },
  vendors: {
    id: "vendors", label: "Vendors", description: "Game providers & integrations", icon: Server, group: "operations", roles: ALL,
    use: "Game providers and platform integrations (aggregators, live casino, payments), including callback health.",
    connections: ["/api/vendors"],
  },
  "ml-pipeline": {
    id: "ml-pipeline", label: "ML Pipeline", description: "Models, predictions & training", icon: Brain, group: "operations", roles: ["controller", "super_admin"], badge: "ML",
    use: "Machine-learning models (churn, revenue forecast, fraud), their predictions and training jobs.",
    connections: ["/api/ml-pipeline"],
  },
  "ai-tutor": {
    id: "ai-tutor", label: "AI Tutor", description: "Intelligent operator assistant", icon: Bot, group: "operations", roles: ALL, badge: "AI",
    use: "Ask the assistant natural-language questions about platform data; it answers with context from the sections.",
    connections: ["/api/ai-tutor"],
  },
  notifications: {
    id: "notifications", label: "Notifications", description: "Alert center, preferences & channels", icon: Bell, group: "operations", roles: ALL,
    use: "Alert center with channels (in-app, email, Telegram), priorities and read state.",
    connections: ["/api/notifications"],
  },

  kyc: {
    id: "kyc", label: "KYC / Verification", description: "Identity verification queue", icon: BadgeCheck, group: "compliance", roles: ["super_admin"], badge: "KYC",
    use: "Review identity-verification requests: approve, reject or request more documents. Verified players can withdraw real money.",
    connections: ["/api/kyc"],
  },
  responsible: {
    id: "responsible", label: "Responsible Gaming", description: "Self-exclusion & limits", icon: LifeBuoy, group: "compliance", roles: ["super_admin"],
    use: "Responsible-gaming controls: active self-exclusions, deposit/wager/loss/session limits, and players flagged for intervention.",
    connections: ["/api/responsible-gaming"],
  },
  risk: {
    id: "risk", label: "Risk & Fraud", description: "AML flags & suspicious activity", icon: ShieldAlert, group: "compliance", roles: ["controller", "super_admin"], badge: "AML",
    use: "Anti-money-laundering and fraud signals: flagged players, suspicious deposits/withdrawals, and multi-account links. Review and escalate.",
    connections: ["/api/risk"],
  },
  legal: {
    id: "legal", label: "Legal", description: "Contracts, audit & compliance", icon: Scale, group: "compliance", roles: ["super_admin"],
    use: "Contracts, DocuSign envelopes, audit trail and compliance status.",
    connections: ["/api/legal"],
  },

  casino: {
    id: "casino", label: "Casino Link", description: "Connection status, checks & event feed", icon: PlugZap, group: "bridge", roles: ALL, badge: "LINK",
    use: "The single connection panel for the Governance ⇄ Casino bridge: live/offline with latency from the Casino health probe, the RS256 JWT whoami check, the HMAC webhook ping (pong), and the feed of signed events the Casino has delivered to this project. All configuration is environment-backed on Vercel.",
    connections: [
      "Casino GET /api/platform/health (public heartbeat)",
      "Casino GET /api/platform/whoami (RS256 JWT check)",
      "Casino POST /api/bridge/webhook (HMAC commands + ping)",
      "Governance /api/platform/webhooks ← signed Casino events",
    ],
  },

  auth: {
    id: "auth", label: "Auth & Security", description: "Users, roles, sessions & permissions", icon: Shield, group: "system", roles: ["super_admin"],
    use: "Operators, roles and permissions, active sessions, 2FA and password policy.",
    connections: ["/api/auth"],
  },
  "api-hub": {
    id: "api-hub", label: "API Hub", description: "Tokens, webhooks & MCP", icon: Zap, group: "system", roles: ["super_admin"], badge: "API",
    use: "Manage API tokens and scopes, webhook endpoints, and MCP tool integrations for external services.",
    connections: ["/api/api-hub"],
  },
};

export const ALL_SECTIONS: SectionDef[] = Object.values(SECTIONS);

export function isSectionVisible(def: SectionDef, role: UserRole): boolean {
  return def.roles.includes(role);
}

export function sectionsByGroup(role: UserRole): { group: SectionGroup; label: string; items: SectionDef[] }[] {
  return GROUP_ORDER.map((g) => ({
    group: g.id,
    label: g.label,
    items: ALL_SECTIONS.filter((s) => s.group === g.id && isSectionVisible(s, role)),
  })).filter((g) => g.items.length > 0);
}

export function sectionsForRole(role: UserRole, exclude: Section[] = []): SectionDef[] {
  return ALL_SECTIONS.filter((s) => !exclude.includes(s.id) && isSectionVisible(s, role));
}
