'use client'

// ─────────────────────────────────────────────────────────────────────────────
// settings-store — operator preferences, persisted to localStorage and APPLIED.
//
// Unlike the old settings dialog (pure local state that reset on close and did
// nothing), every value here:
//   • survives reloads (zustand persist → localStorage), and
//   • is actually applied (theme toggles the root class, compact mode changes
//     the content density, currency drives the formatters).
// ─────────────────────────────────────────────────────────────────────────────

import { create } from 'zustand'
import { persist } from 'zustand/middleware'

export type ThemePref = 'dark' | 'light'
export type CurrencyPref = 'USD' | 'EUR' | 'GBP' | 'BTC'

export interface SettingsState {
  // Appearance
  theme: ThemePref
  compact: boolean
  showDecimals: boolean
  // Locale
  language: string
  timezone: string
  dateFormat: string
  currency: CurrencyPref
  // Behavior
  autoRefresh: boolean
  refreshInterval: number
  rowsPerPage: number
  // Alerts
  emailNotifs: boolean
  pushNotifs: boolean
  soundNotifs: boolean
  criticalOnly: boolean
  varianceAlerts: boolean
  // Security
  sessionTimeout: number
  auditLog: boolean

  set: <K extends keyof SettingsState>(key: K, value: SettingsState[K]) => void
  patch: (partial: Partial<SettingsState>) => void
  reset: () => void
}

const DEFAULTS = {
  theme: 'dark' as ThemePref,
  compact: false,
  showDecimals: true,
  language: 'en',
  timezone: 'UTC',
  dateFormat: 'YYYY-MM-DD',
  currency: 'USD' as CurrencyPref,
  autoRefresh: true,
  refreshInterval: 15,
  rowsPerPage: 25,
  emailNotifs: true,
  pushNotifs: false,
  soundNotifs: false,
  criticalOnly: false,
  varianceAlerts: true,
  sessionTimeout: 30,
  auditLog: true,
}

export const useSettingsStore = create<SettingsState>()(
  persist(
    (set) => ({
      ...DEFAULTS,
      set: (key, value) => set({ [key]: value } as Partial<SettingsState>),
      patch: (partial) => set(partial),
      reset: () => set(DEFAULTS),
    }),
    { name: 'tols-governance-settings' },
  ),
)

/** Format a currency amount according to the operator's currency preference. */
export function formatCurrency(value: number, currency: CurrencyPref, showDecimals = true): string {
  const digits = showDecimals ? 2 : 0
  if (currency === 'BTC') {
    return `₿ ${value.toLocaleString('en-US', { maximumFractionDigits: 6 })}`
  }
  return value.toLocaleString('en-US', {
    style: 'currency',
    currency,
    minimumFractionDigits: digits,
    maximumFractionDigits: digits,
  })
}
