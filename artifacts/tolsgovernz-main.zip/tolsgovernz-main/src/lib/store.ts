// App state — section navigation, operator role, sidebar collapse.
// Section/role TYPES live in src/lib/sections.ts (single source of truth) and
// are re-exported here for backward-compatible imports.
import { create } from 'zustand'
import type { Section, UserRole } from '@/lib/sections'

export type { Section, UserRole } from '@/lib/sections'

interface AppState {
  activeSection: Section
  setActiveSection: (section: Section) => void
  activeRole: UserRole
  setActiveRole: (role: UserRole) => void
  sidebarCollapsed: boolean
  toggleSidebar: () => void
}

export const useAppStore = create<AppState>((set) => ({
  activeSection: 'lobby',
  setActiveSection: (section) => set({ activeSection: section }),
  activeRole: 'super_admin',
  setActiveRole: (role) => set({ activeRole: role }),
  sidebarCollapsed: false,
  toggleSidebar: () => set((state) => ({ sidebarCollapsed: !state.sidebarCollapsed })),
}))
