# TOLS Operator Bot — private Telegram console for the bridge

A private, zero-dependency Telegram bot that lets an operator run the
**Governance ↔ Casino** bridge from a phone chat:

| Command | Action |
| --- | --- |
| `/status` | Governance + casino bridge connectivity |
| `/stats` | Casino aggregate stats (users, bets, deposits, withdrawals) |
| `/deposits` | Recent deposits (real casino data over the bridge) |
| `/withdrawals` | Pending withdrawals with **✅ Approve / ❌ Reject** buttons |
| `/payments` | Payments / treasury summary |
| `/approve <id> <txHash>` | Approve a withdrawal (after broadcasting the payout) |
| `/reject <id> [reason]` | Reject a withdrawal & refund the player |
| `/cancel` | Cancel a pending approve |

The bot talks **only** to the Governance controller routes (`/api/platform/*`).
Those routes require the machine token (`GOVERNANCE_ADMIN_TOKEN`) and, behind
the scenes, sign an RS256 JWT and forward to the casino platform — so the bot
inherits the bridge's auth, scopes and fail-closed behaviour for free. It never
speaks to the casino directly and never holds a secret beyond the admin token.

## Setup

1. **Create the bot** — chat with [@BotFather](https://t.me/BotFather):
   - `/newbot` → name + username → copy the **token**.
   - (Optional) `/setcommands` with the list above.
2. **Whitelist operators** — send `/start` to [@userinfobot](https://t.me/userinfobot)
   and copy the numeric `Id` for each operator.
3. **Configure** — `cp telegram-bot/.env.example telegram-bot/.env` and fill in:
   - `TELEGRAM_BOT_TOKEN`
   - `TELEGRAM_ADMIN_IDS` (comma-separated ids)
   - `GOVERNANCE_URL` (`http://localhost:3000` locally, or `https://gov.tols.fun`)
   - `GOVERNANCE_ADMIN_TOKEN` (same value as on Governance)
4. **Run** (long-polling, needs a persistent host — a small VPS/Dokploy):
   ```bash
   cd telegram-bot && node index.mjs
   ```

## Webhook mode (optional)

On a self-hosted box you can switch to webhooks instead of long-polling:

```bash
WEBHOOK_URL=https://your-host.example/telegram \
TELEGRAM_WEBHOOK_SECRET=$(openssl rand -hex 16) \
TELEGRAM_WEBHOOK_PORT=4001 \
node index.mjs
```

The receiver verifies the `X-Telegram-Bot-Api-Secret-Token` header in constant
time and refuses everything else.

## Security model

- **Private by whitelist** — only chats whose numeric user id is in
  `TELEGRAM_ADMIN_IDS` are answered; everyone else gets `⛔ Unauthorized`.
- **No secrets in chat** — the bot holds only `GOVERNANCE_ADMIN_TOKEN`; the JWT
  private key stays on Governance.
- **Approve is two-step** — approving a withdrawal prompts for the on-chain
  payout `txHash`, so an accidental tap can't pay out without the operator
  broadcasting the transaction first.
- **Webhook secret** — constant-time comparison of the Telegram secret header.
- **Fail-closed** — if Governance/bridge is down or misconfigured, the bot
  reports the error instead of guessing.

## Offline test (no Telegram token needed)

`test.mjs` spins up a mock Governance server and drives the bot's pure logic
with canned Telegram updates, asserting the right calls happen:

```bash
node telegram-bot/test.mjs
```

To dry-run the real runner against a live Governance (bridge must be up):

```bash
TELEGRAM_MOCK=1 node telegram-bot/index.mjs   # reads mock-updates.json
```

## Notes

- The casino backend (`tols-casino-next`) already exposes the full platform
  surface (`/api/platform/health|whoami|deposits|withdrawals|approve|reject|
  payments|stats`) and verifies Governance's signed JWT — no casino-side change
  is needed for this bot.
- The bridge only returns real data once the two platforms have exchanged
  public keys (see `docs/PLATFORM_INTEGRATION.md`). Until then `/status` reports
  the bridge offline and the data commands surface that error.
