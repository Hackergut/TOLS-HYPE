// ─────────────────────────────────────────────────────────────────────────────
// TOLS Operator Bot — pure command/callback logic.
//
// This module is side-effect free: `handleUpdate` turns a Telegram update into
// a list of Telegram API "actions" (sendMessage / editMessageText /
// answerCallbackQuery). The runner (index.mjs long-polling, or a webhook) is
// responsible for executing them against api.telegram.org. Because the logic
// is pure, test.mjs can drive it with canned updates + a mock GovClient.
//
// Every command is gated on the chat being a whitelisted operator chat.
// ─────────────────────────────────────────────────────────────────────────────

const HELP = [
  "🤖 <b>TOLS Operator Bot</b> — private bridge console",
  "",
  "<b>Overview</b>",
  "/status — bridge + casino connectivity",
  "/stats — casino aggregate stats",
  "/deposits — recent deposits",
  "/withdrawals — pending withdrawals (approve/reject)",
  "/payments — payments summary",
  "",
  "<b>Withdrawal actions</b>",
  "/approve &lt;id&gt; &lt;txHash&gt; — approve after broadcasting payout",
  "/reject &lt;id&gt; [reason] — reject &amp; refund",
  "/cancel — cancel a pending approve",
  "",
  "ℹ️ Use the inline buttons under each withdrawal for one-tap reject or a guided approve.",
].join("\n");

const START = [
  "👋 <b>TOLS Operator Bot</b>",
  "",
  "Private bridge console for the TOLS casino platform. I read real casino data through the Governance bridge and let you action pending withdrawals from your phone.",
  "",
  "Send /help for the command list.",
].join("\n");

function esc(s) {
  return String(s ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function money(n, currency = "USD") {
  const v = Number(n ?? 0);
  const isCrypto = !["USD", "EUR", "GBP"].includes(currency);
  const digits = isCrypto ? 6 : 2;
  const s = v.toLocaleString("en-US", { minimumFractionDigits: digits, maximumFractionDigits: digits });
  return `${s} ${currency}`;
}

function shortId(id) {
  const s = String(id ?? "");
  return s.length > 10 ? `…${s.slice(-8)}` : s;
}

const STATUS_ICON = { pending: "⏳", approved: "✅", completed: "✅", rejected: "❌", failed: "⚠️" };

/**
 * @param {object} opts
 * @param {import('./gov-client.mjs').GovClient} opts.gov
 * @param {Set<number>|Array<number>} opts.adminIds  whitelisted Telegram user ids
 * @param {(level: string, msg: string) => void} [opts.log]
 */
export function createBot({ gov, adminIds, log = () => {} }) {
  const admins = new Set(adminIds.map((id) => Number(id)));
  /** @type {Map<number, { id: string; amount: number; currency: string }>} */
  const pendingApprove = new Map();

  const isAdmin = (chatId) => admins.has(Number(chatId));

  const deny = (chatId) => [
    { method: "sendMessage", chat_id: chatId, text: "⛔ Unauthorized. This is a private operator bot.", parse_mode: "HTML" },
  ];

  function helpMsg(chatId) {
    return [{ method: "sendMessage", chat_id: chatId, text: HELP, parse_mode: "HTML" }];
  }

  function startMsg(chatId) {
    return [{ method: "sendMessage", chat_id: chatId, text: START, parse_mode: "HTML" }];
  }

  async function status(chatId) {
    const lines = [];
    try {
      const health = await gov.health();
      lines.push("🟢 <b>Governance</b>: " + esc(health?.platform ?? "ok") + " — " + esc(health?.ts ?? ""));
    } catch (e) {
      lines.push("🔴 <b>Governance</b>: " + esc(e.message));
    }
    try {
      const conn = await gov.connection();
      if (conn?.ok) {
        lines.push("🟢 <b>Casino bridge</b>: connected" + (conn.claims?.iss ? ` — verified partner ${esc(conn.claims.iss)}` : ""));
        if (conn.health?.platform) lines.push("   casino platform: " + esc(conn.health.platform));
      } else {
        lines.push("🟠 <b>Casino bridge</b>: " + esc(conn?.error ?? "offline"));
        lines.push("   → complete the key exchange (PARTNER_PUBLIC_KEY / casino PLATFORM_JWT_PUBLIC_KEY) to activate.");
      }
    } catch (e) {
      lines.push("🔴 <b>Casino bridge</b>: " + esc(e.message));
    }
    return [{ method: "sendMessage", chat_id: chatId, text: lines.join("\n"), parse_mode: "HTML" }];
  }

  async function stats(chatId) {
    try {
      const s = await gov.stats();
      const bets = s?.bets ?? {};
      const deposits = s?.deposits ?? {};
      const withdrawals = s?.withdrawals ?? {};
      const text = [
        "📊 <b>Casino stats</b> (live)",
        `👥 Users: ${s?.users ?? 0}`,
        `🎰 Bets: ${bets.count ?? 0} · wagered ${money(bets.wagered)} · paid ${money(bets.payout)}`,
        `💵 Deposits: ${deposits.count ?? 0} · total ${money(deposits.total)}`,
        `🏧 Withdrawals pending: ${withdrawals.pendingCount ?? 0} · ${money(withdrawals.pendingAmount)}`,
      ].join("\n");
      return [{ method: "sendMessage", chat_id: chatId, text, parse_mode: "HTML" }];
    } catch (e) {
      return [{ method: "sendMessage", chat_id: chatId, text: "⚠️ " + esc(e.message), parse_mode: "HTML" }];
    }
  }

  async function deposits(chatId, n = 5) {
    const limit = Math.min(20, Math.max(1, Number(n) || 5));
    try {
      const rows = await gov.deposits();
      const list = Array.isArray(rows) ? rows : [];
      if (!list.length) return [{ method: "sendMessage", chat_id: chatId, text: "No deposits yet." }];
      const lines = ["💵 <b>Recent deposits</b>"];
      for (const d of list.slice(0, limit)) {
        lines.push(`• ${esc(d.username ?? d.userId)} — ${money(d.amount, d.currency)} [${esc(d.status)}] ${esc(d.chain ?? "")}`);
      }
      return [{ method: "sendMessage", chat_id: chatId, text: lines.join("\n"), parse_mode: "HTML" }];
    } catch (e) {
      return [{ method: "sendMessage", chat_id: chatId, text: "⚠️ " + esc(e.message), parse_mode: "HTML" }];
    }
  }

  async function withdrawals(chatId) {
    try {
      const rows = await gov.withdrawals("pending");
      const list = Array.isArray(rows) ? rows : [];
      if (!list.length) {
        return [{ method: "sendMessage", chat_id: chatId, text: "✅ No pending withdrawals." }];
      }
      const actions = [];
      actions.push({
        method: "sendMessage",
        chat_id: chatId,
        text: `⏳ <b>${list.length} pending withdrawal(s)</b>\nTap ✅ to approve (asks for txHash) or ❌ to reject.`,
        parse_mode: "HTML",
      });
      for (const w of list.slice(0, 20)) {
        const icon = STATUS_ICON[w.status] ?? "❔";
        const text = [
          `${icon} <b>${money(w.amount, w.currency)}</b> → ${esc(w.username ?? w.userId)}`,
          `id: ${esc(shortId(w.id))} · ${esc(w.chain ?? "")}`,
          `address: <code>${esc(w.walletAddress ?? "")}</code>`,
        ].join("\n");
        actions.push({
          method: "sendMessage",
          chat_id: chatId,
          text,
          parse_mode: "HTML",
          reply_markup: {
            inline_keyboard: [
              [
                { text: "✅ Approve", callback_data: `appr:${w.id}` },
                { text: "❌ Reject", callback_data: `rej:${w.id}` },
              ],
            ],
          },
        });
      }
      return actions;
    } catch (e) {
      return [{ method: "sendMessage", chat_id: chatId, text: "⚠️ " + esc(e.message), parse_mode: "HTML" }];
    }
  }

  async function payments(chatId) {
    try {
      const p = await gov.payments();
      const s = p?.stats ?? p ?? {};
      const lines = [
        "💳 <b>Payments / treasury</b> (live)",
        `Deposits: ${money(s.totalDeposits)}`,
        `Withdrawals: ${money(s.totalWithdrawals)}`,
        `Pending deposits: ${s.pendingDeposits ?? 0} · pending withdrawals: ${s.pendingWithdrawals ?? 0}`,
        `Approval queue: ${s.approvalQueue ?? 0} · fees: ${money(s.totalFees)}`,
        `Success rate: ${s.successRate ?? 0}%`,
      ];
      return [{ method: "sendMessage", chat_id: chatId, text: lines.join("\n"), parse_mode: "HTML" }];
    } catch (e) {
      return [{ method: "sendMessage", chat_id: chatId, text: "⚠️ " + esc(e.message), parse_mode: "HTML" }];
    }
  }

  async function approve(chatId, id, txHash) {
    if (!id || !txHash) {
      return [{ method: "sendMessage", chat_id: chatId, text: "Usage: /approve &lt;id&gt; &lt;txHash&gt;", parse_mode: "HTML" }];
    }
    try {
      await gov.approve(id, txHash);
      return [{ method: "sendMessage", chat_id: chatId, text: `✅ Withdrawal ${esc(shortId(id))} approved.\nTx: <code>${esc(txHash)}</code>`, parse_mode: "HTML" }];
    } catch (e) {
      return [{ method: "sendMessage", chat_id: chatId, text: "⚠️ " + esc(e.message), parse_mode: "HTML" }];
    }
  }

  async function reject(chatId, id, reason) {
    if (!id) {
      return [{ method: "sendMessage", chat_id: chatId, text: "Usage: /reject &lt;id&gt; [reason]", parse_mode: "HTML" }];
    }
    try {
      await gov.reject(id, reason || "Rejected by operator via Telegram");
      return [{ method: "sendMessage", chat_id: chatId, text: `❌ Withdrawal ${esc(shortId(id))} rejected &amp; refunded.`, parse_mode: "HTML" }];
    } catch (e) {
      return [{ method: "sendMessage", chat_id: chatId, text: "⚠️ " + esc(e.message), parse_mode: "HTML" }];
    }
  }

  // ── Update handling ──────────────────────────────────────────────────────

  /**
   * @param {object} update Telegram Update
   * @returns {Promise<Array<object>>} actions to run against Telegram
   */
  async function handleUpdate(update) {
    if (update?.callback_query) {
      return handleCallback(update.callback_query);
    }
    if (update?.message) {
      return handleMessage(update.message);
    }
    return [];
  }

  async function handleMessage(msg) {
    const chatId = msg?.chat?.id;
    if (!chatId) return [];
    if (!isAdmin(chatId)) return deny(chatId);

    const text = (msg.text ?? "").trim();
    if (!text) return [];

    // A pending approve: the next free-text message is the payout txHash.
    if (!text.startsWith("/") && pendingApprove.has(chatId)) {
      const pending = pendingApprove.get(chatId);
      pendingApprove.delete(chatId);
      return approve(chatId, pending.id, text);
    }

    const [rawCmd, ...rest] = text.split(/\s+/);
    const cmd = rawCmd.toLowerCase().split("@")[0]; // strip @BotName
    const args = rest;

    switch (cmd) {
      case "/start":
        return startMsg(chatId);
      case "/help":
        return helpMsg(chatId);
      case "/status":
        return status(chatId);
      case "/stats":
        return stats(chatId);
      case "/deposits":
        return deposits(chatId, args[0] ? Number(args[0]) : 5);
      case "/withdrawals":
        return withdrawals(chatId);
      case "/payments":
        return payments(chatId);
      case "/approve":
        return approve(chatId, args[0], args.slice(1).join(" "));
      case "/reject":
        return reject(chatId, args[0], args.slice(1).join(" "));
      case "/cancel":
        pendingApprove.delete(chatId);
        return [{ method: "sendMessage", chat_id: chatId, text: "Cancelled." }];
      default:
        return [{ method: "sendMessage", chat_id: chatId, text: "Unknown command. Send /help.", parse_mode: "HTML" }];
    }
  }

  async function handleCallback(cb) {
    const chatId = cb?.message?.chat?.id ?? cb?.from?.id;
    const cbId = cb?.id;
    const data = cb?.data ?? "";
    const ack = cbId ? [{ method: "answerCallbackQuery", callback_query_id: cbId }] : [];

    if (!chatId) return ack;
    if (!isAdmin(chatId)) {
      return [...ack, ...deny(chatId)];
    }

    if (data.startsWith("appr:")) {
      const id = data.slice(5);
      // We need the withdrawal details for a nice prompt; fetch them.
      let info = null;
      try {
        const rows = await gov.withdrawals("pending");
        info = (Array.isArray(rows) ? rows : []).find((w) => w.id === id) ?? null;
      } catch {
        info = null;
      }
      pendingApprove.set(chatId, { id, amount: info?.amount ?? 0, currency: info?.currency ?? "USD" });
      const amt = info ? money(info.amount, info.currency) : "";
      return [
        ...ack,
        {
          method: "sendMessage",
          chat_id: chatId,
          text: `🟡 <b>Approve ${amt}</b> (${esc(shortId(id))})\nReply with the payout txHash, or send /cancel.`,
          parse_mode: "HTML",
        },
      ];
    }

    if (data.startsWith("rej:")) {
      const id = data.slice(4);
      return [...ack, ...(await reject(chatId, id, "Rejected by operator via Telegram"))];
    }

    return ack;
  }

  return { handleUpdate, isAdmin, pendingApprove };
}
