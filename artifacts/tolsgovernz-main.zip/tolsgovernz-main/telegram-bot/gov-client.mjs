// ─────────────────────────────────────────────────────────────────────────────
// Minimal HTTP client for the TOLS Governance controller endpoints.
//
// The governance `/api/platform/*` routes are the bridge to the casino:
// they require `Authorization: Bearer <GOVERNANCE_ADMIN_TOKEN>` and, under the
// hood, sign an RS256 JWT and forward to the casino platform. The bot only
// ever talks to Governance — never directly to the casino — so it inherits the
// bridge's authentication, scopes and fail-closed behaviour for free.
// ─────────────────────────────────────────────────────────────────────────────

export class GovClient {
  /**
   * @param {object} opts
   * @param {string} opts.baseUrl    e.g. "http://localhost:3000" or "https://gov.tols.fun"
   * @param {string} opts.adminToken GOVERNANCE_ADMIN_TOKEN
   * @param {number} [opts.timeoutMs]
   */
  constructor({ baseUrl, adminToken, timeoutMs = 10000 }) {
    this.baseUrl = String(baseUrl || "").replace(/\/+$/, "");
    this.adminToken = adminToken || "";
    this.timeoutMs = timeoutMs;
  }

  /** GET with auth + timeout. Returns { status, data } (data may be null). */
  async _req(method, path, body) {
    const url = `${this.baseUrl}${path}`;
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), this.timeoutMs);
    try {
      const res = await fetch(url, {
        method,
        headers: {
          Authorization: `Bearer ${this.adminToken}`,
          "Content-Type": "application/json",
          Accept: "application/json",
        },
        body: body === undefined ? undefined : JSON.stringify(body),
        signal: controller.signal,
        cache: "no-store",
      });
      const data = await res.json().catch(() => null);
      return { status: res.status, data };
    } finally {
      clearTimeout(timer);
    }
  }

  async _get(path) {
    return this._req("GET", path);
  }

  async _post(path, body) {
    return this._req("POST", path, body ?? {});
  }

  /** Unwrap the governance { success, data } envelope, throwing on failure. */
  static unwrap(res) {
    if (res.status === 401) throw new Error("Governance rejected the machine token (401) — check GOVERNANCE_ADMIN_TOKEN.");
    if (res.status === 503) throw new Error("Governance bridge/auth is not configured (503).");
    if (res.status >= 400) {
      const msg = res.data?.error || `Governance error (HTTP ${res.status})`;
      throw new Error(msg);
    }
    if (res.data && typeof res.data === "object" && res.data.success === false) {
      throw new Error(res.data.error || "Governance returned success:false");
    }
    return res.data?.data ?? res.data;
  }

  /** Governance liveness (public). */
  async health() {
    const res = await this._get("/api/platform/health");
    return res.data;
  }

  /** Bridge connectivity probe: casino health + verified JWT claims. */
  async connection() {
    const res = await this._get("/api/platform/connection");
    return GovClient.unwrap(res);
  }

  /** Casino deposit list (real data over the bridge). */
  async deposits() {
    const res = await this._get("/api/platform/deposits");
    return GovClient.unwrap(res);
  }

  /** Casino withdrawal list, optionally filtered by status. */
  async withdrawals(status) {
    const q = status ? `?status=${encodeURIComponent(status)}` : "";
    const res = await this._get(`/api/platform/withdrawals${q}`);
    return GovClient.unwrap(res);
  }

  /** Approve a withdrawal — requires the on-chain payout txHash. */
  async approve(id, txHash) {
    const res = await this._post(`/api/platform/withdrawals/${encodeURIComponent(id)}/approve`, { txHash });
    return GovClient.unwrap(res);
  }

  /** Reject a withdrawal — the casino refunds the player's wallet. */
  async reject(id, reason) {
    const res = await this._post(`/api/platform/withdrawals/${encodeURIComponent(id)}/reject`, { reason });
    return GovClient.unwrap(res);
  }

  /** Casino payments / treasury summary. */
  async payments() {
    const res = await this._get("/api/platform/payments");
    return GovClient.unwrap(res);
  }

  /** Casino aggregate stats (users, bets, deposits, withdrawals). */
  async stats() {
    const res = await this._get("/api/platform/stats");
    return GovClient.unwrap(res);
  }
}
