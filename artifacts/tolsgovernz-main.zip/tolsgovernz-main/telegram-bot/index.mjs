#!/usr/bin/env node
// ─────────────────────────────────────────────────────────────────────────────
// TOLS Operator Telegram bot — runner.
//
//   long-polling (default):  node telegram-bot/index.mjs
//   webhook (self-hosted):   WEBHOOK_URL=https://host/telegram node telegram-bot/index.mjs
//   mock (offline test):     TELEGRAM_MOCK=1 node telegram-bot/index.mjs
//
// Zero npm dependencies — uses Node's global fetch. Run it anywhere Node ≥ 18
// is available (a small VPS/Dokploy works; Vercel serverless does not keep a
// long-poll loop alive, so host it on a persistent box).
// ─────────────────────────────────────────────────────────────────────────────

import { readFileSync } from "node:fs";
import { createServer } from "node:http";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
import { createBot } from "./bot.mjs";
import { GovClient } from "./gov-client.mjs";

const __dirname = dirname(fileURLToPath(import.meta.url));

const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN || "";
const ADMIN_IDS = (process.env.TELEGRAM_ADMIN_IDS || "")
  .split(",")
  .map((s) => s.trim())
  .filter(Boolean)
  .map(Number)
  .filter((n) => Number.isFinite(n) && n > 0);
const GOV_URL = process.env.GOVERNANCE_URL || "http://localhost:3000";
const GOV_TOKEN = process.env.GOVERNANCE_ADMIN_TOKEN || "";
const POLL_TIMEOUT = Number(process.env.TELEGRAM_POLL_TIMEOUT || 25);
const SECRET_HEADER = process.env.TELEGRAM_WEBHOOK_SECRET || "";
const WEBHOOK_URL = process.env.WEBHOOK_URL || "";
const PORT = Number(process.env.TELEGRAM_WEBHOOK_PORT || 4001);

const log = (level, msg) => console.log(`[${new Date().toISOString()}] [${level}] ${msg}`);

function checkConfig() {
  const missing = [];
  if (!BOT_TOKEN) missing.push("TELEGRAM_BOT_TOKEN");
  if (!ADMIN_IDS.length) missing.push("TELEGRAM_ADMIN_IDS");
  if (!GOV_TOKEN) missing.push("GOVERNANCE_ADMIN_TOKEN");
  if (missing.length) {
    console.error(`❌ Missing config: ${missing.join(", ")}`);
    console.error("   See telegram-bot/.env.example");
    process.exit(1);
  }
}

const gov = new GovClient({ baseUrl: GOV_URL, adminToken: GOV_TOKEN });
const bot = createBot({ gov, adminIds: ADMIN_IDS, log });

// ── Telegram API ────────────────────────────────────────────────────────────

const TG = "https://api.telegram.org";

async function tg(method, payload) {
  const res = await fetch(`${TG}/bot${BOT_TOKEN}/${method}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  const data = await res.json().catch(() => null);
  if (!res.ok || data?.ok !== true) {
    log("warn", `Telegram ${method} failed: ${JSON.stringify(data?.description ?? res.status)}`);
    return null;
  }
  return data.result;
}

async function execAction(action) {
  switch (action.method) {
    case "sendMessage":
      await tg("sendMessage", action);
      break;
    case "editMessageText":
      await tg("editMessageText", action);
      break;
    case "answerCallbackQuery":
      await tg("answerCallbackQuery", action);
      break;
    default:
      log("warn", `Unknown action method: ${action.method}`);
  }
}

async function processUpdate(update) {
  try {
    const actions = await bot.handleUpdate(update);
    for (const a of actions) await execAction(a);
  } catch (e) {
    log("error", `Update handling failed: ${e.message}`);
  }
}

// ── Long polling ────────────────────────────────────────────────────────────

async function longPoll() {
  let offset = 0;
  log("info", `Long-polling as bot (admins: ${ADMIN_IDS.join(", ")}) → ${GOV_URL}`);
  // eslint-disable-next-line no-constant-condition
  while (true) {
    try {
      const updates = await tg("getUpdates", { offset, timeout: POLL_TIMEOUT, allowed_updates: ["message", "callback_query"] });
      if (Array.isArray(updates)) {
        for (const u of updates) {
          offset = u.update_id + 1;
          await processUpdate(u);
        }
      }
    } catch (e) {
      log("error", `getUpdates failed: ${e.message} (retrying in 3s)`);
      await sleep(3000);
    }
  }
}

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

// ── Webhook mode (self-hosted) ──────────────────────────────────────────────

function safeEqual(a, b) {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

async function webhookMode() {
  await tg("setWebhook", { url: WEBHOOK_URL, secret_token: SECRET_HEADER || undefined });
  log("info", `Webhook set to ${WEBHOOK_URL}`);

  const server = createServer((req, res) => {
    if (req.method !== "POST" || req.url !== "/telegram") {
      res.writeHead(404).end();
      return;
    }
    const provided = String(req.headers["x-telegram-bot-api-secret-token"] ?? "");
    if (SECRET_HEADER && !safeEqual(provided, SECRET_HEADER)) {
      res.writeHead(401).end("unauthorized");
      return;
    }
    let body = "";
    req.on("data", (c) => (body += c));
    req.on("end", () => {
      res.writeHead(200, { "Content-Type": "application/json" }).end('{"ok":true}');
      try {
        processUpdate(JSON.parse(body));
      } catch (e) {
        log("error", `webhook parse failed: ${e.message}`);
      }
    });
  });
  server.listen(PORT, "0.0.0.0", () => log("info", `Webhook receiver listening on :${PORT}`));
}

// ── Mock mode (offline self-test against a real Governance) ─────────────────

async function mockMode() {
  const file = resolve(__dirname, process.env.TELEGRAM_MOCK_FILE || "mock-updates.json");
  log("info", `Mock mode: reading updates from ${file}`);
  let updates;
  try {
    updates = JSON.parse(readFileSync(file, "utf8"));
  } catch (e) {
    console.error(`❌ Cannot read mock updates file: ${file}`);
    process.exit(1);
  }
  for (const u of updates) {
    const actions = await bot.handleUpdate(u);
    console.log("\n── update:", JSON.stringify(u).slice(0, 140));
    for (const a of actions) {
      console.log("  →", a.method, "|", (a.text ?? "").replace(/\n/g, " ").slice(0, 160) || a.callback_query_id);
    }
  }
  log("info", "Mock run complete.");
}

// ── Main ────────────────────────────────────────────────────────────────────

checkConfig();

if (process.env.TELEGRAM_MOCK === "1") {
  mockMode().catch((e) => {
    console.error(e);
    process.exit(1);
  });
} else if (WEBHOOK_URL) {
  webhookMode().catch((e) => {
    console.error(e);
    process.exit(1);
  });
} else {
  longPoll().catch((e) => {
    console.error(e);
    process.exit(1);
  });
}
