// ─────────────────────────────────────────────────────────────────────────────
// Offline self-test for the TOLS Operator bot.
//
// Starts a mock Governance HTTP server (with the /api/platform/* envelope the
// real controller routes produce), then drives createBot().handleUpdate with
// canned Telegram updates and asserts the expected actions + governance calls.
//
//   node telegram-bot/test.mjs
// ─────────────────────────────────────────────────────────────────────────────

import { createServer } from "node:http";
import { createBot } from "./bot.mjs";
import { GovClient } from "./gov-client.mjs";

const ADMIN_ID = 123456789;
const INTRUDER = 999999999;

// ── Mock Governance ──────────────────────────────────────────────────────────

const withdrawals = [
  {
    id: "wd-real-1", userId: "u-9003", username: "RealPlayer_C", email: "c@casino.io",
    amount: 2000, currency: "USD", chain: "bank", walletAddress: "iban-1234", status: "pending",
    txHash: "", balanceBefore: 9000, balanceAfter: 7000, processedDate: null,
    createdAt: new Date().toISOString(),
  },
];

const calls = []; // record of governance requests: {method, path, body}

const server = createServer((req, res) => {
  const url = new URL(req.url, "http://x");
  let body = "";
  req.on("data", (c) => (body += c));
  req.on("end", () => {
    const parsed = body ? JSON.parse(body || "{}") : {};
    calls.push({ method: req.method, path: url.pathname + url.search, body: parsed });
    const json = (o, status = 200) => {
      res.writeHead(status, { "content-type": "application/json" });
      res.end(JSON.stringify(o));
    };
    if (req.headers.authorization !== "Bearer test-admin-token") {
      return json({ success: false, error: "Unauthorized" }, 401);
    }
    if (url.pathname === "/api/platform/health") return json({ ok: true, platform: "tols-governance", ts: new Date().toISOString() });
    if (url.pathname === "/api/platform/connection") return json({ success: true, data: { ok: true, health: { ok: true, platform: "tols-casino" }, claims: { iss: "tols-casino", aud: "tols-governance" } } });
    if (url.pathname === "/api/platform/stats") return json({ success: true, data: { users: 1234, bets: { count: 9000, wagered: 450000, payout: 430000 }, deposits: { count: 500, total: 120000 }, withdrawals: { pendingCount: 1, pendingAmount: 2000 } } });
    if (url.pathname === "/api/platform/deposits") return json({ success: true, data: [{ id: "dep-real-1", userId: "u-9001", username: "RealPlayer_A", email: "a@casino.io", chain: "ethereum", txHash: "0xREAL1", amount: 1.5, amountUsd: 4500, currency: "ETH", status: "confirmed", credited: true, createdAt: new Date().toISOString() }] });
    if (url.pathname === "/api/platform/withdrawals") return json({ success: true, data: withdrawals });
    if (url.pathname === "/api/platform/payments") return json({ success: true, data: { stats: { totalDeposits: 120000, totalWithdrawals: 2000, pendingDeposits: 2, pendingWithdrawals: 1, approvalQueue: 1, totalFees: 500, successRate: 96.4 } } });
    if (url.pathname === "/api/platform/withdrawals/wd-real-1/approve") return json({ success: true, data: { approved: true } });
    if (url.pathname === "/api/platform/withdrawals/wd-real-1/reject") return json({ success: true, data: { rejected: true } });
    return json({ success: false, error: "not found" }, 404);
  });
});

// ── Assertions ───────────────────────────────────────────────────────────────

let failures = 0;
function assert(cond, label) {
  if (cond) console.log("  ✅", label);
  else {
    failures++;
    console.error("  ❌", label);
  }
}

const gov = new GovClient({ baseUrl: "http://127.0.0.1:PORT", adminToken: "test-admin-token" });

await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
gov.baseUrl = `http://127.0.0.1:${server.address().port}`;

const bot = createBot({ gov, adminIds: [ADMIN_ID], log: () => {} });

console.log("\n— auth: admin allowed, intruder denied —");
const startActions = await bot.handleUpdate({ message: { chat: { id: ADMIN_ID }, from: { id: ADMIN_ID }, text: "/start" } });
assert(startActions.length === 1 && startActions[0].method === "sendMessage", "admin /start → sendMessage");

const intruder = await bot.handleUpdate({ message: { chat: { id: INTRUDER }, from: { id: INTRUDER }, text: "/stats" } });
assert(intruder.length === 1 && intruder[0].text.includes("Unauthorized"), "intruder /stats → denied");

console.log("\n— status/stats/deposits/payments —");
const statusActs = await bot.handleUpdate({ message: { chat: { id: ADMIN_ID }, from: { id: ADMIN_ID }, text: "/status" } });
assert(statusActs[0].text.includes("Casino bridge") && statusActs[0].text.includes("connected"), "/status reports bridge connected");

const statsActs = await bot.handleUpdate({ message: { chat: { id: ADMIN_ID }, from: { id: ADMIN_ID }, text: "/stats" } });
assert(statsActs[0].text.includes("1234") && statsActs[0].text.includes("wagered"), "/stats shows casino stats");

const depActs = await bot.handleUpdate({ message: { chat: { id: ADMIN_ID }, from: { id: ADMIN_ID }, text: "/deposits" } });
assert(depActs[0].text.includes("RealPlayer_A"), "/deposits lists real deposit");

const payActs = await bot.handleUpdate({ message: { chat: { id: ADMIN_ID }, from: { id: ADMIN_ID }, text: "/payments" } });
assert(payActs[0].text.includes("120,000") || payActs[0].text.includes("120000"), "/payments shows totals");

console.log("\n— withdrawals + approve/reject flow —");
const wdActs = await bot.handleUpdate({ message: { chat: { id: ADMIN_ID }, from: { id: ADMIN_ID }, text: "/withdrawals" } });
const kb = wdActs.find((a) => a.reply_markup);
assert(!!kb, "/withdrawals returns inline keyboard");
const approveBtn = kb?.reply_markup?.inline_keyboard?.[0]?.[0];
const rejectBtn = kb?.reply_markup?.inline_keyboard?.[0]?.[1];
assert(approveBtn?.callback_data === "appr:wd-real-1" && rejectBtn?.callback_data === "rej:wd-real-1", "buttons carry appr/rej callbacks");

const approvePrompt = await bot.handleUpdate({ callback_query: { id: "cb1", from: { id: ADMIN_ID }, message: { chat: { id: ADMIN_ID } }, data: "appr:wd-real-1" } });
assert(approvePrompt.some((a) => a.text && a.text.includes("txHash")), "approve callback asks for txHash");

const before = calls.filter((c) => c.path.includes("approve")).length;
const approveDone = await bot.handleUpdate({ message: { chat: { id: ADMIN_ID }, from: { id: ADMIN_ID }, text: "0xPAYOUT-123" } });
const after = calls.filter((c) => c.path.includes("approve")).length;
assert(after === before + 1, "txHash reply triggers approve call");
const approveCall = calls.find((c) => c.path.includes("approve"));
assert(approveCall?.body?.txHash === "0xPAYOUT-123", "approve forwards txHash");

const rejectDone = await bot.handleUpdate({ callback_query: { id: "cb2", from: { id: ADMIN_ID }, message: { chat: { id: ADMIN_ID } }, data: "rej:wd-real-1" } });
const rejectCall = calls.find((c) => c.path.includes("reject"));
assert(!!rejectCall, "reject callback triggers reject call");

console.log(`\n${failures === 0 ? "✅ ALL TESTS PASSED" : `❌ ${failures} FAILURE(S)`}`);
server.close();
process.exit(failures === 0 ? 0 : 1);
