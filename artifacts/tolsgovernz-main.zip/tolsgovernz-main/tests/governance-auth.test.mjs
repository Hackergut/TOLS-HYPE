// Governance operator session tests (scrypt password + HMAC-signed cookie token).
//   node --test tests/governance-auth.test.mjs
import { test, beforeEach } from "node:test";
import assert from "node:assert/strict";
import {
  hashPassword,
  verifyPassword,
  createGovToken,
  verifyGovToken,
  generateSecret,
} from "../src/lib/governance-auth.ts";

beforeEach(() => {
  process.env.GOVERNANCE_SESSION_SECRET = generateSecret();
});

test("hashes and verifies a password", () => {
  const h = hashPassword("correct horse battery staple");
  assert.ok(h.startsWith("scrypt:"));
  assert.equal(verifyPassword("correct horse battery staple", h), true);
  assert.equal(verifyPassword("wrong password", h), false);
  assert.equal(verifyPassword("correct horse battery staple", "garbage"), false);
});

test("issues and verifies a signed session token", () => {
  const token = createGovToken("operator-1");
  assert.ok(token.includes("."));
  const session = verifyGovToken(token);
  assert.ok(session);
  assert.equal(session.username, "operator-1");
  assert.ok(session.issuedAt <= Date.now());
});

test("rejects a tampered session token", () => {
  const token = createGovToken("operator-1");
  const [b64, sig] = token.split(".");
  const flipped = (sig[0] === "0" ? "1" : "0") + sig.slice(1);
  assert.equal(verifyGovToken(`${b64}.${flipped}`), null);
});

test("rejects malformed or empty tokens", () => {
  assert.equal(verifyGovToken(undefined), null);
  assert.equal(verifyGovToken(""), null);
  assert.equal(verifyGovToken("abc"), null);
  assert.equal(verifyGovToken("a.b.c"), null);
});

test("rejects a token signed with a different secret", () => {
  const token = createGovToken("operator-1");
  process.env.GOVERNANCE_SESSION_SECRET = generateSecret(); // rotate the secret
  assert.equal(verifyGovToken(token), null);
});

test("fails closed when the secret is missing", () => {
  delete process.env.GOVERNANCE_SESSION_SECRET;
  assert.throws(() => createGovToken("x"), /GOVERNANCE_SESSION_SECRET/);
});
