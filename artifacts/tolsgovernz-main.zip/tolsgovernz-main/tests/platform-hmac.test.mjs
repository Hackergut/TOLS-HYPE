// HMAC bridge helpers — Casino and Governance must agree on this scheme.
//   node --test tests/platform-hmac.test.mjs
import { test, beforeEach, afterEach } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import {
  signBridgePayload,
  verifyBridgeSignature,
  verifyBridgeTimestamp,
  eventIdFromBody,
  isBridgeSecretReady,
  getBridgeSecret,
  normalizeBridgeSignature,
  BRIDGE_MAX_SKEW_SECONDS,
} from "../src/lib/platform/hmac.ts";

const SECRET = "a".repeat(32);
let prevSecret;
let prevAlias;

beforeEach(() => {
  prevSecret = process.env.GOVERNANCE_BRIDGE_SECRET;
  prevAlias = process.env.GOVERNANCE_WEBHOOK_SECRET;
  process.env.GOVERNANCE_BRIDGE_SECRET = SECRET;
  delete process.env.GOVERNANCE_WEBHOOK_SECRET;
});

afterEach(() => {
  if (prevSecret === undefined) delete process.env.GOVERNANCE_BRIDGE_SECRET;
  else process.env.GOVERNANCE_BRIDGE_SECRET = prevSecret;
  if (prevAlias === undefined) delete process.env.GOVERNANCE_WEBHOOK_SECRET;
  else process.env.GOVERNANCE_WEBHOOK_SECRET = prevAlias;
});

test("signs and verifies the raw JSON body", () => {
  const raw = JSON.stringify({ type: "ping", payload: {} });
  const sig = signBridgePayload(raw);
  assert.equal(verifyBridgeSignature(raw, sig), true);
  assert.equal(verifyBridgeSignature(raw, `sha256=${sig}`), true);
  assert.equal(verifyBridgeSignature(raw, `SHA256=${sig.toUpperCase()}`), true);
});

test("rejects a tampered body or signature", () => {
  const raw = JSON.stringify({ type: "casino.bet", payload: { amount: 1 } });
  const sig = signBridgePayload(raw);
  assert.equal(verifyBridgeSignature(raw + " ", sig), false);
  assert.equal(verifyBridgeSignature(raw, sig.slice(0, -1) + "0"), false);
  assert.equal(verifyBridgeSignature(raw, null), false);
  assert.equal(verifyBridgeSignature(raw, ""), false);
});

test("fails closed when the secret is missing", () => {
  const raw = "{\"type\":\"casino.bet\"}";
  const sig = signBridgePayload(raw);
  delete process.env.GOVERNANCE_BRIDGE_SECRET;
  assert.equal(getBridgeSecret(), "");
  assert.equal(isBridgeSecretReady(), false);
  assert.equal(verifyBridgeSignature(raw, sig), false);
  assert.throws(() => signBridgePayload(raw), /GOVERNANCE_BRIDGE_SECRET/);
});

test("GOVERNANCE_WEBHOOK_SECRET is an accepted alias", () => {
  const raw = "{\"type\":\"ping\"}";
  const sig = signBridgePayload(raw, SECRET);
  delete process.env.GOVERNANCE_BRIDGE_SECRET;
  process.env.GOVERNANCE_WEBHOOK_SECRET = SECRET;
  assert.equal(verifyBridgeSignature(raw, `sha256=${sig}`), true);
  assert.equal(isBridgeSecretReady(), true);
});

test("timestamp accepts a 5-minute window and rejects stale/missing values", () => {
  const now = Date.now();
  const nowSec = Math.floor(now / 1000);
  assert.equal(verifyBridgeTimestamp(String(nowSec), now), true);
  assert.equal(verifyBridgeTimestamp(String(nowSec - BRIDGE_MAX_SKEW_SECONDS + 1), now), true);
  assert.equal(verifyBridgeTimestamp(String(nowSec - BRIDGE_MAX_SKEW_SECONDS - 1), now), false);
  assert.equal(verifyBridgeTimestamp(null, now), false);
  assert.equal(verifyBridgeTimestamp("nope", now), false);
});

test("event id prefers explicit ids and otherwise hashes the raw body", () => {
  const raw = "{\"type\":\"casino.win\"}";
  assert.equal(eventIdFromBody({ id: "evt-1" }, raw), "evt-1");
  assert.equal(eventIdFromBody({ eventId: "evt-2" }, raw), "evt-2");
  const hashed = eventIdFromBody({}, raw);
  assert.equal(hashed.length, 64);
  assert.equal(eventIdFromBody({}, raw), hashed);
});

test("normalizeBridgeSignature strips the sha256= prefix", () => {
  assert.equal(normalizeBridgeSignature(" sha256=AbC "), "abc");
});

test("webhook route is a public GET probe, ping-pong, and HMAC-only POST", () => {
  const route = readFileSync(new URL("../src/app/api/platform/webhooks/route.ts", import.meta.url), "utf8");
  assert.match(route, /reachable: true/);
  assert.match(route, /type: "pong"/);
  assert.match(route, /verifyBridgeSignature/);
  assert.match(route, /X-Bridge-Timestamp/);
  assert.match(route, /peekGovOperatorOrToken/);
  assert.doesNotMatch(route, /verifyPlatformRequest/);
  assert.doesNotMatch(route, /requireGovOperatorOrToken/);
  assert.match(route, /Operator cookies are/);
});
