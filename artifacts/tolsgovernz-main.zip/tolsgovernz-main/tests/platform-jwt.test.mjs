// Platform-to-platform RS256 JWT tests (shared across both TOLS repos).
// Run with Node's built-in test runner — no dependencies required:
//   node --test tests/platform-jwt.test.mjs
// Node ≥ 22.18 strips the TS types in src/lib/platform/*.ts on import.
import { test } from "node:test";
import assert from "node:assert/strict";
import {
  signPlatformToken,
  verifyPlatformToken,
  scopeHas,
  generateRsaKeyPair,
  loadPrivateKey,
  loadPublicKey,
} from "../src/lib/platform/jwt.ts";
import {
  SCOPES,
  EVENT_TYPES,
  isPlatformEventType,
  PLATFORM_GOVERNANCE,
  PLATFORM_CASINO,
} from "../src/lib/platform/contract.ts";

const GOV = PLATFORM_GOVERNANCE;
const CASINO = PLATFORM_CASINO;
const govKeys = generateRsaKeyPair();
const casinoKeys = generateRsaKeyPair();

test("round-trips a signed token and returns matching claims", () => {
  const token = signPlatformToken({
    privateKey: govKeys.privateKey,
    issuer: GOV,
    audience: CASINO,
    subject: "op-42",
    scope: SCOPES.depositsRead,
  });
  const res = verifyPlatformToken(token, {
    publicKey: govKeys.publicKey,
    issuer: GOV,
    audience: CASINO,
  });
  assert.equal(res.valid, true);
  if (!res.valid) return;
  assert.equal(res.claims.iss, GOV);
  assert.equal(res.claims.aud, CASINO);
  assert.equal(res.claims.sub, "op-42");
  assert.equal(res.claims.scope, SCOPES.depositsRead);
  assert.ok(res.claims.jti.length > 0);
  assert.ok(res.claims.exp > res.claims.iat);
});

test("rejects a tampered signature", () => {
  const token = signPlatformToken({ privateKey: govKeys.privateKey, issuer: GOV, audience: CASINO });
  const parts = token.split(".");
  const last = parts[2];
  const flipped = (last[0] === "A" ? "B" : "A") + last.slice(1);
  const res = verifyPlatformToken(`${parts[0]}.${parts[1]}.${flipped}`, {
    publicKey: govKeys.publicKey,
    issuer: GOV,
    audience: CASINO,
  });
  assert.equal(res.valid, false);
  assert.equal(res.reason, "signature mismatch");
});

test("rejects a tampered payload re-encoded without re-signing", () => {
  const token = signPlatformToken({
    privateKey: govKeys.privateKey,
    issuer: GOV,
    audience: CASINO,
    scope: SCOPES.depositsRead,
  });
  const [h, p, s] = token.split(".");
  const payload = JSON.parse(Buffer.from(p, "base64url").toString());
  payload.scope = SCOPES.withdrawalsApprove; // escalate scope
  const newP = Buffer.from(JSON.stringify(payload)).toString("base64url");
  const res = verifyPlatformToken(`${h}.${newP}.${s}`, {
    publicKey: govKeys.publicKey,
    issuer: GOV,
    audience: CASINO,
  });
  assert.equal(res.valid, false);
  assert.equal(res.reason, "signature mismatch");
});

test("rejects an expired token", () => {
  const token = signPlatformToken({
    privateKey: govKeys.privateKey,
    issuer: GOV,
    audience: CASINO,
    ttlSeconds: 60,
  });
  const res = verifyPlatformToken(token, {
    publicKey: govKeys.publicKey,
    issuer: GOV,
    audience: CASINO,
    now: new Date(Date.now() + 10 * 60 * 1000),
  });
  assert.equal(res.valid, false);
  assert.equal(res.reason, "token expired");
});

test("rejects a not-yet-valid token", () => {
  const future = new Date(Date.now() + 10 * 60 * 1000);
  const token = signPlatformToken({
    privateKey: govKeys.privateKey,
    issuer: GOV,
    audience: CASINO,
    now: future,
  });
  const res = verifyPlatformToken(token, {
    publicKey: govKeys.publicKey,
    issuer: GOV,
    audience: CASINO,
    now: new Date(),
  });
  assert.equal(res.valid, false);
  assert.equal(res.reason, "token not yet valid");
});

test("rejects a token with the wrong audience", () => {
  const token = signPlatformToken({ privateKey: govKeys.privateKey, issuer: GOV, audience: CASINO });
  const res = verifyPlatformToken(token, {
    publicKey: govKeys.publicKey,
    issuer: GOV,
    audience: "some-other-platform",
  });
  assert.equal(res.valid, false);
  assert.equal(res.reason, "audience mismatch");
});

test("rejects a token with the wrong issuer", () => {
  const token = signPlatformToken({ privateKey: govKeys.privateKey, issuer: GOV, audience: CASINO });
  const res = verifyPlatformToken(token, {
    publicKey: govKeys.publicKey,
    issuer: "some-other-platform",
    audience: CASINO,
  });
  assert.equal(res.valid, false);
  assert.equal(res.reason, "issuer mismatch");
});

test("rejects a token verified with the wrong public key", () => {
  const token = signPlatformToken({ privateKey: govKeys.privateKey, issuer: GOV, audience: CASINO });
  const res = verifyPlatformToken(token, {
    publicKey: casinoKeys.publicKey, // wrong key
    issuer: GOV,
    audience: CASINO,
  });
  assert.equal(res.valid, false);
  assert.equal(res.reason, "signature mismatch");
});

test("rejects non-RS256 algorithms (e.g. 'none')", () => {
  const token = signPlatformToken({ privateKey: govKeys.privateKey, issuer: GOV, audience: CASINO });
  const [h, p, s] = token.split(".");
  const header = JSON.parse(Buffer.from(h, "base64url").toString());
  header.alg = "none";
  const newH = Buffer.from(JSON.stringify(header)).toString("base64url");
  const res = verifyPlatformToken(`${newH}.${p}.${s}`, {
    publicKey: govKeys.publicKey,
    issuer: GOV,
    audience: CASINO,
  });
  assert.equal(res.valid, false);
  assert.equal(res.reason, "unsupported algorithm");
});

test("rejects malformed tokens", () => {
  for (const t of ["", "abc", "a.b", "a.b.c.d"]) {
    const res = verifyPlatformToken(t, { publicKey: govKeys.publicKey });
    assert.equal(res.valid, false, `expected "${t}" to be rejected`);
  }
});

test("scopeHas checks required scopes", () => {
  const claims = { scope: "deposits:read withdrawals:read" };
  assert.equal(scopeHas(claims, "deposits:read"), true);
  assert.equal(scopeHas(claims, "withdrawals:approve"), false);
  assert.equal(scopeHas({ scope: "*" }, "anything:at:all"), true);
  assert.equal(scopeHas(claims, "deposits:read withdrawals:read"), true);
  assert.equal(scopeHas(claims, "deposits:read withdrawals:approve"), false);
});

test("governance ↔ casino handshake with each platform's keypair", () => {
  // Governance signs for the Casino; Casino verifies with Governance's public key.
  const govToCasino = signPlatformToken({
    privateKey: govKeys.privateKey,
    issuer: GOV,
    audience: CASINO,
    scope: SCOPES.withdrawalsApprove,
  });
  const casinoCheck = verifyPlatformToken(govToCasino, {
    publicKey: govKeys.publicKey,
    issuer: GOV,
    audience: CASINO,
  });
  assert.equal(casinoCheck.valid, true);

  // Casino signs for Governance; Governance verifies with Casino's public key.
  const casinoToGov = signPlatformToken({
    privateKey: casinoKeys.privateKey,
    issuer: CASINO,
    audience: GOV,
    scope: SCOPES.eventsWrite,
  });
  const govCheck = verifyPlatformToken(casinoToGov, {
    publicKey: casinoKeys.publicKey,
    issuer: CASINO,
    audience: GOV,
  });
  assert.equal(govCheck.valid, true);

  // Crossed keys must fail.
  const crossed = verifyPlatformToken(govToCasino, {
    publicKey: casinoKeys.publicKey,
    issuer: GOV,
    audience: CASINO,
  });
  assert.equal(crossed.valid, false);
});

test("loads keys from PEM, escaped-newline PEM and base64 forms", () => {
  assert.doesNotThrow(() => loadPrivateKey(govKeys.privateKey));
  assert.doesNotThrow(() => loadPublicKey(govKeys.publicKey));

  const escaped = govKeys.privateKey.replace(/\n/g, "\\n");
  assert.doesNotThrow(() => loadPrivateKey(escaped));

  const b64 = Buffer.from(govKeys.publicKey, "utf8").toString("base64");
  assert.doesNotThrow(() => loadPublicKey(b64));
});

test("detects token replay", () => {
  const token = signPlatformToken({ privateKey: govKeys.privateKey, issuer: GOV, audience: CASINO });
  const opts = { publicKey: govKeys.publicKey, issuer: GOV, audience: CASINO };
  assert.equal(verifyPlatformToken(token, opts).valid, true);
  const second = verifyPlatformToken(token, opts);
  assert.equal(second.valid, false);
  assert.equal(second.reason, "replay detected");
});

test("validates platform event types and constants", () => {
  assert.equal(isPlatformEventType("withdrawal.approved"), true);
  assert.equal(isPlatformEventType("not.a.real.event"), false);
  assert.ok(EVENT_TYPES.includes("deposit.confirmed"));
  assert.equal(PLATFORM_GOVERNANCE, "tols-governance");
  assert.equal(PLATFORM_CASINO, "tols-casino");
});
