# TOLS · Live-Bet Integration Guide

Drop the provably-fair horse-derby engine into any crypto-casino platform.
Three integration levels — pick whichever fits.

```
┌──────────────────────────────────────────────────────┐
│  Partner platform (web, mobile, casino aggregator)   │
└──────────────────────────────────────────────────────┘
            │  REST / WebSocket  /  SDK
┌──────────────────────────────────────────────────────┐
│  TOLS Live-Bet API    (server/live-bet.ts, Node)     │
│   · provably-fair rounds (HMAC-SHA256)               │
│   · RTP 96% guaranteed by construction               │
│   · HMAC-signed webhooks to your wallet              │
└──────────────────────────────────────────────────────┘
```

---

## 1 · JS/TS SDK — fastest path (30 min)

```bash
npm i @tols/live-bet
# or vendor the two files: src/live/engine.ts + src/game/{rtp,fair}.ts
```

```ts
import { createLiveBetClient } from "@tols/live-bet";

const client = createLiveBetClient({
  apiUrl: "https://api.tols.fun",   // or your mounted server
  apiKey: process.env.TOLS_KEY!,
  playerId: currentUser.id,
  playerName: currentUser.name,
});

client.on("round.settled", (e) => {
  const you = e.results.find(r => r.playerId === currentUser.id);
  if (you?.win) celebrate(you.payout);
});
client.on("bet.placed", (e) => updatePot(e.pot));

// Place a bet (debited from the platform wallet immediately).
await client.placeBet(2, 100);          // horse 2, ₡100
```

### Run the whole loop locally (preview / sandbox)
No server needed:

```ts
const client = createLiveBetClient({ apiKey: "preview", playerId: "u1", offline: true });
```

### Verify a round independently (auditor / regulator)
```ts
import { verifyRound, seedCommitment } from "@tols/live-bet";

// after the round settles the server has revealed its seed:
const { order, winnerId, floats } = verifyRound({
  serverSeed: revealedSeed,
  clientSeed: yourClientSeed,
  nonce: settled.nonce,
});
// → order is EXACTLY what the lobby saw. seedCommitment matches the pre-round hash.
```

---

## 2 · Self-host the room as a Node API (revenue-grade)

The same `LiveBetRoom` the browser uses runs server-side out of the box.

```ts
import { createServer } from "http";
import { mountLiveBet } from "tols-live/server";
import { MyPostgresWallet } from "./myWallet"; // implement WalletAdapter

const api = mountLiveBet({
  secret: process.env.TOLS_SECRET!,          // HMAC webhook signing
  wallet: new MyPostgresWallet(),            // platform wallet / balance
  webhookUrl: "https://wallet.yourgame.com/webhooks/tols",
});
createServer(api.server).listen(8080);
```

### REST surface

| Method | Endpoint | Body | Purpose |
|---|---|---|---|
| `GET` | `/state` | — | current round + lobby |
| `GET` | `/rounds` | — | last 50 settled |
| `GET` | `/stats` | — | RTP live (target + lobby-weighted) |
| `GET` | `/balance/:id` | — | wallet balance |
| `POST` | `/players` | `{id,name}` | onboard a player |
| `POST` | `/bets` | `{horseId,amount}` | place bet |
| `DELETE` | `/bets` | — | cancel |
| `GET` | `/fair/verify?seed&clientSeed&nonce` | — | independent replay |

### WebSocket (`/ws?key&player`)
Push feed of all `RoomEvent`s — same payload the SDK emits.

### Wallet integration — implement one interface

```ts
interface WalletAdapter {
  balance(playerId: string): number;
  debit(playerId: string, amount: number, roundId: string): boolean;
  credit(playerId: string, amount: number, roundId: string): void;
}
```

### Signed webhooks
Every settled round POSTs to `webhookUrl` with `x-tols-signature`:

```ts
const sig = hmacSha256(process.env.TOLS_SECRET!, rawBody);
if (sig !== req.headers["x-tols-signature"]) return 401;
```

---

## 3 · Embed the whole game (5 min)

The browser bundle is a single self-contained HTML. Three options:

```html
<!-- A · iframe (easiest) -->
<iframe src="https://derby.tols.fun/?key=S2F3KT&theme=live"
        style="width:100%;aspect-ratio:16/9;border:0;border-radius:14px"></iframe>

<!-- B · mount in your React tree -->
import HorseRaceGame from "@tols/derby";
<HorseRaceGame apiUrl="https://api.tols.fun" />

<!-- C · script tag -->
<script src="https://derby.tols.fun/embed.js" data-tols-key="S2F3KT"></script>
<div id="tols-derby"></div>
```

---

## Provably-fair reference

```
serverSeed  ← random 32 bytes (SHA-256 committed BEFORE the round)
clientSeed  ← player's own string, editable any time
nonce       ← round counter, increments every round

order = winnerDraw(TRUE_P, HMAC(serverSeed, `${clientSeed}:${nonce}:0`))
RTP   = P(win) × odds   ≡ 0.96 exactly per runner
```

Everybody can recompute the winner from the revealed seed trio.
`server/live-bet.ts /fair/verify` and `verifyRound()` in the SDK do the same math.

---

## Runner paytable (fixed, derived from declared probabilities)

| Runner | P(win) | Payout | RTP |
|---|---:|---:|---:|
| Crimson Bolt  | 32.0% | 3.00×  | 96.00% |
| Azure Rocket  | 24.0% | 4.00×  | 96.00% |
| Lime Ghost    | 18.0% | 5.33×  | 95.94% |
| Solar Flare   | 13.0% | 7.38×  | 95.94% |
| Fluo Phantom  |  8.5% | 11.29× | 96.96% |
| Silver Whale  |  4.5% | 21.33× | 95.99% |

Streak promo: disclosed `×1 → ×1.30` for consecutive wins — transparent on top of base RTP.

---

## Run the test suite once

```bash
# verifies 30 000 rounds land in the scripted order (0 mismatches) and RTP ≈ 96 %
node scripts/test-fairness.mjs
```
