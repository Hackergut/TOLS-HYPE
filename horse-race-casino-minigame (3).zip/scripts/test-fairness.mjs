#!/usr/bin/env node
/**
 * TOLS · fairness test — proves the seeded outcome is ALWAYS what the animation
 * delivers (0 mismatches over 30k rounds) and that realised RTP ≈ declared RTP.
 */
import { resolveRound, TRUE_P, oddsFor } from "../src/game/rtp.ts";

const N = 30000;
let mismatches = 0;
let photo = 0;
const wins = new Array(TRUE_P.length).fill(0);
const seed = "f".repeat(64);

function run(nonce) {
  const o = resolveRound(seed, "test-suite", nonce, TRUE_P.length);
  wins[o.winnerId]++;
  if (o.photoFinish) photo++;
  // emulate the choreography tie-break used by the game loop
  const BASE = 7.4, SPREAD = o.photoFinish ? 0.55 : 1.9;
  const finishAt = new Array(TRUE_P.length).fill(BASE);
  o.order.forEach((id, place) => { finishAt[id] = BASE + o.margins[place] * SPREAD; });
  const sorted = [...Array(TRUE_P.length).keys()].sort((a, b) => finishAt[a] - finishAt[b]);
  return { scripted: o.order, actual: sorted };
}

for (let i = 0; i < N; i++) {
  const r = run(i + 1);
  if (JSON.stringify(r.scripted) !== JSON.stringify(r.actual)) mismatches++;
}

console.log(`== TOLS fairness test · ${N.toLocaleString()} rounds ==`);
console.log(`order mismatches : ${mismatches}  (${((mismatches / N) * 100).toFixed(4)}%)`);
console.log(`photo finishes   : ${((photo / N) * 100).toFixed(2)}%`);
console.log("\nrunner  declared  observed   RTP");
let rtp = 0;
wins.forEach((w, i) => {
  const f = w / N;
  rtp += f * oddsFor(i);
  console.log(`  ${i}    ${(TRUE_P[i] * 100).toFixed(2).padStart(5)}%   ${(f * 100).toFixed(2).padStart(5)}%   ${(f * oddsFor(i) * 100).toFixed(2)}%`);
});
console.log(`\nfield-average RTP: ${((rtp / TRUE_P.length) * 100).toFixed(3)}%  · target 96%`);
if (mismatches !== 0) process.exit(1);
console.log("\n✔ PASS — choreography is faithful, RTP is provable.");
