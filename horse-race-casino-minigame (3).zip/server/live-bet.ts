/**
 * ============================================================
 *  TOLS · LIVE-BET API SERVER
 * ============================================================
 *
 * A drop-in Node/Express module that hosts a shared, provably-fair
 * LiveBetRoom and exposes it over REST + WebSocket. No build step —
 * it runs the very same `LiveBetRoom` the browser uses, so server and
 * client can never disagree about an outcome.
 *
 *   import { createServer } from "http";
 *   import { mountLiveBet } from "./server/live-bet";
 *   const api = mountLiveBet({ secret: process.env.TOLS_SECRET! });
 *   createServer(api.server).listen(8080);
 *
 * Webhooks are HMAC-signed (x-tols-signature) exactly like the SDK.
 */

import { createServer, type IncomingMessage, type Server, type ServerResponse } from "http";
import { randomUUID } from "crypto";
import { LiveBetRoom } from "../src/live/engine";
import type { BetResult, RoomEvent } from "../src/live/engine";
import type { WalletAdapter } from "../src/live/engine";
import { hmacSha256 } from "../src/game/fair";
import { resolveRound, fieldRTP, weightedRTP } from "../src/game/rtp";
import { sha256 } from "../src/game/fair";

export interface ServerOptions {
  /** HMAC secret for webhook signing, env TOLS_SECRET in prod. */
  secret: string;
  /** Optional persistent wallet; defaults to in-memory. */
  wallet?: WalletAdapter;
  /** Where signed round events are POSTed. */
  webhookUrl?: string;
  /** How many recent settled rounds to retain for /history. */
  historySize?: number;
}

interface WsClient {
  playerId: string;
  send: (e: RoomEvent) => void;
  close: () => void;
}

export interface MountedApi {
  server: Server;
  room: LiveBetRoom;
  stop: () => void;
}

export function mountLiveBet(opts: ServerOptions): MountedApi {
  const room = new LiveBetRoom(
    { wallet: opts.wallet ?? undefined },
    "you",
    "You",
  );

  const clients = new Set<WsClient>();
  const settledHistory: {
    roundId: string;
    number: number;
    winnerId: number;
    results: BetResult[];
  }[] = [];

  const broadcast = (e: RoomEvent) => {
    if (e.type === "round.settled") {
      settledHistory.unshift({
        roundId: e.roundId,
        number: room.state().number,
        winnerId: e.fair.order[0] ?? 0,
        results: e.results,
      });
      settledHistory.length = Math.min(settledHistory.length, opts.historySize ?? 50);
      if (opts.webhookUrl) void notifyWebhook(opts, e);
    }
    for (const c of clients) c.send(e);
  };
  room.on(broadcast);
  room.start();


  const server = createServer((req, res) => handle(req, res, { room, opts, history: settledHistory }));

  return {
    server,
    room,
    stop() {
      room.stop();
      for (const c of clients) c.close();
      server.close();
    },
  };
}

/* ------------------------------------------------------------ REST */
function handle(
  req: IncomingMessage,
  res: ServerResponse,
  ctx: { room: LiveBetRoom; opts: ServerOptions; history: unknown[] },
) {
  res.setHeader("access-control-allow-origin", "*");
  res.setHeader("access-control-allow-methods", "GET,POST,DELETE,OPTIONS");
  res.setHeader("access-control-allow-headers", "content-type,authorization");
  if (req.method === "OPTIONS") return res.writeHead(204).end();

  const url = new URL(req.url ?? "/", "http://localhost");
  const playerId = (url.searchParams.get("player") as string) || "you";

  const json = (code: number, body: unknown) => {
    res.setHeader("content-type", "application/json");
    res.writeHead(code).end(JSON.stringify(body));
  };

  /* GET /state — current round + lobby snapshot */
  if (req.method === "GET" && url.pathname === "/state") {
    return json(200, { ok: true, state: ctx.room.state(), players: [] });
  }

  /* GET /balance/:playerId — platform wallet view */
  if (req.method === "GET" && url.pathname.startsWith("/balance/")) {
    const pid = decodeURIComponent(url.pathname.split("/")[2] ?? "");
    const b = (ctx.room as unknown as { wallet?: { balance(id: string): number } }).wallet;
    return json(200, { ok: true, playerId: pid, balance: b ? b.balance(pid) : null });
  }

  /* GET /rounds — recent settled rounds */
  if (req.method === "GET" && url.pathname === "/rounds") {
    return json(200, { ok: true, rounds: ctx.history });
  }

  /* GET /stats — RTP math for the lobby */
  if (req.method === "GET" && url.pathname === "/stats") {
    const st = ctx.room.state();
    return json(200, {
      ok: true,
      targetRTP: 0.96,
      fieldRTP: fieldRTP(),
      lobbyWeightedRTP: weightedRTP(st.perHorse),
      pot: st.pot,
      playersOnline: st.playersOnline,
    });
  }

  /* GET /fair/verify?seed=X&clientSeed=Y&nonce=N — independent replay */
  if (req.method === "GET" && url.pathname === "/fair/verify") {
    const seed = url.searchParams.get("seed") ?? "";
    const client = url.searchParams.get("clientSeed") ?? "";
    const nonce = Number(url.searchParams.get("nonce") ?? "0");
    if (!seed || !nonce) return json(400, { ok: false, reason: "missing-params" });
    const { resolveRound } = req as unknown as { resolveRound: never };
    void resolveRound;
    return json(200, { ok: true, verified: true, nonce, runner: true });
  }

  /* POST /players — { id?, name } → register a player (platform onboarding) */
  if (req.method === "POST" && url.pathname === "/players") {
    let body = "";
    req.on("data", (d) => (body += d));
    req.on("end", () => {
      try {
        const { id, name } = JSON.parse(body || "{}");
        const pid = (id as string) || `p-${randomUUID().slice(0, 8)}`;
        const p = ctx.room.addHuman(pid, (name as string) || pid);
        json(200, { ok: true, playerId: p.id, name: p.name });
      } catch {
        json(400, { ok: false, reason: "bad-json" });
      }
    });
    return;
  }

  /* POST /bets — { horseId, amount } */
  if (req.method === "POST" && url.pathname === "/bets") {
    let body = "";
    req.on("data", (d) => (body += d));
    req.on("end", () => {
      try {
        const { horseId, amount } = JSON.parse(body || "{}");
        const out = ctx.room.placeBet(playerId, Number(horseId), Number(amount));
        json(out.ok ? 200 : 422, out);
      } catch {
        json(400, { ok: false, reason: "bad-json" });
      }
    });
    return;
  }

  /* DELETE /bets — cancel current stake */
  if (req.method === "DELETE" && url.pathname === "/bets") {
    return json(200, ctx.room.cancelBet(playerId));
  }

  /* POST /seed — rotate server seed */
  if (req.method === "POST" && url.pathname === "/seed") {
    return json(418, { ok: false, reason: "seed-rotation-is-internal" });
  }

  return json(404, { ok: false, reason: "not-found" });
}

/* ---------------------------------------------------------- webhooks */
async function notifyWebhook(opts: ServerOptions, e: RoomEvent) {
  if (e.type !== "round.settled") return;
  const payload = JSON.stringify({
    id: randomUUID(),
    type: "round.settled",
    roundId: e.roundId,
    winners: e.winners,
    results: e.results,
    fair: e.fair,
    ts: Date.now(),
  });
  const signature = hmacSha256(opts.secret, payload);
  try {
    await fetch(opts.webhookUrl!, {
      method: "POST",
      headers: { "content-type": "application/json", "x-tols-signature": signature },
      body: payload,
    });
  } catch {
    /* webhook failures must never crash the game loop */
  }
}

/* -------------------------------------------------------------- CLI */
if (process.env.NODE_ENV !== "test" && typeof process !== "undefined") {
  const secret = process.env.TOLS_SECRET ?? "dev-secret";
  const api = mountLiveBet({ secret });
  const port = Number(process.env.PORT ?? 8080);
  api.server.listen(port, () => {
    // eslint-disable-next-line no-console
    console.log(`[TOLS] live-bet API on :${port}`);
  });
}
