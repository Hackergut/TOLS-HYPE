import HorseRaceGame from "./game/HorseRaceGame";

export default function App() {
  return <HorseRaceGame />;
}

/**
 * Public SDK surface — import from "@tols/live-bet" in partner bundles.
 * Re-exported here so `src/App.tsx` is the single public entry point.
 */
export {
  createLiveBetClient,
  seedCommitment,
  signWebhook,
  verifyRound,
  LiveBetRoom,
  LocalWallet,
} from "./live";
export { HORSES } from "./game/types";
export {
  TRUE_P, TARGET_RTP, HOUSE_EDGE, STREAK_STEPS,
  resolveRound, oddsFor, rtpFor, paytable, effectiveRTP,
  fieldRTP, weightedRTP, streakMultiplier,
} from "./game/rtp";
export { sha256, hmacSha256, randomSeed, fairFloats } from "./game/fair";
