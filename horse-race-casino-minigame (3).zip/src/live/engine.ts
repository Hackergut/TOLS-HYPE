import { fairFloats, randomSeed, sha256 } from "../game/fair";
import { oddsFor, TRUE_P } from "../game/rtp";

/**
 * ============================================================
 *  TOLS · LIVE-BET ENGINE
 * ============================================================
 *
 * A completely self-contained, framework-agnostic, provably-fair
 * live-betting session. It owns the round lifecycle, lobster-like
 * player lobby, betting, settlement and streaks, and emits plain
 * JSON events. A UI simply subscribes; a server simply wraps it.
 *
 * No DOM. No React. Pure ES modules — it runs in Node, Deno, Bun or
 * the browser unchanged.
 *
 *   const room = new LiveBetRoom(new LocalWallet());
 *   room.on("bet.settled", console.log);
 *   room.start();
 *   room.placeBet("you", 0, 100);
 */

export type RoomPhase = "waiting" | "countdown" | "racing" | "result";

export interface LobbyPlayer {
  id: string;
  name: string;
  avatar: string;
  hue: number;
  bet: number;
  horseId: number;
  /** Session profit/loss. */
  pl: number;
  /** Consecutive winning rounds. */
  streak: number;
}

export interface BetResult {
  playerId: string;
  bet: number;
  horseId: number;
  win: boolean;
  /** Multiplier actually applied (odds × streak). */
  mult: number;
  payout: number;
  pl: number;
  streak: number;
}

export interface FairRecord {
  roundId: string;
  serverSeedHash: string;
  serverSeed: string | null; // null until revealed at settle
  clientSeed: string;
  nonce: number;
  /** Full finishing order, first place first. */
  order: number[];
  /** The raw float stream used (for third-party verification). */
  floats: number[];
  photoFinish: boolean;
}

export interface RoundState {
  id: string;
  number: number;
  phase: RoomPhase;
  /** Countdown / settle deadlines as epoch ms. */
  phaseEndsAt: number;
  winners: number[];        // last-winner ids, newest first
  pot: number;              // total staked this round
  perHorse: number[];       // stake per runner id
  playersOnline: number;
}

export type RoomEvent =
  | { type: "room.init"; state: RoundState; players: LobbyPlayer[] }
  | { type: "round.state"; state: RoundState }
  | { type: "lobby.upsert"; players: LobbyPlayer[] }
  | { type: "lobby.remove"; playerId: string }
  | { type: "bet.placed"; playerId: string; bet: number; horseId: number; pot: number }
  | { type: "round.starting"; roundId: string; countdown: number }
  | { type: "round.racing"; roundId: string; fair: FairRecord }
  | { type: "round.settled"; roundId: string; results: BetResult[]; fair: FairRecord; winners: number[] }
  | { type: "tick"; countdown: number };

type Handler = (e: RoomEvent) => void;

export interface WalletAdapter {
  balance(playerId: string): number;
  debit(playerId: string, amount: number, roundId: string): boolean;
  credit(playerId: string, amount: number, roundId: string): void;
}

/* ------------------------------------------------------- deterministic PRNG */
function mulberry32(seed: number) {
  return () => {
    seed |= 0;
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const BOT_NAMES = [
  "NeonNina", "CryptoKing", "LimeLord", "FluoFox", "WhaleWalker", "PhotoFin", "SilkStorm",
  "StakeStack", "TurboTom", "PhotoGat", "DerbyDan", "LuckyLucy", "PurplePete", "ChipChaser",
  "AstroAva", "MegaMina", "RiskyRex", "JetSetJim", "SoloSam", "BlinkBlaze", "OddsOla",
  "QuinnQuick", "RushRita", "PixelPat", "TropTroy", "VegaVik", "ZenZoe", "HyperHank",
];
const BOT_AVATARS = ["🦊","🐺","🦉","🐸","🦅","🐍","🦩","🐋","🦎","🐆","🦈","🐉","🦜","🐳","🦅","🐘"];

export interface RoomOptions {
  runners?: number;
  waitingSec?: number;
  countdownSec?: number;
  resultSec?: number;
  /** Base race duration (s) for the winner. */
  raceBaseSec?: number;
  bots?: { min: number; max: number };
  /** Seedable for tests/server; defaults to crypto-random. */
  prngSeed?: number;
  /** Wallet backing; defaults to an in-memory local wallet. */
  wallet?: WalletAdapter;
  clientSeed?: string;
}

export class LocalWallet implements WalletAdapter {
  private balances = new Map<string, number>();
  constructor(private startBalance = 1_000) {}
  balance(id: string) {
    if (!this.balances.has(id)) this.balances.set(id, this.startBalance);
    return this.balances.get(id)!;
  }
  debit(id: string, amount: number) {
    const b = this.balance(id);
    if (amount <= 0 || amount > b) return false;
    this.balances.set(id, this.round(b - amount));
    return true;
  }
  credit(id: string, amount: number) {
    this.balances.set(id, this.round(this.balance(id) + amount));
  }
  setBalance(id: string, amount: number) { this.balances.set(id, this.round(amount)); }
  private round(n: number) { return Math.round(n * 100) / 100; }
}

export class LiveBetRoom {
  readonly runners: number;
  readonly options: Required<Omit<RoomOptions, "prngSeed" | "wallet" | "clientSeed">> & {
    clientSeed: string;
  };

  private rand: () => number;
  private wallet: WalletAdapter;
  private handlers = new Set<Handler>();
  private players = new Map<string, LobbyPlayer>();
  private phase: RoomPhase = "waiting";
  private phaseEndsAt = 0;
  private roundNumber = 0;
  private roundId = "";
  private serverSeed = "";
  private serverSeedHash = "";
  private clientSeed: string;
  private nonce = 0;
  private winners: number[] = [];
  private timer: ReturnType<typeof setInterval> | null = null;
  private outcome: ReturnType<typeof this.computeOutcome> | null = null;

  constructor(opts: RoomOptions = {}, humanId = "you", humanName = "You") {
    this.runners = opts.runners ?? TRUE_P.length;
    this.options = {
      runners: this.runners,
      waitingSec: opts.waitingSec ?? 8,
      countdownSec: opts.countdownSec ?? 3,
      resultSec: opts.resultSec ?? 6,
      raceBaseSec: opts.raceBaseSec ?? 7.4,
      bots: opts.bots ?? { min: 7, max: 13 },
      clientSeed: opts.clientSeed ?? "derby",
    };
    this.rand = mulberry32(opts.prngSeed ?? Math.floor(Math.random() * 0xffffffff));
    this.wallet = opts.wallet ?? new LocalWallet();
    this.clientSeed = this.options.clientSeed;
    this.seedBots();
    this.addHuman(humanId, humanName);
    this.rotateSeed();
  }

  /* ------------------------------------------------ herd of lobby bots */
  private seedBots() {
    const { min, max } = this.options.bots;
    const count = min + Math.floor(this.rand() * (max - min + 1));
    const names = [...BOT_NAMES].sort(() => this.rand() - 0.5);
    for (let i = 0; i < count; i++) {
      this.addHuman(
        `bot-${i}`,
        names[i % names.length],
        true,
      );
    }
  }

  addHuman(id: string, name: string, bot = false): LobbyPlayer {
    if (this.players.has(id)) return this.players.get(id)!;
    const p: LobbyPlayer = {
      id,
      name,
      avatar: bot ? BOT_AVATARS[Math.floor(this.rand() * BOT_AVATARS.length)] : "🧑",
      hue: Math.floor(this.rand() * 360),
      bet: 0,
      horseId: -1,
      pl: 0,
      streak: 0,
    };
    this.players.set(id, p);
    return p;
  }

  on(handler: Handler): () => void {
    this.handlers.add(handler);
    return () => this.handlers.delete(handler);
  }
  private emit(e: RoomEvent) {
    for (const h of this.handlers) h(e);
  }

  /* ------------------------------------------------ waiters lifecycle */
  start() {
    if (this.timer) return;
    this.timer = setInterval(() => this.tick(), 100);
    this.emit({ type: "room.init", state: this.state(), players: this.playersArray() });
  }
  stop() {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
  }

  /* ----------------------------------------------------- player actions */
  /** Place or move a bet. Debited from the wallet immediately. */
  placeBet(playerId: string, horseId: number, amount: number): { ok: boolean; reason?: string } {
    const p = this.players.get(playerId);
    if (!p) return { ok: false, reason: "unknown-player" };
    if (this.phase !== "waiting" && this.phase !== "countdown")
      return { ok: false, reason: "betting-closed" };
    if (horseId < 0 || horseId >= this.runners) return { ok: false, reason: "bad-runner" };

    amount = Math.round(amount * 100) / 100;
    if (amount <= 0) return this.cancelBet(playerId);

    // Refund the previous stake, charge the new one.
    const prev = p.bet;
    if (prev > 0) this.wallet.credit(playerId, prev, this.roundId);
    if (!this.wallet.debit(playerId, amount, this.roundId)) {
      if (prev > 0) this.wallet.debit(playerId, prev, this.roundId); // put it back
      return { ok: false, reason: "insufficient-funds" };
    }
    p.bet = amount;
    p.horseId = horseId;
    this.emit({ type: "bet.placed", playerId, bet: amount, horseId, pot: this.pot() });
    return { ok: true };
  }

  cancelBet(playerId: string): { ok: boolean; reason?: string } {
    const p = this.players.get(playerId);
    if (!p) return { ok: false, reason: "unknown-player" };
    if (this.phase !== "waiting" && this.phase !== "countdown")
      return { ok: false, reason: "betting-closed" };
    if (p.bet > 0) this.wallet.credit(playerId, p.bet, this.roundId);
    p.bet = 0;
    p.horseId = -1;
    this.emit({ type: "bet.placed", playerId, bet: 0, horseId: -1, pot: this.pot() });
    return { ok: true };
  }

  setClientSeed(s: string) {
    this.clientSeed = s || "derby";
  }

  /* --------------------------------------------------------- internals */
  private rotateSeed() {
    this.serverSeed = randomSeed();
    this.serverSeedHash = sha256(this.serverSeed);
  }

  private computeOutcome() {
    this.nonce += 1;
    const floats = fairFloats(this.serverSeed, this.clientSeed, this.nonce, this.runners + 1);
    const pool = Array.from({ length: this.runners }, (_, i) => i);
    const weights = pool.map((i) => TRUE_P[i]);
    const order: number[] = [];
    for (let place = 0; place < this.runners; place++) {
      const w = weights.map((x) => (place === 0 ? x : Math.pow(x, 0.75)));
      const total = w.reduce((a, b) => a + b, 0);
      let x = floats[place] * total;
      let k = w.length - 1;
      for (let i = 0, acc = 0; i < w.length; i++) {
        acc += w[i];
        if (x < acc) { k = i; break; }
      }
      order.push(pool[k]);
      pool.splice(k, 1);
      weights.splice(k, 1);
    }
    const tight = floats[this.runners];
    const photoFinish = tight < 0.18;
    const spread = photoFinish ? 0.1 + tight : 0.35 + tight * 0.65;
    const margins = order.map((_, i) => (i === 0 ? 0 : spread * (i / this.runners) + tight * 0.05 * i));
    const base = this.options.raceBaseSec;
    const SPREAD = photoFinish ? 0.55 : 1.9;
    const finishAt = order.map((_id, place) => base + margins[place] * SPREAD);
    return { order, winnerId: order[0], finishAt, margins, photoFinish, floats };
  }

  private fairRecord(revealed: boolean): FairRecord {
    return {
      roundId: this.roundId,
      serverSeedHash: this.serverSeedHash,
      serverSeed: revealed ? this.serverSeed : null,
      clientSeed: this.clientSeed,
      nonce: this.nonce,
      order: this.outcome?.order ?? [],
      floats: this.outcome?.floats ?? [],
      photoFinish: this.outcome?.photoFinish ?? false,
    };
  }

  private tick() {
    const now = Date.now();
    this.botActivity();

    if (this.phase === "waiting" && now >= this.phaseEndsAt) {
      this.beginRound(now);
    } else if (this.phase === "countdown" && now >= this.phaseEndsAt) {
      this.beginRace(now);
    } else if (this.phase === "racing" && now >= this.phaseEndsAt) {
      // Headless safety: the host renderer didn't call settle() in time.
      if (this.outcome) this.settle();
      else this.beginWaiting(now);
    } else if (this.phase === "result" && now >= this.phaseEndsAt) {
      this.beginWaiting(now);
    }
  }

  private beginWaiting(now: number) {
    this.phase = "waiting";
    this.phaseEndsAt = now + this.options.waitingSec * 1000;
    for (const p of this.players.values()) { p.bet = 0; p.horseId = -1; }
    this.rotateSeed();
    this.emit({ type: "round.state", state: this.state() });
  }

  private beginRound(now: number) {
    this.roundNumber += 1;
    this.roundId = `r${this.roundNumber}-${randomSeed(4).slice(0, 8)}`;
    this.phase = "countdown";
    this.phaseEndsAt = now + this.options.countdownSec * 1000;
    this.emit({ type: "round.starting", roundId: this.roundId, countdown: this.options.countdownSec });
    this.emit({ type: "round.state", state: this.state() });
  }

  private beginRace(now: number) {
    this.phase = "racing";
    this.outcome = this.computeOutcome();
    // Resolve the moment the last runner would theoretically cross.
    const lane1 = this.outcome.finishAt.reduce((a, b) => Math.max(a, b), 0);
    this.phaseEndsAt = now + lane1 * 1000 + 1200;
    this.emit({ type: "round.racing", roundId: this.roundId, fair: this.fairRecord(false) });
    this.emit({ type: "round.state", state: this.state() });
  }

  /** Called by the renderer the moment every runner has crossed on screen. */
  settle() {
    if (this.phase !== "racing") return;
    this.phase = "result";
    this.phaseEndsAt = Date.now() + this.options.resultSec * 1000;
    const results = this.settlePlayers();
    const winnerId = this.outcome!.winnerId;
    this.winners = [winnerId, ...this.winners].slice(0, 4);
    this.emit({
      type: "round.settled",
      roundId: this.roundId,
      results,
      fair: this.fairRecord(true),
      winners: this.winners,
    });
    this.emit({ type: "round.state", state: this.state() });
  }

  private settlePlayers(): BetResult[] {
    const winnerId = this.outcome!.winnerId;
    const results: BetResult[] = [];
    for (const p of this.players.values()) {
      if (p.bet <= 0) continue;
      const win = p.horseId === winnerId;
      const odds = oddsFor(p.horseId);
      const streak = win ? p.streak + 1 : 0;
      const boundary = [1, 1.05, 1.1, 1.18, 1.3];
      const mult = odds * boundary[Math.min(p.streak, boundary.length - 1)];
      const payout = win ? Math.floor(p.bet * mult * 100) / 100 : 0;
      if (payout > 0) this.wallet.credit(p.id, payout, this.roundId);
      p.pl += (payout - p.bet) || 0;
      p.streak = streak;
      results.push({
        playerId: p.id,
        bet: p.bet,
        horseId: p.horseId,
        win,
        mult: Math.round(mult * 100) / 100,
        payout,
        pl: Math.round(p.pl * 100) / 100,
        streak,
      });
    }
    return results;
  }

  /* ------------------------------------------------------ bot theatre */
  private botActivity() {
    if (this.phase !== "waiting" && this.phase !== "countdown") return;
    if (this.rand() > 0.06) return;
    const bots = this.playersArray().filter((p) => p.id.startsWith("bot"));
    if (!bots.length) return;
    const b = bots[Math.floor(this.rand() * bots.length)];
    const roll = this.rand();
    const amount = roll < 0.7
      ? 10 + Math.floor(this.rand() * 14) * 10
      : roll < 0.95
        ? 200 + Math.floor(this.rand() * 20) * 50
        : 1000 + Math.floor(this.rand() * 5) * 100;
    b.bet = amount;
    b.horseId = Math.floor(this.rand() * this.runners);
    this.emit({ type: "lobby.upsert", players: [b] });
    this.emit({ type: "bet.placed", playerId: b.id, bet: amount, horseId: b.horseId, pot: this.pot() });
  }

  /** Occasionally a bot leaves or a new one joins. */
  churn() {
    if (this.rand() > 0.03) return;
    if (this.rand() < 0.6 && this.players.size < 16) {
      const p = this.addHuman(`bot-${Date.now().toString(36)}`, BOT_NAMES[Math.floor(this.rand() * BOT_NAMES.length)], true);
      this.emit({ type: "lobby.upsert", players: [p] });
    } else if (this.players.size > 4) {
      const bots = this.playersArray().filter((x) => x.id.startsWith("bot"));
      if (bots.length) {
        const b = bots[Math.floor(this.rand() * bots.length)];
        this.players.delete(b.id);
        this.emit({ type: "lobby.remove", playerId: b.id });
      }
    }
  }

  /* ------------------------------------------------------------ state */
  private pot() {
    return Math.round(this.playersArray().reduce((s, p) => s + p.bet, 0) * 100) / 100;
  }
  private perHorse() {
    const a = new Array(this.runners).fill(0);
    for (const p of this.players.values()) if (p.horseId >= 0) a[p.horseId] += p.bet;
    return a;
  }
  private playersArray() {
    return Array.from(this.players.values());
  }
  state(): RoundState {
    return {
      id: this.roundId,
      number: this.roundNumber,
      phase: this.phase,
      phaseEndsAt: this.phaseEndsAt,
      winners: this.winners,
      pot: this.pot(),
      perHorse: this.perHorse(),
      playersOnline: this.players.size,
    };
  }
}
