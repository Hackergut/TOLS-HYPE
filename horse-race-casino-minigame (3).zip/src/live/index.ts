/**
 * ============================================================
 *  TOLS · PUBLIC LIVE-BET SDK
 * ============================================================
 *
 * The single import a partner platform needs. Wraps the provably-fair
 * engine in a platform-agnostic interface and works either against the
 * hosted API (REST + WebSocket) or fully client-side in preview mode.
 *
 *   import { createLiveBetClient } from "@tols/live-bet";
 *   const client = createLiveBetClient({ apiUrl:"https://api.tols.fun", apiKey, playerId });
 *   client.on("round.settled", showWin);
 *   await client.placeBet(0, 100);
 */

import { hmacSha256, sha256 } from "../game/fair";
import { LiveBetRoom, LocalWallet } from "./engine";
import type { RoomEvent } from "./engine";
import { resolveRound } from "../game/rtp";

/* ---------- public re-exports ---------- */
export { LiveBetRoom, LocalWallet } from "./engine";
export type {
  RoomEvent, RoundState, LobbyPlayer, BetResult, FairRecord, RoomPhase, WalletAdapter, RoomOptions,
} from "./engine";
export { fairFloats, hmacSha256, randomSeed, sha256 } from "../game/fair";
export {
  oddsFor, rtpFor, TRUE_P, TARGET_RTP, HOUSE_EDGE, resolveRound,
  STREAK_STEPS, streakMultiplier, fieldRTP, weightedRTP, paytable, effectiveRTP,
} from "../game/rtp";
export { HORSES } from "../game/types";

/* =========================================================
   HTTP / WebSocket-ready client
   ========================================================= */

export interface ClientOptions {
  /** Base URL of the TOLS API, or your own mounted server module. */
  apiUrl?: string;
  apiKey: string;
  playerId: string;
  playerName?: string;
  /** Extra headers a platform adds to every call (region, device…). */
  headers?: Record<string, string>;
  /** True = run the whole loop client-side (demo / preview). */
  offline?: boolean;
}

export interface LiveBetClient {
  on(fn: (e: RoomEvent) => void): () => void;
  placeBet(horseId: number, amount: number): Promise<{ ok: boolean; reason?: string }>;
  cancel(): Promise<{ ok: boolean; reason?: string }>;
  staticState(): Promise<{ ok: true; rounds: unknown[] } | { ok: false }>;
  disconnect(): void;
}

export function createLiveBetClient(opts: ClientOptions): LiveBetClient {
  const listeners = new Set<(e: RoomEvent) => void>();
  let room: LiveBetRoom | null = null;
  let ws: WebSocket | null = null;
  const emit = (e: RoomEvent) => listeners.forEach((f) => f(e));

  const base = (opts.apiUrl ?? "").replace(/\/$/, "");
  const isOffline = opts.offline || !opts.apiUrl;

  if (isOffline) {
    room = new LiveBetRoom({ wallet: new LocalWallet() }, opts.playerId, opts.playerName ?? "You");
    room.on(emit);
    room.start();
  }

  return {
    on(fn) {
      listeners.add(fn);
      return () => listeners.delete(fn);
    },

    async placeBet(horseId, amount) {
      if (room) return Promise.resolve(room.placeBet(opts.playerId, horseId, amount));
      if (!ws) {
        ws = new WebSocket(
          `${base}/ws?key=${encodeURIComponent(opts.apiKey)}&player=${encodeURIComponent(opts.playerId)}`,
        );
        ws.onmessage = (m) => {
          try { emit(JSON.parse(m.data)); } catch { /* ignore */ }
        };
      }
      const res = await fetch(`${base}/bets`, {
        method: "POST",
        headers: {
          "content-type": "application/json",
          authorization: `Bearer ${opts.apiKey}`,
          ...opts.headers,
        },
        body: JSON.stringify({ horseId, amount }),
      });
      return (await res.json()) as { ok: boolean; reason?: string };
    },

    async cancel() {
      if (room) return Promise.resolve(room.cancelBet(opts.playerId));
      const res = await fetch(`${base}/bets`, {
        method: "DELETE",
        headers: { authorization: `Bearer ${opts.apiKey}`, ...opts.headers },
      });
      return (await res.json()) as { ok: boolean; reason?: string };
    },

    async staticState() {
      if (room) return { ok: true as const, rounds: [room.state()] };
      try {
        const res = await fetch(`${base}/rounds`, {
          headers: { authorization: `Bearer ${opts.apiKey}`, ...opts.headers },
        });
        return (await res.json()) as { ok: true; rounds: unknown[] };
      } catch {
        return { ok: false as const };
      }
    },

    disconnect() {
      room?.stop();
      ws?.close();
      listeners.clear();
    },
  };
}

/* =========================================================
   Independent verifier (auditor / regulator / partner)
   ========================================================= */

export interface VerifyInput {
  serverSeed: string;
  clientSeed: string;
  nonce: number;
  runners?: number;
}

/**
 * Recompute the exact finishing order a round produced — this is what a
 * partner or auditor runs against the revealed seed trio to prove a round
 * was not tampered with.
 */
export function verifyRound(v: VerifyInput): {
  order: number[];
  winnerId: number;
  floats: number[];
  photoFinish: boolean;
  commitment: string;
} {
  const outcome = resolveRound(v.serverSeed, v.clientSeed, v.nonce, v.runners ?? 6);
  return {
    order: outcome.order,
    winnerId: outcome.winnerId,
    floats: outcome.floats,
    photoFinish: outcome.photoFinish,
    commitment: seedCommitment(v.serverSeed),
  };
}

/** The hash the API commits to before a round. */
export function seedCommitment(serverSeed: string): string {
  return sha256(serverSeed);
}

/** Sign a webhook payload the same way the API does. */
export function signWebhook(payload: string, secret: string): string {
  return hmacSha256(secret, payload);
}
