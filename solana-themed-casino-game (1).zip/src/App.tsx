import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import WheelCanvas from "./components/WheelCanvas";
import FxCanvas from "./components/FxCanvas";
import BonusGame from "./components/BonusGame";
import { BetBoard, ChipRail, History, LiveFeed, TopSlot } from "./components/Ui";
import { GameOverScreen, Logo, PauseOverlay, StartScreen } from "./components/Screens";
import {
  BET_SECONDS,
  CHIPS,
  MIN_BET,
  SPOTS,
  SPOT_ORDER,
  START_BALANCE,
  TOP_SLOT_MULTIS,
  WHEEL,
  fmt,
  pick,
  type SpotId,
} from "./game/constants";
import { fx, elCenter } from "./game/juice";
import { sfx } from "./game/audio";
import { loadMute, loadName, loadScores, saveScore, storeName, type ScoreEntry } from "./game/storage";
import { usePayment, DEPOSIT_PRESETS, onPaymentBalanceChange } from "./game/payment";
import * as api from "./game/api";
import { cn } from "./utils/cn";

/* ---------------------------------------------------------------- types */
type Phase = "bet" | "topslot" | "spin" | "result" | "bonus";
type Screen = "start" | "play" | "over" | "deposit";

/* ---------------------------------------------------------------- helpers */
const emptyBets = (): Record<SpotId, number> =>
  SPOT_ORDER.reduce((a, s) => ({ ...a, [s]: 0 }), {} as Record<SpotId, number>);

function useCountUp(value: number) {
  const [display, setDisplay] = useState(value);
  const ref = useRef(value);
  useEffect(() => {
    let raf = 0;
    const step = () => {
      const diff = value - ref.current;
      if (Math.abs(diff) < 0.6) {
        ref.current = value;
        setDisplay(value);
        return;
      }
      ref.current += diff * 0.18;
      setDisplay(Math.round(ref.current));
      raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [value]);
  return display;
}

/* ================================================================== APP */
export default function App() {
  /* ----- payment layer ----- */
  const payment = usePayment();

  /* ----- screens ----- */
  const [screen, setScreen] = useState<Screen>("start");
  const [paused, setPaused] = useState(false);
  const [phase, setPhase] = useState<Phase>("bet");
  const [muted, setMuted] = useState(loadMute);

  /* ----- player data ----- */
  const [name, setName] = useState(() => loadName());
  const [scores, setScores] = useState<ScoreEntry[]>(() => loadScores());
  const [stamp, setStamp] = useState(0);
  const [cashedOut, setCashedOut] = useState(false);
  const [finalScore, setFinalScore] = useState(0);

  /* ----- game state ----- */
  const [balance, setBalance] = useState(START_BALANCE);
  const [bets, setBets] = useState<Record<SpotId, number>>(emptyBets);
  const [lastBets, setLastBets] = useState<Record<SpotId, number>>(emptyBets);
  const [chip, setChip] = useState<number>(CHIPS[0].value);
  const [round, setRound] = useState(1);
  const [timeLeft, setTimeLeft] = useState(BET_SECONDS);
  const [history, setHistory] = useState<SpotId[]>([]);
  const [bestMulti, setBestMulti] = useState(0);

  /* ----- spin/topslot state ----- */
  const [topSlot, setTopSlot] = useState<{ spot: SpotId; multi: number } | null>(null);
  const [topRevealed, setTopRevealed] = useState(false);
  const [spinToken, setSpinToken] = useState(0);
  const [target, setTarget] = useState(0);
  const [winnerIdx, setWinnerIdx] = useState<number | null>(null);
  const [lastWin, setLastWin] = useState<{ amount: number; spot: SpotId; multi: number } | null>(null);
  const [flash, setFlash] = useState<SpotId | null>(null);
  const [toast, setToast] = useState<string>("");
  const [bonusStake, setBonusStake] = useState(0);
  const [bigFlash, setBigFlash] = useState(0);

  /* ----- refs ----- */
  const shakeRef = useRef<HTMLDivElement>(null);
  const wheelBoxRef = useRef<HTMLDivElement>(null);
  const phaseRef = useRef(phase);
  phaseRef.current = phase;
  const balanceRef = useRef(balance);
  balanceRef.current = balance;
  const totalBetRef = useRef(0);

  const totalBet = useMemo(() => SPOT_ORDER.reduce((a, s) => a + bets[s], 0), [bets]);
  totalBetRef.current = totalBet;
  const shownBalance = useCountUp(balance);
  const winner = winnerIdx !== null ? WHEEL[winnerIdx] : null;

  /* ----- derived ----- */
  const timePct = Math.max(0, Math.min(1, timeLeft / BET_SECONDS));
  const roundHash = useMemo(() => {
    let h = 2166136261;
    const s = `${name}:${round}:${stamp}`;
    for (let i = 0; i < s.length; i++) {
      h ^= s.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    return ("00000000" + (h >>> 0).toString(16)).slice(-8);
  }, [name, round, stamp]);

  const statusText =
    phase === "bet"
      ? timeLeft > 0
        ? "PLACE YOUR BETS"
        : "NO MORE BETS"
      : phase === "topslot"
        ? "TOP SLOT ROLLING"
        : phase === "spin"
          ? "WHEEL IN MOTION"
          : phase === "bonus"
            ? "BONUS ROUND"
            : "PAYING OUT";

  /* ----- effects ----- */
  useEffect(() => {
    fx.shakeTarget = shakeRef.current;
    sfx.setMuted(muted);
  }, [muted]);

  // auto-downscale chip when balance drops
  useEffect(() => {
    if (chip <= balance) return;
    const affordable = [...CHIPS].reverse().find((c) => c.value <= balance);
    if (affordable) setChip(affordable.value);
  }, [balance, chip]);

  // unlock audio on first tap
  useEffect(() => {
    const unlock = () => sfx.resume();
    window.addEventListener("pointerdown", unlock, { once: true });
    return () => window.removeEventListener("pointerdown", unlock);
  }, []);

  // sync payment balance → game balance
  useEffect(() => {
    onPaymentBalanceChange((newBal) => setBalance(newBal));
    return () => onPaymentBalanceChange(() => {});
  }, []);

  const say = useCallback((msg: string) => {
    setToast(msg);
    window.setTimeout(() => setToast((t) => (t === msg ? "" : t)), 1400);
  }, []);

  /* ======================================================== run management */
  const beginRun = useCallback(
    (playerName: string) => {
      sfx.resume();
      storeName(playerName);
      setName(playerName);
      payment.setBalance(START_BALANCE);
      setBalance(START_BALANCE);

      const starter = emptyBets();
      starter.one = 50;
      starter.crazytime = 10;
      setBets(starter);
      setLastBets(starter);
      setRound(1);
      setHistory([]);
      setBestMulti(0);
      setLastWin(null);
      setWinnerIdx(null);
      setTopSlot(null);
      setTopRevealed(false);
      setCashedOut(false);
      setTimeLeft(BET_SECONDS);
      setPhase("bet");
      setPaused(false);
      setScreen("play");
      fx.clear();
      sfx.win(1);

      // API callback
      api.initSession(playerName);
      api.advanceRound();
      api.emitSessionStart(START_BALANCE);

      say("starter bet on the table — hit SPIN");
    },
    [payment, say],
  );

  const endRun = useCallback(
    (didCashOut: boolean, finalBalance: number) => {
      setFinalScore(Math.round(finalBalance));
      const entry: ScoreEntry = {
        name: name || "anon",
        score: Math.round(finalBalance),
        rounds: round,
        best: bestMulti,
        cashedOut: didCashOut,
        date: Date.now(),
      };
      setScores(saveScore(entry));
      setStamp(entry.date);
      setCashedOut(didCashOut);
      setScreen("over");
      setPaused(false);

      // API callbacks
      if (didCashOut) api.emitCashOut(finalBalance);
      else api.emitBust(finalBalance);
      api.emitSessionEnd(finalBalance, round, bestMulti, didCashOut);

      if (didCashOut) {
        sfx.jackpot();
        fx.confettiRain(window.innerWidth, 120, ["#14F195", "#9945FF", "#19E8FF", "#FFD84D"]);
      } else {
        sfx.lose();
        fx.shake(26);
      }
    },
    [name, round, bestMulti],
  );

  /* ======================================================== betting */
  const place = useCallback(
    (spot: SpotId) => {
      if (screen !== "play" || phaseRef.current !== "bet" || paused) return;
      if (balance < chip) {
        sfx.deny();
        say("not enough credits");
        return;
      }
      setBalance((b) => b - chip);
      setBets((b) => ({ ...b, [spot]: b[spot] + chip }));
      sfx.chip();
      setFlash(spot);
      window.setTimeout(() => setFlash((f) => (f === spot ? null : f)), 220);
      const c = elCenter(document.getElementById("spot-" + spot));
      fx.burst(c.x, c.y, 8, [SPOTS[spot].color, "#ffffff"], {
        speed: 190,
        size: 3,
        life: 0.5,
        grav: 700,
      });

      // API callback
      api.emitBetPlaced(spot, chip, totalBetRef.current + chip);
    },
    [balance, chip, paused, say, screen],
  );

  const clearBets = useCallback(() => {
    if (phaseRef.current !== "bet") return;
    if (totalBetRef.current <= 0) return;
    const refunded = totalBetRef.current;
    setBalance((b) => b + refunded);
    setBets(emptyBets());
    sfx.click();
    say("bets cleared");
    api.emitBetCleared(refunded);
  }, [say]);

  const repeatBets = useCallback(() => {
    if (phaseRef.current !== "bet") return;
    const need = SPOT_ORDER.reduce((a, s) => a + lastBets[s], 0);
    if (need <= 0) {
      sfx.deny();
      say("no previous bet");
      return;
    }
    if (need > balance) {
      sfx.deny();
      say("not enough credits");
      return;
    }
    setBalance((b) => b - need);
    setBets((b) => {
      const n = { ...b };
      for (const s of SPOT_ORDER) n[s] += lastBets[s];
      return n;
    });
    sfx.chip();
    say("bet repeated");
    api.emitBetRepeated(need);
  }, [lastBets, balance, say]);

  /* ======================================================== spin flow */
  const launchSpin = useCallback(() => {
    if (phaseRef.current !== "bet") return;
    setLastBets(totalBetRef.current > 0 ? bets : lastBets);
    setPhase("topslot");
    setTopRevealed(false);
    const tsSpot = pick(SPOT_ORDER);
    const tsMulti = pick(TOP_SLOT_MULTIS);
    setTopSlot({ spot: tsSpot, multi: tsMulti });
    sfx.slot();
    api.emitSpinStart(totalBetRef.current, bets);
  }, [bets, lastBets]);

  /* --- betting countdown --- */
  const timeRef = useRef(BET_SECONDS);
  timeRef.current = timeLeft;
  useEffect(() => {
    if (screen !== "play" || phase !== "bet" || paused) return;
    const id = window.setInterval(() => {
      const n = Math.max(0, +(timeRef.current - 0.1).toFixed(1));
      timeRef.current = n;
      if (n > 0 && n <= 3 && Number.isInteger(n)) sfx.beep(n <= 1);
      setTimeLeft(n);
    }, 100);
    return () => window.clearInterval(id);
  }, [screen, phase, paused]);

  useEffect(() => {
    if (screen === "play" && phase === "bet" && timeLeft <= 0 && !paused) launchSpin();
  }, [timeLeft, phase, screen, paused, launchSpin]);

  /* --- topslot reveal -> spin --- */
  useEffect(() => {
    if (screen !== "play" || phase !== "topslot" || paused) return;
    const t1 = window.setTimeout(() => {
      setTopRevealed(true);
      sfx.bonusHit();
      if (topSlot) api.emitTopSlotResult(topSlot.spot, topSlot.multi);
      const c = elCenter(document.getElementById("topslot-box"));
      fx.burst(c.x, c.y, 26, ["#FFD84D", "#ffffff", "#9945FF"], { speed: 260, size: 3.5 });
      fx.shake(8);
    }, 1000);
    const t2 = window.setTimeout(() => {
      if (phaseRef.current !== "topslot") return;
      setTarget((Math.random() * WHEEL.length) | 0);
      setSpinToken((s) => s + 1);
      setWinnerIdx(null);
      setPhase("spin");
      sfx.whoosh();
      fx.shake(6);
    }, 1750);
    return () => {
      window.clearTimeout(t1);
      window.clearTimeout(t2);
    };
  }, [screen, phase, paused, topSlot]);

  /* --- settle payout --- */
  const settle = useCallback(
    (spot: SpotId, amountWon: number, multiLabel: number) => {
      setLastWin({ amount: amountWon, spot, multi: multiLabel });
      const newBal = balanceRef.current + amountWon;
      if (amountWon > 0) {
        setBalance(newBal);
        setBestMulti((m) => Math.max(m, multiLabel));
        setBigFlash((n) => n + 1);
        const c = elCenter(wheelBoxRef.current);
        const big = amountWon >= Math.max(totalBetRef.current * 8, 800);
        fx.float(c.x, c.y - 30, `+${fmt(amountWon)}`, "#14F195", big ? 54 : 38);
        fx.burst(c.x, c.y, big ? 90 : 40, ["#14F195", "#FFD84D", "#19E8FF", "#ffffff"], {
          speed: big ? 620 : 380,
          size: big ? 6 : 4,
          life: big ? 1.3 : 0.9,
        });
        fx.shake(big ? 30 : 14);
        if (big) {
          fx.confettiRain(window.innerWidth, 90, ["#14F195", "#9945FF", "#19E8FF", "#FFD84D"]);
          sfx.jackpot();
        } else {
          sfx.win(Math.min(4, Math.ceil(amountWon / Math.max(1, totalBetRef.current))));
        }
      } else {
        sfx.lose();
        fx.shake(6);
      }
      api.emitPayout(spot, amountWon, newBal);
      setPhase("result");
    },
    [],
  );

  /* --- wheel lands --- */
  const handleLand = useCallback(
    (idx: number) => {
      if (phaseRef.current !== "spin") return;
      setWinnerIdx(idx);
      const spot = WHEEL[idx];
      setHistory((h) => [spot, ...h].slice(0, 16));
      const stake = bets[spot];
      const def = SPOTS[spot];
      const tm = topSlot && topSlot.spot === spot ? topSlot.multi : 1;
      fx.shake(12);
      sfx.bonusHit();
      const c = elCenter(wheelBoxRef.current);
      fx.burst(c.x, c.y - 120, 26, [def.color, "#ffffff"], { speed: 300, size: 4 });
      api.emitSpinResult(idx, spot, def.pays === null);

      if (def.pays === null) {
        if (stake > 0) {
          setBonusStake(stake);
          api.emitBonusStart(spot, stake, tm);
          window.setTimeout(() => setPhase("bonus"), 700);
        } else {
          window.setTimeout(() => settle(spot, 0, 0), 500);
        }
      } else {
        const ratio = def.pays * tm;
        const won = stake > 0 ? stake * (ratio + 1) : 0;
        window.setTimeout(() => settle(spot, won, stake > 0 ? ratio : 0), 550);
      }
    },
    [bets, topSlot, settle],
  );

  /* --- bonus end --- */
  const finishBonus = useCallback(
    (multi: number) => {
      const spot = winner!;
      const payout = Math.round(bonusStake * multi);
      api.emitBonusResult(spot, multi, payout);
      settle(spot, payout, multi);
    },
    [bonusStake, settle, winner],
  );

  /* --- result -> next round --- */
  const nextRound = useCallback(() => {
    setBets(emptyBets());
    setWinnerIdx(null);
    setTopRevealed(false);
    setTopSlot(null);
    setLastWin(null);
    setRound((r) => r + 1);
    setTimeLeft(BET_SECONDS);
    setPhase("bet");
    api.advanceRound();
  }, []);

  useEffect(() => {
    if (screen !== "play" || phase !== "result" || paused) return;
    const t = window.setTimeout(nextRound, 2400);
    return () => window.clearTimeout(t);
  }, [screen, phase, paused, nextRound]);

  /* --- bust detection --- */
  useEffect(() => {
    if (screen !== "play" || phase !== "bet") return;
    if (balance < MIN_BET && totalBet === 0) {
      const t = window.setTimeout(() => endRun(false, balance), 900);
      return () => window.clearTimeout(t);
    }
  }, [screen, phase, balance, totalBet, endRun]);

  /* ======================================================== keyboard */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement) return;
      const k = e.code;
      if (k === "KeyM") {
        setMuted((m) => !m);
        return;
      }
      if (screen !== "play") return;
      if (k === "KeyP" || k === "Escape") {
        e.preventDefault();
        setPaused((p) => !p);
        sfx.click();
        return;
      }
      if (paused || phaseRef.current === "bonus") return;
      sfx.resume();
      const chipIdx = ["Digit1", "Digit2", "Digit3", "Digit4"].indexOf(k);
      if (chipIdx >= 0) {
        setChip(CHIPS[chipIdx].value);
        sfx.click();
        return;
      }
      const map: Record<string, SpotId> = {
        KeyQ: "one",
        KeyW: "two",
        KeyE: "five",
        KeyR: "ten",
        KeyA: "coinflip",
        KeyS: "pachinko",
        KeyD: "cashhunt",
        KeyF: "crazytime",
      };
      if (map[k]) {
        e.preventDefault();
        place(map[k]);
        return;
      }
      if (k === "KeyC") clearBets();
      if (k === "KeyX") repeatBets();
      if (k === "Space" || k === "Enter") {
        e.preventDefault();
        if (phaseRef.current === "bet") {
          launchSpin();
          sfx.click();
        } else if (phaseRef.current === "result") {
          nextRound();
          sfx.click();
        }
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [screen, paused, place, clearBets, repeatBets, launchSpin, nextRound]);

  /* ======================================================== RENDER */
  return (
    <div className="relative h-[100dvh] w-full overflow-hidden bg-[#06040d] bg-grid text-white">
      <FxCanvas />
      <div ref={shakeRef} className="flex h-full w-full flex-col will-change-transform">

        {/* ================================== HEADER ============================== */}
        <header className="z-20 flex shrink-0 items-center justify-between gap-1 border-b border-white/8 bg-black/40 px-2 py-1.5 backdrop-blur sm:px-4 sm:py-2">
          <Logo small />
          <div className="flex items-center gap-1 sm:gap-3">
            {/* balance pill — tappable to deposit on mobile */}
            <button
              onPointerDown={() => screen === "play" && setScreen("deposit")}
              className="rounded-lg border border-[#14F195]/30 bg-[#14F195]/10 px-2 py-1 text-right sm:px-3"
            >
              <div className="font-mono text-[7px] uppercase tracking-widest text-white/40">
                balance
              </div>
              <div className="font-display text-sm font-black leading-none text-[#14F195] sm:text-lg">
                {fmt(shownBalance)}
              </div>
            </button>
            <div className="hidden rounded-lg border border-white/10 bg-white/5 px-3 py-1 text-right sm:block">
              <div className="font-mono text-[8px] uppercase tracking-widest text-white/40">round</div>
              <div className="font-display text-lg font-black leading-none text-white/85">{round}</div>
            </div>
            <div className="hidden rounded-lg border border-white/10 bg-white/5 px-2 py-1 text-right sm:block sm:px-3">
              <div className="font-mono text-[8px] uppercase tracking-widest text-white/40">best</div>
              <div className="font-display text-base font-black leading-none text-[#FFD84D] sm:text-lg">
                ×{fmt(bestMulti)}
              </div>
            </div>
            {/* mobile: compact round+best */}
            <div className="flex flex-col items-end rounded-lg border border-white/10 bg-white/5 px-1.5 py-0.5 sm:hidden">
              <span className="font-mono text-[7px] text-white/40">R{round}</span>
              <span className="font-display text-[10px] font-black text-[#FFD84D]">×{fmt(bestMulti)}</span>
            </div>
            <button
              onPointerDown={() => setMuted((m) => !m)}
              className="grid h-7 w-7 place-items-center rounded-lg border border-white/10 bg-white/5 text-xs active:scale-90 sm:h-8 sm:w-8 sm:text-sm"
              aria-label="toggle sound"
            >
              {muted ? "🔇" : "🔊"}
            </button>
            <button
              onPointerDown={() => screen === "play" && setPaused((p) => !p)}
              className="grid h-7 w-7 place-items-center rounded-lg border border-white/10 bg-white/5 text-xs active:scale-90 sm:h-8 sm:w-8 sm:text-sm"
              aria-label="pause"
            >
              ⏸
            </button>
          </div>
        </header>

        {/* ================================== MAIN ============================== */}
        <main className="flex min-h-0 flex-1 flex-col gap-1.5 p-1.5 sm:gap-2 sm:p-2 lg:grid lg:grid-cols-[1fr_356px] lg:gap-3 lg:p-3">
          {/* === wheel column === */}
          <section className="relative flex min-h-[28dvh] min-w-0 flex-1 flex-col items-center justify-start gap-1 overflow-hidden sm:gap-1.5 lg:min-h-0">
            <div id="topslot-box" className="z-10 w-full max-w-[460px] shrink-0 px-1 sm:px-2">
              <TopSlot
                rolling={phase === "topslot" || phase === "spin"}
                spot={topSlot?.spot ?? null}
                multi={topSlot?.multi ?? null}
                revealed={topRevealed}
              />
            </div>

            <div ref={wheelBoxRef} className="relative min-h-0 w-full flex-1">
              <WheelCanvas
                spinToken={spinToken}
                targetIndex={target}
                duration={4300}
                paused={paused}
                winner={winnerIdx}
                onLand={handleLand}
              />

              {/* result overlay */}
              {phase === "result" && lastWin && (
                <div className="pointer-events-none absolute inset-x-0 bottom-1 z-20 flex justify-center">
                  <div
                    className="animate-pop rounded-2xl border px-4 py-1.5 text-center backdrop-blur-md sm:px-5 sm:py-2"
                    style={{
                      borderColor: SPOTS[lastWin.spot].color,
                      background: "rgba(6,4,13,0.86)",
                      boxShadow: `0 0 34px ${SPOTS[lastWin.spot].color}77`,
                    }}
                  >
                    <div
                      className="font-display text-base font-black uppercase leading-none sm:text-2xl"
                      style={{ color: SPOTS[lastWin.spot].color }}
                    >
                      {SPOTS[lastWin.spot].label}
                      {lastWin.multi > 0 && (
                        <span className="text-white/80">
                          {SPOTS[lastWin.spot].pays !== null
                            ? ` pays ${fmt(lastWin.multi)}:1`
                            : ` ×${fmt(lastWin.multi)}`}
                        </span>
                      )}
                    </div>
                    <div
                      className={cn(
                        "mt-0.5 font-mono text-xs font-bold sm:text-sm",
                        lastWin.amount > 0 ? "text-[#14F195]" : "text-white/40",
                      )}
                    >
                      {lastWin.amount > 0 ? `+${fmt(lastWin.amount)} credits` : "no win — next spin"}
                    </div>
                  </div>
                </div>
              )}

              {/* status ribbon */}
              <div className="pointer-events-none absolute inset-x-0 top-0 z-10 flex justify-center">
                <div
                  className={cn(
                    "rounded-full border px-2.5 py-0.5 font-mono text-[8px] uppercase tracking-[0.25em] backdrop-blur sm:text-[9px] sm:tracking-[0.3em]",
                    phase === "bet" && timeLeft > 0
                      ? "border-[#14F195]/50 bg-[#14F195]/10 text-[#14F195]"
                      : "border-[#FF3D6E]/50 bg-[#FF3D6E]/10 text-[#FF3D6E]",
                  )}
                >
                  {statusText}
                </div>
              </div>

              {/* provably fair hash */}
              <div className="pointer-events-none absolute inset-x-0 bottom-0 z-10 flex justify-center">
                <span className="font-mono text-[7px] tracking-wider text-white/20 sm:text-[8px]">
                  provably fair · #{round} · 0x{roundHash}
                </span>
              </div>
            </div>
          </section>

          {/* === betting column === */}
          <section className="z-10 flex max-h-[50dvh] shrink-0 flex-col gap-1 overflow-y-auto rounded-2xl border border-white/8 bg-black/45 p-1.5 backdrop-blur sm:gap-1.5 sm:p-2.5 lg:max-h-none lg:gap-3 lg:p-3">
            {/* timer */}
            <div>
              <div className="mb-0.5 flex items-baseline justify-between sm:mb-1">
                <span className="font-mono text-[8px] uppercase tracking-[0.2em] text-white/40 sm:text-[9px] sm:tracking-[0.3em]">
                  betting time
                </span>
                <span
                  className={cn(
                    "font-display text-sm font-black leading-none sm:text-lg",
                    timeLeft <= 3 ? "text-[#FF3D6E]" : "text-white",
                  )}
                >
                  {phase === "bet" ? Math.ceil(timeLeft) : 0}s
                </span>
              </div>
              <div className="h-1 w-full overflow-hidden rounded-full bg-white/10 sm:h-1.5">
                <div
                  className="h-full rounded-full transition-[width] duration-100 ease-linear"
                  style={{
                    width: `${phase === "bet" ? timePct * 100 : 0}%`,
                    background:
                      timeLeft <= 3
                        ? "linear-gradient(90deg,#FF3D6E,#FFD84D)"
                        : "linear-gradient(90deg,#9945FF,#14F195)",
                  }}
                />
              </div>
            </div>

            <History items={history} />

            <BetBoard
              bets={bets}
              onPlace={place}
              topSlotSpot={topRevealed ? (topSlot?.spot ?? null) : null}
              winner={phase === "result" || phase === "bonus" ? winner : null}
              disabled={phase !== "bet" || paused}
              flash={flash}
            />

            <ChipRail selected={chip} onSelect={(v) => (setChip(v), sfx.click())} balance={balance} />

            {/* total bet + action buttons */}
            <div className="flex items-center gap-1.5">
              <div className="flex-1 rounded-lg border border-white/8 bg-white/[0.03] px-2 py-1 text-right">
                <div className="font-mono text-[7px] uppercase tracking-widest text-white/35 sm:text-[9px]">
                  total bet
                </div>
                <div className="font-display text-sm font-black text-[#19E8FF] sm:text-base">
                  {fmt(totalBet)}
                </div>
              </div>
              <button
                onPointerDown={clearBets}
                disabled={phase !== "bet"}
                className="rounded-lg border border-white/12 px-2 py-1 font-mono text-[9px] uppercase text-white/65 transition active:scale-95 disabled:opacity-35 sm:px-3 sm:text-[10px]"
              >
                clear
              </button>
              <button
                onPointerDown={repeatBets}
                disabled={phase !== "bet"}
                className="rounded-lg border border-white/12 px-2 py-1 font-mono text-[9px] uppercase text-white/65 transition active:scale-95 disabled:opacity-35 sm:px-3 sm:text-[10px]"
              >
                repeat
              </button>
            </div>

            <button
              onPointerDown={launchSpin}
              disabled={phase !== "bet" || paused}
              className="relative overflow-hidden rounded-2xl py-2.5 font-display text-sm font-black uppercase tracking-wide text-black transition-transform active:scale-[0.97] disabled:opacity-40 sm:py-3.5 sm:text-lg"
              style={{
                background: "linear-gradient(100deg,#14F195,#19E8FF 50%,#9945FF)",
                boxShadow: "0 0 32px rgba(20,241,149,0.32)",
              }}
            >
              {phase === "bet" ? "SPIN NOW" : statusText}
            </button>

            <div className="hidden lg:block">
              <LiveFeed tick={round} />
            </div>
          </section>
        </main>

        {/* toast */}
        {toast && (
          <div className="pointer-events-none absolute left-1/2 top-14 z-40 -translate-x-1/2 sm:top-16">
            <div className="animate-pop rounded-full border border-white/15 bg-black/80 px-3 py-1 font-mono text-[10px] text-white/80 backdrop-blur sm:px-4 sm:py-1.5 sm:text-[11px]">
              {toast}
            </div>
          </div>
        )}
      </div>

      {/* ================================== OVERLAYS ================================== */}
      {bigFlash > 0 && (
        <div
          key={bigFlash}
          className="animate-flash pointer-events-none fixed inset-0 z-[55]"
          style={{
            background:
              "radial-gradient(circle at 50% 45%, rgba(20,241,149,0.55), rgba(153,69,255,0.25) 45%, transparent 72%)",
          }}
        />
      )}

      {/* bonus game overlay */}
      {screen === "play" && phase === "bonus" && winner && (
        <BonusGame
          kind={winner}
          stake={bonusStake}
          topMulti={topSlot && topSlot.spot === winner ? topSlot.multi : 1}
          paused={paused}
          onDone={finishBonus}
        />
      )}

      {/* pause overlay */}
      {screen === "play" && paused && (
        <PauseOverlay
          onResume={() => setPaused(false)}
          onRestart={() => beginRun(name)}
          onQuit={() => endRun(true, balance + totalBet)}
          muted={muted}
          onMute={() => setMuted((m) => !m)}
        />
      )}

      {/* start screen */}
      {screen === "start" && <StartScreen scores={scores} onStart={beginRun} />}

      {/* deposit screen */}
      {screen === "deposit" && (
        <DepositOverlay
          onClose={() => setScreen("play")}
          onDeposit={async (amount) => {
            const res = await payment.deposit(amount);
            if (res.ok) setBalance(res.newBalance);
          }}
          status={payment.status}
          error={payment.error}
          balance={balance}
        />
      )}

      {/* game over */}
      {screen === "over" && (
        <GameOverScreen
          score={finalScore}
          rounds={round}
          best={bestMulti}
          cashedOut={cashedOut}
          scores={scores}
          stamp={stamp}
          onRestart={() => beginRun(name)}
        />
      )}
    </div>
  );
}

/* ===================================================== DEPOSIT OVERLAY */
function DepositOverlay({
  onClose,
  onDeposit,
  status,
  error,
  balance,
}: {
  onClose: () => void;
  onDeposit: (amount: number) => Promise<void>;
  status: string;
  error: string | null;
  balance: number;
}) {
  const [loading, setLoading] = useState(false);
  const [amount, setAmount] = useState(0);

  const doDeposit = async (a: number) => {
    if (loading) return;
    setLoading(true);
    setAmount(a);
    await onDeposit(a);
    setLoading(false);
  };

  return (
    <div className="absolute inset-0 z-50 grid place-items-center bg-black/85 p-3 backdrop-blur-md">
      <div className="w-full max-w-sm rounded-3xl border border-[#14F195]/30 bg-gradient-to-b from-[#0f0b1f] to-[#07050f] p-5 shadow-[0_0_60px_rgba(20,241,149,0.2)]">
        <div className="mb-3 text-center">
          <div className="font-mono text-[10px] uppercase tracking-[0.3em] text-white/40">
            deposit credits
          </div>
          <div className="font-display text-xl font-black text-[#14F195]">
            current: {fmt(balance)}
          </div>
        </div>

        <div className="mb-4 grid grid-cols-2 gap-2">
          {DEPOSIT_PRESETS.map((p) => (
            <button
              key={p.amount}
              onPointerDown={() => doDeposit(p.amount)}
              disabled={loading}
              className="group rounded-xl border border-[#14F195]/30 bg-[#14F195]/8 py-2.5 transition active:scale-95 hover:border-[#14F195]/60"
            >
              <div className="font-display text-lg font-black text-[#14F195]">{p.label}</div>
              <div className="font-mono text-[9px] text-white/40">{p.sol}</div>
            </button>
          ))}
        </div>

        {status === "pending" && (
          <div className="mb-3 text-center font-mono text-sm text-[#19E8FF]">
            processing {fmt(amount)} credits…
          </div>
        )}
        {error && (
          <div className="mb-3 rounded-lg border border-[#FF3D6E]/40 bg-[#FF3D6E]/10 px-3 py-2 text-center font-mono text-xs text-[#FF3D6E]">
            {error}
          </div>
        )}
        {status === "confirmed" && (
          <div className="mb-3 rounded-lg border border-[#14F195]/40 bg-[#14F195]/10 px-3 py-2 text-center font-mono text-xs text-[#14F195]">
            ✓ credits deposited successfully
          </div>
        )}

        <button
          onPointerDown={onClose}
          className="w-full rounded-xl border border-white/15 py-2.5 font-mono text-xs text-white/65 active:scale-95"
        >
          back to game
        </button>
        <div className="mt-2 text-center font-mono text-[9px] text-white/30">
          powered by Solana Pay · instant settlement · demo mode
        </div>
      </div>
    </div>
  );
}
