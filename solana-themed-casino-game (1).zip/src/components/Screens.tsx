import { useEffect, useState } from "react";
import TolsLogo3D from "./TolsLogo3D";
import { SPOTS, SPOT_ORDER, START_BALANCE, fmt } from "../game/constants";
import { randomWallet, type ScoreEntry } from "../game/storage";
import { cn } from "../utils/cn";

/* ====================================================== LOGO */
export function Logo({ small }: { small?: boolean }) {
  return (
    <div className="flex items-center gap-1.5 sm:gap-2">
      {small ? (
        <TolsLogo3D size={28} color="#9945FF" animate="float" material="chrome" depth={1.0} />
      ) : (
        <TolsLogo3D size={52} color="#9945FF" animate="pulse" material="chrome" depth={1.3} />
      )}
      <div className="leading-none">
        <div className={cn("font-display font-black tracking-tight", small ? "text-sm" : "text-xl")}>
          <span className="text-white">TOLS</span>
          <span className="bg-gradient-to-r from-[#9945FF] to-[#14F195] bg-clip-text text-transparent">
            .FUN
          </span>
        </div>
        {!small && (
          <div className="font-mono text-[9px] uppercase tracking-[0.3em] text-white/40">
            crypto casino · live
          </div>
        )}
      </div>
    </div>
  );
}

/* ====================================================== SCORE TABLE */
export function ScoreTable({
  scores,
  highlight,
}: {
  scores: ScoreEntry[];
  highlight?: number;
}) {
  if (!scores.length)
    return (
      <div className="rounded-xl border border-dashed border-white/12 py-5 text-center font-mono text-[11px] text-white/35">
        no runs recorded yet — be the first degen
      </div>
    );
  return (
    <div className="space-y-1">
      {scores.map((s, i) => (
        <div
          key={s.date + "" + i}
          className={cn(
            "flex items-center gap-2 rounded-lg border px-2 py-1.5 font-mono text-[10px] sm:text-[11px]",
            highlight === s.date
              ? "border-[#14F195] bg-[#14F195]/15 text-white"
              : "border-white/8 bg-white/[0.03] text-white/70",
          )}
        >
          <span
            className={cn(
              "w-5 shrink-0 text-center font-display font-black",
              i === 0 ? "text-[#FFD84D]" : i === 1 ? "text-white/70" : i === 2 ? "text-[#c98c3c]" : "text-white/30",
            )}
          >
            {i + 1}
          </span>
          <span className="flex-1 truncate">{s.name}</span>
          <span className="hidden shrink-0 text-white/35 sm:inline">r{s.rounds}</span>
          <span className="shrink-0 text-[#19E8FF]">×{fmt(s.best)}</span>
          <span className="w-16 shrink-0 text-right font-bold text-[#14F195]">{fmt(s.score)}</span>
        </div>
      ))}
    </div>
  );
}

/* ====================================================== START SCREEN */
export function StartScreen({
  scores,
  onStart,
}: {
  scores: ScoreEntry[];
  onStart: (name: string) => void;
}) {
  const [name, setName] = useState(() => randomWallet());

  useEffect(() => {
    const k = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement && e.code !== "Enter") return;
      if (e.code === "Space" || e.code === "Enter") {
        e.preventDefault();
        onStart(name.trim() || randomWallet());
      }
    };
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  }, [name, onStart]);

  return (
    <div className="absolute inset-0 z-40 flex items-start justify-center overflow-y-auto bg-[#05040b]/92 p-3 backdrop-blur-md sm:p-4 sm:items-center">
      <div className="grid w-full max-w-4xl gap-3 sm:gap-4 lg:grid-cols-[1.25fr_1fr]">
        {/* left panel */}
        <div className="rounded-3xl border border-[#9945FF]/35 bg-gradient-to-b from-[#150e2b] to-[#07050f] p-4 shadow-[0_0_70px_rgba(153,69,255,0.25)] sm:p-7">
          <div className="flex items-center justify-center sm:justify-start">
            <Logo />
          </div>

          {/* 3D hero logo */}
          <div className="mt-4 flex justify-center sm:justify-start">
            <TolsLogo3D
              size={140}
              color="#9945FF"
              animate={"spinFloat"}
              material="holographic"
              depth={1.6}
              interactive
              className="drop-shadow-[0_0_30px_rgba(153,69,255,0.5)]"
            />
          </div>

          <h1 className="mt-3 text-center font-display text-4xl font-black leading-[0.88] tracking-tighter sm:text-left sm:text-6xl">
            <span className="block bg-gradient-to-r from-[#9945FF] via-[#19E8FF] to-[#14F195] bg-clip-text text-transparent">
              CRAZYTOLS
            </span>
            <span className="block text-lg font-bold text-white/70 sm:text-2xl">
              ON-CHAIN CASINO WHEEL
            </span>
          </h1>
          <p className="mt-2 max-w-md text-center text-xs leading-relaxed text-white/50 sm:text-left sm:text-sm">
            The classic 54-segment live money wheel, rebuilt for crypto casinos.
            Stack chips on numbers or four bonus rounds, chase the TOP SLOT
            multiplier and cash out before the wheel eats your bag.
          </p>

          {/* name input */}
          <div className="mt-4">
            <label className="font-mono text-[10px] uppercase tracking-[0.3em] text-white/40">
              player handle
            </label>
            <div className="mt-1.5 flex gap-2">
              <input
                value={name}
                maxLength={14}
                onChange={(e) => setName(e.target.value)}
                className="min-w-0 flex-1 rounded-xl border border-white/15 bg-black/50 px-3 py-2 font-mono text-sm text-[#14F195] outline-none transition focus:border-[#14F195] sm:py-2.5"
                placeholder="your.sol"
              />
              <button
                onPointerDown={() => setName(randomWallet())}
                className="rounded-xl border border-white/15 px-3 font-mono text-xs text-white/60 transition hover:border-[#9945FF] hover:text-white"
              >
                ⟳
              </button>
            </div>
          </div>

          <button
            onPointerDown={() => onStart(name.trim() || randomWallet())}
            className="group mt-3 w-full rounded-2xl px-6 py-3 font-display text-lg font-black uppercase tracking-wide text-black transition-transform duration-150 active:scale-[0.98] sm:mt-4 sm:py-4 sm:text-xl"
            style={{
              background: "linear-gradient(100deg,#14F195,#19E8FF 45%,#9945FF)",
              boxShadow: "0 0 45px rgba(20,241,149,0.4)",
            }}
          >
            Deposit {fmt(START_BALANCE)} · Play
          </button>
          <div className="mt-1.5 text-center font-mono text-[9px] text-white/35 sm:text-[10px]">
            press SPACE to start · demo credits · no real funds
          </div>

          {/* spot previews */}
          <div className="mt-4 grid grid-cols-4 gap-1.5 text-[10px] sm:grid-cols-4 sm:gap-2 sm:text-[11px]">
            {SPOT_ORDER.map((id) => {
              const d = SPOTS[id];
              return (
                <div
                  key={id}
                  className="rounded-lg border px-1.5 py-1 sm:px-2 sm:py-1.5"
                  style={{ borderColor: d.color + "44", background: d.color + "12" }}
                >
                  <div className="font-display text-xs font-black sm:text-sm" style={{ color: d.color }}>
                    {d.pays !== null ? d.label : d.icon + " " + d.short}
                  </div>
                  <div className="font-mono text-[8px] text-white/45 sm:text-[9px]">
                    {d.pays !== null ? `pays ${d.pays}:1` : "bonus"}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* right panel */}
        <div className="space-y-3">
          <div className="rounded-3xl border border-white/10 bg-[#0b0818]/90 p-3 sm:p-4">
            <div className="mb-2 font-mono text-[10px] uppercase tracking-[0.3em] text-white/40">
              hall of degens
            </div>
            <ScoreTable scores={scores} />
          </div>
          <div className="rounded-3xl border border-white/10 bg-[#0b0818]/90 p-3 sm:p-4">
            <div className="mb-2 font-mono text-[10px] uppercase tracking-[0.3em] text-white/40">
              controls
            </div>
            <div className="grid grid-cols-2 gap-1.5 font-mono text-[9px] text-white/55 sm:text-[10px]">
              {[
                ["1-4", "chip value"],
                ["Q W E R", "bet 1 / 2 / 5 / 10"],
                ["A S D F", "bet bonus spots"],
                ["SPACE", "spin now"],
                ["X", "repeat bet"],
                ["C", "clear bets"],
                ["P / ESC", "pause"],
                ["M", "mute"],
              ].map(([k, v]) => (
                <div key={k} className="flex items-center gap-1.5">
                  <kbd className="rounded bg-white/10 px-1.5 py-0.5 text-[8px] text-white/80">{k}</kbd>
                  <span>{v}</span>
                </div>
              ))}
            </div>
            <div className="mt-2 font-mono text-[9px] leading-relaxed text-white/35 sm:text-[10px]">
              Touch: tap chip → tap bet spot. Tappable everything.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ====================================================== PAUSE */
export function PauseOverlay({
  onResume,
  onRestart,
  onQuit,
  muted,
  onMute,
}: {
  onResume: () => void;
  onRestart: () => void;
  onQuit: () => void;
  muted: boolean;
  onMute: () => void;
}) {
  return (
    <div className="absolute inset-0 z-50 grid place-items-center bg-black/80 p-3 backdrop-blur-md sm:p-4">
      <div className="w-full max-w-xs rounded-3xl border border-[#9945FF]/40 bg-[#0c0918] p-4 text-center shadow-[0_0_60px_rgba(153,69,255,0.3)] sm:p-6">
        <div className="font-display text-2xl font-black tracking-tight text-white sm:text-3xl">PAUSED</div>
        <div className="mt-1 font-mono text-[9px] uppercase tracking-[0.3em] text-white/35 sm:text-[10px]">
          table on hold
        </div>
        <div className="mt-4 space-y-2 sm:mt-5">
          <button
            onPointerDown={onResume}
            className="w-full rounded-xl bg-gradient-to-r from-[#14F195] to-[#19E8FF] py-2.5 font-display font-black uppercase text-black active:scale-95 sm:py-3"
          >
            Resume
          </button>
          <button
            onPointerDown={onMute}
            className="w-full rounded-xl border border-white/15 py-2 font-mono text-[10px] text-white/70 active:scale-95 sm:py-2.5 sm:text-xs"
          >
            sound: {muted ? "off" : "on"}
          </button>
          <button
            onPointerDown={onRestart}
            className="w-full rounded-xl border border-white/15 py-2 font-mono text-[10px] text-white/70 active:scale-95 sm:py-2.5 sm:text-xs"
          >
            restart run
          </button>
          <button
            onPointerDown={onQuit}
            className="w-full rounded-xl border border-[#FF3D6E]/40 py-2 font-mono text-[10px] text-[#FF3D6E] active:scale-95 sm:py-2.5 sm:text-xs"
          >
            cash out &amp; end run
          </button>
        </div>
        <div className="mt-4 grid grid-cols-2 gap-1 text-left font-mono text-[8px] text-white/40 sm:text-[9px]">
          {[
            ["1-4", "chip"],
            ["Q W E R", "1 / 2 / 5 / 10"],
            ["A S D F", "bonus spots"],
            ["SPACE", "spin"],
            ["X", "repeat"],
            ["C", "clear"],
            ["P / ESC", "pause"],
            ["M", "mute"],
          ].map(([k, v]) => (
            <div key={k} className="flex items-center gap-1">
              <kbd className="rounded bg-white/10 px-1 py-0.5 text-[7px] text-white/75">{k}</kbd>
              <span className="truncate">{v}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ====================================================== GAME OVER */
export function GameOverScreen({
  score,
  rounds,
  best,
  cashedOut,
  scores,
  stamp,
  onRestart,
}: {
  score: number;
  rounds: number;
  best: number;
  cashedOut: boolean;
  scores: ScoreEntry[];
  stamp: number;
  onRestart: () => void;
}) {
  useEffect(() => {
    const k = (e: KeyboardEvent) => {
      if (e.code === "Space" || e.code === "Enter" || e.code === "KeyR") {
        e.preventDefault();
        onRestart();
      }
    };
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  }, [onRestart]);

  const rank = scores.findIndex((s) => s.date === stamp);

  return (
    <div className="absolute inset-0 z-50 flex items-start justify-center overflow-y-auto bg-[#05040b]/93 p-3 backdrop-blur-md sm:p-4 sm:items-center">
      <div className="w-full max-w-md rounded-3xl border border-white/12 bg-gradient-to-b from-[#140e28] to-[#07050f] p-4 shadow-[0_0_70px_rgba(153,69,255,0.25)] sm:p-6">
        <div className="text-center">
          <div className="mb-2 flex justify-center">
            <TolsLogo3D
              size={80}
              color={cashedOut ? "#14F195" : "#FF3D6E"}
              animate={cashedOut ? "float" : "wobble"}
              material="chrome"
              depth={1.0}
            />
          </div>
          <div className="font-mono text-[10px] uppercase tracking-[0.4em] text-white/40">
            {cashedOut ? "session closed" : "balance liquidated"}
          </div>
          <h2
            className="font-display text-3xl font-black tracking-tighter sm:text-5xl"
            style={{
              background: cashedOut
                ? "linear-gradient(90deg,#14F195,#19E8FF)"
                : "linear-gradient(90deg,#FF3D6E,#9945FF)",
              WebkitBackgroundClip: "text",
              backgroundClip: "text",
              color: "transparent",
            }}
          >
            {cashedOut ? "CASHED OUT" : "REKT"}
          </h2>
        </div>

        <div className="mt-3 grid grid-cols-3 gap-2 text-center sm:mt-4">
          {[
            ["final", fmt(score), "#14F195"],
            ["rounds", String(rounds), "#19E8FF"],
            ["best win", "×" + fmt(best), "#FFD84D"],
          ].map(([l, v, c]) => (
            <div key={l} className="rounded-xl border border-white/8 bg-white/[0.04] py-2 sm:py-2.5">
              <div className="font-mono text-[8px] uppercase tracking-widest text-white/35 sm:text-[9px]">{l}</div>
              <div className="font-display text-base font-black sm:text-lg" style={{ color: c }}>
                {v}
              </div>
            </div>
          ))}
        </div>

        {rank >= 0 && (
          <div className="mt-3 rounded-xl border border-[#FFD84D]/40 bg-[#FFD84D]/10 py-2 text-center font-display text-xs font-black text-[#FFD84D] sm:text-sm">
            🏆 NEW HIGH SCORE — RANK #{rank + 1}
          </div>
        )}

        <div className="mt-3 sm:mt-4">
          <div className="mb-2 font-mono text-[10px] uppercase tracking-[0.3em] text-white/40">
            hall of degens
          </div>
          <ScoreTable scores={scores} highlight={stamp} />
        </div>

        <button
          onPointerDown={onRestart}
          className="mt-4 w-full rounded-2xl py-3 font-display text-base font-black uppercase tracking-wide text-black active:scale-[0.98] sm:mt-5 sm:py-4 sm:text-lg"
          style={{
            background: "linear-gradient(100deg,#14F195,#19E8FF 50%,#9945FF)",
            boxShadow: "0 0 40px rgba(20,241,149,0.35)",
          }}
        >
          Re-buy &amp; Play Again
        </button>
        <div className="mt-1.5 text-center font-mono text-[9px] text-white/35 sm:text-[10px]">
          press SPACE / ENTER for instant restart
        </div>
      </div>
    </div>
  );
}
