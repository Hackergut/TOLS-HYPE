import { lazy, Suspense, useState } from "react";

const SVG3D = lazy(() =>
  import("3dsvg").then((m) => ({ default: m.SVG3D }))
);

const TOLS_SVG = `<svg xmlns="http://www.w3.org/2000/svg" width="192" height="192" viewBox="0 0 192 192">
  <path d="M0,12L12,12L24,12L36,12L48,12L60,12L72,12L84,12L96,12L108,12L120,12L132,12L144,12L156,12L168,12L180,12L192,12L192,24L192,36L192,48L192,60L192,72L192,84L192,96L180,96L168,96L156,96L144,96L144,108L144,120L144,132L144,144L144,156L144,168L144,180L144,192L132,192L120,192L108,192L96,192L84,192L72,192L60,192L48,192L48,180L48,168L48,156L48,144L48,132L48,120L48,108L48,96L36,96L24,96L12,96L0,96L0,84L0,72L0,60L0,48L0,36L0,24L0,12Z M12,24L24,24L36,24L48,24L60,24L72,24L84,24L96,24L108,24L120,24L132,24L144,24L156,24L168,24L180,24L180,36L180,48L180,60L180,72L180,84L168,84L156,84L144,84L132,84L132,96L132,108L132,120L132,132L132,144L132,156L132,168L132,180L120,180L108,180L96,180L84,180L72,180L60,180L60,168L60,156L60,144L60,132L60,120L60,108L60,96L60,84L48,84L36,84L24,84L12,84L12,72L12,60L12,48L12,36L12,24Z" fill="black" fill-rule="evenodd"/>
</svg>`;

function LogoFallback({ size }: { size: number }) {
  return (
    <div
      className="grid place-items-center rounded-2xl font-display font-black text-black"
      style={{
        width: size,
        height: size,
        background: "linear-gradient(135deg, #9945FF, #14F195)",
        fontSize: size * 0.42,
      }}
    >
      ◎
    </div>
  );
}

type TolsLogo3DProps = {
  size?: number;
  className?: string;
  color?: string;
  animate?: "spin" | "float" | "pulse" | "wobble" | "swing" | "spinFloat";
  material?:
    | "default"
    | "metal"
    | "glass"
    | "gold"
    | "chrome"
    | "clay"
    | "rubber"
    | "emissive"
    | "holographic"
    | "plastic";
  interactive?: boolean;
  depth?: number;
  onClick?: () => void;
};

export default function TolsLogo3D({
  size = 64,
  className = "",
  color = "#9945FF",
  animate = "pulse",
  material = "chrome",
  interactive = false,
  depth = 1.3,
  onClick,
}: TolsLogo3DProps) {
  const [ready, setReady] = useState(false);

  return (
    <div
      className={`relative ${className}`}
      style={{ width: size, height: size }}
      onClick={onClick}
      role={onClick ? "button" : undefined}
      tabIndex={onClick ? 0 : undefined}
    >
      <Suspense fallback={<LogoFallback size={size} />}>
        <SVG3D
          svg={TOLS_SVG}
          depth={depth}
          smoothness={0.6}
          color={color}
          material={material}
          metalness={1}
          roughness={0.26}
          animate={animate}
          animateSpeed={0.8}
          cursorOrbit={interactive}
          resetOnIdle={interactive}
          lightPosition={[3, 4.5, 10]}
          lightIntensity={4.2}
          ambientIntensity={1.8}
          onLoadingChange={(loading: boolean, progress: number) => {
            if (!loading && progress >= 100) setReady(true);
          }}
        />
        {!ready && (
          <div className="absolute inset-0 grid place-items-center">
            <LogoFallback size={size} />
          </div>
        )}
      </Suspense>
    </div>
  );
}
