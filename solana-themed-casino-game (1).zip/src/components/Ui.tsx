import { memo, useEffect, useRef, useState } from "react";
import { CHIPS, SPOTS, SPOT_ORDER, fmt, type SpotId } from "../game/constants";
import { cn } from "../utils/cn";

/* --------------------------------------------------------------- TOP SLOT */
export function TopSlot({
  rolling,
  spot,
  multi,
  revealed,
}: {
  rolling: boolean;
  spot: SpotId | null;
  multi: number | null;
  revealed: boolean;
}) {
  const [a, setA] = useState(0);
  const [b, setB] = useState(0);
  const multis = [2, 3, 4, 5, 7, 10, 15, 20, 25, 50];

  useEffect(() => {
    if (!rolling) return;
    const i1 = setInterval(() => setA((v) => (v + 1) % SPOT_ORDER.length), 70);
    const i2 = setInterval(() => setB((v) => (v + 1) % multis.length), 55);
    return () => {
      clearInterval(i1);
      clearInterval(i2);
    };
  }, [rolling]);

  const showSpot = revealed && spot ? SPOTS[spot] : SPOTS[SPOT_ORDER[a]];
  const showMulti = revealed && multi ? multi : multis[b];

  return (
    <div className="relative w-full max-w-[460px]">
      <div className="mb-1 text-center font-mono text-[9px] font-bold uppercase tracking-[0.42em] text-white/40">
        top slot
      </div>
      <div
        className={cn(
          "grid grid-cols-2 gap-1.5 rounded-2xl border border-white/15 bg-black/60 p-1.5 transition-shadow duration-300",
          revealed
            ? "shadow-[0_0_30px_rgba(255,216,77,0.45)]"
            : "shadow-[0_0_18px_rgba(153,69,255,0.25)]",
        )}
      >
        <div className="relative h-11 overflow-hidden rounded-xl bg-gradient-to-b from-white/10 to-black/60 sm:h-14">
          <div
            key={String(revealed) + showSpot.id}
            className={cn(
              "grid h-full w-full place-items-center font-display text-lg font-black uppercase tracking-tight sm:text-2xl",
              revealed && "animate-pop",
              rolling && !revealed && "blur-[1.2px]",
            )}
            style={{ color: showSpot.color, textShadow: `0 0 18px ${showSpot.color}99` }}
          >
            {showSpot.label}
          </div>
        </div>
        <div className="relative h-11 overflow-hidden rounded-xl bg-gradient-to-b from-white/10 to-black/60 sm:h-14">
          <div
            key={String(revealed) + showMulti}
            className={cn(
              "grid h-full w-full place-items-center font-display text-lg font-black text-[#FFD84D] sm:text-2xl",
              revealed && "animate-pop",
              rolling && !revealed && "blur-[1.2px]",
            )}
            style={{ textShadow: "0 0 18px rgba(255,216,77,0.8)" }}
          >
            ×{showMulti}
          </div>
        </div>
      </div>
    </div>
  );
}

/* --------------------------------------------------------------- CHIP RAIL */
export const ChipRail = memo(function ChipRail({
  selected,
  onSelect,
  balance,
}: {
  selected: number;
  onSelect: (v: number) => void;
  balance: number;
}) {
  return (
    <div className="flex items-center justify-start gap-1.5 pb-3 sm:gap-2">
      {CHIPS.map((c, i) => {
        const dis = c.value > balance;
        return (
          <button
            key={c.value}
            disabled={dis}
            onPointerDown={() => onSelect(c.value)}
            className={cn(
              "relative grid h-10 w-10 shrink-0 place-items-center rounded-full border-[2.5px] border-dashed font-display text-[10px] font-black transition-all duration-150 active:scale-90 sm:h-12 sm:w-12 sm:text-sm",
              selected === c.value
                ? "-translate-y-1 scale-110 ring-2 ring-white/30"
                : "opacity-75 active:opacity-100",
              dis && "cursor-not-allowed opacity-20",
            )}
            style={{
              borderColor: "rgba(255,255,255,0.75)",
              background: `radial-gradient(circle at 34% 28%, #ffffff33, ${c.color} 45%, ${c.ring})`,
              color: "#07040f",
              boxShadow:
                selected === c.value
                  ? `0 0 0 2px #fff, 0 0 26px ${c.color}, 0 8px 18px #000a`
                  : `0 4px 12px #0008`,
            }}
          >
            {c.label}
            <span className="absolute -bottom-3.5 font-mono text-[9px] text-white/40">{i + 1}</span>
          </button>
        );
      })}
    </div>
  );
});

/* --------------------------------------------------------------- BET BOARD */
export const BetBoard = memo(function BetBoard({
  bets,
  onPlace,
  topSlotSpot,
  winner,
  disabled,
  flash,
}: {
  bets: Record<SpotId, number>;
  onPlace: (s: SpotId) => void;
  topSlotSpot: SpotId | null;
  winner: SpotId | null;
  disabled: boolean;
  flash: SpotId | null;
}) {
  return (
    <div className="grid grid-cols-4 gap-1.5 sm:gap-2">
      {SPOT_ORDER.map((id) => {
        const d = SPOTS[id];
        const amt = bets[id];
        const isWin = winner === id;
        const isTop = topSlotSpot === id;
        return (
          <button
            key={id}
            id={"spot-" + id}
            disabled={disabled}
            onPointerDown={() => onPlace(id)}
            className={cn(
              "group relative flex h-[3.4rem] flex-col items-center justify-center overflow-hidden rounded-xl border-2 transition-all duration-150 active:scale-95 sm:h-[4.4rem]",
              disabled ? "opacity-55" : "hover:-translate-y-0.5",
              isWin && "animate-winpulse",
              flash === id && "animate-pop",
            )}
            style={{
              borderColor: isWin ? "#ffffff" : d.color + (amt ? "ff" : "66"),
              background: `linear-gradient(160deg, ${d.color}${amt ? "44" : "1a"} 0%, #0b0818 75%)`,
              boxShadow: isWin
                ? `0 0 32px ${d.color}, inset 0 0 20px ${d.color}66`
                : amt
                  ? `0 0 16px ${d.color}55`
                  : "none",
            }}
          >
            {isTop && (
              <span className="absolute right-0.5 top-0.5 rounded bg-[#FFD84D] px-1 font-mono text-[8px] font-black text-black">
                TOP
              </span>
            )}
            <span
              className="font-display text-base font-black leading-none sm:text-lg"
              style={{ color: d.color, textShadow: `0 0 12px ${d.color}77` }}
            >
              {d.pays !== null ? d.label : d.icon}
            </span>
            <span className="mt-0.5 font-mono text-[8.5px] uppercase leading-none tracking-wider text-white/55">
              {d.pays !== null ? `${d.pays}:1` : d.short}
            </span>
            {amt > 0 ? (
              <span
                className="mt-1 rounded-full px-1.5 py-[1px] font-mono text-[10px] font-bold text-black"
                style={{ background: d.color }}
              >
                {fmt(amt)}
              </span>
            ) : (
              <span className="mt-1 font-mono text-[9px] text-white/25">[{d.hotkey}]</span>
            )}
          </button>
        );
      })}
    </div>
  );
});

/* --------------------------------------------------------------- HISTORY */
export const History = memo(function History({ items }: { items: SpotId[] }) {
  return (
    <div className="flex items-center gap-1 overflow-hidden">
      <span className="shrink-0 font-mono text-[9px] uppercase tracking-widest text-white/35">
        last
      </span>
      <div className="flex flex-1 gap-1 overflow-hidden">
        {items.slice(0, 12).map((s, i) => {
          const d = SPOTS[s];
          return (
            <span
              key={i}
              className="grid h-6 w-6 shrink-0 place-items-center rounded-md font-display text-[10px] font-black"
              style={{
                background: d.color + "26",
                color: d.color,
                border: `1px solid ${d.color}66`,
                opacity: 1 - i * 0.055,
              }}
              title={d.label}
            >
              {d.pays !== null ? d.label : d.icon}
            </span>
          );
        })}
      </div>
    </div>
  );
});

/* --------------------------------------------------------------- LIVE FEED */
const NAMES = [
  "0xdeg3n", "solkid", "pumpwhale", "jito.sol", "bonk_lord", "anon4242",
  "meme.sol", "phantomX", "toly_fan", "rugsniper", "gm_ser", "chad.sol",
];
export function LiveFeed({ tick }: { tick: number }) {
  const [rows, setRows] = useState<{ n: string; a: number; k: string }[]>([]);
  const first = useRef(true);
  useEffect(() => {
    const make = () => ({
      n: NAMES[(Math.random() * NAMES.length) | 0],
      a: Math.round((10 + Math.pow(Math.random(), 3) * 9000) / 10) * 10,
      k: Math.random().toString(36).slice(2),
    });
    if (first.current) {
      setRows([make(), make(), make(), make()]);
      first.current = false;
      return;
    }
    setRows((r) => [make(), ...r].slice(0, 4));
  }, [tick]);
  return (
    <div className="space-y-1">
      <div className="font-mono text-[9px] uppercase tracking-[0.3em] text-white/35">
        live wins
      </div>
      {rows.map((r, i) => (
        <div
          key={r.k}
          className="flex items-center justify-between rounded-lg border border-white/5 bg-white/[0.03] px-2 py-1 font-mono text-[10px]"
          style={{ opacity: 1 - i * 0.22 }}
        >
          <span className="truncate text-white/55">{r.n}</span>
          <span className="font-bold text-[#14F195]">+{fmt(r.a)}</span>
        </div>
      ))}
    </div>
  );
}
