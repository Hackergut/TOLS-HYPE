import { useEffect, useRef } from "react";
import { SPOTS, WHEEL } from "../game/constants";
import { fx } from "../game/juice";
import { sfx } from "../game/audio";

const N = WHEEL.length;
const SEG = (Math.PI * 2) / N;
const CACHE_SIZE = 1024;

function buildWheelCache(): HTMLCanvasElement {
  const c = document.createElement("canvas");
  c.width = CACHE_SIZE;
  c.height = CACHE_SIZE;
  const ctx = c.getContext("2d")!;
  const cx = CACHE_SIZE / 2;
  const cy = CACHE_SIZE / 2;
  const R = CACHE_SIZE / 2 - 10;
  const rIn = R * 0.44;

  // outer dark ring
  ctx.beginPath();
  ctx.arc(cx, cy, R + 8, 0, Math.PI * 2);
  ctx.fillStyle = "#0a0716";
  ctx.fill();

  for (let i = 0; i < N; i++) {
    const def = SPOTS[WHEEL[i]];
    const mid = -Math.PI / 2 + i * SEG;
    const a0 = mid - SEG / 2;
    const a1 = mid + SEG / 2;

    const g = ctx.createRadialGradient(cx, cy, rIn, cx, cy, R);
    g.addColorStop(0, def.color2);
    g.addColorStop(0.55, def.color);
    g.addColorStop(1, def.color2);

    ctx.beginPath();
    ctx.arc(cx, cy, R, a0, a1);
    ctx.arc(cx, cy, rIn, a1, a0, true);
    ctx.closePath();
    ctx.fillStyle = g;
    ctx.fill();
    ctx.strokeStyle = "rgba(4,2,10,0.85)";
    ctx.lineWidth = 2;
    ctx.stroke();

    // gloss
    ctx.save();
    ctx.beginPath();
    ctx.arc(cx, cy, R, a0, a1);
    ctx.arc(cx, cy, R * 0.78, a1, a0, true);
    ctx.closePath();
    ctx.fillStyle = "rgba(255,255,255,0.10)";
    ctx.fill();
    ctx.restore();

    // label
    ctx.save();
    ctx.translate(cx, cy);
    ctx.fillStyle = def.ink;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    if (def.pays !== null) {
      ctx.rotate(mid + Math.PI / 2);
      ctx.font = `900 ${Math.round(R * (def.wheelText.length > 1 ? 0.064 : 0.078))}px "Space Grotesk", system-ui, sans-serif`;
      ctx.fillText(def.wheelText, 0, -R * 0.78);
      ctx.globalAlpha = 0.35;
      ctx.font = `700 ${Math.round(R * 0.032)}px "Space Grotesk", system-ui, sans-serif`;
      ctx.fillText(def.wheelText + ":1", 0, -R * 0.62);
    } else {
      ctx.rotate(mid);
      ctx.font = `900 ${Math.round(R * 0.046)}px "Space Grotesk", system-ui, sans-serif`;
      ctx.fillStyle = "rgba(255,255,255,0.96)";
      ctx.shadowColor = "rgba(0,0,0,0.6)";
      ctx.shadowBlur = 6;
      ctx.fillText(def.wheelText, R * 0.7, 0);
      ctx.shadowBlur = 0;
      ctx.beginPath();
      ctx.arc(R * 0.51, 0, R * 0.018, 0, Math.PI * 2);
      ctx.fillStyle = "rgba(255,255,255,0.9)";
      ctx.fill();
    }
    ctx.restore();
  }

  // inner hub rings on the wheel
  ctx.beginPath();
  ctx.arc(cx, cy, rIn, 0, Math.PI * 2);
  ctx.fillStyle = "#0b0818";
  ctx.fill();
  ctx.lineWidth = 6;
  ctx.strokeStyle = "rgba(153,69,255,0.55)";
  ctx.stroke();

  // pegs on segment boundaries
  for (let i = 0; i < N; i++) {
    const a = -Math.PI / 2 + i * SEG - SEG / 2;
    const px = cx + Math.cos(a) * (R + 1);
    const py = cy + Math.sin(a) * (R + 1);
    const pg = ctx.createRadialGradient(px - 2, py - 2, 0, px, py, 7);
    pg.addColorStop(0, "#fff8d8");
    pg.addColorStop(0.5, "#ffd84d");
    pg.addColorStop(1, "#7a5200");
    ctx.beginPath();
    ctx.arc(px, py, 6.5, 0, Math.PI * 2);
    ctx.fillStyle = pg;
    ctx.fill();
  }

  return c;
}

type Props = {
  spinToken: number;
  targetIndex: number;
  duration: number;
  paused: boolean;
  winner: number | null;
  onLand: (index: number) => void;
};

export default function WheelCanvas({
  spinToken,
  targetIndex,
  duration,
  paused,
  winner,
  onLand,
}: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const cacheRef = useRef<HTMLCanvasElement | null>(null);
  const landRef = useRef(onLand);
  landRef.current = onLand;

  const st = useRef({
    rot: 0,
    spinning: false,
    from: 0,
    to: 0,
    t: 0,
    dur: 3000,
    lastSeg: -1,
    flap: 0,
    flapV: 0,
    winner: null as number | null,
    winPulse: 0,
    paused: false,
    dpr: 1,
    size: 0,
  });

  st.current.paused = paused;
  st.current.winner = winner;

  useEffect(() => {
    cacheRef.current = buildWheelCache();
  }, []);

  // trigger a spin
  useEffect(() => {
    if (spinToken <= 0) return;
    const s = st.current;
    const offset = (Math.random() - 0.5) * SEG * 0.62;
    const desired = -targetIndex * SEG + offset;
    const spins = 5 + Math.floor(Math.random() * 2);
    const base = s.rot + spins * Math.PI * 2;
    const mod = (((desired - base) % (Math.PI * 2)) + Math.PI * 2) % (Math.PI * 2);
    s.from = s.rot;
    s.to = base + mod;
    s.t = 0;
    s.dur = duration;
    s.spinning = true;
    s.winPulse = 0;
  }, [spinToken, targetIndex, duration]);

  useEffect(() => {
    const canvas = canvasRef.current!;
    const ctx = canvas.getContext("2d", { alpha: true })!;
    const wrap = wrapRef.current!;
    let raf = 0;
    let last = performance.now();

    const resize = () => {
      const r = wrap.getBoundingClientRect();
      const size = Math.max(120, Math.min(r.width, r.height));
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = Math.round(size * dpr);
      canvas.height = Math.round(size * dpr);
      canvas.style.width = size + "px";
      canvas.style.height = size + "px";
      st.current.dpr = dpr;
      st.current.size = size;
    };
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(wrap);

    const frame = (now: number) => {
      raf = requestAnimationFrame(frame);
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      const s = st.current;
      const size = s.size;
      if (!size) return;

      let av = 0;
      if (!s.paused) {
        if (s.spinning) {
          s.t += dt * 1000;
          const k = Math.min(1, s.t / s.dur);
          const e = 1 - Math.pow(1 - k, 4.2);
          const wob = Math.sin(k * Math.PI * 2.2) * Math.pow(1 - k, 2.6) * SEG * 0.5;
          const prev = s.rot;
          s.rot = s.from + (s.to - s.from) * e + wob;
          av = Math.abs(s.rot - prev) / Math.max(dt, 0.0001);
          if (k >= 1) {
            s.spinning = false;
            s.rot = s.to;
            s.winPulse = 1;
            const idx = ((Math.round(-s.rot / SEG) % N) + N) % N;
            landRef.current(idx);
          }
        } else {
          s.rot += dt * 0.09;
          av = 0.09;
        }
        s.flapV += -s.flap * 90 * dt;
        s.flapV *= Math.pow(0.02, dt);
        s.flap += s.flapV * dt;
        if (s.winPulse > 0) s.winPulse = Math.max(0, s.winPulse - dt * 0.35);
      }

      // tick detection
      const seg = ((Math.round(-s.rot / SEG) % N) + N) % N;
      if (seg !== s.lastSeg) {
        if (s.lastSeg !== -1 && s.spinning) {
          const speed = Math.min(1, av / 22);
          sfx.tick(speed);
          s.flapV = -Math.min(7, 1.6 + av * 0.5);
          if (av < 6 && Math.random() < 0.6) {
            const rect = canvas.getBoundingClientRect();
            fx.burst(
              rect.left + rect.width / 2,
              rect.top + 8,
              2,
              ["#FFD84D", "#fff8d8"],
              { speed: 130, size: 2, grav: 500, life: 0.4, spread: 1.6, dir: Math.PI / 2 },
            );
          }
        }
        s.lastSeg = seg;
      }

      // ---- render ----
      const dpr = s.dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, size, size);
      const cx = size / 2;
      const cy = size / 2;
      const R = size / 2 - size * 0.045;

      // bezel glow
      const t = now / 1000;
      ctx.save();
      const bez = ctx.createRadialGradient(cx, cy, R * 0.9, cx, cy, R * 1.09);
      bez.addColorStop(0, "rgba(153,69,255,0.0)");
      bez.addColorStop(0.6, "rgba(153,69,255,0.35)");
      bez.addColorStop(1, "rgba(20,241,149,0.0)");
      ctx.fillStyle = bez;
      ctx.beginPath();
      ctx.arc(cx, cy, R * 1.09, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();

      // rim bulbs
      const bulbs = 36;
      for (let i = 0; i < bulbs; i++) {
        const a = (i / bulbs) * Math.PI * 2 - Math.PI / 2;
        const rr = R * 1.045;
        const bx = cx + Math.cos(a) * rr;
        const by = cy + Math.sin(a) * rr;
        const phase = (t * 2.2 + i / bulbs) % 1;
        const on = s.spinning ? phase < 0.34 : (t * 0.8 + i / bulbs) % 1 < 0.5;
        ctx.beginPath();
        ctx.arc(bx, by, size * 0.0075, 0, Math.PI * 2);
        ctx.fillStyle = on ? (i % 2 ? "#14F195" : "#9945FF") : "rgba(120,110,160,0.25)";
        ctx.fill();
      }

      // wheel
      const cache = cacheRef.current;
      if (cache) {
        ctx.save();
        ctx.translate(cx, cy);
        ctx.rotate(s.rot);
        ctx.drawImage(cache, -R, -R, R * 2, R * 2);
        ctx.restore();
      }

      // winner highlight
      if (s.winner !== null && !s.spinning) {
        const mid = -Math.PI / 2 + s.winner * SEG + s.rot;
        const pulse = 0.35 + 0.3 * Math.sin(t * 8);
        ctx.save();
        ctx.beginPath();
        ctx.arc(cx, cy, R, mid - SEG / 2, mid + SEG / 2);
        ctx.arc(cx, cy, R * 0.44, mid + SEG / 2, mid - SEG / 2, true);
        ctx.closePath();
        ctx.fillStyle = `rgba(255,255,255,${pulse * 0.55})`;
        ctx.fill();
        ctx.strokeStyle = `rgba(255,255,255,${0.5 + pulse * 0.5})`;
        ctx.lineWidth = 2.5;
        ctx.stroke();
        ctx.restore();
      }

      // hub
      ctx.save();
      const hr = R * 0.42;
      const hg = ctx.createRadialGradient(cx, cy - hr * 0.3, hr * 0.1, cx, cy, hr);
      hg.addColorStop(0, "#2a1a4d");
      hg.addColorStop(0.7, "#120c24");
      hg.addColorStop(1, "#07040f");
      ctx.beginPath();
      ctx.arc(cx, cy, hr, 0, Math.PI * 2);
      ctx.fillStyle = hg;
      ctx.fill();
      ctx.lineWidth = Math.max(2, size * 0.006);
      const ring = ctx.createLinearGradient(cx - hr, cy - hr, cx + hr, cy + hr);
      ring.addColorStop(0, "#9945FF");
      ring.addColorStop(1, "#14F195");
      ctx.strokeStyle = ring;
      ctx.stroke();

      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillStyle = "#ffffff";
      ctx.font = `900 ${Math.round(hr * 0.26)}px "Space Grotesk", system-ui, sans-serif`;
      ctx.fillText("CRAZY", cx, cy - hr * 0.24);
      const tg = ctx.createLinearGradient(cx - hr * 0.6, cy, cx + hr * 0.6, cy);
      tg.addColorStop(0, "#9945FF");
      tg.addColorStop(1, "#14F195");
      ctx.fillStyle = tg;
      ctx.font = `900 ${Math.round(hr * 0.26)}px "Space Grotesk", system-ui, sans-serif`;
      ctx.fillText("TOOLS", cx, cy + hr * 0.06);
      ctx.fillStyle = "rgba(255,255,255,0.5)";
      ctx.font = `700 ${Math.round(hr * 0.13)}px "JetBrains Mono", ui-monospace, monospace`;
      ctx.fillText("TOLS.FUN", cx, cy + hr * 0.36);
      ctx.restore();

      // flapper / pointer
      ctx.save();
      ctx.translate(cx, cy - R * 1.0);
      ctx.rotate(s.flap * 0.22);
      ctx.beginPath();
      ctx.moveTo(0, size * 0.062);
      ctx.lineTo(-size * 0.026, -size * 0.036);
      ctx.lineTo(0, -size * 0.018);
      ctx.lineTo(size * 0.026, -size * 0.036);
      ctx.closePath();
      const fg = ctx.createLinearGradient(0, -size * 0.04, 0, size * 0.06);
      fg.addColorStop(0, "#ffffff");
      fg.addColorStop(0.45, "#ffd84d");
      fg.addColorStop(1, "#ff8a00");
      ctx.fillStyle = fg;
      ctx.shadowColor = "rgba(255,190,60,0.85)";
      ctx.shadowBlur = size * 0.035;
      ctx.fill();
      ctx.shadowBlur = 0;
      ctx.strokeStyle = "rgba(60,30,0,0.7)";
      ctx.lineWidth = 1.5;
      ctx.stroke();
      ctx.restore();
    };

    raf = requestAnimationFrame(frame);
    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
    };
  }, []);

  return (
    <div ref={wrapRef} className="relative flex h-full w-full items-center justify-center">
      <canvas ref={canvasRef} className="block touch-none select-none" />
    </div>
  );
}
