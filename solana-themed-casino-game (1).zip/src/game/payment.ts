/**
 * CrazyTols Payment Integration Layer
 *
 * Provides a hook-based interface for deposits and withdrawals.
 * The actual implementation is swappable: Solana Pay, USDC/SOL SPL,
 * MetaMask (EVM), Stripe, or a mock adapter for dev.
 *
 * Usage from components:
 * ```tsx
 * const { balance, deposit, withdraw, status } = usePayment();
 * ```
 */

import { useCallback, useEffect, useRef, useState } from "react";
import { emitDeposit, emitWithdraw } from "./api";
import { START_BALANCE } from "./constants";

/* ------------------------------------------------------------------ types */

export type PaymentStatus = "idle" | "pending" | "confirmed" | "failed";
export type DepositResult = { ok: true; txHash: string; newBalance: number } | { ok: false; error: string };
export type WithdrawResult = { ok: true; txHash: string } | { ok: false; error: string };

export type PaymentProvider = {
  name: string;
  /** Connect wallet / auth — returns player address or null if cancelled */
  connect(): Promise<string | null>;
  /** Deposit funds into the game balance. Returns txHash or error. */
  deposit(amount: number, currency: string, playerAddress: string): Promise<{ txHash: string } | { error: string }>;
  /** Withdraw funds from game balance. Returns txHash or error. */
  withdraw(amount: number, currency: string, playerAddress: string): Promise<{ txHash: string } | { error: string }>;
  /** Check if currently connected */
  isConnected(): boolean;
  /** Get current connected address */
  getAddress(): string | null;
};

/* ---------------------------------------------------------------- mock adapter */

const mockProvider: PaymentProvider = {
  name: "demo",
  connect: async () => {
    await sleep(400);
    return "DEMO" + Math.random().toString(36).slice(2, 10);
  },
  deposit: async (_amount, _currency) => {
    await sleep(600 + Math.random() * 800);
    if (Math.random() < 0.03) return { error: "transaction failed — retry" };
    return { txHash: "0x" + Math.random().toString(36).slice(2, 14) };
  },
  withdraw: async (_amount, _currency) => {
    await sleep(600 + Math.random() * 800);
    if (Math.random() < 0.03) return { error: "insufficient on-chain balance" };
    return { txHash: "0x" + Math.random().toString(36).slice(2, 14) };
  },
  isConnected: () => true,
  getAddress: () => "DEMOw4LL3T",
};

/* ------------------------------------------------------------ provider mgmt */

let _provider: PaymentProvider = mockProvider;

export function setPaymentProvider(p: PaymentProvider) {
  _provider = p;
}

export function getPaymentProvider(): PaymentProvider {
  return _provider;
}

/* ----------------------------------------------------------- React hook */

export type UsePaymentReturn = {
  /** Current game balance (in credits) */
  balance: number;
  /** Set balance directly (from game engine) */
  setBalance: (n: number) => void;
  /** Start balance for reference */
  startBalance: number;
  /** Connect wallet */
  connect: () => Promise<string | null>;
  /** Connected wallet address (or null) */
  address: string | null;
  /** Provider display name */
  providerName: string;
  /** Deposit credits */
  deposit: (amount: number, currency?: string) => Promise<DepositResult>;
  /** Withdraw credits */
  withdraw: (amount: number, currency?: string) => Promise<WithdrawResult>;
  /** Current operation status */
  status: PaymentStatus;
  /** Last error message */
  error: string | null;
  /** Is connected to wallet */
  connected: boolean;
};

let _onBalanceChange: ((newBal: number) => void) | null = null;

export function onPaymentBalanceChange(cb: (newBal: number) => void) {
  _onBalanceChange = cb;
}

export function usePayment(): UsePaymentReturn {
  const [balance, setBalance] = useState(START_BALANCE);
  const [address, setAddress] = useState<string | null>(_provider.getAddress());
  const [status, setStatus] = useState<PaymentStatus>("idle");
  const [error, setError] = useState<string | null>(null);
  const balanceRef = useRef(balance);
  balanceRef.current = balance;

  useEffect(() => {
    setAddress(_provider.getAddress());
  }, []);

  const connect = useCallback(async () => {
    try {
      const addr = await _provider.connect();
      setAddress(addr);
      return addr;
    } catch (e) {
      setError(String(e));
      return null;
    }
  }, []);

  const deposit = useCallback(
    async (amount: number, currency = "SOL"): Promise<DepositResult> => {
      if (amount <= 0) return { ok: false, error: "amount must be > 0" };
      setStatus("pending");
      setError(null);
      try {
        if (!_provider.isConnected()) {
          const a = await _provider.connect();
          if (!a) {
            setStatus("failed");
            setError("wallet connection cancelled");
            return { ok: false, error: "cancelled" };
          }
          setAddress(a);
        }
        const addr = _provider.getAddress() || "";
        const res = await _provider.deposit(amount, currency, addr);
        if ("error" in res) {
          setStatus("failed");
          setError(res.error);
          return { ok: false, error: res.error };
        }
        const newBal = balanceRef.current + amount;
        setBalance(newBal);
        setStatus("confirmed");
        emitDeposit(amount, currency, res.txHash);
        if (_onBalanceChange) _onBalanceChange(newBal);
        return { ok: true, txHash: res.txHash, newBalance: newBal };
      } catch (e) {
        const msg = String(e);
        setStatus("failed");
        setError(msg);
        return { ok: false, error: msg };
      }
    },
    [],
  );

  const withdraw = useCallback(
    async (amount: number, currency = "SOL"): Promise<WithdrawResult> => {
      if (amount <= 0) return { ok: false, error: "amount must be > 0" };
      if (amount > balanceRef.current) return { ok: false, error: "insufficient balance" };
      setStatus("pending");
      setError(null);
      try {
        const addr = _provider.getAddress() || "";
        const res = await _provider.withdraw(amount, currency, addr);
        if ("error" in res) {
          setStatus("failed");
          setError(res.error);
          return { ok: false, error: res.error };
        }
        const newBal = balanceRef.current - amount;
        setBalance(newBal);
        setStatus("confirmed");
        emitWithdraw(amount, currency, addr);
        if (_onBalanceChange) _onBalanceChange(newBal);
        return { ok: true, txHash: res.txHash };
      } catch (e) {
        const msg = String(e);
        setStatus("failed");
        setError(msg);
        return { ok: false, error: msg };
      }
    },
    [],
  );

  return {
    balance,
    setBalance,
    startBalance: START_BALANCE,
    connect,
    address,
    providerName: _provider.name,
    deposit,
    withdraw,
    status,
    error,
    connected: _provider.isConnected(),
  };
}

/* ----------------------------------------------------------- deposit presets */

export const DEPOSIT_PRESETS = [
  { amount: 100, label: "100", sol: "≈0.04 SOL" },
  { amount: 500, label: "500", sol: "≈0.18 SOL" },
  { amount: 1000, label: "1K", sol: "≈0.36 SOL" },
  { amount: 5000, label: "5K", sol: "≈1.8 SOL" },
] as const;

/* ------------------------------------------------------------ util */

function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}
