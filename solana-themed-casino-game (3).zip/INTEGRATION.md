# CRAZYTOLS Platform Layout

## Structure

- `src/App.tsx`: platform composition, toolbar, keyboard shortcuts and dialogs.
- `src/components/PlatformShell.tsx`: navigation rail, TOLS branding, search and wallet header.
- `src/components/BetPanel.tsx`: chip presets, custom stakes, number/bonus bets and spin controls.
- `src/game/useCrazyTols.ts`: game state, ledger usage, round lifecycle and existing event callbacks.
- `src/game/payment.ts`: the shared balance and replaceable payment provider.
- `src/game/api.ts`: typed event subscriptions and an optional backend transport.
- `src/index.css`: responsive platform theme. Below 761px, the wheel sits above the betting controls.

The default entry screen is part of the table rather than a full-screen cover. Spin begins a session immediately; choosing a spot first reserves that stake. Clear refunds only unsettled bets. Ending a session never refunds a settled round.

## Events

Register `onEvent(listener)` to receive typed game events and retain the returned unsubscribe function. `setTransport(async event => { ... })` connects an analytics or backend notification adapter. It must return `void` or `Promise<void>`; check HTTP response status inside your adapter. Rejected transports are caught and reported to the console without changing local settlement.

The existing session, bet, spin, Top Slot, bonus, payout, deposit, withdrawal, cash-out and bust events are preserved. Each includes a session ID and timestamp; round events also include the round number. Event callbacks are notifications, not payment authorization or a reliable financial ledger. Implement server-side idempotency and reconciliation before accepting real funds.

The browser also exposes `window.CRAZYTOLS`. For a same-page integration use `CRAZYTOLS.onEvent(listener)`. For an iframe, call `CRAZYTOLS.configurePlatform({ parentOrigin: "https://casino.example" })`; events are never posted to a wildcard origin. To send events to an aggregator, configure an authenticated HTTPS adapter:

```ts
const transport = CRAZYTOLS.createHttpTransport({
  endpoint: "https://api.example.com/v1/crazytols/events",
  operatorId: "casino-example",
  getAccessToken: () => session.accessToken,
});
CRAZYTOLS.configurePlatform({ transport });
```

The adapter adds an idempotency key, operator ID, schema version and timeout. Keep access tokens short-lived. The aggregator must reject duplicate event IDs and must not trust payout amounts calculated by this browser.

## Auto Play

Auto Play supports 10, 25, 50 or 100 rounds, an optional stop-loss and an optional take-profit. It repeats the exact current bet map, reserves each next wager from the single balance ledger and stops when limits are reached or funds are insufficient. Bonus rounds still require player input. Opening a modal, hiding the page or pausing the game freezes transitions. A user-visible STOP control remains available while the sequence is active.

## RTP Audit

`src/game/math.ts` validates the 54-segment manifest and computes exact theoretical RTP for the four numeric bets, both before and after the current Top Slot feature. The Fairness dialog exposes these values and a deterministic 250,000-spin frequency test. The audit is versioned as `CRAZYTOLS-DEMO-1.1`.

Top Slot only selects number bets. Its weighted spot probabilities (35% / 33% / 20% / 12%) and 2.5x mean multiplier produce exact theoretical number RTP values from about 94.8% to 98.2%. Interactive bonus RTP is intentionally not claimed because bonus outcomes are generated in the browser. This profile is suitable for product/demo validation only. A real-money release requires a frozen full paytable, server-side outcome generation and settlement, regulatory lab certification, jurisdiction approvals and responsible-gaming controls.

## Payment Adapter

Call `setPaymentProvider(provider)` before mounting the application. The provider interface has `connect`, `deposit`, `withdraw`, `isConnected` and `getAddress` methods. It must confirm transactions before resolving. Both the game and wallet now use the same balance state; there is no independent wallet copy to overwrite game winnings or losses.

The supplied UI and adapter transact integer `CREDITS`, not SOL, lamports or tokens. No exchange rate is implied. The demo adapter only adds or removes local credits, and its identifiers explicitly start with `demo-`. The wallet is unavailable for transactions while a round is unsettled.

For a real platform, add authentication, currency conversion rules, server-authoritative session balances and outcome settlement, verified deposit webhooks, withdrawal authorization, idempotent transaction IDs and recovery after failed network requests. Never ship payment-provider secrets in this frontend. Replacing this adapter alone does not make the client-side game suitable for real-money play.

## Local Features

Favorites, player preferences and the top ten session scores use local storage. My Bets and notifications use actual session results. The weekly leaderboard filters locally saved scores; it is not a multiplayer race. Lottery is an explicit inactive platform placeholder, not a simulated draw. There are no fabricated live wins or cryptographic fairness claims.

## Mobile and Motion

The mobile layout supports safe-area insets, natural page scrolling, touch controls, custom numeric stakes and a lower-positioned Spin button. At 760px and below the wheel is enlarged to 148vw and horizontally cropped to its upper half, keeping the pointer and winning segment centered. Desktop retains the full wheel. The final third of each spin uses normalized exponential angular drag and a camera push toward the output; the pointer uses a frame-rate-independent damped-pendulum equation with velocity-proportional peg impulses. The main wheel pre-renders its segments and does not repaint continuously while idle. WebGL is limited to the optional lobby logo, with an official SVG fallback. All round and bonus transition timers pause with the game and cancel on restart. Reduced-motion preferences disable optional effects by default.

## Realtime Room

The social section has two explicit modes. `PRACTICE ROOM` uses simulated participants, activity and chat and labels them as simulated. `LIVE TABLE` only appears after an authenticated WebSocket opens. Connect it with:

```ts
await CRAZYTOLS.connectLive({
  url: "wss://realtime.example.com/v1/crazytols/room",
  getAccessToken: () => session.shortLivedRealtimeToken,
});
```

The first WebSocket message is `{ type: "auth", token }`. The server must verify the request origin, authenticate before accepting any other message, assign the room server-side, rate-limit chat and sanitize content. Supported incoming messages are `snapshot`, `event` (`join`, `bet`, `win`) and `chat`. The client bounds message size, text length and list length, but server validation remains mandatory. Calling `CRAZYTOLS.disconnectLive()` returns the UI to the clearly marked practice room.

## Verification

Production build: `npm run build`.

Manual browser checks: place and clear a bet, repeat a completed bet, change animation speed, pause and resume a spin and each bonus, add and withdraw demo credits, end a session, restart, reload the local leaderboard, and check portrait layouts at 360px and 390px. Device-specific frame rates and real payment integrations must be tested in the target platform.