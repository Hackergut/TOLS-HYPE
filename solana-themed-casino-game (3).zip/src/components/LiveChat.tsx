import { useEffect, useMemo, useRef, useState, type FormEvent } from "react";
import { fmt } from "../game/constants";
import { sendLiveChat, useLiveRoom } from "../game/live";
import type { RoundRecord } from "../game/useCrazyTols";
import Icon from "./Icon";

type Entry =
  | { kind: "message"; id: string; at: number; player: string; text: string; own?: boolean }
  | { kind: "event"; id: string; at: number; player: string; type: "join" | "bet" | "win"; amount?: number; own?: boolean };

export default function LiveChat({
  open,
  onClose,
  player,
  records,
}: {
  open: boolean;
  onClose: () => void;
  player: string;
  records: RoundRecord[];
}) {
  const room = useLiveRoom();
  const [tab, setTab] = useState<"chat" | "players">("chat");
  const [message, setMessage] = useState("");
  const streamRef = useRef<HTMLDivElement>(null);

  // Local rounds are real results; they are merged without being relabelled.
  const entries = useMemo<Entry[]>(() => {
    const own: Entry[] = records.slice(0, 6).map((record) => ({
      kind: "event",
      id: `own-${record.id}`,
      at: record.time,
      player: player || "You",
      type: record.payout > 0 ? "win" : "bet",
      amount: record.payout > 0 ? record.payout : record.bet,
      own: true,
    }));
    const feed: Entry[] = room.events.map((event) => ({
      kind: "event", id: event.id, at: event.at, player: event.player, type: event.type, amount: event.amount,
    }));
    const chat: Entry[] = room.messages.map((item) => ({
      kind: "message", id: item.id, at: item.at, player: item.player, text: item.text, own: item.own,
    }));
    return [...own, ...feed, ...chat].sort((a, b) => a.at - b.at).slice(-60);
  }, [records, room.events, room.messages, player]);

  useEffect(() => {
    if (!open || tab !== "chat") return;
    const node = streamRef.current;
    if (node) node.scrollTop = node.scrollHeight;
  }, [entries.length, open, tab]);

  const submit = (event: FormEvent) => {
    event.preventDefault();
    if (sendLiveChat(player, message)) setMessage("");
  };

  const live = room.mode === "live";
  const time = (at: number) => new Date(at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });

  return (
    <>
    {open && <button type="button" className="rail-scrim" aria-label="Close chat" onClick={onClose} />}
    <aside className={`live-rail ${open ? "open" : ""}`} aria-label={live ? "Live table chat" : "Practice room chat"} aria-hidden={!open}>
      <header className="rail-head">
        <div>
          <span className={`live-pulse ${room.mode}`} />
          <div>
            <strong>{live ? "LIVE TABLE" : room.mode === "connecting" ? "CONNECTING" : "PRACTICE ROOM"}</strong>
            <small>{room.online} {live ? "players online" : "simulated players"}</small>
          </div>
        </div>
        <button className="icon-button" onClick={onClose} aria-label="Close chat"><Icon name="close" size={17} /></button>
      </header>

      <div className="rail-tabs" role="tablist">
        <button role="tab" aria-selected={tab === "chat"} className={tab === "chat" ? "active" : ""} onClick={() => setTab("chat")}>Chat</button>
        <button role="tab" aria-selected={tab === "players"} className={tab === "players" ? "active" : ""} onClick={() => setTab("players")}>Players <span>{room.players.length}</span></button>
      </div>

      {tab === "chat" ? (
        <>
          <div className="rail-stream" ref={streamRef}>
            {entries.map((entry) => entry.kind === "message" ? (
              <div key={entry.id} className={`chat-line ${entry.own ? "own" : ""}`}>
                <span>{entry.player}</span>
                <p>{entry.text}</p>
                <time>{time(entry.at)}</time>
              </div>
            ) : (
              <div key={entry.id} className={`event-line ${entry.type} ${entry.own ? "own" : ""}`}>
                <i><Icon name={entry.type === "join" ? "plus" : entry.type === "win" ? "trophy" : "wheel"} size={12} /></i>
                <p><strong>{entry.player}</strong> {entry.type === "join" ? "joined the table" : entry.type === "win" ? "won" : "bet"}
                  {entry.amount ? <b>{entry.type === "win" ? "+" : ""}{fmt(entry.amount)} CR</b> : null}
                </p>
              </div>
            ))}
          </div>
          <form className="rail-compose" onSubmit={submit}>
            <input value={message} onChange={(event) => setMessage(event.target.value)} maxLength={80} placeholder={live ? "Message the table..." : "Chat in practice room..."} aria-label="Chat message" />
            <button disabled={!message.trim()} aria-label="Send message"><Icon name="arrow" size={16} /></button>
          </form>
        </>
      ) : (
        <div className="rail-players">
          {room.players.map((item) => (
            <div key={item.id}>
              <i style={{ background: item.color }}>{item.name.slice(0, 2).toUpperCase()}</i>
              <div><strong>{item.name}</strong><small>{live ? "at the table" : "simulated player"}</small></div>
              <span className="player-dot" style={{ background: item.color }} />
            </div>
          ))}
        </div>
      )}

      <p className="rail-note">
        <Icon name="shield" size={11} />
        {live ? "Verified realtime feed." : "Preview room. Players and activity are simulated."}
      </p>
    </aside>
    </>
  );
}
