import { useState, type FormEvent } from "react";
import Dialog from "./Dialog";
import Icon from "./Icon";
import { ScoreTable } from "./ActivityTable";
import { SolanaCoin } from "./Brand";
import TolsLogo3D from "./TolsLogo3D";
import type { Panel } from "./PlatformShell";
import type { CrazyTolsGame } from "../game/useCrazyTols";
import { DEPOSIT_PRESETS } from "../game/payment";
import { fmt } from "../game/constants";
import { spotLabel } from "./BetPanel";
import { MATH_AUDIT, simulateWheel } from "../game/math";

function Toggle({ label, description, checked, onChange }: { label: string; description: string; checked: boolean; onChange: () => void }) {
  return <div className="setting-row"><div><strong>{label}</strong><p>{description}</p></div><button role="switch" className={`toggle ${checked ? "on" : ""}`} aria-checked={checked} aria-label={label} onClick={onChange}><i /></button></div>;
}

function WalletDialog({ game, close }: { game: CrazyTolsGame; close: () => void }) {
  const [tab, setTab] = useState<"deposit" | "withdraw">("deposit");
  const [amount, setAmount] = useState(500);
  const [message, setMessage] = useState<{ ok: boolean; text: string } | null>(null);
  const [pending, setPending] = useState(false);
  const canTransact = (game.phase === "bet" || game.phase === "result") && !game.autoPlay.active;
  const submit = async (event: FormEvent) => {
    event.preventDefault();
    if (pending || !canTransact) return;
    game.ensureSession();
    setPending(true);
    setMessage(null);
    const response = await game.payment[tab](amount, "CREDITS");
    setMessage(response.ok ? { ok: true, text: `${fmt(amount)} credits ${tab === "deposit" ? "added to" : "removed from"} your demo balance.` } : { ok: false, text: response.error });
    setPending(false);
  };
  return <Dialog title="Your wallet" subtitle="Your balance, all in one place." onClose={close} locked={pending}>
    <div className="wallet-balance"><span>Available balance</span><div><SolanaCoin /><strong>{fmt(game.balance)}</strong><span>CR</span></div><small>{game.payment.providerName === "demo" ? "Demo wallet. No blockchain transactions." : `Provider: ${game.payment.providerName}`}</small></div>
    <div className="dialog-tabs">{(["deposit", "withdraw"] as const).map((item) => <button key={item} disabled={pending} className={tab === item ? "active" : ""} onClick={() => { setTab(item); setMessage(null); }}>{item === "deposit" ? "Add credits" : "Withdraw"}</button>)}</div>
    {!canTransact && <p className="notice-box">Finish the current round and stop Auto Play before managing funds. Close the wallet to resume your game.</p>}
    <form onSubmit={submit}>
      <label className="dialog-field">Amount in credits<input type="number" inputMode="numeric" min="1" step="1" max={tab === "withdraw" ? game.balance : 1000000} value={amount || ""} required disabled={pending || !canTransact} onChange={(event) => setAmount(Number(event.target.value))} /></label>
      <div className="deposit-presets">{DEPOSIT_PRESETS.map((preset) => <button type="button" key={preset.amount} className={preset.amount === amount ? "active" : ""} disabled={pending || !canTransact || (tab === "withdraw" && preset.amount > game.balance)} onClick={() => setAmount(preset.amount)}>{preset.label}</button>)}</div>
      {message && <p className={`payment-message ${message.ok ? "success" : "error"}`} role="status"><Icon name={message.ok ? "check" : "info"} size={17} />{message.text}</p>}
      <button type="submit" className="primary-button" disabled={pending || !canTransact || !Number.isSafeInteger(amount) || amount <= 0}>{pending ? <><span className="button-spinner" />Processing</> : tab === "deposit" ? "Add demo credits" : "Withdraw demo credits"}</button>
    </form>
    <p className="dialog-footnote">Credits have no cash value. Real payments require your platform's authenticated backend and payment provider.</p>
  </Dialog>;
}

export default function PlatformDialogs({ panel, game, close, autoSpin, setAutoSpin, effects, setEffects, onGame }: {
  panel: Panel; game: CrazyTolsGame; close: () => void; autoSpin: boolean; setAutoSpin: (value: boolean) => void;
  effects: boolean; setEffects: (value: boolean) => void; onGame: () => void;
}) {
  const [search, setSearch] = useState("");
  const [autoRounds, setAutoRounds] = useState(10);
  const [stopLoss, setStopLoss] = useState(0);
  const [takeProfit, setTakeProfit] = useState(0);
  const [simulation, setSimulation] = useState<ReturnType<typeof simulateWheel> | null>(null);
  if (panel === "autoplay") return <Dialog title="Auto Play" subtitle="Set your limits before the wheel starts." onClose={close}>
    <div className="autoplay-summary"><span>Bet per spin</span><strong>{fmt(game.totalBet)} CR</strong><small>Your current bets repeat unchanged.</small></div>
    {!game.totalBet && <p className="notice-box">Place at least one bet before starting Auto Play.</p>}
    <div className="autoplay-rounds"><span>Number of spins</span><div>{[10, 25, 50, 100].map((value) => <button key={value} className={autoRounds === value ? "active" : ""} onClick={() => setAutoRounds(value)}>{value}</button>)}</div></div>
    <div className="limit-grid">
      <label className="dialog-field">Stop-loss (credits)<input type="number" inputMode="numeric" min="0" step="10" value={stopLoss} onChange={(event) => setStopLoss(Math.max(0, Number(event.target.value)))} /></label>
      <label className="dialog-field">Take-profit (credits)<input type="number" inputMode="numeric" min="0" step="10" value={takeProfit} onChange={(event) => setTakeProfit(Math.max(0, Number(event.target.value)))} /></label>
    </div>
    <div className="auto-safety"><Icon name="shield" size={18} /><p>Auto Play stops after the selected spins, when a limit is reached, when funds are insufficient, or when you press STOP. Bonus rounds still require your input.</p></div>
    <button className="primary-button" disabled={!game.totalBet || game.screen === "over"} onClick={() => { if (game.startAutoPlay(autoRounds, stopLoss, takeProfit)) close(); }}><Icon name="play" size={16} />Start {autoRounds} spins</button>
    <p className="dialog-footnote">Limits compare your available balance with the bankroll at Auto Play start. Closing the page stops the sequence.</p>
  </Dialog>;
  if (panel === "wallet") return <WalletDialog game={game} close={close} />;
  if (panel === "settings") return <Dialog title="Game settings" subtitle="Make this table yours." onClose={close}>
    <label className="dialog-field">Player name<input value={game.name} maxLength={18} disabled={game.screen === "play"} onChange={(event) => game.setName(event.target.value)} placeholder="Your name" /></label>
    {game.screen === "play" && <p className="dialog-footnote">Your player name can be changed between sessions.</p>}
    <Toggle label="Game sounds" description="Wheel ticks, chips and win sounds." checked={!game.muted} onChange={() => game.setMuted(!game.muted)} />
    <Toggle label="Win effects" description="Particles, confetti and screen shake." checked={effects} onChange={() => setEffects(!effects)} />
    <Toggle label="Betting countdown" description="Spin automatically 10 seconds after a bet." checked={autoSpin} onChange={() => setAutoSpin(!autoSpin)} />
    <div className="dialog-actions">
      <button className="secondary-button" disabled={game.screen !== "play"} onClick={() => { game.setUserPaused(true); close(); }}><Icon name="pause" size={16} />Pause game</button>
      <button className="secondary-button" disabled={!game.canCashOut} onClick={() => { game.cashOut(); close(); }}><Icon name="logout" size={16} />End session</button>
    </div>
    <button className="text-link centered" onClick={() => { game.restart(); close(); }} disabled={game.payment.providerName !== "demo"}><Icon name="repeat" size={14} />Restart demo</button>
  </Dialog>;
  if (panel === "vip") return <Dialog title="High rollers" subtitle="Your best sessions, saved on this device." onClose={close}><ScoreTable scores={game.scores} /></Dialog>;
  if (panel === "notifications") return <Dialog title="Notifications" subtitle="Updates from your current session." onClose={close}>
    {game.records.length ? <div className="notifications-list">{game.records.slice(0, 6).map((record) => <div key={record.id}><Icon name={record.payout > 0 ? "trophy" : "wheel"} /><div><strong>{record.payout ? `You won ${fmt(record.payout)} credits` : `Round ${record.round} complete`}</strong><p>{spotLabel(record.spot)} &middot; {new Date(record.time).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</p></div></div>)}</div> : <div className="empty-state compact"><Icon name="bell" size={28} /><strong>You're all caught up.</strong><p>Your round results will appear here.</p></div>}
  </Dialog>;
  if (panel === "fairness") return <Dialog title="Math & fairness audit" subtitle="Transparent demo mathematics. Not a gambling certification." onClose={close} wide>
    <div className="info-intro"><Icon name="shield" size={30} /><div><strong>Demo mode</strong><p>54 segments. One randomly selected outcome.</p></div></div>
    <p className="body-copy">The wheel distribution is checked at startup against the versioned math manifest. The values below are exact theoretical returns for number bets under the current client settlement and Top Slot rules.</p>
    <div className={`math-status ${MATH_AUDIT.passed ? "passed" : "failed"}`}><Icon name={MATH_AUDIT.passed ? "check" : "info"} size={16} /><strong>{MATH_AUDIT.passed ? "Math manifest passed" : "Math manifest failed"}</strong><span>{MATH_AUDIT.version}</span></div>
    <div className="rtp-table"><div><span>Spot</span><span>Chance</span><span>Base RTP</span><span>With Top Slot</span></div>{MATH_AUDIT.numberRtp.map((row) => <div key={row.spot}><strong>{spotLabel(row.spot)}</strong><span>{(row.probability * 100).toFixed(4)}%</span><span>{(row.baseRtp * 100).toFixed(4)}%</span><span>{(row.topSlotRtp * 100).toFixed(4)}%</span></div>)}</div>
    <dl className="detail-list"><div><dt>Segments</dt><dd>1: 21 / 2: 13 / 5: 7 / 10: 4 / Bonus: 9</dd></div><div><dt>Top Slot mean</dt><dd>{MATH_AUDIT.topSlotMean.toFixed(6)}x across 10 weighted entries</dd></div><div><dt>Top Slot spots</dt><dd>1: 35% / 2: 33% / 5: 20% / 10: 12%</dd></div><div><dt>Payment mode</dt><dd>{game.payment.providerName === "demo" ? "Demo credits only" : game.payment.providerName}</dd></div></dl>
    <button className="secondary-button audit-button" onClick={() => setSimulation(simulateWheel())}><Icon name="chart" size={16} />Run 250,000-spin sampler test</button>
    {simulation && <div className={`simulation-result ${simulation.passed ? "passed" : "failed"}`}><strong>{simulation.passed ? "PASS" : "REVIEW"}</strong><span>{simulation.spins.toLocaleString()} deterministic spins</span><span>max frequency deviation {(simulation.maxDeviation * 100).toFixed(4)}%</span></div>}
    <p className="dialog-footnote">Exact numeric RTP range: 94.814815%-98.194444%. Bonus RTP is not claimed: interactive bonus results are currently client-generated. Before real-money release, move outcomes and settlement server-side, freeze a complete bonus paytable, independently certify RNG/RTP, and obtain the required gaming approvals. Frontend tests alone cannot make a game live-ready.</p>
  </Dialog>;
  if (panel === "responsible") return <Dialog title="Play at your own pace" subtitle="Keep it fun. Stay in control." onClose={close}>
    <p className="body-copy">This demo uses credits with no monetary value. Outcomes are random and past results do not predict the next spin. Take a break whenever you need one.</p>
    <dl className="detail-list"><div><dt>Rounds played</dt><dd>{game.completed}</dd></div><div><dt>Available credits</dt><dd>{fmt(game.balance)}</dd></div></dl>
    <div className="dialog-actions"><button className="primary-button" onClick={() => { game.setUserPaused(true); close(); }} disabled={game.screen !== "play"}>Take a break</button><button className="secondary-button" onClick={() => { game.cashOut(); close(); }} disabled={!game.canCashOut}>End session</button></div>
    <p className="dialog-footnote">Real-money platforms must apply local licensing, age verification and responsible-gaming requirements.</p>
  </Dialog>;
  if (panel === "lobby" || panel === "search") return <Dialog title={panel === "search" ? "Search games" : "Welcome to TOLS"} subtitle="A little luck. A lot of possibility." onClose={close}>
    {panel === "search" && <label className="dialog-field">Find your game<input placeholder="Search games..." value={search} onChange={(event) => setSearch(event.target.value)} autoFocus /></label>}
    {panel !== "search" && <div className="lobby-logo"><TolsLogo3D size={116} color="#06b6d4" animate={effects ? "pulse" : "none"} material="chrome" interactive depth={1.3} /></div>}
    {!search || "crazytols wheel casino".includes(search.toLowerCase()) ? <button className="lobby-game" onClick={() => { close(); onGame(); }}><span><Icon name="wheel" size={28} /></span><div><strong>CRAZYTOLS</strong><p>TOLS Original &middot; 4 bonus rounds</p></div><Icon name="arrow" /></button> : <div className="empty-state compact"><p>No games match your search.</p></div>}
    <p className="dialog-footnote">Play instantly with 1,000 demo credits. No wallet required.</p>
  </Dialog>;
  if (panel === "rules" || panel === "help") return <Dialog title={panel === "rules" ? "How to play CRAZYTOLS" : "TOLS help center"} subtitle="One wheel. Four ways to go a little crazy." onClose={close} wide>
    <ol className="how-to"><li><b>01</b><div><strong>Set your bet</strong><p>Enter an amount or select a quick chip. Minimum: 10 credits.</p></div></li><li><b>02</b><div><strong>Pick your spots</strong><p>Tap a number or bonus to add a chip. You can bet on several spots.</p></div></li><li><b>03</b><div><strong>Give it a spin</strong><p>Top Slot boosts one spot. If the wheel lands on your bet, you win.</p></div></li></ol>
    <div className="bonus-guide">
      {[["Coin Flip", "Flip the coin. Red or blue reveals your multiplier."], ["Cash Hunt", "Choose a hidden target before the timer runs out."], ["Pachinko", "Aim your drop. Bounce through pegs to a multiplier."], ["CrazyTols", "Pick a flapper and spin the bonus wheel. Doubles trigger a respin."]].map(([title, description]) => <details key={title}><summary>{title}<Icon name="plus" size={15} /></summary><p>{description}</p></details>)}
    </div>
    <div className="keyboard-guide">{[["SPACE", "Spin / next round"], ["1 - 4", "Select quick chip"], ["Q W E R", "Bet on numbers"], ["A S D F", "Bet on bonuses"], ["C / X", "Clear / repeat bets"], ["P / ESC", "Pause / resume"]].map(([key, value]) => <div key={key}><kbd>{key}</kbd><span>{value}</span></div>)}</div>
    <p className="dialog-footnote">On touch screens, every action is available with a tap. All balances are demo credits.</p>
  </Dialog>;
  return null;
}