import { useEffect, useRef, useState, type ReactNode } from "react";
import Icon, { type IconName } from "./Icon";
import { SolanaCoin, TolsMark, TolsWordmark } from "./Brand";
import { fmt } from "../game/constants";

export type Panel = "wallet" | "settings" | "help" | "fairness" | "rules" | "lobby" | "vip" | "responsible" | "notifications" | "search" | "autoplay" | null;

function BalanceValue({ value }: { value: number }) {
  const [display, setDisplay] = useState(value);
  const previous = useRef(value);
  useEffect(() => {
    const from = previous.current;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      previous.current = value;
      setDisplay(value);
      return;
    }
    let frame = 0;
    const start = performance.now();
    const tick = (now: number) => {
      const progress = Math.min(1, (now - start) / 330);
      previous.current = from + (value - from) * (1 - Math.pow(1 - progress, 3));
      setDisplay(Math.round(previous.current));
      if (progress < 1) frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [value]);
  return <strong>{fmt(display)} <span>CR</span></strong>;
}

export default function PlatformShell({ children, balance, onPanel, onShare, onGame, notificationCount, chatOpen, onToggleChat }: {
  children: ReactNode; balance: number; onPanel: (panel: Panel) => void; onShare: () => void; onGame: () => void;
  notificationCount: number; chatOpen: boolean; onToggleChat: () => void;
}) {
  const [query, setQuery] = useState("");
  const [searchOpen, setSearchOpen] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const close = (event: PointerEvent) => { if (!searchRef.current?.contains(event.target as Node)) setSearchOpen(false); };
    document.addEventListener("pointerdown", close);
    return () => document.removeEventListener("pointerdown", close);
  }, []);
  const nav = (icon: IconName, label: string, callback: () => void, active = false) => <button type="button" className={`rail-link ${active ? "active" : ""}`} title={label} aria-label={label} aria-current={active ? "page" : undefined} onClick={callback}><Icon name={icon} size={21} /><span className="rail-tooltip">{label}</span></button>;
  const matches = !query.trim() || "crazytols tols casino wheel".includes(query.toLowerCase().trim());
  return (
    <div className={`platform-shell ${chatOpen ? "chat-open" : ""}`}>
      <aside className="platform-rail" aria-label="Platform navigation">
        <button className="rail-brand" onClick={() => onPanel("lobby")} title="TOLS lobby" aria-label="TOLS lobby"><TolsMark /></button>
        <nav className="rail-navigation">
          {nav("home", "Lobby", () => onPanel("lobby"))}
          {nav("wheel", "Casino", onGame, true)}
          {nav("ticket", "Bonus rounds", () => onPanel("rules"))}
          {nav("share", "Share game", onShare)}
          <button className="rail-link vip-link" onClick={() => onPanel("vip")} title="Local leaderboard" aria-label="Local leaderboard"><span>VIP</span><span className="rail-tooltip">Leaderboard</span></button>
        </nav>
        <div className="rail-bottom">
          {nav("shield", "Fairness information", () => onPanel("fairness"))}
          {nav("heart", "Responsible play", () => onPanel("responsible"))}
        </div>
      </aside>

      <header className="platform-header">
        <button className="header-brand" onClick={() => onPanel("lobby")} aria-label="Open TOLS lobby"><TolsWordmark /></button>
        <div className="platform-search" ref={searchRef}>
          <Icon name="search" size={18} />
          <input id="platform-search" aria-label="Search games" value={query} onChange={(event) => { setQuery(event.target.value); setSearchOpen(true); }} onFocus={() => setSearchOpen(true)} onKeyDown={(event) => {
            if (event.key === "Escape") { event.stopPropagation(); setSearchOpen(false); event.currentTarget.blur(); }
            if (event.key === "Enter" && matches) { setSearchOpen(false); event.currentTarget.blur(); onGame(); }
          }} placeholder="Search games..." autoComplete="off" />
          <kbd><span>&#8984;</span>K</kbd>
          {searchOpen && <div className="search-results">
            <span>Games</span>
            {matches ? <button onClick={() => { setSearchOpen(false); setQuery(""); onGame(); }}><span className="search-game-icon"><Icon name="wheel" size={24} /></span><span><strong>CRAZYTOLS</strong><small>TOLS Original &middot; Casino wheel</small></span><Icon name="chevron" size={15} /></button> : <p>No games found for &quot;{query}&quot;.</p>}
          </div>}
        </div>
        <div className="header-actions">
          <button className="icon-button mobile-search-button" onClick={() => onPanel("search")} aria-label="Search games"><Icon name="search" /></button>
          <button className="balance-button" onClick={() => onPanel("wallet")} title="Demo balance" aria-label={`Wallet balance: ${fmt(balance)} demo credits`}><SolanaCoin /><BalanceValue value={balance} /></button>
          <button className="wallet-button" onClick={() => onPanel("wallet")}><Icon name="plus" size={18} /><span>Wallet</span></button>
          <button className={`icon-button header-chat ${chatOpen ? "is-active" : ""}`} onClick={onToggleChat} title="Live table chat" aria-label="Toggle live table chat" aria-pressed={chatOpen}><Icon name="chat" size={21} /></button>
          <button className="icon-button notification-button" onClick={() => onPanel("notifications")} title="Notifications" aria-label={`Notifications${notificationCount ? `, ${notificationCount} rounds` : ""}`}><Icon name="bell" size={21} />{notificationCount > 0 && <i />}</button>
          <button className="profile-button" onClick={() => onPanel("settings")} title="Player settings" aria-label="Player settings"><svg viewBox="0 0 32 32" aria-hidden="true"><circle cx="16" cy="16" r="16" fill="#f6f4fb" /><path d="m9 7-4 8 17-3 6-5H9Zm1 10-6 8h19l4-10-17 2Z" fill="#8962e8" /></svg></button>
        </div>
      </header>
      {children}
    </div>
  );
}