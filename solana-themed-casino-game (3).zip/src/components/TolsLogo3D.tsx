import { Component, lazy, Suspense, useState, type ReactNode } from "react";
import type { SVG3DProps } from "3dsvg";
import { TOLS_PATH, TolsMark } from "./Brand";

const SVG3D = lazy(() => import("3dsvg").then((module) => ({ default: module.SVG3D })));
const SVG = `<svg xmlns="http://www.w3.org/2000/svg" width="192" height="192" viewBox="0 0 192 192"><path d="${TOLS_PATH}" fill="black" fill-rule="evenodd"/></svg>`;
let webglSupported: boolean | undefined;

function hasWebGL() {
  if (webglSupported !== undefined) return webglSupported;
  try {
    const context = document.createElement("canvas").getContext("webgl2");
    webglSupported = Boolean(context);
    context?.getExtension("WEBGL_lose_context")?.loseContext();
  } catch { webglSupported = false; }
  return webglSupported;
}

function Fallback({ size }: { size: number }) {
  return <div className="logo-fallback" style={{ width: size, height: size }}><TolsMark /></div>;
}

class LogoBoundary extends Component<{ size: number; children: ReactNode }, { failed: boolean }> {
  state = { failed: false };
  static getDerivedStateFromError() { return { failed: true }; }
  render() { return this.state.failed ? <Fallback size={this.props.size} /> : this.props.children; }
}

type Props = Pick<SVG3DProps, "color" | "animate" | "material" | "interactive" | "depth" | "className"> & { size?: number };

export default function TolsLogo3D({ size = 80, className = "", color = "#06b6d4", animate = "pulse", material = "chrome", interactive = true, depth = 1.3 }: Props) {
  const [ready, setReady] = useState(false);
  const [supported] = useState(hasWebGL);
  const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  return <div className={className} style={{ position: "relative", width: size, height: size }} aria-label="Official TOLS logo" role="img">
    {supported ? <LogoBoundary size={size}><Suspense fallback={<Fallback size={size} />}>
      <SVG3D svg={SVG} width={size} height={size} depth={depth} smoothness={0.6} color={color} material={material} metalness={1} roughness={0.26} animate={reduced ? "none" : animate} animateSpeed={0.8} interactive={interactive && !reduced} cursorOrbit={interactive && !reduced} resetOnIdle lightPosition={[3, 4.5, 10]} lightIntensity={4.2} ambientIntensity={1.8} shadow={false} intro="fade" introDuration={0.4} scrollZoom={false} onReady={() => setReady(true)} onLoadingChange={(loading) => { if (!loading) setReady(true); }} />
      {!ready && <div style={{ position: "absolute", inset: 0, pointerEvents: "none" }}><Fallback size={size} /></div>}
    </Suspense></LogoBoundary> : <Fallback size={size} />}
  </div>;
}