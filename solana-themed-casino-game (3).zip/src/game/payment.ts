import { useCallback, useRef, useState, type Dispatch, type SetStateAction } from "react";
import { emitDeposit, emitWithdraw } from "./api";
import { START_BALANCE } from "./constants";

export type PaymentStatus = "idle" | "pending" | "confirmed" | "failed";
export type DepositResult = { ok: true; txHash: string; newBalance: number } | { ok: false; error: string };
export type WithdrawResult = { ok: true; txHash: string } | { ok: false; error: string };
export type PaymentProvider = {
  name: string;
  connect(): Promise<string | null>;
  deposit(amount: number, currency: string, playerAddress: string): Promise<{ txHash: string } | { error: string }>;
  withdraw(amount: number, currency: string, playerAddress: string): Promise<{ txHash: string } | { error: string }>;
  isConnected(): boolean;
  getAddress(): string | null;
};

let demoAddress: string | null = null;
const delay = () => new Promise<void>((resolve) => window.setTimeout(resolve, 550));
const demoProvider: PaymentProvider = {
  name: "demo",
  async connect() { await delay(); demoAddress = "DEMO-LOCAL-WALLET"; return demoAddress; },
  async deposit() { await delay(); return { txHash: `demo-deposit-${Date.now()}` }; },
  async withdraw() { await delay(); return { txHash: `demo-withdraw-${Date.now()}` }; },
  isConnected: () => demoAddress !== null,
  getAddress: () => demoAddress,
};

let provider: PaymentProvider = demoProvider;
export function setPaymentProvider(next: PaymentProvider) { provider = next; }
export function getPaymentProvider() { return provider; }

const balanceListeners = new Set<(balance: number) => void>();
export function onPaymentBalanceChange(callback: (balance: number) => void) {
  balanceListeners.add(callback);
  return () => { balanceListeners.delete(callback); };
}

// The game and wallet use this same ledger; there is no second cached balance.
export function usePayment() {
  const [balance, updateBalance] = useState(START_BALANCE);
  const balanceRef = useRef(START_BALANCE);
  const [address, setAddress] = useState<string | null>(provider.getAddress());
  const [status, setStatus] = useState<PaymentStatus>("idle");
  const [error, setError] = useState<string | null>(null);
  const pending = useRef(false);

  const setBalance: Dispatch<SetStateAction<number>> = useCallback((next) => {
    const value = typeof next === "function" ? next(balanceRef.current) : next;
    if (!Number.isSafeInteger(value) || value < 0) return;
    balanceRef.current = value;
    updateBalance(value);
  }, []);

  const connect = useCallback(async () => {
    try {
      const connected = await provider.connect();
      setAddress(connected);
      return connected;
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Wallet connection failed.");
      return null;
    }
  }, []);

  const transact = useCallback(async (kind: "deposit" | "withdraw", amount: number, currency: string): Promise<DepositResult> => {
    if (pending.current) return { ok: false, error: "A transaction is already pending." };
    if (!Number.isSafeInteger(amount) || amount <= 0) return { ok: false, error: "Enter a positive whole amount." };
    if (kind === "withdraw" && amount > balanceRef.current) return { ok: false, error: "Insufficient available credits." };
    if (kind === "deposit" && !Number.isSafeInteger(balanceRef.current + amount)) return { ok: false, error: "Amount is too large." };
    pending.current = true;
    setStatus("pending");
    setError(null);
    const activeProvider = provider;
    try {
      const connected = activeProvider.getAddress() || await activeProvider.connect();
      if (!connected) throw new Error("Wallet connection cancelled.");
      setAddress(connected);
      const response = await activeProvider[kind](amount, currency, connected);
      if ("error" in response) throw new Error(response.error);
      const next = balanceRef.current + (kind === "deposit" ? amount : -amount);
      if (!Number.isSafeInteger(next) || next < 0) throw new Error("Balance changed. Reconciliation is required.");
      setBalance(next);
      if (kind === "deposit") emitDeposit(amount, currency, response.txHash);
      else emitWithdraw(amount, currency, connected);
      for (const listener of balanceListeners) {
        try { listener(next); } catch { /* External observers cannot change settlement. */ }
      }
      setStatus("confirmed");
      return { ok: true, txHash: response.txHash, newBalance: next };
    } catch (cause) {
      const message = cause instanceof Error ? cause.message : "Transaction failed. Please try again.";
      setError(message);
      setStatus("failed");
      return { ok: false, error: message };
    } finally { pending.current = false; }
  }, [setBalance]);

  const deposit = useCallback((amount: number, currency = "CREDITS") => transact("deposit", amount, currency), [transact]);
  const withdraw = useCallback((amount: number, currency = "CREDITS") => transact("withdraw", amount, currency), [transact]);
  return { balance, setBalance, startBalance: START_BALANCE, connect, address, providerName: provider.name, deposit, withdraw, status, error, connected: address !== null };
}

export const DEPOSIT_PRESETS = [
  { amount: 100, label: "100" }, { amount: 500, label: "500" },
  { amount: 1000, label: "1,000" }, { amount: 5000, label: "5,000" },
] as const;

export type UsePaymentReturn = ReturnType<typeof usePayment>;